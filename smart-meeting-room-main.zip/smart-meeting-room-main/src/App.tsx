import { Routes, Route, Navigate, Outlet, useLocation } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { useAuthStore } from './web/store/auth.store';
import { authApi } from './shared/api/auth';
import { PublicRoomDisplayPage } from './web/pages/public/PublicRoomDisplayPage';
import { MobileRoomListPage } from './web/pages/mobile/MobileRoomListPage';
import { MobileRoomControlPage } from './web/pages/mobile/MobileRoomControlPage';
import { LoginPage } from './web/pages/auth/LoginPage';
import { ChangePasswordPage } from './web/pages/auth/ChangePasswordPage';
import { ResetPasswordPage } from './web/pages/auth/ResetPasswordPage';
import { ForbiddenPage } from './web/pages/ForbiddenPage';
import { DashboardPage } from './web/pages/DashboardPage';
import { UserListPage } from './web/pages/users/UserListPage';
import { DepartmentListPage } from './web/pages/users/DepartmentListPage';
import { RoleListPage } from './web/pages/roles/RoleListPage';
import { ProfilePage } from './web/pages/users/ProfilePage';
import { RoomListPage } from './web/pages/rooms/RoomListPage';
import { RoomQrPage } from './web/pages/rooms/RoomQrPage';
import { BuildingListPage } from './web/pages/rooms/BuildingListPage';
// Live meeting & denah kursi
import { RoomLayoutPage } from './web/pages/rooms/RoomLayoutPage';
import { BookingListPage } from './web/pages/bookings/BookingListPage';
import { NewBookingPage } from './web/pages/bookings/NewBookingPage';
import { MeetingListPage } from './web/pages/bookings/MeetingListPage';
import { MeetingLivePage } from './web/pages/bookings/MeetingLivePage';
import { CalendarPage } from './web/pages/calendar/CalendarPage';
import { EquipmentListPage } from './web/pages/equipment/EquipmentListPage';
import { DeviceListPage } from './web/pages/devices/DeviceListPage';
import { VideowallControlPage } from './web/pages/videowall/VideowallControlPage';
import { AudioControlPage } from './web/pages/audio/AudioControlPage';
import { NotesListPage } from './web/pages/notes/NotesListPage';
import { NoteDetailPage } from './web/pages/notes/NoteDetailPage';
import { SearchPage } from './web/pages/search/SearchPage';
import { FollowupsDashboardPage } from './web/pages/followups/FollowupsDashboardPage';
import { SetupWizardPage } from './web/pages/setup/SetupWizardPage';
import { NotificationsPage } from './web/pages/notifications/NotificationsPage';
import { ReportsPage } from './web/pages/reports/ReportsPage';
import { SettingsPage } from './web/pages/settings/SettingsPage';
import { AuditLogsPage } from './web/pages/audit/AuditLogsPage';
import { MaintenancePage } from './web/pages/maintenance/MaintenancePage';
import { MyTicketsPage } from './web/pages/presensi/MyTicketsPage';
import { PresensiScannerPage } from './web/pages/presensi/PresensiScannerPage';
import { LicenseActivatePage } from './web/pages/license/LicenseActivatePage';
import { AdminLayout } from './web/layouts/AdminLayout';

function LicenseGuard({ children }: { children: React.ReactNode }) {
  const [checking, setChecking] = useState(true);
  const [activated, setActivated] = useState(true);

  useEffect(() => {
    let cancelled = false;
    authApi
      .getLicenseStatus()
      .then((res) => {
        if (!cancelled) setActivated(!res.enforced || res.activated);
      })
      .catch(() => {
        if (!cancelled) setActivated(true);
      })
      .finally(() => {
        if (!cancelled) setChecking(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (checking) {
    return (
      <div className="min-h-screen w-screen bg-gray flex items-center justify-center">
        <svg className="animate-spin h-10 w-10 text-primary" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
        </svg>
      </div>
    );
  }

  if (!activated) {
    return <Navigate to="/license" replace />;
  }

  return <>{children}</>;
}

function ProtectedRoute({ children }: { children?: React.ReactNode }) {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated && !!s.accessToken);
  const mustChangePassword = useAuthStore((s) => !!s.user?.must_change_password);
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }

  // Selama wajib ganti password, semua rute lain diblokir.
  if (mustChangePassword && location.pathname !== '/change-password') {
    return <Navigate to="/change-password" replace />;
  }

  return children ? <>{children}</> : <Outlet />;
}

/**
 * Guard berbasis izin (UX saja — backend tetap memvalidasi setiap request).
 * Lolos bila user memiliki SALAH SATU izin pada `anyOf`; ["*"] = semua izin.
 */
function RequirePermission({ anyOf, children }: { anyOf: string[]; children: React.ReactNode }) {
  const allowed = useAuthStore((s) => s.hasPermission(anyOf));
  if (!allowed) return <ForbiddenPage />;
  return <>{children}</>;
}

const guard = (anyOf: string[], el: React.ReactNode) => <RequirePermission anyOf={anyOf}>{el}</RequirePermission>;

function App() {
  return (
    <Routes>
      <Route path="/license" element={<LicenseActivatePage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage />} />
      <Route
        path="/change-password"
        element={
          <ProtectedRoute>
            <ChangePasswordPage />
          </ProtectedRoute>
        }
      />
      {/* Setup wizard ala WordPress: butuh login, tapi tanpa gate lisensi. */}
      <Route
        path="/setup"
        element={
          <ProtectedRoute>
            <SetupWizardPage />
          </ProtectedRoute>
        }
      />
      <Route
        element={
          <LicenseGuard>
            <ProtectedRoute>
              <AdminLayout />
            </ProtectedRoute>
          </LicenseGuard>
        }
      >
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/users" element={guard(['users.view'], <UserListPage />)} />
        <Route path="/users/departments" element={guard(['users.view'], <DepartmentListPage />)} />
        <Route path="/roles" element={guard(['roles.view', 'roles.write'], <RoleListPage />)} />
        <Route path="/rooms" element={guard(['rooms.view', 'rooms.write'], <RoomListPage />)} />
        <Route path="/rooms/qr/:room_code" element={guard(['rooms.view', 'rooms.write', 'door_display.manage'], <RoomQrPage />)} />
        <Route path="/rooms/buildings" element={guard(['rooms.view', 'rooms.write'], <BuildingListPage />)} />
        <Route path="/rooms/:roomId/layout" element={guard(['rooms.view', 'rooms.write'], <RoomLayoutPage />)} />
        <Route path="/bookings" element={<BookingListPage />} />
        <Route path="/bookings/new" element={<NewBookingPage />} />
        <Route path="/bookings/meeting" element={<MeetingListPage />} />
        <Route path="/bookings/:id/meeting" element={<MeetingLivePage />} />
        <Route path="/calendar" element={<CalendarPage />} />
        <Route path="/equipment" element={guard(['devices.view', 'devices.write'], <EquipmentListPage />)} />
        <Route path="/devices" element={guard(['devices.view', 'devices.write'], <DeviceListPage />)} />
        <Route path="/videowall" element={guard(['videowall.control'], <VideowallControlPage />)} />
        <Route path="/audio" element={guard(['audio.control'], <AudioControlPage />)} />
        <Route path="/notes" element={<NotesListPage />} />
        <Route path="/notes/:id" element={<NoteDetailPage />} />
        <Route path="/search" element={guard(['notes.view', 'notes.write'], <SearchPage />)} />
        <Route path="/followups" element={guard(['notes.view', 'notes.write'], <FollowupsDashboardPage />)} />
        <Route path="/notifications" element={<NotificationsPage />} />
        <Route path="/reports" element={guard(['reports.view'], <ReportsPage />)} />
        <Route path="/settings" element={guard(['settings.view', 'settings.write'], <SettingsPage />)} />
        <Route path="/audit" element={guard(['audit.read'], <AuditLogsPage />)} />
        <Route path="/maintenance" element={guard(['system.maintenance'], <MaintenancePage />)} />
        <Route path="/presensi/tickets" element={<MyTicketsPage />} />
        <Route
          path="/presensi/scanner"
          element={guard(['bookings.approve', 'door_display.manage'], <PresensiScannerPage />)}
        />
      </Route>
      <Route path="/public/display/:room_code" element={<PublicRoomDisplayPage />} />
      <Route
        element={
          <LicenseGuard>
            <ProtectedRoute />
          </LicenseGuard>
        }
      >
        <Route path="/m" element={<MobileRoomListPage />} />
        <Route path="/m/room/:room_code" element={<MobileRoomControlPage />} />
      </Route>
      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />

    </Routes>
  );
}

export default App;
