/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Base URL REST API (default: `/api/v1`, relatif terhadap origin halaman). */
  readonly VITE_API_URL?: string;
  /** Override origin WebSocket, mis. `wss://api.contoh.id` (default: origin halaman). */
  readonly VITE_WS_URL?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
