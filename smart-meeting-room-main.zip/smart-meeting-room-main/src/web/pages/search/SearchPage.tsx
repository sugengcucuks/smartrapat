import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { searchApi, type SearchResponse, type SearchType } from '@shared/api/auth';

const inputCls =
  'w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80';

/** Escape HTML lalu kembalikan <mark> sorotan dari backend (anti-XSS). */
function highlight(snippet: string): string {
  const escaped = snippet
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
  return escaped.replace(/&lt;mark&gt;/g, '<mark>').replace(/&lt;\/mark&gt;/g, '</mark>');
}

const TABS: { key: SearchType; label: string }[] = [
  { key: 'all', label: 'Semua' },
  { key: 'notes', label: 'Notulen' },
  { key: 'transcripts', label: 'Transkrip' },
  { key: 'actions', label: 'Tindak Lanjut' },
];

function countFor(res: SearchResponse | null, key: SearchType): number | null {
  if (!res) return null;
  if (key === 'all') return res.counts.total;
  return res.counts[key];
}

export function SearchPage() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [submitted, setSubmitted] = useState('');
  const [type, setType] = useState<SearchType>('all');
  const [result, setResult] = useState<SearchResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const doSearch = useCallback(async (q: string, t: SearchType) => {
    if (q.trim().length < 2) return;
    setLoading(true);
    setError(null);
    try {
      const res = await searchApi.search({ q: q.trim(), type: t, limit: 20 });
      setResult(res);
    } catch (err) {
      setResult(null);
      setError(err instanceof Error ? err.message : 'Pencarian gagal');
    } finally {
      setLoading(false);
    }
  }, []);

  // Cari otomatis dengan debounce saat mengetik / ganti kategori.
  useEffect(() => {
    const q = query.trim();
    if (q.length < 2) {
      setResult(null);
      setSubmitted('');
      return;
    }
    const t = window.setTimeout(() => {
      setSubmitted(q);
      doSearch(q, type);
    }, 350);
    return () => window.clearTimeout(t);
  }, [query, type, doSearch]);

  const showCounts = submitted.length >= 2;

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-3 mb-1">
        <i className="ri-search-line text-2xl text-primary" />
        <h1 className="text-xl font-semibold dark:text-white">Pencarian Arsip Rapat</h1>
      </div>
      <p className="text-sm text-gray-500 dark:text-gray-400 mb-5">
        Cari satu kata kunci ke seluruh notulen, transkrip, dan tindak lanjut rapat.
      </p>

      {/* Kotak pencarian */}
      <div className="relative mb-4">
        <i className="ri-search-line absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          autoFocus
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Ketik kata kunci, mis. anggaran, renovasi, siapa pun namanya…"
          className={`${inputCls} !py-3 !pl-10 !text-base`}
        />
        {loading && (
          <svg
            className="animate-spin h-5 w-5 text-primary absolute right-3 top-1/2 -translate-y-1/2"
            viewBox="0 0 24 24"
          >
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
          </svg>
        )}
      </div>

      {/* Tab kategori */}
      <div className="flex flex-wrap gap-2 mb-6">
        {TABS.map((tab) => {
          const active = type === tab.key;
          const count = showCounts ? countFor(result, tab.key) : null;
          return (
            <button
              key={tab.key}
              onClick={() => setType(tab.key)}
              className={`px-3.5 py-1.5 rounded-full text-sm transition-colors ${
                active
                  ? 'bg-primary text-white'
                  : 'bg-black/5 dark:bg-black/40 text-gray-600 dark:text-gray-300 hover:bg-black/10'
              }`}
            >
              {tab.label}
              {count !== null && (
                <span
                  className={`ml-1.5 px-1.5 py-0.5 rounded-full text-xs ${
                    active ? 'bg-white/20' : 'bg-black/10 dark:bg-white/10'
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {error && (
        <div className="p-3 mb-4 text-sm text-red-600 bg-red-50 dark:bg-red-500/10 rounded-lg">{error}</div>
      )}

      {!result && !loading && (
        <div className="text-center py-16 text-gray-400 dark:text-gray-500">
          <i className="ri-file-search-line text-5xl block mb-3 opacity-50" />
          <p className="text-sm">Mulai ketik untuk mencari di seluruh arsip rapat.</p>
        </div>
      )}

      {result && result.counts.total === 0 && (
        <div className="text-center py-16 text-gray-400 dark:text-gray-500">
          <i className="ri-emotion-normal-line text-5xl block mb-3 opacity-50" />
          <p className="text-sm">
            Tidak ada hasil untuk &quot;{result.query}&quot;. Coba kata kunci lain.
          </p>
        </div>
      )}

      {result && result.counts.notes > 0 && (type === 'all' || type === 'notes') && (
        <section className="mb-8">
          <h2 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-3">
            Notulen ({result.counts.notes})
          </h2>
          <div className="space-y-3">
            {result.results.notes.map((n) => (
              <button
                key={n.id}
                onClick={() => navigate(`/notes/${n.note_id}`)}
                className="w-full text-left p-4 bg-white dark:bg-gray-800 rounded-xl border border-black/5 dark:border-white/10 hover:border-primary transition-colors"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-medium dark:text-white truncate">{n.title}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                      {n.date}
                      {n.start_time ? ` · ${n.start_time}` : ''}
                      {n.booking_title ? ` · ${n.booking_title}` : ''}
                    </p>
                  </div>
                  <i className="ri-arrow-right-s-line text-gray-300 shrink-0" />
                </div>
                <p
                  className="text-sm text-gray-600 dark:text-gray-300 mt-2 line-clamp-2 [&_mark]:bg-yellow-200 [&_mark]:dark:bg-yellow-500/40 [&_mark]:rounded-sm [&_mark]:px-0.5"
                  dangerouslySetInnerHTML={{ __html: highlight(n.snippet) }}
                />
              </button>
            ))}
          </div>
        </section>
      )}

      {result && result.counts.transcripts > 0 && (type === 'all' || type === 'transcripts') && (
        <section className="mb-8">
          <h2 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-3">
            Transkrip ({result.counts.transcripts})
          </h2>
          <div className="space-y-3">
            {result.results.transcripts.map((t) => (
              <button
                key={t.id}
                onClick={() => navigate(`/notes/${t.note_id}`)}
                className="w-full text-left p-4 bg-white dark:bg-gray-800 rounded-xl border border-black/5 dark:border-white/10 hover:border-primary transition-colors"
              >
                <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400 mb-1.5">
                  <i className="ri-mic-line" />
                  <span className="font-medium text-gray-700 dark:text-gray-200">
                    {t.speaker_name || 'Tidak diketahui'}
                  </span>
                  <span>·</span>
                  <span className="truncate">{t.note_title || t.booking_title || '-'}</span>
                  {t.date && (
                    <>
                      <span>·</span>
                      <span>{t.date}</span>
                    </>
                  )}
                </div>
                <p
                  className="text-sm text-gray-600 dark:text-gray-300 line-clamp-3 [&_mark]:bg-yellow-200 [&_mark]:dark:bg-yellow-500/40 [&_mark]:rounded-sm [&_mark]:px-0.5"
                  dangerouslySetInnerHTML={{ __html: highlight(t.snippet) }}
                />
              </button>
            ))}
          </div>
        </section>
      )}

      {result && result.counts.actions > 0 && (type === 'all' || type === 'actions') && (
        <section className="mb-8">
          <h2 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-3">
            Tindak Lanjut ({result.counts.actions})
          </h2>
          <div className="space-y-3">
            {result.results.actions.map((a) => (
              <button
                key={a.id}
                onClick={() => navigate(`/notes/${a.note_id}`)}
                className="w-full text-left p-4 bg-white dark:bg-gray-800 rounded-xl border border-black/5 dark:border-white/10 hover:border-primary transition-colors"
              >
                <div className="flex items-start gap-3">
                  <i className="ri-task-line text-primary mt-0.5" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm dark:text-white">{a.task}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      {a.note_title || '-'}
                      {a.date ? ` · ${a.date}` : ''}
                      {a.owner ? ` · PIC: ${a.owner}` : ''}
                      {a.due_date ? ` · Tenggat: ${a.due_date}` : ''}
                    </p>
                  </div>
                  <span
                    className={`shrink-0 px-2 py-0.5 rounded-full text-xs font-medium ${
                      a.status === 'done'
                        ? 'bg-green-100 text-green-700 dark:bg-green-500/20 dark:text-green-300'
                        : a.status === 'in_progress'
                          ? 'bg-blue-100 text-blue-700 dark:bg-blue-500/20 dark:text-blue-300'
                          : a.status === 'cancelled'
                            ? 'bg-gray-100 text-gray-500 dark:bg-white/10 dark:text-gray-400'
                            : 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300'
                    }`}
                  >
                    {a.status === 'open'
                      ? 'Terbuka'
                      : a.status === 'in_progress'
                        ? 'Berjalan'
                        : a.status === 'done'
                          ? 'Selesai'
                          : a.status === 'cancelled'
                            ? 'Dibatalkan'
                            : a.status}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
