import { useEffect, useState } from 'react';
import { useAuthStore } from '../../store/auth.store';
import { authApi } from '@shared/api/auth';
import { getErrorMessage } from '@shared/api/client';
import { PASSWORD_MIN_LENGTH } from '@shared/utils/password';

export function ProfilePage() {
  const { user, updateUser, setTokens } = useAuthStore();

  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    username: user?.username || '',
    phone: user?.phone || '',
  });
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileMsg, setProfileMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const [changePass, setChangePass] = useState({ old: '', newP: '', confirm: '' });
  const [passLoading, setPassLoading] = useState(false);
  const [passMsg, setPassMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Muat profil terbaru dari server (GET /users/me).
  useEffect(() => {
    let cancelled = false;
    authApi
      .getMe()
      .then((me) => {
        if (cancelled || !me) return;
        setProfileData({ name: me.name ?? '', email: me.email ?? '', username: me.username ?? '', phone: me.phone ?? '' });
        updateUser({ name: me.name, email: me.email, phone: me.phone ?? null, avatar_url: me.avatar_url ?? undefined, created_at: me.created_at });
      })
      .catch(() => {
        /* tetap pakai data sesi */
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.id) {
      setProfileMsg({ type: 'error', text: 'User tidak terautentikasi.' });
      return;
    }
    setProfileLoading(true);
    setProfileMsg(null);
    try {
      const updated = await authApi.updateMe({
        name: profileData.name,
        email: profileData.email,
        phone: profileData.phone,
      });
      // Data server menimpa data lama (bukan sebaliknya).
      updateUser({
        name: updated?.name ?? profileData.name,
        email: updated?.email ?? profileData.email,
        phone: updated?.phone ?? null,
        avatar_url: updated?.avatar_url ?? user.avatar_url,
      });
      setProfileMsg({ type: 'success', text: 'Profil berhasil diperbarui!' });
    } catch (err: unknown) {
      setProfileMsg({ type: 'error', text: `Gagal memperbarui profil: ${getErrorMessage(err, 'Coba beberapa saat lagi.')}` });
    } finally {
      setProfileLoading(false);
    }
  };

  const handleSavePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassMsg(null);
    if (changePass.newP !== changePass.confirm) {
      setPassMsg({ type: 'error', text: 'Password baru dan konfirmasi tidak sama.' });
      return;
    }
    if (changePass.newP.length < PASSWORD_MIN_LENGTH) {
      setPassMsg({ type: 'error', text: `Password baru minimal ${PASSWORD_MIN_LENGTH} karakter.` });
      return;
    }
    setPassLoading(true);
    try {
      const tokens = await authApi.changePassword(changePass.old, changePass.newP);
      // Token lama dicabut server; simpan token baru.
      if (tokens?.access_token) setTokens(tokens.access_token, tokens.refresh_token);
      setPassMsg({ type: 'success', text: 'Password berhasil diubah!' });
      setChangePass({ old: '', newP: '', confirm: '' });
    } catch (err: unknown) {
      setPassMsg({ type: 'error', text: `Gagal mengubah password: ${getErrorMessage(err, 'Password lama salah atau terjadi kesalahan.')}` });
    } finally {
      setPassLoading(false);
    }
  };

  const initial = profileData.name?.charAt(0) || profileData.username?.charAt(0) || 'U';

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-black dark:text-white">Profil Saya</h1>
        <p className="text-sm text-black/60 dark:text-white/60 mt-1">Kelola informasi akun dan keamanan Anda.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <div className="bg-white dark:bg-gray rounded-xl shadow-sm border border-black/10 dark:border-white/10 overflow-hidden">
            <div className="bg-gradient-to-br from-primary to-indigo-500 h-28"></div>
            <div className="px-6 pb-6 -mt-12">
              <div className="w-24 h-24 rounded-full bg-white dark:bg-gray border-4 border-white dark:border-gray shadow-sm flex items-center justify-center overflow-hidden">
                {user?.avatar_url ? (
                  <img src={user.avatar_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-4xl font-bold text-primary">{initial}</span>
                )}
              </div>
              <h3 className="mt-4 text-lg font-bold text-black dark:text-white">{profileData.name || 'Nama Pengguna'}</h3>
              <p className="text-sm text-black/60 dark:text-white/60">@{profileData.username || 'username'}</p>
              <div className="mt-3 inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-semibold">
                {user?.role || 'Pengguna'}
              </div>
              <div className="mt-6 space-y-2.5 text-sm">
                <div className="flex items-center gap-2 text-black/70 dark:text-white/70">
                  <i className="ri-mail-line text-base text-black/40 dark:text-white/40"></i>
                  <span className="truncate">{profileData.email || 'Email belum diisi'}</span>
                </div>
                <div className="flex items-center gap-2 text-black/70 dark:text-white/70">
                  <i className="ri-phone-line text-base text-black/40 dark:text-white/40"></i>
                  <span>{profileData.phone || 'Nomor telepon belum diisi'}</span>
                </div>
                <div className="flex items-center gap-2 text-black/70 dark:text-white/70">
                  <i className="ri-calendar-line text-base text-black/40 dark:text-white/40"></i>
                  <span>Bergabung: {user?.created_at ? new Date(user.created_at).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' }) : '-'}</span>
                </div>
              </div>
              {/* Tombol ganti foto disembunyikan: backend belum punya endpoint upload avatar. */}

            </div>
          </div>
        </div>

        <div className="md:col-span-2 space-y-6">
          <div className="bg-white dark:bg-gray rounded-xl shadow-sm border border-black/10 dark:border-white/10 p-6">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-lg font-bold text-black dark:text-white">Informasi Pribadi</h3>
                <p className="text-sm text-black/60 dark:text-white/60 mt-0.5">Perbarui data diri Anda.</p>
              </div>
              <i className="ri-user-settings-line text-2xl text-primary/60"></i>
            </div>

            {profileMsg && (
              <div
                className={`mb-5 px-4 py-3 rounded-lg text-sm flex items-center gap-2 ${
                  profileMsg.type === 'success'
                    ? 'bg-success/10 text-success border border-success/20'
                    : 'bg-danger/10 text-danger border border-danger/20'
                }`}
              >
                <i className={profileMsg.type === 'success' ? 'ri-checkbox-circle-line' : 'ri-error-warning-line'}></i>
                <span>{profileMsg.text}</span>
              </div>
            )}

            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">Nama Lengkap *</label>
                  <input
                    type="text"
                    value={profileData.name}
                    onChange={(e) => setProfileData((p) => ({ ...p, name: e.target.value }))}
                    className="w-full h-10 px-3 rounded-lg bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 text-sm text-black dark:text-white outline-none focus:border-primary transition-colors"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">Username</label>
                  <input
                    type="text"
                    value={profileData.username}
                    disabled
                    className="w-full h-10 px-3 rounded-lg bg-black/[0.02] dark:bg-black/20 border border-black/10 dark:border-white/10 text-sm text-black/50 dark:text-white/50 cursor-not-allowed"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">Email *</label>
                  <input
                    type="email"
                    value={profileData.email}
                    onChange={(e) => setProfileData((p) => ({ ...p, email: e.target.value }))}
                    className="w-full h-10 px-3 rounded-lg bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 text-sm text-black dark:text-white outline-none focus:border-primary transition-colors"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">Nomor Telepon</label>
                  <input
                    type="tel"
                    value={profileData.phone}
                    onChange={(e) => setProfileData((p) => ({ ...p, phone: e.target.value }))}
                    placeholder="+62..."
                    className="w-full h-10 px-3 rounded-lg bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 text-sm text-black dark:text-white outline-none focus:border-primary transition-colors"
                  />
                </div>
              </div>
              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={profileLoading}
                  className="px-5 h-10 text-sm font-semibold text-white bg-primary hover:bg-primary/90 rounded-lg shadow-sm shadow-primary/30 transition-colors disabled:opacity-60 flex items-center gap-2"
                >
                  {profileLoading && (
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                  )}
                  <span>Simpan Perubahan</span>
                </button>
              </div>
            </form>
          </div>

          <div className="bg-white dark:bg-gray rounded-xl shadow-sm border border-black/10 dark:border-white/10 p-6">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-lg font-bold text-black dark:text-white">Ganti Password</h3>
                <p className="text-sm text-black/60 dark:text-white/60 mt-0.5">Ubah password akun secara berkala.</p>
              </div>
              <i className="ri-lock-password-line text-2xl text-primary/60"></i>
            </div>

            {passMsg && (
              <div
                className={`mb-5 px-4 py-3 rounded-lg text-sm flex items-center gap-2 ${
                  passMsg.type === 'success'
                    ? 'bg-success/10 text-success border border-success/20'
                    : 'bg-danger/10 text-danger border border-danger/20'
                }`}
              >
                <i className={passMsg.type === 'success' ? 'ri-checkbox-circle-line' : 'ri-error-warning-line'}></i>
                <span>{passMsg.text}</span>
              </div>
            )}

            <form onSubmit={handleSavePassword} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">Password Lama *</label>
                <input
                  type="password"
                  value={changePass.old}
                  onChange={(e) => setChangePass((p) => ({ ...p, old: e.target.value }))}
                  className="w-full h-10 px-3 rounded-lg bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 text-sm text-black dark:text-white outline-none focus:border-primary transition-colors"
                  required
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">Password Baru *</label>
                  <input
                    type="password"
                    value={changePass.newP}
                    onChange={(e) => setChangePass((p) => ({ ...p, newP: e.target.value }))}
                    placeholder="Min. 8 karakter"
                    minLength={8}
                    className="w-full h-10 px-3 rounded-lg bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 text-sm text-black dark:text-white outline-none focus:border-primary transition-colors"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">Konfirmasi Password Baru *</label>
                  <input
                    type="password"
                    value={changePass.confirm}
                    onChange={(e) => setChangePass((p) => ({ ...p, confirm: e.target.value }))}
                    placeholder="Ulangi password baru"
                    minLength={8}
                    className="w-full h-10 px-3 rounded-lg bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 text-sm text-black dark:text-white outline-none focus:border-primary transition-colors"
                    required
                  />
                </div>
              </div>
              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={passLoading}
                  className="px-5 h-10 text-sm font-semibold text-white bg-primary hover:bg-primary/90 rounded-lg shadow-sm shadow-primary/30 transition-colors disabled:opacity-60 flex items-center gap-2"
                >
                  {passLoading && (
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                  )}
                  <span>Ubah Password</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
