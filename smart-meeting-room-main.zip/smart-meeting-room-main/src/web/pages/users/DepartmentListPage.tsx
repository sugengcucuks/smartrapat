import { useEffect, useState } from 'react';
import { authApi } from '../../../shared/api/auth';
import { getErrorMessage } from '../../../shared/api/client';
import { usePermission } from '../../store/auth.store';
import type { Department, DepartmentCreate, DepartmentUpdate, UserResponse } from '@shared/types';

interface DepartmentFormState {
  name: string;
  code: string;
  head_id: string;
}

const INITIAL_FORM: DepartmentFormState = {
  name: '',
  code: '',
  head_id: '',
};

export function DepartmentListPage() {
  const can = usePermission();
  const canCreate = can('users.create');
  const canEdit = can('users.edit');
  const canDelete = can('users.delete');
  const [departments, setDepartments] = useState<Department[]>([]);
  const [users, setUsers] = useState<UserResponse[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [showModal, setShowModal] = useState(false);
  const [editingDept, setEditingDept] = useState<Department | null>(null);
  const [form, setForm] = useState<DepartmentFormState>(INITIAL_FORM);
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [deleteConfirm, setDeleteConfirm] = useState<Department | null>(null);

  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const fetchDepartments = async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const result = await authApi.listDepartments();
      setDepartments(result ?? []);
    } catch (err) {
      setDepartments([]);
      setLoadError(getErrorMessage(err, 'Gagal memuat daftar departemen'));
    } finally {
      setLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      const result = await authApi.listUsers({ per_page: 100 });
      setUsers(result.items ?? []);
    } catch {
      // Hanya untuk pilihan kepala departemen.
      setUsers([]);
    }
  };

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 3000);
  };

  useEffect(() => {
    fetchDepartments();
    fetchUsers();
  }, []);

  const openCreateModal = () => {
    setEditingDept(null);
    setForm(INITIAL_FORM);
    setFormError(null);
    setShowModal(true);
  };

  const openEditModal = (dept: Department) => {
    setEditingDept(dept);
    setForm({
      name: dept.name,
      code: dept.code,
      head_id: dept.head_id || '',
    });
    setFormError(null);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingDept(null);
    setForm(INITIAL_FORM);
    setFormError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSubmitting(true);

    try {
      if (editingDept) {
        const data: DepartmentUpdate = {
          name: form.name,
          code: form.code,
          head_id: form.head_id || null,
        };
        await authApi.updateDepartment(editingDept.id, data);
        showToast('success', 'Departemen berhasil diperbarui');
      } else {
        const data: DepartmentCreate = {
          name: form.name,
          code: form.code,
          head_id: form.head_id || null,
        };
        await authApi.createDepartment(data);
        showToast('success', 'Departemen berhasil ditambahkan');
      }
      closeModal();
      fetchDepartments();
    } catch (err: unknown) {
      setFormError(getErrorMessage(err, 'Gagal menyimpan departemen'));
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (dept: Department) => {
    try {
      await authApi.deleteDepartment(dept.id);
      showToast('success', 'Departemen berhasil dihapus');
      setDeleteConfirm(null);
      fetchDepartments();
    } catch (err: unknown) {
      showToast('error', getErrorMessage(err, 'Gagal menghapus departemen'));
      setDeleteConfirm(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Daftar Departemen</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Kelola departemen dalam sistem Smart Meeting Room
          </p>
        </div>
        {canCreate && (
          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors shadow-sm"
          >
            <i className="ri-add-line text-lg"></i>
            <span>Tambah Departemen</span>
          </button>
        )}
      </div>

      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
        <div className="overflow-x-auto -mx-6">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-y border-black/10 dark:border-white/10">
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Kode
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Nama Departemen
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Kepala Departemen
                </th>
                <th className="text-right py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Aksi
                </th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={4} className="py-12 text-center text-black/50 dark:text-white/50">
                    <div className="inline-flex items-center gap-2">
                      <svg className="animate-spin h-5 w-5 text-primary" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      <span>Memuat data...</span>
                    </div>
                  </td>
                </tr>
              ) : loadError ? (
                <tr>
                  <td colSpan={4} className="py-12 text-center">
                    <p className="text-sm text-red-600 dark:text-red-400">{loadError}</p>
                    <button
                      type="button"
                      onClick={fetchDepartments}
                      className="mt-3 inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-primary bg-primary/10 hover:bg-primary/15 rounded-lg"
                    >
                      <i className="ri-refresh-line"></i> Coba Lagi
                    </button>
                  </td>
                </tr>
              ) : departments.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-12 text-center text-black/50 dark:text-white/50">
                    <div className="flex flex-col items-center gap-2">
                      <i className="ri-building-2-line text-4xl text-black/30 dark:text-white/30"></i>
                      <span>Belum ada data</span>
                    </div>
                  </td>
                </tr>
              ) : (
                departments.map((dept) => (
                  <tr
                    key={dept.id}
                    className="border-b border-black/5 dark:border-white/5 hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors"
                  >
                    <td className="py-3 px-6 whitespace-nowrap">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-semibold bg-primary/10 text-primary">
                        {dept.code}
                      </span>
                    </td>
                    <td className="py-3 px-6 text-black/80 dark:text-white/80 font-medium whitespace-nowrap">
                      {dept.name}
                    </td>
                    <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap">
                      {dept.head_name || '-'}
                    </td>
                    <td className="py-3 px-6">
                      <div className="flex items-center justify-end gap-1">
                        {canEdit && (
                        <button
                          type="button"
                          onClick={() => openEditModal(dept)}
                          title="Ubah"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-primary hover:bg-primary/10 rounded-lg transition-colors"
                        >
                          <i className="ri-edit-line"></i>
                        </button>
                        )}
                        {canDelete && (
                        <button
                          type="button"
                          onClick={() => setDeleteConfirm(dept)}
                          title="Hapus"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-danger hover:bg-danger/10 rounded-lg transition-colors"
                        >
                          <i className="ri-delete-bin-line"></i>
                        </button>
                        )}
                      </div>

                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={closeModal}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-lg overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">
                {editingDept ? 'Ubah Departemen' : 'Tambah Departemen'}
              </h2>
              <button
                type="button"
                onClick={closeModal}
                className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="px-6 py-5 space-y-4">
                {formError && (
                  <div className="p-3 rounded-lg bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 text-sm">
                    <div className="flex items-start gap-2">
                      <i className="ri-error-warning-line mt-0.5"></i>
                      <span>{formError}</span>
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                    Kode Departemen <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={20}
                    value={form.code}
                    onChange={(e) => setForm({ ...form, code: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 uppercase"
                    placeholder="Contoh: IT, HRD, FIN"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                    Nama Departemen <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={100}
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    placeholder="Contoh: Information Technology"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                    Kepala Departemen
                  </label>
                  <select
                    value={form.head_id}
                    onChange={(e) => setForm({ ...form, head_id: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                  >
                    <option value="">Pilih Kepala Departemen</option>
                    {users.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name} ({u.username})
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={closeModal}
                  disabled={submitting}
                  className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors disabled:opacity-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submitting && (
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                  )}
                  <span>Simpan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setDeleteConfirm(null)}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-md overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-5">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-500/10 flex items-center justify-center shrink-0">
                  <i className="ri-delete-bin-line text-2xl text-red-600 dark:text-red-400"></i>
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-black dark:text-white">Hapus Departemen</h3>
                  <p className="text-sm text-black/60 dark:text-white/60 mt-1">
                    Apakah Anda yakin ingin menghapus departemen <span className="font-semibold">{deleteConfirm.name}</span>? Departemen yang masih memiliki pengguna tidak dapat dihapus.
                  </p>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 bg-black/[0.02] dark:bg-white/[0.02] flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => handleDelete(deleteConfirm)}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors shadow-sm"
              >
                Hapus
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className={`fixed top-4 right-4 z-[60] max-w-sm rounded-lg shadow-lg p-4 flex items-start gap-3 ${
          toast.type === 'success'
            ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20'
            : 'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20'
        }`}>
          <div className="flex-shrink-0">
            {toast.type === 'success' ? (
              <i className={`ri-check-line text-lg ${toast.type === 'success' ? 'text-green-600 dark:text-green-400' : ''}`}></i>
            ) : (
              <i className={`ri-error-warning-line text-lg ${toast.type === 'error' ? 'text-red-600 dark:text-red-400' : ''}`}></i>
            )}
          </div>
          <p className={`flex-1 text-sm font-medium ${toast.type === 'success' ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>
            {toast.message}
          </p>
          <button
            type="button"
            onClick={() => setToast(null)}
            className={`flex-shrink-0 transition-colors ${toast.type === 'success' ? 'text-green-400 hover:text-green-600' : 'text-red-400 hover:text-red-600'}`}
          >
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}
    </div>
  );
}
