import { useEffect, useState, useMemo } from 'react';
import { authApi } from '../../../shared/api/auth';
import { getErrorMessage } from '../../../shared/api/client';
import { PASSWORD_MIN_LENGTH } from '../../../shared/utils/password';
import { usePermission } from '../../store/auth.store';
import type { UserResponse, UserCreate, UserUpdate, Department, Role } from '@shared/types';

interface UserFormState {
  username: string;
  name: string;
  email: string;
  password: string;
  nik: string;
  rank: string;
  position: string;
  role_id: string;
  department_id: string;
  phone: string;
}

const INITIAL_FORM: UserFormState = {
  username: '',
  name: '',
  email: '',
  password: '',
  nik: '',
  rank: '',
  position: '',
  role_id: '',
  department_id: '',
  phone: '',
};

export function UserListPage() {
  const can = usePermission();
  const canCreate = can('users.create');
  const canEdit = can('users.edit');
  const canDelete = can('users.delete');
  const [users, setUsers] = useState<UserResponse[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [filterRole, setFilterRole] = useState('');
  const [filterDept, setFilterDept] = useState('');
  const [page, setPage] = useState(1);
  const [perPage] = useState(10);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState<UserResponse | null>(null);
  const [form, setForm] = useState<UserFormState>(INITIAL_FORM);
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [deleteConfirm, setDeleteConfirm] = useState<UserResponse | null>(null);
  const [resetPwdModal, setResetPwdModal] = useState<UserResponse | null>(null);
  const [newPassword, setNewPassword] = useState('');

  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const fetchUsers = async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const result = await authApi.listUsers({
        page,
        per_page: perPage,
        search: search.trim() || undefined,
        role_id: filterRole || undefined,
        department_id: filterDept || undefined,
      });
      setUsers(result.items ?? []);
      setTotal(result.total ?? 0);
      setTotalPages(result.total_pages ?? 0);
    } catch (err) {
      setUsers([]);
      setTotal(0);
      setTotalPages(0);
      setLoadError(getErrorMessage(err, 'Gagal memuat daftar pengguna'));
    } finally {
      setLoading(false);
    }
  };

  const fetchDepartments = async () => {
    try {
      const result = await authApi.listDepartments();
      setDepartments(result ?? []);
    } catch {
      setDepartments([]);
    }
  };

  const fetchRoles = async () => {
    try {
      const result = await authApi.listRoles({ per_page: 100 });
      setRoles(result.items ?? []);
    } catch {
      // Tanpa roles.view daftar peran tidak bisa dimuat; pilihan peran dikosongkan.
      setRoles([]);
    }
  };

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 3000);
  };

  useEffect(() => {
    fetchDepartments();
    fetchRoles();
  }, []);

  useEffect(() => {
    fetchUsers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, filterRole, filterDept]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(1);
      fetchUsers();
    }, 400);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  const defaultRoleId = () => {
    const userRole = roles.find((r) => ['user', 'staff'].includes(r.name.toLowerCase()));
    return userRole?.id ?? '';
  };

  const openCreateModal = () => {
    setEditingUser(null);
    setForm({ ...INITIAL_FORM, role_id: defaultRoleId() });
    setFormError(null);
    setShowModal(true);
  };

  const openEditModal = (user: UserResponse) => {
    setEditingUser(user);
    setForm({
      username: user.username,
      name: user.name,
      email: user.email,
      password: '',
      nik: user.nik || '',
      rank: user.rank || '',
      position: user.position || '',
      role_id: user.role_id || '',
      department_id: user.department_id || '',
      phone: user.phone || '',
    });
    setFormError(null);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingUser(null);
    setForm(INITIAL_FORM);
    setFormError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSubmitting(true);

    try {
      if (editingUser) {
        const data: UserUpdate = {
          username: form.username,
          name: form.name,
          email: form.email,
          nik: form.nik || null,
          rank: form.rank || null,
          position: form.position || null,
          department_id: form.department_id || null,
          phone: form.phone || null,
        };
        // Jangan kirim role_id kosong (akan menghapus peran).
        if (form.role_id) data.role_id = form.role_id;
        await authApi.updateUser(editingUser.id, data);
        showToast('success', 'Pengguna berhasil diperbarui');
      } else {
        if (!form.password || form.password.length < PASSWORD_MIN_LENGTH) {
          setFormError(`Kata sandi wajib diisi, minimal ${PASSWORD_MIN_LENGTH} karakter`);
          setSubmitting(false);
          return;
        }
        if (!form.role_id) {
          setFormError('Pilih peran pengguna');
          setSubmitting(false);
          return;
        }
        const data: UserCreate = {
          username: form.username,
          name: form.name,
          email: form.email,
          password: form.password,
          nik: form.nik || null,
          rank: form.rank || null,
          position: form.position || null,
          role_id: form.role_id,
          department_id: form.department_id || null,
          phone: form.phone || null,
        };
        await authApi.createUser(data);
        showToast('success', 'Pengguna berhasil ditambahkan');
      }
      closeModal();
      fetchUsers();
    } catch (err: unknown) {
      setFormError(getErrorMessage(err, 'Gagal menyimpan pengguna'));
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleStatus = async (user: UserResponse) => {
    try {
      const newStatus = user.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
      await authApi.updateUser(user.id, { status: newStatus });
      showToast('success', `Status pengguna diubah menjadi ${newStatus === 'ACTIVE' ? 'Aktif' : 'Nonaktif'}`);
      fetchUsers();
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal mengubah status pengguna'));
    }
  };

  const handleDelete = async (user: UserResponse) => {
    try {
      await authApi.deleteUser(user.id);
      showToast('success', 'Pengguna berhasil dihapus');
      setDeleteConfirm(null);
      fetchUsers();
    } catch (err: unknown) {
      showToast('error', getErrorMessage(err, 'Gagal menghapus pengguna'));
      setDeleteConfirm(null);
    }
  };

  const handleResetPassword = async () => {
    if (!resetPwdModal || !newPassword) return;
    if (newPassword.length < PASSWORD_MIN_LENGTH) {
      showToast('error', `Kata sandi minimal ${PASSWORD_MIN_LENGTH} karakter`);
      return;
    }
    try {
      await authApi.resetPassword(resetPwdModal.id, newPassword);
      showToast('success', 'Kata sandi berhasil direset');
      setResetPwdModal(null);
      setNewPassword('');
    } catch (err: unknown) {
      showToast('error', getErrorMessage(err, 'Gagal mereset kata sandi'));
    }
  };

  const roleLabel = (user: UserResponse) =>
    user.role_name || roles.find((r) => r.id === user.role_id)?.name || '-';

  const pageNumbers = useMemo(() => {
    const pages: (number | string)[] = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      if (page <= 4) {
        pages.push(1, 2, 3, 4, 5, '...', totalPages);
      } else if (page >= totalPages - 3) {
        pages.push(1, '...', totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages);
      } else {
        pages.push(1, '...', page - 1, page, page + 1, '...', totalPages);
      }
    }
    return pages;
  }, [page, totalPages]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Daftar Pengguna</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Kelola akun pengguna sistem Smart Meeting Room
          </p>
        </div>
        {canCreate && (
          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors shadow-sm"
          >
            <i className="ri-add-line text-lg"></i>
            <span>Tambah Pengguna</span>
          </button>
        )}
      </div>

      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1 max-w-sm">
            <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40"></i>
            <input
              type="text"
              placeholder="Cari nama, username, email..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 placeholder:text-black/40 dark:placeholder:text-white/40"
            />
          </div>
          <select
            value={filterRole}
            onChange={(e) => {
              setFilterRole(e.target.value);
              setPage(1);
            }}
            className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
          >
            <option value="">Semua Peran</option>
            {roles.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
          </select>
          <select
            value={filterDept}
            onChange={(e) => {
              setFilterDept(e.target.value);
              setPage(1);
            }}
            className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
          >
            <option value="">Semua Departemen</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>
        </div>

        <div className="overflow-x-auto -mx-6">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-y border-black/10 dark:border-white/10">
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Username
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Nama
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Email
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Peran
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Departemen
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Status
                </th>
                <th className="text-right py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Aksi
                </th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-black/50 dark:text-white/50">
                    <div className="inline-flex items-center gap-2">
                      <svg className="animate-spin h-5 w-5 text-primary" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      <span>Memuat data...</span>
                    </div>
                  </td>
                </tr>
              ) : loadError ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center">
                    <p className="text-sm text-red-600 dark:text-red-400">{loadError}</p>
                    <button
                      type="button"
                      onClick={fetchUsers}
                      className="mt-3 inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-primary bg-primary/10 hover:bg-primary/15 rounded-lg"
                    >
                      <i className="ri-refresh-line"></i> Coba Lagi
                    </button>
                  </td>
                </tr>
              ) : users.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-black/50 dark:text-white/50">
                    <div className="flex flex-col items-center gap-2">
                      <i className="ri-user-search-line text-4xl text-black/30 dark:text-white/30"></i>
                      <span>Belum ada data</span>
                    </div>
                  </td>
                </tr>
              ) : (
                users.map((user) => (
                  <tr
                    key={user.id}
                    className="border-b border-black/5 dark:border-white/5 hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors"
                  >
                    <td className="py-3 px-6 text-black/80 dark:text-white/80 font-medium whitespace-nowrap">
                      {user.username}
                    </td>
                    <td className="py-3 px-6 text-black/80 dark:text-white/80 whitespace-nowrap">
                      {user.name}
                    </td>
                    <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap">
                      {user.email}
                    </td>
                    <td className="py-3 px-6 whitespace-nowrap">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary">
                        {roleLabel(user)}
                      </span>
                    </td>
                    <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap">
                      {user.department_name || '-'}
                    </td>
                    <td className="py-3 px-6 whitespace-nowrap">
                      <label className="inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          className="sr-only peer"
                          checked={user.status === 'ACTIVE'}
                          disabled={!canEdit}
                          onChange={() => handleToggleStatus(user)}
                        />
                        <div className="relative w-11 h-6 bg-black/15 dark:bg-white/15 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-success"></div>
                        <span className={`ml-2 text-xs font-medium ${user.status === 'ACTIVE' ? 'text-success' : 'text-black/50 dark:text-white/50'}`}>
                          {user.status === 'ACTIVE' ? 'Aktif' : 'Nonaktif'}
                        </span>
                      </label>
                    </td>
                    <td className="py-3 px-6">
                      <div className="flex items-center justify-end gap-1">
                        {canEdit && (<>
                        <button
                          type="button"
                          onClick={() => openEditModal(user)}
                          title="Ubah"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-primary hover:bg-primary/10 rounded-lg transition-colors"
                        >
                          <i className="ri-edit-line"></i>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setResetPwdModal(user);
                            setNewPassword('');
                          }}
                          title="Reset Kata Sandi"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-info hover:bg-info/10 rounded-lg transition-colors"
                        >
                          <i className="ri-lock-password-line"></i>
                        </button>
                        </>)}
                        {canDelete && (
                        <button
                          type="button"
                          onClick={() => setDeleteConfirm(user)}
                          title="Hapus"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-danger hover:bg-danger/10 rounded-lg transition-colors"
                        >
                          <i className="ri-delete-bin-line"></i>
                        </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {totalPages > 0 && (
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-6 pt-4 border-t border-black/10 dark:border-white/10">
            <p className="text-sm text-black/60 dark:text-white/60">
              Menampilkan {((page - 1) * perPage) + 1} - {Math.min(page * perPage, total)} dari {total} data
            </p>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <i className="ri-arrow-left-s-line"></i>
              </button>
              {pageNumbers.map((p, idx) =>
                typeof p === 'number' ? (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setPage(p)}
                    className={`w-9 h-9 rounded-lg text-sm font-medium transition-colors ${
                      p === page
                        ? 'bg-primary text-white shadow-sm'
                        : 'text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5'
                    }`}
                  >
                    {p}
                  </button>
                ) : (
                  <span key={idx} className="w-9 h-9 flex items-center justify-center text-sm text-black/40 dark:text-white/40">
                    {p}
                  </span>
                )
              )}
              <button
                type="button"
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <i className="ri-arrow-right-s-line"></i>
              </button>
            </div>
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={closeModal}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">
                {editingUser ? 'Ubah Pengguna' : 'Tambah Pengguna'}
              </h2>
              <button
                type="button"
                onClick={closeModal}
                className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <form onSubmit={handleSubmit} className="overflow-y-auto flex-1">
              <div className="px-6 py-5 space-y-4">
                {formError && (
                  <div className="p-3 rounded-lg bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 text-sm">
                    <div className="flex items-start gap-2">
                      <i className="ri-error-warning-line mt-0.5"></i>
                      <span>{formError}</span>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      Username <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={form.username}
                      onChange={(e) => setForm({ ...form, username: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      Nama Lengkap <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      Email <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      required
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    />
                  </div>
                  {!editingUser && (
                    <div>
                      <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                        Kata Sandi <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="password"
                        required
                        minLength={PASSWORD_MIN_LENGTH}
                        value={form.password}
                        onChange={(e) => setForm({ ...form, password: e.target.value })}
                        className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                      />
                    </div>
                  )}
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      Peran
                    </label>
                    <select
                      value={form.role_id}
                      onChange={(e) => setForm({ ...form, role_id: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    >
                      <option value="">{roles.length === 0 ? 'Daftar peran tidak tersedia' : 'Pilih peran'}</option>
                      {roles.map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      Departemen
                    </label>
                    <select
                      value={form.department_id}
                      onChange={(e) => setForm({ ...form, department_id: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    >
                      <option value="">Pilih Departemen</option>
                      {departments.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      NIK
                    </label>
                    <input
                      type="text"
                      value={form.nik}
                      onChange={(e) => setForm({ ...form, nik: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      No. Telepon
                    </label>
                    <input
                      type="text"
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      Pangkat/Golongan
                    </label>
                    <input
                      type="text"
                      value={form.rank}
                      onChange={(e) => setForm({ ...form, rank: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      Jabatan
                    </label>
                    <input
                      type="text"
                      value={form.position}
                      onChange={(e) => setForm({ ...form, position: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    />
                  </div>
                </div>
              </div>
              <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={closeModal}
                  disabled={submitting}
                  className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors disabled:opacity-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submitting && (
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                  )}
                  <span>Simpan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setDeleteConfirm(null)}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-md overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-5">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-500/10 flex items-center justify-center shrink-0">
                  <i className="ri-delete-bin-line text-2xl text-red-600 dark:text-red-400"></i>
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-black dark:text-white">Hapus Pengguna</h3>
                  <p className="text-sm text-black/60 dark:text-white/60 mt-1">
                    Apakah Anda yakin ingin menghapus pengguna <span className="font-semibold">{deleteConfirm.name}</span>? Tindakan ini tidak dapat dibatalkan.
                  </p>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 bg-black/[0.02] dark:bg-white/[0.02] flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => handleDelete(deleteConfirm)}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors shadow-sm"
              >
                Hapus
              </button>
            </div>
          </div>
        </div>
      )}

      {resetPwdModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setResetPwdModal(null)}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-md overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">Reset Kata Sandi</h2>
              <button
                type="button"
                onClick={() => setResetPwdModal(null)}
                className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <div className="px-6 py-5 space-y-4">
              <p className="text-sm text-black/60 dark:text-white/60">
                Atur kata sandi baru untuk pengguna <span className="font-semibold">{resetPwdModal.name}</span>.
              </p>
              <div>
                <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                  Kata Sandi Baru <span className="text-red-500">*</span>
                </label>
                <input
                  type="password"
                  required
                  minLength={PASSWORD_MIN_LENGTH}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                  placeholder={`Minimal ${PASSWORD_MIN_LENGTH} karakter`}

                />
              </div>
            </div>
            <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setResetPwdModal(null)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleResetPassword}
                disabled={!newPassword || newPassword.length < 6}
                className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Simpan
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className={`fixed top-4 right-4 z-[60] max-w-sm rounded-lg shadow-lg p-4 flex items-start gap-3 ${
          toast.type === 'success'
            ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20'
            : 'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20'
        }`}>
          <div className="flex-shrink-0">
            {toast.type === 'success' ? (
              <i className={`ri-check-line text-lg ${toast.type === 'success' ? 'text-green-600 dark:text-green-400' : ''}`}></i>
            ) : (
              <i className={`ri-error-warning-line text-lg ${toast.type === 'error' ? 'text-red-600 dark:text-red-400' : ''}`}></i>
            )}
          </div>
          <p className={`flex-1 text-sm font-medium ${toast.type === 'success' ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>
            {toast.message}
          </p>
          <button
            type="button"
            onClick={() => setToast(null)}
            className={`flex-shrink-0 transition-colors ${toast.type === 'success' ? 'text-green-400 hover:text-green-600' : 'text-red-400 hover:text-red-600'}`}
          >
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}
    </div>
  );
}
