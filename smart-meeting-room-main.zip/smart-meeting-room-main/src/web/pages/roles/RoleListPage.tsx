import { useEffect, useState, useMemo } from 'react';
import { authApi } from '../../../shared/api/auth';
import { getErrorMessage } from '../../../shared/api/client';
import { usePermission } from '../../store/auth.store';
import type {
  Role,
  RoleCreate,
  RoleUpdate,
  Permission,
  PermissionGroup,
} from '@shared/types';
import { PERMISSION_GROUPS } from '@shared/types';

interface RoleFormState {
  name: string;
  description: string;
}

const INITIAL_FORM: RoleFormState = {
  name: '',
  description: '',
};

export function RoleListPage() {
  const can = usePermission();
  const canWrite = can('roles.write');
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [perPage] = useState(10);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  const [showModal, setShowModal] = useState(false);
  const [editingRole, setEditingRole] = useState<Role | null>(null);
  const [form, setForm] = useState<RoleFormState>(INITIAL_FORM);
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [deleteConfirm, setDeleteConfirm] = useState<Role | null>(null);

  const [permissionModal, setPermissionModal] = useState<Role | null>(null);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [permissionsError, setPermissionsError] = useState<string | null>(null);
  /** Kode izin terpilih (mis. "users.view"). */
  const [selectedPerms, setSelectedPerms] = useState<string[]>([]);
  const [permSubmitting, setPermSubmitting] = useState(false);

  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchRoles = async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const result = await authApi.listRoles({ page, per_page: perPage });
      setRoles(result.items ?? []);
      setTotal(result.total ?? 0);
      setTotalPages(result.total_pages ?? 0);
    } catch (err) {
      setRoles([]);
      setLoadError(getErrorMessage(err, 'Gagal memuat daftar peran'));
    } finally {
      setLoading(false);
    }
  };

  const fetchPermissions = async () => {
    setPermissionsError(null);
    try {
      const result = await authApi.listPermissions();
      setPermissions(Array.isArray(result) ? result : []);
    } catch (err) {
      setPermissions([]);
      setPermissionsError(getErrorMessage(err, 'Gagal memuat katalog izin'));
    }
  };

  useEffect(() => {
    fetchRoles();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page]);

  useEffect(() => {
    fetchPermissions();
  }, []);

  const openCreateModal = () => {
    setEditingRole(null);
    setForm(INITIAL_FORM);
    setFormError(null);
    setShowModal(true);
  };

  const openEditModal = (role: Role) => {
    setEditingRole(role);
    setForm({
      name: role.name,
      description: role.description || '',
    });
    setFormError(null);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingRole(null);
    setForm(INITIAL_FORM);
    setFormError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSubmitting(true);

    try {
      if (editingRole) {
        const data: RoleUpdate = {
          name: form.name.trim(),
          description: form.description || undefined,
        };
        await authApi.updateRole(editingRole.id, data);
        showToast('success', 'Peran berhasil diperbarui');
      } else {
        const data: RoleCreate = {
          name: form.name.trim(),
          description: form.description || undefined,
        };
        await authApi.createRole(data);
        showToast('success', 'Peran berhasil ditambahkan');
      }
      closeModal();
      fetchRoles();
    } catch (err: unknown) {
      setFormError(getErrorMessage(err, 'Gagal menyimpan peran'));
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (role: Role) => {
    try {
      await authApi.deleteRole(role.id);
      showToast('success', 'Peran berhasil dihapus');
      setDeleteConfirm(null);
      fetchRoles();
    } catch (err: unknown) {
      showToast('error', getErrorMessage(err, 'Gagal menghapus peran'));
      setDeleteConfirm(null);
    }
  };

  const knownCodes = useMemo(() => new Set(permissions.map((p) => p.code)), [permissions]);
  const isFullAccess = (role: Role | null) => !!role?.permissions?.includes('*') || !!role?.is_system;

  const openPermissionModal = (role: Role) => {
    setPermissionModal(role);
    // Hanya kode yang dikenal katalog; "*" (akses penuh) ditangani terpisah.
    setSelectedPerms((role.permissions || []).filter((c) => knownCodes.has(c)));
  };

  const closePermissionModal = () => {
    setPermissionModal(null);
    setSelectedPerms([]);
  };

  const togglePermission = (code: string) => {
    setSelectedPerms((prev) =>
      prev.includes(code) ? prev.filter((p) => p !== code) : [...prev, code]
    );
  };

  const toggleGroupPermissions = (group: PermissionGroup) => {
    const groupCodes = permissions.filter((p) => p.group === group).map((p) => p.code);
    const allSelected = groupCodes.every((c) => selectedPerms.includes(c));
    if (allSelected) {
      setSelectedPerms((prev) => prev.filter((c) => !groupCodes.includes(c)));
    } else {
      setSelectedPerms((prev) => [...new Set([...prev, ...groupCodes])]);
    }
  };

  const handleSavePermissions = async () => {
    if (!permissionModal) return;
    setPermSubmitting(true);
    try {
      await authApi.syncRolePermissions(permissionModal.id, { permissions: selectedPerms });
      showToast('success', 'Izin akses berhasil disimpan');
      closePermissionModal();
      fetchRoles();
    } catch (err: unknown) {
      showToast('error', getErrorMessage(err, 'Gagal menyimpan izin akses'));
    } finally {
      setPermSubmitting(false);
    }
  };

  // Backend /roles belum mendukung parameter pencarian: filter di sisi klien
  // hanya untuk halaman yang sedang dimuat.
  const visibleRoles = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return roles;
    return roles.filter(
      (r) => r.name.toLowerCase().includes(q) || (r.description ?? '').toLowerCase().includes(q)
    );
  }, [roles, search]);

  const safeTotalPages = totalPages ?? 0;
  const safeTotal = total ?? 0;
  const safeRoles = visibleRoles ?? [];

  const pageNumbers = useMemo(() => {
    const pages: (number | string)[] = [];
    if (safeTotalPages <= 7) {
      for (let i = 1; i <= safeTotalPages; i++) pages.push(i);
    } else {
      if (page <= 4) {
        pages.push(1, 2, 3, 4, 5, '...', safeTotalPages);
      } else if (page >= safeTotalPages - 3) {
        pages.push(1, '...', safeTotalPages - 4, safeTotalPages - 3, safeTotalPages - 2, safeTotalPages - 1, safeTotalPages);
      } else {
        pages.push(1, '...', page - 1, page, page + 1, '...', safeTotalPages);
      }
    }
    return pages;
  }, [page, safeTotalPages]);

  const groupedPermissions = useMemo(() => {
    const map: Record<PermissionGroup, Permission[]> = {
      users: [],
      rooms: [],
      bookings: [],
      notes: [],
      devices: [],
      reports: [],
      settings: [],
      audit: [],
    };
    for (const p of permissions) {
      (map[p.group] ??= []).push(p);
    }
    return map;
  }, [permissions]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Daftar Peran &amp; Izin Akses</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Kelola peran pengguna dan izin akses dalam sistem Smart Meeting Room
          </p>
        </div>
        {canWrite && (
          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors shadow-sm"
          >
            <i className="ri-add-line text-lg"></i>
            <span>Tambah Peran</span>
          </button>
        )}
      </div>

      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1 max-w-sm">
            <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40"></i>
            <input
              type="text"
              placeholder="Cari di halaman ini (nama, deskripsi)..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 placeholder:text-black/40 dark:placeholder:text-white/40"
            />
          </div>
        </div>

        <div className="overflow-x-auto -mx-6">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-y border-black/10 dark:border-white/10">
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Nama Peran
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Deskripsi
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Jumlah Izin
                </th>
                <th className="text-right py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Aksi
                </th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={4} className="py-12 text-center text-black/50 dark:text-white/50">
                    <div className="inline-flex items-center gap-2">
                      <svg className="animate-spin h-5 w-5 text-primary" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      <span>Memuat data...</span>
                    </div>
                  </td>
                </tr>
              ) : loadError ? (
                <tr>
                  <td colSpan={4} className="py-12 text-center">
                    <p className="text-sm text-red-600 dark:text-red-400">{loadError}</p>
                    <button
                      type="button"
                      onClick={fetchRoles}
                      className="mt-3 inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-primary bg-primary/10 hover:bg-primary/15 rounded-lg"
                    >
                      <i className="ri-refresh-line"></i> Coba Lagi
                    </button>
                  </td>
                </tr>
              ) : safeRoles.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-12 text-center text-black/50 dark:text-white/50">
                    <div className="flex flex-col items-center gap-2">
                      <i className="ri-shield-user-line text-4xl text-black/30 dark:text-white/30"></i>
                      <span>{search.trim() ? 'Tidak ada peran yang cocok di halaman ini' : 'Belum ada data'}</span>
                    </div>
                  </td>
                </tr>
              ) : (
                safeRoles.map((role) => (
                  <tr
                    key={role.id}
                    className="border-b border-black/5 dark:border-white/5 hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors"
                  >
                    <td className="py-3 px-6 whitespace-nowrap">
                      <span className="inline-flex items-center gap-2">
                        <span className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                          <i className="ri-shield-star-line text-primary"></i>
                        </span>
                        <span className="font-semibold text-black/80 dark:text-white/80">{role.name}</span>
                      </span>
                    </td>
                    <td className="py-3 px-6 text-black/60 dark:text-white/60">
                      {role.description || '-'}
                    </td>
                    <td className="py-3 px-6 whitespace-nowrap">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-info/10 text-info">
                        {isFullAccess(role) ? 'Akses penuh' : `${role.permission_count ?? role.permissions?.length ?? 0} izin`}
                      </span>
                    </td>
                    <td className="py-3 px-6">
                      <div className="flex items-center justify-end gap-1">
                        {role.is_system && (
                          <span className="px-2 py-0.5 rounded-full text-[11px] font-medium bg-black/5 dark:bg-white/10 text-black/50 dark:text-white/50" title="Peran bawaan sistem tidak dapat diubah">
                            Sistem
                          </span>
                        )}
                        {canWrite && !role.is_system && (<>
                        <button
                          type="button"
                          onClick={() => openPermissionModal(role)}
                          title="Kelola Izin Akses"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-info hover:bg-info/10 rounded-lg transition-colors"
                        >
                          <i className="ri-key-2-line"></i>
                        </button>
                        <button
                          type="button"
                          onClick={() => openEditModal(role)}
                          title="Ubah"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-primary hover:bg-primary/10 rounded-lg transition-colors"
                        >
                          <i className="ri-edit-line"></i>
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteConfirm(role)}
                          title="Hapus"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-danger hover:bg-danger/10 rounded-lg transition-colors"
                        >
                          <i className="ri-delete-bin-line"></i>
                        </button>
                        </>)}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {safeTotalPages > 0 && (
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-6 pt-4 border-t border-black/10 dark:border-white/10">
            <p className="text-sm text-black/60 dark:text-white/60">
              Menampilkan {safeTotal === 0 ? 0 : ((page - 1) * perPage) + 1} - {Math.min(page * perPage, safeTotal)} dari {safeTotal} data
            </p>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <i className="ri-arrow-left-s-line"></i>
              </button>
              {pageNumbers.map((p, idx) =>
                typeof p === 'number' ? (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setPage(p)}
                    className={`w-9 h-9 rounded-lg text-sm font-medium transition-colors ${
                      p === page
                        ? 'bg-primary text-white shadow-sm'
                        : 'text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5'
                    }`}
                  >
                    {p}
                  </button>
                ) : (
                  <span key={idx} className="w-9 h-9 flex items-center justify-center text-sm text-black/40 dark:text-white/40">
                    {p}
                  </span>
                )
              )}
              <button
                type="button"
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <i className="ri-arrow-right-s-line"></i>
              </button>
            </div>
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={closeModal}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-lg overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">
                {editingRole ? 'Ubah Peran' : 'Tambah Peran'}
              </h2>
              <button
                type="button"
                onClick={closeModal}
                className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="px-6 py-5 space-y-4">
                {formError && (
                  <div className="p-3 rounded-lg bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 text-sm">
                    <div className="flex items-start gap-2">
                      <i className="ri-error-warning-line mt-0.5"></i>
                      <span>{formError}</span>
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                    Nama Peran <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={50}
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    placeholder="Contoh: Admin Ruangan"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                    Deskripsi
                  </label>
                  <textarea
                    rows={3}
                    maxLength={200}
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 resize-none"
                    placeholder="Deskripsi singkat tentang peran ini..."
                  />
                </div>
              </div>
              <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={closeModal}
                  disabled={submitting}
                  className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors disabled:opacity-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submitting && (
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                  )}
                  <span>Simpan Perubahan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {permissionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={closePermissionModal}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-black dark:text-white">
                  Kelola Izin Akses - {permissionModal.name}
                </h2>
                <p className="text-xs text-black/60 dark:text-white/60 mt-0.5">
                  Pilih izin yang akan diberikan untuk peran ini
                </p>
              </div>
              <button
                type="button"
                onClick={closePermissionModal}
                className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <div className="overflow-y-auto flex-1 px-6 py-5 space-y-5">
              {isFullAccess(permissionModal) && (
                <div className="rounded-lg border border-warning/30 bg-warning/10 p-3 text-sm text-black/80 dark:text-white/80">
                  Peran ini memiliki akses penuh (<code>*</code>). Izin tidak dapat diubah dari sini.
                </div>
              )}
              {permissionsError && (
                <div className="rounded-lg border border-red-200 bg-red-50 dark:bg-red-500/10 p-3 text-sm text-red-700 dark:text-red-300">
                  {permissionsError}{' '}
                  <button type="button" onClick={fetchPermissions} className="underline font-medium">Coba lagi</button>
                </div>
              )}
              {!permissionsError && permissions.length === 0 && (
                <p className="text-sm text-black/50 dark:text-white/50">Belum ada data izin</p>
              )}
              {PERMISSION_GROUPS.map((group) => {
                const groupPerms = groupedPermissions[group.key] ?? [];
                if (groupPerms.length === 0) return null;
                const allSelected = groupPerms.every((p) => selectedPerms.includes(p.code));
                return (
                  <div key={group.key} className="border border-black/10 dark:border-white/10 rounded-lg overflow-hidden">
                    <div className="px-4 py-3 bg-black/[0.02] dark:bg-white/[0.02] border-b border-black/10 dark:border-white/10 flex items-center justify-between">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={allSelected}
                          onChange={() => toggleGroupPermissions(group.key)}
                          className="w-4 h-4 rounded border-black/20 text-primary focus:ring-primary cursor-pointer"
                        />
                        <span className="font-semibold text-sm text-black/80 dark:text-white/80">
                          {group.label}
                        </span>
                      </label>
                      <span className="text-xs text-black/50 dark:text-white/50">
                        {groupPerms.filter((p) => selectedPerms.includes(p.code)).length}/{groupPerms.length}
                      </span>
                    </div>
                    <div className="px-4 py-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {groupPerms.map((perm) => (
                        <label
                          key={perm.code}
                          className={`flex items-start gap-2 p-2 rounded-md cursor-pointer transition-colors ${
                            selectedPerms.includes(perm.code)
                              ? 'bg-primary/5 dark:bg-primary/10'
                              : 'hover:bg-black/[0.02] dark:hover:bg-white/[0.02]'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={selectedPerms.includes(perm.code)}
                            onChange={() => togglePermission(perm.code)}
                            className="mt-0.5 w-4 h-4 rounded border-black/20 text-primary focus:ring-primary cursor-pointer"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-medium text-black/80 dark:text-white/80">
                              {perm.name}
                            </div>
                            <div className="text-xs text-black/50 dark:text-white/50 font-mono">
                              {perm.code}
                            </div>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={closePermissionModal}
                disabled={permSubmitting}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors disabled:opacity-50"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleSavePermissions}
                disabled={permSubmitting || isFullAccess(permissionModal) || permissions.length === 0}

                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {permSubmitting && (
                  <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                )}
                <span>Simpan Izin Akses</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setDeleteConfirm(null)}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-md overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-5">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-500/10 flex items-center justify-center shrink-0">
                  <i className="ri-delete-bin-line text-2xl text-red-600 dark:text-red-400"></i>
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-black dark:text-white">Hapus Peran</h3>
                  <p className="text-sm text-black/60 dark:text-white/60 mt-1">
                    Apakah Anda yakin ingin menghapus peran <span className="font-semibold">{deleteConfirm.name}</span>? Pengguna yang masih memiliki peran ini tidak akan dapat mengakses sistem dengan peran tersebut.
                  </p>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 bg-black/[0.02] dark:bg-white/[0.02] flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => handleDelete(deleteConfirm)}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors shadow-sm"
              >
                Hapus
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className={`fixed top-4 right-4 z-[60] max-w-sm rounded-lg shadow-lg p-4 flex items-start gap-3 ${
          toast.type === 'success'
            ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20'
            : 'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20'
        }`}>
          <div className="flex-shrink-0">
            <i className={`ri-check-line text-lg ${toast.type === 'success' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}></i>
          </div>
          <p className={`flex-1 text-sm font-medium ${toast.type === 'success' ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>
            {toast.message}
          </p>
          <button
            type="button"
            onClick={() => setToast(null)}
            className={`flex-shrink-0 transition-colors ${toast.type === 'success' ? 'text-green-400 hover:text-green-600' : 'text-red-400 hover:text-red-600'}`}
          >
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}
    </div>
  );
}
