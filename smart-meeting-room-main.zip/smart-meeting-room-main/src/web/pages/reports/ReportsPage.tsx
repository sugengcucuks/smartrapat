import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi } from '../../../shared/api/auth';
import { downloadFile, getErrorMessage } from '../../../shared/api/client';
import { addDaysLocal, parseLocalDate, todayLocal } from '../../../shared/utils/date';
import { usePermission } from '../../store/auth.store';
import type {
  DashboardSummary,
  BookingsReport,
  RoomUtilizationItem,
  EquipmentInventoryReport,
} from '@shared/types';
import { BOOKING_STATUS_OPTIONS } from '@shared/types';

type ReportTab = 'summary' | 'bookings' | 'utilization' | 'equipment';

interface Loadable<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

const initial = <T,>(): Loadable<T> => ({ data: null, loading: false, error: null });

const DAY_SHORT = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];

const inputCls =
  'px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80';

function StateBlock({ loading, error, empty, onRetry }: { loading: boolean; error: string | null; empty: boolean; onRetry: () => void }) {
  if (loading) {
    return <div className="py-12 text-center text-sm text-black/50 dark:text-white/50">Memuat data...</div>;
  }
  if (error) {
    return (
      <div className="py-12 text-center">
        <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
        <button
          type="button"
          onClick={onRetry}
          className="mt-3 inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-primary bg-primary/10 hover:bg-primary/15 rounded-lg"
        >
          <i className="ri-refresh-line"></i> Coba Lagi
        </button>
      </div>
    );
  }
  if (empty) {
    return <div className="py-12 text-center text-sm text-black/50 dark:text-white/50">Belum ada data</div>;
  }
  return null;
}

export function ReportsPage() {
  const navigate = useNavigate();
  const can = usePermission();
  const canExport = can('reports.export');
  const [tab, setTab] = useState<ReportTab>('summary');

  const [dashboard, setDashboard] = useState<Loadable<DashboardSummary>>(initial);
  const [last7, setLast7] = useState<Loadable<BookingsReport>>(initial);

  const [bookings, setBookings] = useState<Loadable<BookingsReport>>(initial);
  const [filterBookingFrom, setFilterBookingFrom] = useState(() => addDaysLocal(todayLocal(), -29));
  const [filterBookingTo, setFilterBookingTo] = useState(() => todayLocal());

  const [utilization, setUtilization] = useState<Loadable<RoomUtilizationItem[]>>(initial);
  const [filterUtilFrom, setFilterUtilFrom] = useState(() => addDaysLocal(todayLocal(), -29));
  const [filterUtilTo, setFilterUtilTo] = useState(() => todayLocal());

  const [equipmentInv, setEquipmentInv] = useState<Loadable<EquipmentInventoryReport>>(initial);
  const [downloading, setDownloading] = useState<string | null>(null);

  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 4000);
  };

  const fetchDashboard = useCallback(async () => {
    setDashboard({ data: null, loading: true, error: null });
    setLast7((s) => ({ ...s, loading: true, error: null }));
    const to = todayLocal();
    const from = addDaysLocal(to, -6);
    const [dash, week] = await Promise.allSettled([
      authApi.getDashboardSummary(),
      authApi.getBookingsReport({ from, to }),
    ]);
    setDashboard(
      dash.status === 'fulfilled'
        ? { data: dash.value, loading: false, error: null }
        : { data: null, loading: false, error: getErrorMessage(dash.reason, 'Gagal memuat ringkasan') }
    );
    setLast7(
      week.status === 'fulfilled'
        ? { data: week.value, loading: false, error: null }
        : { data: null, loading: false, error: getErrorMessage(week.reason, 'Gagal memuat data 7 hari') }
    );
  }, []);

  const fetchBookings = useCallback(async () => {
    setBookings((s) => ({ ...s, loading: true, error: null }));
    try {
      const data = await authApi.getBookingsReport({
        from: filterBookingFrom || undefined,
        to: filterBookingTo || undefined,
      });
      setBookings({ data, loading: false, error: null });
    } catch (err) {
      setBookings({ data: null, loading: false, error: getErrorMessage(err, 'Gagal memuat laporan pemesanan') });
    }
  }, [filterBookingFrom, filterBookingTo]);

  const fetchUtilization = useCallback(async () => {
    setUtilization((s) => ({ ...s, loading: true, error: null }));
    try {
      const data = await authApi.getRoomsUtilization({
        from_date: filterUtilFrom || undefined,
        to_date: filterUtilTo || undefined,
      });
      setUtilization({ data: data ?? [], loading: false, error: null });
    } catch (err) {
      setUtilization({ data: null, loading: false, error: getErrorMessage(err, 'Gagal memuat utilisasi ruangan') });
    }
  }, [filterUtilFrom, filterUtilTo]);

  const fetchEquipment = useCallback(async () => {
    setEquipmentInv((s) => ({ ...s, loading: true, error: null }));
    try {
      const data = await authApi.getEquipmentInventory();
      setEquipmentInv({ data, loading: false, error: null });
    } catch (err) {
      setEquipmentInv({ data: null, loading: false, error: getErrorMessage(err, 'Gagal memuat inventaris perangkat') });
    }
  }, []);

  useEffect(() => {
    fetchDashboard();
  }, [fetchDashboard]);

  useEffect(() => {
    if (tab === 'bookings') fetchBookings();
    else if (tab === 'utilization') fetchUtilization();
    else if (tab === 'equipment') fetchEquipment();
    // Filter tanggal diterapkan lewat tombol "Terapkan".
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  const handleDownload = async (kind: 'bookings' | 'equipment', format: 'xlsx' | 'pdf' | 'csv') => {
    const key = `${kind}-${format}`;
    setDownloading(key);
    try {
      if (kind === 'bookings') {
        await downloadFile(
          '/reports/bookings/download',
          { format, from: filterBookingFrom || undefined, to: filterBookingTo || undefined },
          `laporan-pemesanan-${todayLocal()}.${format}`
        );
      } else {
        await downloadFile('/reports/equipment/download', { format }, `laporan-inventaris-${todayLocal()}.${format}`);
      }
      showToast('success', `Laporan ${format.toUpperCase()} berhasil diunduh`);
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal mengunduh laporan'));
    } finally {
      setDownloading(null);
    }
  };

  const statusLabel = (s: string) => BOOKING_STATUS_OPTIONS.find((o) => o.value === s)?.label || s;

  const statusBadge = (s: string) => {
    const map: Record<string, string> = {
      completed: 'bg-green-100 text-green-700 dark:bg-green-500/10 dark:text-green-400',
      approved: 'bg-blue-100 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400',
      pending: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-500/10 dark:text-yellow-400',
      rejected: 'bg-red-100 text-red-700 dark:bg-red-500/10 dark:text-red-400',
      cancelled: 'bg-gray-100 text-gray-700 dark:bg-gray-500/10 dark:text-gray-400',
    };
    return map[s] || 'bg-gray-100 text-gray-700';
  };

  const utilizationColor = (p: number) => {
    if (p >= 75) return 'bg-success';
    if (p >= 50) return 'bg-primary';
    if (p >= 25) return 'bg-warning';
    return 'bg-gray-300 dark:bg-white/30';
  };

  // Grafik 7 hari terakhir dari data nyata (hari tanpa pemesanan = 0).
  const last7Days = useMemo(() => {
    const counts = new Map((last7.data?.per_day ?? []).map((d) => [String(d.date).slice(0, 10), d.count]));
    const to = todayLocal();
    return Array.from({ length: 7 }, (_, i) => {
      const date = addDaysLocal(to, i - 6);
      return { date, label: DAY_SHORT[parseLocalDate(date).getDay()], count: counts.get(date) ?? 0 };
    });
  }, [last7.data]);
  const maxBooking7d = Math.max(1, ...last7Days.map((d) => d.count));

  const perRoom7d = useMemo(
    () => [...(last7.data?.per_room ?? [])].sort((a, b) => b.count - a.count).slice(0, 6),
    [last7.data]
  );
  const maxPerRoom7d = Math.max(1, ...perRoom7d.map((r) => r.count));

  const equipItems = equipmentInv.data?.items ?? [];
  const sumEquip = (k: 'active' | 'maintenance' | 'broken' | 'disposed') => equipItems.reduce((s, e) => s + (e[k] || 0), 0);

  const d = dashboard.data;
  const SUMMARY_CARDS = d
    ? [
        { label: 'Total Ruangan', value: d.total_rooms, icon: 'ri-building-line', color: 'primary' },
        { label: 'Total Pengguna', value: d.total_users, icon: 'ri-user-line', color: 'info' },
        { label: 'Pemesanan Hari Ini', value: d.today_bookings, icon: 'ri-calendar-check-line', color: 'success' },
        { label: 'Rapat Berlangsung', value: d.ongoing_meetings, icon: 'ri-time-line', color: 'warning' },
        { label: 'Perangkat Online', value: d.online_devices, icon: 'ri-monitor-line', color: 'info' },
        { label: 'Persetujuan Menunggu', value: d.pending_approvals, icon: 'ri-clock-line', color: 'warning' },
        { label: '% Utilisasi Ruangan (7 hari)', value: `${Number(d.room_utilization_percent ?? 0).toFixed(1)}%`, icon: 'ri-pie-chart-line', color: 'success' },
        { label: 'Rata-rata Durasi', value: `${Math.round(Number(d.avg_meeting_duration_minutes ?? 0))} mnt`, icon: 'ri-timer-line', color: 'primary' },
      ]
    : [];

  const colorWrapper = (c: string) => {
    const map: Record<string, string> = {
      primary: 'bg-primary/10 text-primary',
      success: 'bg-success/10 text-success',
      info: 'bg-info/10 text-info',
      warning: 'bg-warning/10 text-warning',
    };
    return map[c] || 'bg-primary/10 text-primary';
  };

  const bookingData = bookings.data;
  const utilItems = utilization.data ?? [];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Laporan &amp; Analitik</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Analisis data pemesanan ruangan, utilisasi, dan inventaris perangkat
          </p>
        </div>
      </div>

      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
        <div className="flex gap-1 border-b border-black/10 dark:border-white/10 mb-6 overflow-x-auto">
          {([
            { id: 'summary', label: 'Ringkasan' },
            { id: 'bookings', label: 'Pemesanan' },
            { id: 'utilization', label: 'Utilitas Ruangan' },
            { id: 'equipment', label: 'Inventaris Perangkat' },
          ] as { id: ReportTab; label: string }[]).map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`relative px-4 py-2.5 text-sm font-medium whitespace-nowrap transition-colors ${
                tab === t.id ? 'text-primary' : 'text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white'
              }`}
            >
              {t.label}
              {tab === t.id && <span className="absolute left-0 right-0 -bottom-px h-0.5 bg-primary rounded-t"></span>}
            </button>
          ))}
        </div>

        {tab === 'summary' && (
          <div className="space-y-6">
            {dashboard.loading || dashboard.error ? (
              <StateBlock loading={dashboard.loading} error={dashboard.error} empty={false} onRetry={fetchDashboard} />
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {SUMMARY_CARDS.map((c) => (
                  <div key={c.label} className="flex items-center gap-4 p-4 border border-black/5 dark:border-white/5 rounded-lg">
                    <div className={`w-11 h-11 rounded-lg ${colorWrapper(c.color)} flex items-center justify-center shrink-0`}>
                      <i className={`${c.icon} text-xl`}></i>
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs text-black/50 dark:text-white/50 truncate">{c.label}</p>
                      <h3 className="text-xl font-bold text-black dark:text-white">{c.value}</h3>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="p-5 border border-black/5 dark:border-white/5 rounded-lg">
                <h3 className="text-base font-semibold text-black dark:text-white mb-4">Pemesanan Per Ruangan (7 Hari)</h3>
                {last7.loading || last7.error || perRoom7d.length === 0 ? (
                  <StateBlock loading={last7.loading} error={last7.error} empty={perRoom7d.length === 0} onRetry={fetchDashboard} />
                ) : (
                  <div className="space-y-3">
                    {perRoom7d.map((r) => (
                      <div key={r.room_id} className="flex items-center gap-3">
                        <div className="w-28 text-sm text-black/70 dark:text-white/70 truncate shrink-0">{r.room_name}</div>
                        <div className="flex-1 h-6 bg-black/5 dark:bg-white/5 rounded overflow-hidden">
                          <div className="h-full bg-primary rounded transition-all" style={{ width: `${(r.count / maxPerRoom7d) * 100}%` }}></div>
                        </div>
                        <div className="w-10 text-right text-sm font-semibold text-black dark:text-white">{r.count}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="p-5 border border-black/5 dark:border-white/5 rounded-lg">
                <h3 className="text-base font-semibold text-black dark:text-white mb-4">Pemesanan 7 Hari Terakhir</h3>
                {last7.loading || last7.error ? (
                  <StateBlock loading={last7.loading} error={last7.error} empty={false} onRetry={fetchDashboard} />
                ) : (
                  <div className="flex items-end gap-2 h-48 pt-4">
                    {last7Days.map((day) => (
                      <div key={day.date} className="flex-1 flex flex-col items-center gap-2">
                        <div className="text-xs font-semibold text-black/70 dark:text-white/70">{day.count}</div>
                        <div className="flex-1 w-full flex items-end">
                          <div
                            className="w-full bg-gradient-to-t from-primary to-primary/60 rounded-t transition-all hover:opacity-80"
                            style={{ height: `${(day.count / maxBooking7d) * 100}%`, minHeight: day.count > 0 ? '8px' : '0' }}
                            title={`${day.date}: ${day.count} pemesanan`}
                          ></div>
                        </div>
                        <div className="text-xs text-black/60 dark:text-white/60 font-medium">{day.label}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {tab === 'bookings' && (
          <div className="space-y-5">
            <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
              <div className="flex flex-wrap gap-3 items-center">
                <div className="flex items-center gap-2">
                  <label className="text-sm text-black/60 dark:text-white/60 shrink-0">Dari:</label>
                  <input type="date" value={filterBookingFrom} onChange={(e) => setFilterBookingFrom(e.target.value)} className={inputCls} />
                </div>
                <div className="flex items-center gap-2">
                  <label className="text-sm text-black/60 dark:text-white/60 shrink-0">Sampai:</label>
                  <input type="date" value={filterBookingTo} onChange={(e) => setFilterBookingTo(e.target.value)} className={inputCls} />
                </div>
                <button onClick={fetchBookings} className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors">
                  <i className="ri-filter-3-line"></i> Terapkan
                </button>
              </div>
              {canExport && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleDownload('bookings', 'xlsx')}
                    disabled={downloading !== null}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-success bg-success/10 hover:bg-success/15 rounded-lg transition-colors disabled:opacity-50"
                  >
                    <i className="ri-file-excel-line"></i> {downloading === 'bookings-xlsx' ? 'Mengunduh...' : 'XLSX'}
                  </button>
                  <button
                    onClick={() => handleDownload('bookings', 'pdf')}
                    disabled={downloading !== null}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-500/10 hover:bg-red-100 dark:hover:bg-red-500/15 rounded-lg transition-colors disabled:opacity-50"
                  >
                    <i className="ri-file-pdf-line"></i> {downloading === 'bookings-pdf' ? 'Mengunduh...' : 'PDF'}
                  </button>
                  <button
                    onClick={() => handleDownload('bookings', 'csv')}
                    disabled={downloading !== null}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors disabled:opacity-50"
                  >
                    <i className="ri-file-text-line"></i> {downloading === 'bookings-csv' ? 'Mengunduh...' : 'CSV'}
                  </button>
                </div>
              )}
            </div>

            {bookings.loading || bookings.error || !bookingData ? (
              <StateBlock loading={bookings.loading} error={bookings.error} empty={!bookingData} onRetry={fetchBookings} />
            ) : bookingData.total_bookings === 0 ? (
              <StateBlock loading={false} error={null} empty onRetry={fetchBookings} />
            ) : (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-black/[0.02] dark:bg-white/[0.02] rounded-lg">
                  <div>
                    <p className="text-xs text-black/50 dark:text-white/50">Total Pemesanan</p>
                    <p className="text-lg font-bold text-black dark:text-white">{bookingData.total_bookings}</p>
                  </div>
                  {bookingData.per_status.slice(0, 3).map((s) => (
                    <div key={s.status}>
                      <p className="text-xs text-black/50 dark:text-white/50">{statusLabel(s.status)}</p>
                      <p className="text-lg font-bold text-black dark:text-white">{s.count}</p>
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div>
                    <h3 className="text-sm font-semibold text-black dark:text-white mb-3">Per Status</h3>
                    <ul className="space-y-2">
                      {bookingData.per_status.map((s) => (
                        <li key={s.status} className="flex items-center justify-between text-sm">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusBadge(s.status)}`}>
                            {statusLabel(s.status)}
                          </span>
                          <span className="font-semibold text-black dark:text-white">{s.count}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-black dark:text-white mb-3">Per Ruangan</h3>
                    <ul className="space-y-2">
                      {[...bookingData.per_room].sort((a, b) => b.count - a.count).map((r) => (
                        <li key={r.room_id} className="flex items-center justify-between text-sm">
                          <span className="text-black/70 dark:text-white/70 truncate">{r.room_name}</span>
                          <span className="font-semibold text-black dark:text-white">{r.count}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-black dark:text-white mb-3">Per Hari</h3>
                    <ul className="space-y-2 max-h-72 overflow-y-auto pr-1">
                      {bookingData.per_day.map((dd) => (
                        <li key={String(dd.date)} className="flex items-center justify-between text-sm">
                          <span className="text-black/70 dark:text-white/70">
                            {parseLocalDate(String(dd.date).slice(0, 10)).toLocaleDateString('id-ID', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })}
                          </span>
                          <span className="font-semibold text-black dark:text-white">{dd.count}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {tab === 'utilization' && (
          <div className="space-y-5">
            <div className="flex flex-wrap gap-3 items-center justify-between">
              <div className="flex flex-wrap gap-3">
                <div className="flex items-center gap-2">
                  <label className="text-sm text-black/60 dark:text-white/60 shrink-0">Dari:</label>
                  <input type="date" value={filterUtilFrom} onChange={(e) => setFilterUtilFrom(e.target.value)} className={inputCls} />
                </div>
                <div className="flex items-center gap-2">
                  <label className="text-sm text-black/60 dark:text-white/60 shrink-0">Sampai:</label>
                  <input type="date" value={filterUtilTo} onChange={(e) => setFilterUtilTo(e.target.value)} className={inputCls} />
                </div>
                <button onClick={fetchUtilization} className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors">
                  <i className="ri-refresh-line"></i> Terapkan
                </button>
              </div>
            </div>
            {utilization.loading || utilization.error || utilItems.length === 0 ? (
              <StateBlock loading={utilization.loading} error={utilization.error} empty={utilItems.length === 0} onRetry={fetchUtilization} />
            ) : (
              <div className="overflow-x-auto -mx-6">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-y border-black/10 dark:border-white/10">
                      {['Ruangan', 'Jam Tersedia', 'Jam Dipesan', '% Utilisasi', 'Jumlah Pemesanan'].map((h) => (
                        <th key={h} className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {utilItems.map((u) => (
                      <tr key={u.room_id} className="border-b border-black/5 dark:border-white/5 hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors">
                        <td className="py-3 px-6 text-black/80 dark:text-white/80 font-medium whitespace-nowrap">{u.room_name}</td>
                        <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap">{u.total_hours_available} j</td>
                        <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap">{u.total_hours_booked} j</td>
                        <td className="py-3 px-6 whitespace-nowrap min-w-[180px]">
                          <div className="flex items-center gap-3">
                            <div className="flex-1 h-2.5 bg-black/10 dark:bg-white/10 rounded-full overflow-hidden">
                              <div className={`h-full ${utilizationColor(u.utilization_percent)} rounded-full transition-all`} style={{ width: `${Math.min(100, u.utilization_percent)}%` }}></div>
                            </div>
                            <span className={`text-sm font-semibold ${u.utilization_percent >= 75 ? 'text-success' : u.utilization_percent >= 50 ? 'text-primary' : 'text-warning'}`}>
                              {u.utilization_percent}%
                            </span>
                          </div>
                        </td>
                        <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap">{u.booking_count}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {tab === 'equipment' && (
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-black/60 dark:text-white/60">Total Inventaris Perangkat</p>
                <p className="text-2xl font-bold text-black dark:text-white">{equipmentInv.data?.grand_total ?? '-'}</p>
              </div>
              {canExport && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleDownload('equipment', 'xlsx')}
                    disabled={downloading !== null}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-success bg-success/10 hover:bg-success/15 rounded-lg transition-colors disabled:opacity-50"
                  >
                    <i className="ri-file-excel-line"></i> {downloading === 'equipment-xlsx' ? 'Mengunduh...' : 'Export XLSX'}
                  </button>
                  <button
                    onClick={() => handleDownload('equipment', 'pdf')}
                    disabled={downloading !== null}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-500/10 hover:bg-red-100 dark:hover:bg-red-500/15 rounded-lg transition-colors disabled:opacity-50"
                  >
                    <i className="ri-file-pdf-line"></i> {downloading === 'equipment-pdf' ? 'Mengunduh...' : 'Export PDF'}
                  </button>
                </div>
              )}
            </div>
            {equipmentInv.loading || equipmentInv.error || equipItems.length === 0 ? (
              <StateBlock loading={equipmentInv.loading} error={equipmentInv.error} empty={equipItems.length === 0} onRetry={fetchEquipment} />
            ) : (
              <div className="overflow-x-auto -mx-6">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-y border-black/10 dark:border-white/10">
                      {['Kategori', 'Total', 'Aktif', 'Perawatan', 'Rusak', 'Dibuang'].map((h) => (
                        <th key={h} className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {equipItems.map((e) => (
                      <tr key={e.category} className="border-b border-black/5 dark:border-white/5 hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors">
                        <td className="py-3 px-6 text-black/80 dark:text-white/80 font-medium whitespace-nowrap">{e.category}</td>
                        <td className="py-3 px-6 text-black/80 dark:text-white/80 font-bold whitespace-nowrap">{e.total}</td>
                        <td className="py-3 px-6 whitespace-nowrap">
                          <span className="inline-flex items-center gap-1 text-success font-medium"><i className="ri-checkbox-circle-line"></i> {e.active}</span>
                        </td>
                        <td className="py-3 px-6 whitespace-nowrap">
                          <span className="inline-flex items-center gap-1 text-warning font-medium"><i className="ri-tools-line"></i> {e.maintenance}</span>
                        </td>
                        <td className="py-3 px-6 whitespace-nowrap">
                          <span className="inline-flex items-center gap-1 text-red-600 dark:text-red-400 font-medium"><i className="ri-error-warning-line"></i> {e.broken}</span>
                        </td>
                        <td className="py-3 px-6 text-black/40 dark:text-white/40 whitespace-nowrap">{e.disposed}</td>
                      </tr>
                    ))}
                    <tr className="border-t border-black/10 dark:border-white/10 bg-black/[0.02] dark:bg-white/[0.02]">
                      <td className="py-3 px-6 font-bold text-black dark:text-white whitespace-nowrap">Total</td>
                      <td className="py-3 px-6 text-black/80 dark:text-white/80 font-bold whitespace-nowrap">{equipmentInv.data?.grand_total ?? 0}</td>
                      <td className="py-3 px-6 text-success font-bold whitespace-nowrap">{sumEquip('active')}</td>
                      <td className="py-3 px-6 text-warning font-bold whitespace-nowrap">{sumEquip('maintenance')}</td>
                      <td className="py-3 px-6 text-red-600 dark:text-red-400 font-bold whitespace-nowrap">{sumEquip('broken')}</td>
                      <td className="py-3 px-6 text-black/40 dark:text-white/40 font-bold whitespace-nowrap">{sumEquip('disposed')}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}
            <button
              onClick={() => navigate('/equipment')}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-primary bg-primary/5 hover:bg-primary/10 rounded-lg transition-colors"
            >
              <i className="ri-arrow-right-line"></i>
              Lihat Daftar Perangkat Lengkap
            </button>
          </div>
        )}
      </div>

      {toast && (
        <div className={`fixed top-4 right-4 z-[60] max-w-sm rounded-lg shadow-lg p-4 flex items-start gap-3 ${
          toast.type === 'success' ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20' :
            'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20'
        }`}>
          <div className="flex-shrink-0">
            {toast.type === 'success' ? <i className="ri-check-line text-lg text-green-600 dark:text-green-400"></i> :
              <i className="ri-error-warning-line text-lg text-red-600 dark:text-red-400"></i>}
          </div>
          <p className={`flex-1 text-sm font-medium ${toast.type === 'success' ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>
            {toast.message}
          </p>
          <button type="button" onClick={() => setToast(null)}
            className={`flex-shrink-0 transition-colors ${toast.type === 'success' ? 'text-green-400 hover:text-green-600' : 'text-red-400 hover:text-red-600'}`}>
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}
    </div>
  );
}
