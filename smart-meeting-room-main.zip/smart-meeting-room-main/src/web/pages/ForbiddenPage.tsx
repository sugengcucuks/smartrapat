import { useNavigate } from 'react-router-dom';

export function ForbiddenPage() {
  const navigate = useNavigate();
  return (
    <div className="flex flex-col items-center justify-center text-center py-24 px-4">
      <div className="w-16 h-16 rounded-2xl bg-danger/10 text-danger flex items-center justify-center mb-4">
        <i className="ri-lock-2-line text-3xl"></i>
      </div>
      <p className="text-sm font-semibold text-danger mb-1">403</p>
      <h1 className="text-2xl font-bold text-black dark:text-white">Akses Ditolak</h1>
      <p className="text-sm text-black/60 dark:text-white/60 mt-2 max-w-md">
        Anda tidak memiliki izin untuk membuka halaman ini. Hubungi administrator bila Anda memerlukan akses.
      </p>
      <button
        type="button"
        onClick={() => navigate('/dashboard')}
        className="mt-6 px-5 h-10 text-sm font-semibold text-white bg-primary hover:bg-primary/90 rounded-lg"
      >
        Kembali ke Dashboard
      </button>
    </div>
  );
}
