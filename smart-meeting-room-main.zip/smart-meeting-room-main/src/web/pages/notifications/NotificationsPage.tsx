import { useEffect, useState, useMemo } from 'react';
import { authApi } from '../../../shared/api/auth';
import type { Notification, NotificationType, UserResponse } from '@shared/types';
import { NOTIFICATION_TYPE_OPTIONS } from '@shared/types';
import { usePermission } from '../../store/auth.store';
import { getErrorMessage } from '../../../shared/api/client';

type FilterTab = 'all' | 'unread' | 'read';

// Tipe yang diterima backend untuk broadcast/kirim (schemas/notification.py).
const SENDABLE_TYPES = new Set(['info', 'success', 'warning', 'error']);
const SENDABLE_TYPE_OPTIONS = NOTIFICATION_TYPE_OPTIONS.filter((o) => SENDABLE_TYPES.has(o.value));

const NOTIFICATION_ICON_CLASS: Record<NotificationType, { icon: string; wrapper: string; iconColor: string }> = {
  info: { icon: 'ri-information-line', wrapper: 'bg-info/10', iconColor: 'text-info' },
  success: { icon: 'ri-check-line', wrapper: 'bg-success/10', iconColor: 'text-success' },
  warning: { icon: 'ri-error-warning-line', wrapper: 'bg-warning/10', iconColor: 'text-warning' },
  error: { icon: 'ri-close-line', wrapper: 'bg-red-100 dark:bg-red-500/10', iconColor: 'text-red-600 dark:text-red-400' },
  booking_request: { icon: 'ri-timer-line', wrapper: 'bg-warning/10', iconColor: 'text-warning' },
  booking_approved: { icon: 'ri-checkbox-circle-line', wrapper: 'bg-success/10', iconColor: 'text-success' },
  booking_rejected: { icon: 'ri-close-circle-line', wrapper: 'bg-red-100 dark:bg-red-500/10', iconColor: 'text-red-600 dark:text-red-400' },
  booking_cancelled: { icon: 'ri-calendar-close-line', wrapper: 'bg-gray-100 dark:bg-white/10', iconColor: 'text-gray-600 dark:text-white/60' },
  room_available: { icon: 'ri-door-open-line', wrapper: 'bg-primary/10', iconColor: 'text-primary' },
  system: { icon: 'ri-settings-3-line', wrapper: 'bg-primary/10', iconColor: 'text-primary' },
};

function formatRelativeTime(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Baru saja';
  if (mins < 60) return `${mins} menit lalu`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} jam lalu`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days} hari lalu`;
  const months = Math.floor(days / 30);
  if (months < 12) return `${months} bulan lalu`;
  return `${Math.floor(months / 12)} tahun lalu`;
}

function formatDateTime(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleString('id-ID', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function NotificationsPage() {
  const can = usePermission();
  const canSend = can('notifications.send');
  const [items, setItems] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [filterTab, setFilterTab] = useState<FilterTab>('all');
  const [page, setPage] = useState(1);
  const [perPage] = useState(20);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [unreadCount, setUnreadCount] = useState(0);

  const [detailModal, setDetailModal] = useState<Notification | null>(null);
  const [broadcastModal, setBroadcastModal] = useState(false);
  const [broadcastForm, setBroadcastForm] = useState<{
    type: NotificationType;
    title: string;
    message: string;
    send_to_all: boolean;
    user_ids: string[];
  }>({
    type: 'info',
    title: '',
    message: '',
    send_to_all: true,
    user_ids: [],
  });
  const [users, setUsers] = useState<UserResponse[]>([]);
  const [usersError, setUsersError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchData = async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const result = await authApi.listNotifications({
        page,
        limit: perPage,
        is_read: filterTab === 'unread' ? false : filterTab === 'read' ? true : undefined,
      });
      setItems(result.items ?? []);
      setTotal(result.total ?? 0);
      setTotalPages(result.total_pages ?? 0);
      setUnreadCount(result.unread_count ?? 0);
    } catch (err) {
      setItems([]);
      setLoadError(getErrorMessage(err, 'Gagal memuat notifikasi'));
    } finally {
      setLoading(false);
    }
  };

  const fetchUsers = async () => {
    setUsersError(null);
    try {
      const res = await authApi.listUsers({ per_page: 100 });
      setUsers(res.items ?? []);
    } catch (err) {
      setUsers([]);
      setUsersError(getErrorMessage(err, 'Gagal memuat daftar pengguna'));
    }
  };

  useEffect(() => {
    // Daftar penerima hanya diperlukan oleh pengirim notifikasi.
    if (canSend && can('users.view')) fetchUsers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canSend]);

  useEffect(() => {
    setPage(1);
    fetchData();
  }, [filterTab]);

  useEffect(() => {
    fetchData();
  }, [page]);

  const handleRowClick = async (item: Notification) => {
    if (!item.is_read) {
      try {
        await authApi.markRead(item.id);
        setItems((prev) =>
          prev.map((n) => (n.id === item.id ? { ...n, is_read: true, read_at: new Date().toISOString() } : n))
        );
        setUnreadCount((c) => Math.max(0, c - 1));
      } catch (err) {
        showToast('error', getErrorMessage(err, 'Gagal menandai notifikasi sebagai dibaca'));
        setDetailModal(item);
        return;
      }
    }
    setDetailModal({ ...item, is_read: true });
  };

  const handleMarkAllRead = async () => {
    try {
      const res = await authApi.markAllRead();
      showToast('success', `Berhasil menandai ${res?.marked_read ?? 0} notifikasi sebagai dibaca`);
      fetchData();
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal menandai semua notifikasi'));
    }
  };

  const handleDeleteRead = async () => {
    try {
      const res = await authApi.deleteReadNotifications();
      showToast('success', `Berhasil menghapus ${res?.deleted ?? 0} notifikasi`);
      setPage(1);
      fetchData();
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal menghapus notifikasi'));
    }
  };

  const handleRefresh = () => {
    setPage(1);
    fetchData();
  };

  const handleSendBroadcast = async () => {
    if (!broadcastForm.send_to_all && broadcastForm.user_ids.length === 0) {
      showToast('error', 'Pilih minimal satu penerima');
      return;
    }
    setSubmitting(true);
    try {
      const base = {
        type: broadcastForm.type,
        title: broadcastForm.title.trim(),
        message: broadcastForm.message.trim(),
      };
      if (broadcastForm.send_to_all) {
        const res = await authApi.broadcastNotification(base);
        showToast('success', `Notifikasi dikirim ke ${res?.broadcast_count ?? 0} pengguna`);
      } else {
        const res = await authApi.sendNotificationMany({ ...base, user_ids: broadcastForm.user_ids });
        showToast('success', `Notifikasi dikirim ke ${res?.sent_count ?? 0} pengguna`);
      }
      setBroadcastModal(false);
      setBroadcastForm({ type: 'info', title: '', message: '', send_to_all: true, user_ids: [] });
      fetchData();
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal mengirim notifikasi'));
    } finally {
      setSubmitting(false);
    }
  };

  const tabCounts = useMemo(() => {
    const totalAll = total;
    const unread = unreadCount;
    const read = totalAll - unread;
    return { all: totalAll, unread, read };
  }, [total, unreadCount]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold text-black dark:text-white">Pemberitahuan</h1>
          {unreadCount > 0 && (
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-500 text-white">
              {unreadCount} belum dibaca
            </span>
          )}
        </div>
        {canSend && (
          <button
            type="button"
            onClick={() => setBroadcastModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors shadow-sm"
          >
            <i className="ri-send-plane-line text-lg"></i>
            <span>Broadcast</span>
          </button>
        )}
      </div>

      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-5">
          <div className="flex gap-1 border-b border-black/10 dark:border-white/10 sm:border-none">
            {(['all', 'unread', 'read'] as FilterTab[]).map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setFilterTab(tab)}
                className={`relative px-4 py-2.5 text-sm font-medium transition-colors ${
                  filterTab === tab
                    ? 'text-primary'
                    : 'text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white'
                }`}
              >
                {tab === 'all' ? 'Semua' : tab === 'unread' ? 'Belum Dibaca' : 'Sudah Dibaca'}
                <span className="ml-1.5 inline-flex items-center justify-center min-w-5 h-5 px-1.5 rounded-full text-xs font-semibold bg-black/5 dark:bg-white/10 text-black/60 dark:text-white/60">
                  {tabCounts[tab]}
                </span>
                {filterTab === tab && (
                  <span className="absolute left-0 right-0 -bottom-px sm:bottom-0 h-0.5 bg-primary rounded-t"></span>
                )}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleMarkAllRead}
              disabled={unreadCount === 0}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-primary bg-primary/5 hover:bg-primary/10 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <i className="ri-check-double-line"></i>
              <span>Tandai Semua Dibaca</span>
            </button>
            <button
              type="button"
              onClick={handleDeleteRead}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-500/10 hover:bg-red-100 dark:hover:bg-red-500/20 rounded-lg transition-colors"
            >
              <i className="ri-delete-bin-line"></i>
              <span>Hapus Sudah Dibaca</span>
            </button>
            <button
              type="button"
              onClick={handleRefresh}
              className="p-2 text-black/60 dark:text-white/60 hover:text-primary hover:bg-primary/5 rounded-lg transition-colors"
              title="Refresh"
            >
              <i className="ri-refresh-line text-lg"></i>
            </button>
          </div>
        </div>

        <div className="space-y-1">
          {loading ? (
            <div className="py-16 text-center text-black/50 dark:text-white/50">
              <div className="inline-flex items-center gap-2">
                <svg className="animate-spin h-5 w-5 text-primary" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                <span>Memuat notifikasi...</span>
              </div>
            </div>
          ) : loadError ? (
            <div className="py-16 text-center">
              <p className="text-sm text-red-600 dark:text-red-400">{loadError}</p>
              <button
                type="button"
                onClick={fetchData}
                className="mt-3 inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-primary bg-primary/10 hover:bg-primary/15 rounded-lg"
              >
                <i className="ri-refresh-line"></i> Coba Lagi
              </button>
            </div>
          ) : items.length === 0 ? (
            <div className="py-16 text-center text-black/50 dark:text-white/50">
              <div className="flex flex-col items-center gap-2">
                <i className="ri-notification-off-line text-5xl text-black/20 dark:text-white/20"></i>
                <span>Tidak ada notifikasi</span>
              </div>
            </div>
          ) : (
            items.map((item) => {
              const style = NOTIFICATION_ICON_CLASS[item.type] || NOTIFICATION_ICON_CLASS.info;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleRowClick(item)}
                  className={`w-full text-left flex items-start gap-3 px-4 py-3.5 rounded-lg hover:bg-black/[0.03] dark:hover:bg-white/[0.03] transition-colors border-b border-black/5 dark:border-white/5 last:border-b-0 ${
                    !item.is_read ? 'bg-primary/[0.02] dark:bg-primary/[0.05]' : ''
                  }`}
                >
                  <div className={`w-10 h-10 rounded-full ${style.wrapper} flex items-center justify-center shrink-0`}>
                    <i className={`${style.icon} text-lg ${style.iconColor}`}></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <h3 className={`text-sm ${!item.is_read ? 'font-bold text-black dark:text-white' : 'font-normal text-black/80 dark:text-white/80'} truncate`}>
                          {item.title}
                        </h3>
                        <p className="text-sm text-black/60 dark:text-white/60 mt-0.5 line-clamp-1">
                          {item.message}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {!item.is_read && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-primary text-white whitespace-nowrap">
                            Belum Dibaca
                          </span>
                        )}
                        <span className="text-xs text-black/40 dark:text-white/40 whitespace-nowrap">
                          {formatRelativeTime(item.created_at)}
                        </span>
                      </div>
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>

        {totalPages > 1 && (
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-6 pt-4 border-t border-black/10 dark:border-white/10">
            <p className="text-sm text-black/60 dark:text-white/60">
              Menampilkan {((page - 1) * perPage) + 1} - {Math.min(page * perPage, total)} dari {total} data
            </p>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <i className="ri-arrow-left-s-line"></i>
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPage(p)}
                  className={`w-9 h-9 rounded-lg text-sm font-medium transition-colors ${
                    p === page
                      ? 'bg-primary text-white shadow-sm'
                      : 'text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5'
                  }`}
                >
                  {p}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <i className="ri-arrow-right-s-line"></i>
              </button>
            </div>
          </div>
        )}
      </div>

      {detailModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setDetailModal(null)}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-xl max-h-[90vh] overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">Detail Notifikasi</h2>
              <button
                type="button"
                onClick={() => setDetailModal(null)}
                className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <div className="px-6 py-5 overflow-y-auto space-y-4">
              <div className="flex items-start gap-3">
                <div className={`w-12 h-12 rounded-full ${NOTIFICATION_ICON_CLASS[detailModal.type]?.wrapper || 'bg-info/10'} flex items-center justify-center shrink-0`}>
                  <i className={`${NOTIFICATION_ICON_CLASS[detailModal.type]?.icon || 'ri-information-line'} text-xl ${NOTIFICATION_ICON_CLASS[detailModal.type]?.iconColor || 'text-info'}`}></i>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-base font-bold text-black dark:text-white">{detailModal.title}</h3>
                  <p className="text-xs text-black/50 dark:text-white/50 mt-1">
                    Tipe: {NOTIFICATION_TYPE_OPTIONS.find((o) => o.value === detailModal.type)?.label || detailModal.type}
                  </p>
                </div>
              </div>
              <div className="p-4 rounded-lg bg-black/[0.03] dark:bg-white/[0.03]">
                <p className="text-sm text-black/80 dark:text-white/80 whitespace-pre-wrap leading-relaxed">
                  {detailModal.message}
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-black/50 dark:text-white/50">Waktu Dibuat:</span>
                  <p className="text-black/80 dark:text-white/80 font-medium mt-0.5">{formatDateTime(detailModal.created_at)}</p>
                </div>
                <div>
                  <span className="text-black/50 dark:text-white/50">Status:</span>
                  <p className="text-black/80 dark:text-white/80 font-medium mt-0.5">
                    {detailModal.is_read ? (
                      <span className="inline-flex items-center gap-1 text-success">
                        <i className="ri-check-double-line"></i> Sudah dibaca
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-primary">
                        <i className="ri-checkbox-blank-circle-fill text-[8px]"></i> Belum dibaca
                      </span>
                    )}
                  </p>
                </div>
              </div>
              {detailModal.data && Object.keys(detailModal.data).length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold text-black/70 dark:text-white/70 mb-2">Data Tambahan</h4>
                  <pre className="p-4 rounded-lg bg-black/[0.03] dark:bg-white/[0.03] text-xs text-black/80 dark:text-white/80 overflow-x-auto">
                    {JSON.stringify(detailModal.data, null, 2)}
                  </pre>
                </div>
              )}
            </div>
            <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex items-center justify-end">
              <button
                type="button"
                onClick={() => setDetailModal(null)}
                className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {broadcastModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setBroadcastModal(false)}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-xl max-h-[90vh] overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">Kirim Notifikasi</h2>
              <button
                type="button"
                onClick={() => setBroadcastModal(false)}
                className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <div className="px-6 py-5 overflow-y-auto space-y-4">
              <div>
                <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                  Tipe Notifikasi
                </label>
                <select
                  value={broadcastForm.type}
                  onChange={(e) => setBroadcastForm({ ...broadcastForm, type: e.target.value as NotificationType })}
                  className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                >
                  {SENDABLE_TYPE_OPTIONS.map((o) => (
                    <option key={o.value} value={o.value}>{o.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                  Judul <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={broadcastForm.title}
                  onChange={(e) => setBroadcastForm({ ...broadcastForm, title: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                  placeholder="Masukkan judul notifikasi"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                  Pesan <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={4}
                  required
                  value={broadcastForm.message}
                  onChange={(e) => setBroadcastForm({ ...broadcastForm, message: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 resize-none"
                  placeholder="Masukkan isi pesan notifikasi"
                />
              </div>
              <div>
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={broadcastForm.send_to_all}
                    onChange={(e) => setBroadcastForm({ ...broadcastForm, send_to_all: e.target.checked, user_ids: [] })}
                  />
                  <div className="relative w-11 h-6 bg-black/15 dark:bg-white/15 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-success"></div>
                  <span className="text-sm font-medium text-black/80 dark:text-white/80">Kirim ke Semua Pengguna</span>
                </label>
              </div>
              {!broadcastForm.send_to_all && (
                <div>
                  <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                    Pilih Penerima
                  </label>
                  <div className="max-h-48 overflow-y-auto border border-black/10 dark:border-white/10 rounded-lg p-2 space-y-1">
                    {usersError && <p className="p-2 text-xs text-red-600 dark:text-red-400">{usersError}</p>}
                    {!usersError && users.length === 0 && (
                      <p className="p-2 text-xs text-black/50 dark:text-white/50">Belum ada data pengguna</p>
                    )}
                    {users.map((u) => (

                      <label key={u.id} className="flex items-center gap-2 p-2 rounded-md hover:bg-black/[0.03] dark:hover:bg-white/[0.03] cursor-pointer">
                        <input
                          type="checkbox"
                          checked={broadcastForm.user_ids.includes(u.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setBroadcastForm({ ...broadcastForm, user_ids: [...broadcastForm.user_ids, u.id] });
                            } else {
                              setBroadcastForm({ ...broadcastForm, user_ids: broadcastForm.user_ids.filter((id) => id !== u.id) });
                            }
                          }}
                          className="w-4 h-4 rounded border-black/20 dark:border-white/20 text-primary focus:ring-primary"
                        />
                        <div>
                          <p className="text-sm font-medium text-black/80 dark:text-white/80">{u.name}</p>
                          <p className="text-xs text-black/50 dark:text-white/50">{u.email}</p>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setBroadcastModal(false)}
                disabled={submitting}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors disabled:opacity-50"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleSendBroadcast}
                disabled={submitting || !broadcastForm.title || !broadcastForm.message || (!broadcastForm.send_to_all && broadcastForm.user_ids.length === 0)}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submitting && (
                  <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                )}
                <i className="ri-send-plane-line"></i>
                <span>Kirim</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className={`fixed top-4 right-4 z-[60] max-w-sm rounded-lg shadow-lg p-4 flex items-start gap-3 ${
          toast.type === 'success'
            ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20'
            : 'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20'
        }`}>
          <div className="flex-shrink-0">
            {toast.type === 'success' ? (
              <i className="ri-check-line text-lg text-green-600 dark:text-green-400"></i>
            ) : (
              <i className="ri-error-warning-line text-lg text-red-600 dark:text-red-400"></i>
            )}
          </div>
          <p className={`flex-1 text-sm font-medium ${toast.type === 'success' ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>
            {toast.message}
          </p>
          <button
            type="button"
            onClick={() => setToast(null)}
            className={`flex-shrink-0 transition-colors ${toast.type === 'success' ? 'text-green-400 hover:text-green-600' : 'text-red-400 hover:text-red-600'}`}
          >
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}
    </div>
  );
}
