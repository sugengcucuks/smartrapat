import { useEffect, useState, useMemo } from 'react';
import { authApi } from '../../../shared/api/auth';
import { getErrorMessage } from '../../../shared/api/client';
import { usePermission } from '../../store/auth.store';
import type { AuditLog, AuditStatsSummary, AuditModule, AuditAction, UserResponse } from '@shared/types';
import { AUDIT_MODULE_OPTIONS, AUDIT_ACTION_OPTIONS } from '@shared/types';

/** Ringkas user-agent menjadi "Browser / OS" bila backend tidak mengirim field terpisah. */
function shortUserAgent(ua?: string): { browser: string; os: string } {
  if (!ua) return { browser: '-', os: '' };
  const browser =
    /Edg\/(\d+)/.exec(ua)?.[0]?.replace('Edg/', 'Edge ') ||
    /Firefox\/(\d+)/.exec(ua)?.[0]?.replace('/', ' ') ||
    /Chrome\/(\d+)/.exec(ua)?.[0]?.replace('/', ' ') ||
    (/Safari\//.test(ua) ? 'Safari' : ua.slice(0, 30));
  const os = /Windows NT/.test(ua) ? 'Windows' : /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iOS' : /Mac OS X/.test(ua) ? 'macOS' : /Linux/.test(ua) ? 'Linux' : '';
  return { browser, os };
}

function formatAuditTime(dateStr: string): string {
  return new Date(dateStr).toLocaleString('id-ID', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

const MODULE_COLORS: Record<AuditModule, string> = {
  auth: 'bg-purple-100 text-purple-700 dark:bg-purple-500/10 dark:text-purple-400',
  users: 'bg-blue-100 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400',
  roles: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-400',
  rooms: 'bg-teal-100 text-teal-700 dark:bg-teal-500/10 dark:text-teal-400',
  buildings: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-500/10 dark:text-cyan-400',
  bookings: 'bg-primary/10 text-primary',
  equipment: 'bg-orange-100 text-orange-700 dark:bg-orange-500/10 dark:text-orange-400',
  devices: 'bg-info/10 text-info',
  settings: 'bg-warning/10 text-warning',
  notes: 'bg-green-100 text-green-700 dark:bg-green-500/10 dark:text-green-400',
  system: 'bg-red-100 text-red-700 dark:bg-red-500/10 dark:text-red-400',
};

const ACTION_COLORS: Record<AuditAction, string> = {
  create: 'bg-green-100 text-green-700 dark:bg-green-500/10 dark:text-green-400',
  update: 'bg-blue-100 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400',
  delete: 'bg-red-100 text-red-700 dark:bg-red-500/10 dark:text-red-400',
  login: 'bg-purple-100 text-purple-700 dark:bg-purple-500/10 dark:text-purple-400',
  logout: 'bg-gray-100 text-gray-700 dark:bg-gray-500/10 dark:text-gray-400',
  approve: 'bg-green-100 text-green-700 dark:bg-green-500/10 dark:text-green-400',
  reject: 'bg-red-100 text-red-700 dark:bg-red-500/10 dark:text-red-400',
  export: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-400',
  import: 'bg-orange-100 text-orange-700 dark:bg-orange-500/10 dark:text-orange-400',
  other: 'bg-gray-100 text-gray-700 dark:bg-gray-500/10 dark:text-gray-400',
};

export function AuditLogsPage() {
  const can = usePermission();
  const [items, setItems] = useState<AuditLog[]>([]);
  const [stats, setStats] = useState<AuditStatsSummary | null>(null);
  const [statsError, setStatsError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [users, setUsers] = useState<UserResponse[]>([]);

  const [filterUser, setFilterUser] = useState('');
  const [filterModule, setFilterModule] = useState('');
  const [filterAction, setFilterAction] = useState('');
  const [filterTarget, setFilterTarget] = useState('');
  const [filterDateFrom, setFilterDateFrom] = useState('');
  const [filterDateTo, setFilterDateTo] = useState('');

  const [page, setPage] = useState(1);
  const [perPage] = useState(20);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  const [detailModal, setDetailModal] = useState<AuditLog | null>(null);

  const fetchData = async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const data = await authApi.listAuditLogs({
        page,
        per_page: perPage,
        user_id: filterUser || undefined,
        module: filterModule || undefined,
        action: filterAction || undefined,
        target_type: filterTarget.trim() || undefined,
        // Backend memfilter timestamp: batas akhir = akhir hari yang dipilih.
        from_date: filterDateFrom ? `${filterDateFrom}T00:00:00` : undefined,
        to_date: filterDateTo ? `${filterDateTo}T23:59:59` : undefined,
      });
      setItems(data.items ?? []);
      setTotal(data.total ?? 0);
      setTotalPages(data.total_pages ?? 0);
    } catch (err) {
      setItems([]);
      setTotal(0);
      setTotalPages(0);
      setLoadError(getErrorMessage(err, 'Gagal memuat log audit'));
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    setStatsError(null);
    try {
      const data = await authApi.getAuditStatsSummary();
      setStats(data);
    } catch (err) {
      setStats(null);
      setStatsError(getErrorMessage(err, 'Gagal memuat statistik'));
    }
  };

  const fetchUsers = async () => {
    try {
      const res = await authApi.listUsers({ per_page: 100 });
      setUsers(res.items ?? []);
    } catch {
      // Filter pengguna opsional; biarkan kosong bila tidak berizin.
      setUsers([]);
    }
  };

  useEffect(() => {
    fetchStats();
    if (can('users.view')) fetchUsers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    fetchData();
  }, [page, filterUser, filterModule, filterAction, filterTarget, filterDateFrom, filterDateTo]);

  const safeTopModules = stats?.per_module ?? [];
  const safeTopUsers = stats?.top_users ?? [];
  const topModName = safeTopModules[0]?.module;
  const topModLabel = AUDIT_MODULE_OPTIONS.find((o) => o.value === topModName)?.label || topModName || '-';

  const topUserMax = Math.max(...safeTopUsers.map((u) => u.count), 1);

  const pageNumbers = useMemo(() => {
    const pages: (number | string)[] = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else if (page <= 4) {
      pages.push(1, 2, 3, 4, 5, '...', totalPages);
    } else if (page >= totalPages - 3) {
      pages.push(1, '...', totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages);
    } else {
      pages.push(1, '...', page - 1, page, page + 1, '...', totalPages);
    }
    return pages;
  }, [page, totalPages]);

  const jsonPretty = (v: unknown) => {
    if (v === undefined || v === null) return '-';
    try {
      return JSON.stringify(typeof v === 'string' ? JSON.parse(v) : v, null, 2);
    } catch {
      return String(v);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-black dark:text-white">Log Audit Aktivitas</h1>
        <p className="text-sm text-black/60 dark:text-white/60 mt-1">
          Rekam jejak lengkap semua aksi pengguna dalam sistem
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6 flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
            <i className="ri-file-list-3-line text-2xl text-primary"></i>
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm text-black/60 dark:text-white/60">Total Logs (30 Hari)</p>
            <h3 className="text-2xl font-bold text-black dark:text-white">
              {stats ? stats.total_logs_30d.toLocaleString('id-ID') : '-'}
            </h3>
            {statsError && (
              <button type="button" onClick={fetchStats} className="text-xs text-red-600 dark:text-red-400 underline">
                {statsError} — coba lagi
              </button>
            )}
          </div>
        </div>

        <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6 flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-warning/10 flex items-center justify-center shrink-0">
            <i className="ri-stack-line text-2xl text-warning"></i>
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm text-black/60 dark:text-white/60">Modul Terbanyak</p>
            <h3 className="text-2xl font-bold text-black dark:text-white">{topModLabel}</h3>
            <p className="text-xs text-black/40 dark:text-white/40 mt-0.5">
              {safeTopModules[0]?.count?.toLocaleString('id-ID') || 0} aksi
            </p>
          </div>
        </div>

        <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-success/10 flex items-center justify-center shrink-0">
              <i className="ri-user-star-line text-xl text-success"></i>
            </div>
            <div>
              <p className="text-sm text-black/60 dark:text-white/60">Top 5 User Aktif</p>
            </div>
          </div>
          <div className="space-y-2">
            {safeTopUsers.length === 0 && (
              <p className="text-xs text-black/50 dark:text-white/50">Belum ada data</p>
            )}
            {safeTopUsers.slice(0, 5).map((u, i) => (
              <div key={u.user_id} className="flex items-center gap-2">
                <span className="w-4 text-xs text-black/40 dark:text-white/40 font-medium">{i + 1}.</span>
                <div className="flex-1 h-2 bg-black/5 dark:bg-white/5 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-primary to-success rounded-full transition-all"
                    style={{ width: `${(u.count / topUserMax) * 100}%` }}
                  ></div>
                </div>
                <span className="w-20 text-xs text-black/60 dark:text-white/60 truncate">{u.user_name}</span>
                <span className="w-10 text-xs font-semibold text-black/80 dark:text-white/80 text-right">{u.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
        <div className="flex flex-col gap-3 mb-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <select
              value={filterUser}
              onChange={(e) => { setFilterUser(e.target.value); setPage(1); }}
              className="px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
            >
              <option value="">Semua User</option>
              {users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
            </select>
            <select
              value={filterModule}
              onChange={(e) => { setFilterModule(e.target.value); setPage(1); }}
              className="px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
            >
              <option value="">Semua Modul</option>
              {AUDIT_MODULE_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
            <select
              value={filterAction}
              onChange={(e) => { setFilterAction(e.target.value); setPage(1); }}
              className="px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
            >
              <option value="">Semua Aksi</option>
              {AUDIT_ACTION_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
            <input
              type="text"
              placeholder="Tipe target persis (contoh: booking)"
              value={filterTarget}
              onChange={(e) => { setFilterTarget(e.target.value); setPage(1); }}
              className="px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 placeholder:text-black/40 dark:placeholder:text-white/40"
            />
          </div>
          <div className="flex flex-wrap gap-3 items-center">
            <div className="flex items-center gap-2">
              <label className="text-sm text-black/60 dark:text-white/60 shrink-0">Dari:</label>
              <input
                type="date"
                value={filterDateFrom}
                onChange={(e) => { setFilterDateFrom(e.target.value); setPage(1); }}
                className="px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
              />
            </div>
            <div className="flex items-center gap-2">
              <label className="text-sm text-black/60 dark:text-white/60 shrink-0">Sampai:</label>
              <input
                type="date"
                value={filterDateTo}
                onChange={(e) => { setFilterDateTo(e.target.value); setPage(1); }}
                className="px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
              />
            </div>
            <button
              onClick={() => {
                setFilterUser(''); setFilterModule(''); setFilterAction('');
                setFilterTarget(''); setFilterDateFrom(''); setFilterDateTo('');
                setPage(1);
              }}
              className="ml-auto inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors"
            >
              <i className="ri-filter-off-line"></i> Reset Filter
            </button>
          </div>
        </div>

        <div className="overflow-x-auto -mx-6">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-y border-black/10 dark:border-white/10">
                {['Waktu', 'User', 'Modul', 'Aksi', 'Target', 'IP Address', 'Browser', ''].map((h) => (
                  <th key={h} className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-black/50 dark:text-white/50">
                    <div className="inline-flex items-center gap-2">
                      <svg className="animate-spin h-5 w-5 text-primary" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      <span>Memuat data...</span>
                    </div>
                  </td>
                </tr>
              ) : loadError ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center">
                    <p className="text-sm text-red-600 dark:text-red-400">{loadError}</p>
                    <button
                      type="button"
                      onClick={fetchData}
                      className="mt-3 inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-primary bg-primary/10 hover:bg-primary/15 rounded-lg"
                    >
                      <i className="ri-refresh-line"></i> Coba Lagi
                    </button>
                  </td>
                </tr>
              ) : items.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-black/50 dark:text-white/50">
                    <div className="flex flex-col items-center gap-2">
                      <i className="ri-file-search-line text-4xl text-black/30 dark:text-white/30"></i>
                      <span>Belum ada data</span>
                    </div>
                  </td>
                </tr>
              ) : (
                items.map((log) => (
                  <tr
                    key={log.id}
                    onClick={() => setDetailModal(log)}
                    className="border-b border-black/5 dark:border-white/5 hover:bg-black/[0.02] dark:hover:bg-white/[0.02] cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap">{formatAuditTime(log.timestamp)}</td>
                    <td className="py-3 px-6 text-black/80 dark:text-white/80 font-medium whitespace-nowrap">{log.user_name || '-'}</td>
                    <td className="py-3 px-6 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${MODULE_COLORS[log.module] || MODULE_COLORS.system}`}>
                        {AUDIT_MODULE_OPTIONS.find((o) => o.value === log.module)?.label || log.module}
                      </span>
                    </td>
                    <td className="py-3 px-6 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${ACTION_COLORS[log.action] || ACTION_COLORS.other}`}>
                        {AUDIT_ACTION_OPTIONS.find((o) => o.value === log.action)?.label || log.action}
                      </span>
                    </td>
                    <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap">
                      {log.target_type || '-'} {log.target_id ? <span className="text-black/40 dark:text-white/40 font-mono text-xs">#{log.target_id.slice(0, 8)}</span> : ''}
                    </td>
                    <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap font-mono text-xs">{log.ip_address || '-'}</td>
                    <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap text-xs">
                      <div>{log.browser || shortUserAgent(log.user_agent).browser}</div>
                      <div className="text-black/40 dark:text-white/40">{log.os || shortUserAgent(log.user_agent).os}</div>
                    </td>
                    <td className="py-3 px-6">
                      <button
                        type="button"
                        title="Lihat detail"
                        onClick={(e) => {
                          e.stopPropagation();
                          setDetailModal(log);
                        }}
                        className="p-1.5 text-black/40 dark:text-white/40 hover:text-primary hover:bg-primary/5 rounded transition-colors"
                      >

                        <i className="ri-eye-line"></i>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {totalPages > 0 && (
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-6 pt-4 border-t border-black/10 dark:border-white/10">
            <p className="text-sm text-black/60 dark:text-white/60">
              Menampilkan {((page - 1) * perPage) + 1} - {Math.min(page * perPage, total)} dari {total} data
            </p>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <i className="ri-arrow-left-s-line"></i>
              </button>
              {pageNumbers.map((p, idx) =>
                typeof p === 'number' ? (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setPage(p)}
                    className={`w-9 h-9 rounded-lg text-sm font-medium transition-colors ${
                      p === page ? 'bg-primary text-white shadow-sm' : 'text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5'
                    }`}
                  >
                    {p}
                  </button>
                ) : (
                  <span key={idx} className="w-9 h-9 flex items-center justify-center text-sm text-black/40 dark:text-white/40">{p}</span>
                )
              )}
              <button
                type="button"
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <i className="ri-arrow-right-s-line"></i>
              </button>
            </div>
          </div>
        )}
      </div>

      {detailModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setDetailModal(null)}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">Detail Log Audit</h2>
              <button
                type="button"
                onClick={() => setDetailModal(null)}
                className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <div className="px-6 py-5 overflow-y-auto space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-black/[0.02] dark:bg-white/[0.02] rounded-lg">
                <div>
                  <span className="text-xs text-black/50 dark:text-white/50">Waktu</span>
                  <p className="text-sm text-black/80 dark:text-white/80 font-medium mt-0.5">{formatAuditTime(detailModal.timestamp)}</p>
                </div>
                <div>
                  <span className="text-xs text-black/50 dark:text-white/50">User</span>
                  <p className="text-sm text-black/80 dark:text-white/80 font-medium mt-0.5">{detailModal.user_name || '-'}</p>
                </div>
                <div>
                  <span className="text-xs text-black/50 dark:text-white/50">Modul / Aksi</span>
                  <p className="text-sm mt-0.5">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium mr-2 ${MODULE_COLORS[detailModal.module] || ''}`}>
                      {AUDIT_MODULE_OPTIONS.find((o) => o.value === detailModal.module)?.label || detailModal.module}
                    </span>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${ACTION_COLORS[detailModal.action] || ''}`}>
                      {AUDIT_ACTION_OPTIONS.find((o) => o.value === detailModal.action)?.label || detailModal.action}
                    </span>
                  </p>
                </div>
                <div>
                  <span className="text-xs text-black/50 dark:text-white/50">Target</span>
                  <p className="text-sm text-black/80 dark:text-white/80 font-medium mt-0.5">
                    {detailModal.target_type || '-'} {detailModal.target_id && <span className="text-black/40 font-mono text-xs">#{detailModal.target_id}</span>}
                  </p>
                </div>
                <div>
                  <span className="text-xs text-black/50 dark:text-white/50">IP Address</span>
                  <p className="text-sm text-black/80 dark:text-white/80 font-mono mt-0.5">{detailModal.ip_address || '-'}</p>
                </div>
                <div>
                  <span className="text-xs text-black/50 dark:text-white/50">Browser / OS</span>
                  <p className="text-sm text-black/80 dark:text-white/80 mt-0.5">{detailModal.browser || '-'}{detailModal.os ? ` · ${detailModal.os}` : ''}</p>
                </div>
                {detailModal.description && (
                  <div className="sm:col-span-2">
                    <span className="text-xs text-black/50 dark:text-white/50">Deskripsi</span>
                    <p className="text-sm text-black/80 dark:text-white/80 mt-0.5">{detailModal.description}</p>
                  </div>
                )}
                {detailModal.user_agent && (
                  <div className="sm:col-span-2">
                    <span className="text-xs text-black/50 dark:text-white/50">User Agent Lengkap</span>
                    <p className="text-xs text-black/60 dark:text-white/60 font-mono bg-black/[0.03] dark:bg-white/[0.03] p-2 rounded mt-1 break-all">
                      {detailModal.user_agent}
                    </p>
                  </div>
                )}
              </div>

              {(detailModal.old_value !== undefined || detailModal.new_value !== undefined) && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-semibold text-red-600 dark:text-red-400 mb-2 flex items-center gap-1.5">
                      <i className="ri-arrow-left-circle-line"></i> Nilai Sebelumnya (old_value)
                    </h4>
                    <pre className="p-4 rounded-lg bg-red-50 dark:bg-red-500/5 border border-red-100 dark:border-red-500/10 text-xs text-black/80 dark:text-white/80 overflow-x-auto min-h-[140px]">
{jsonPretty(detailModal.old_value)}
                    </pre>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-green-600 dark:text-green-400 mb-2 flex items-center gap-1.5">
                      <i className="ri-arrow-right-circle-line"></i> Nilai Sesudah (new_value)
                    </h4>
                    <pre className="p-4 rounded-lg bg-green-50 dark:bg-green-500/5 border border-green-100 dark:border-green-500/10 text-xs text-black/80 dark:text-white/80 overflow-x-auto min-h-[140px]">
{jsonPretty(detailModal.new_value)}
                    </pre>
                  </div>
                </div>
              )}
            </div>
            <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex items-center justify-end">
              <button
                type="button"
                onClick={() => setDetailModal(null)}
                className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
