import { useCallback, useEffect, useState } from 'react';
import { authApi } from '../../../shared/api/auth';
import type { AudioZone, AudioZoneCommandResult, AudioZoneSource, Device } from '@shared/types';
import { AUDIO_ZONE_SOURCE_OPTIONS } from '@shared/types';
import { MicMixerPanel } from '../../components/av/MicMixerPanel';
import { AudioChannelEditor } from '../../components/av/AudioChannelEditor';
import { RoomSelect, useRoomSelection } from '../../components/av/RoomSelect';
import { CommandBadge, CommandDetail } from '../../components/av/CommandFeedback';
import { apiErrorMessage, hasPermission, useAvCommands } from '../../components/av/avUtils';
import { useAuthStore } from '../../store/auth.store';

type Tab = 'mixer' | 'channels' | 'zones';

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: 'mixer', label: 'Mic & Mixer', icon: 'ri-mic-line' },
  { id: 'channels', label: 'Kanal Mic', icon: 'ri-list-settings-line' },
  { id: 'zones', label: 'Zona Speaker', icon: 'ri-speaker-2-line' },
];

function ZonesSection({ roomId }: { roomId: string }) {
  const user = useAuthStore((s) => s.user);
  const canControl = hasPermission(user, 'audio.control');
  const canEdit = hasPermission(user, 'audio.control', 'devices.write');
  const [zones, setZones] = useState<AudioZone[]>([]);
  const [devices, setDevices] = useState<Device[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [draftVol, setDraftVol] = useState<Record<string, number>>({});
  const [newName, setNewName] = useState('');
  const [newDevice, setNewDevice] = useState('');
  const { states, run, busy } = useAvCommands();

  const load = useCallback(async () => {
    setError(null);
    try {
      const [z, d] = await Promise.all([
        authApi.listAudioZones({ room_id: roomId }),
        authApi.listDevices({ room_id: roomId, per_page: 100 }).catch(() => null),
      ]);
      setZones(z);
      setDraftVol({});
      setDevices((d?.items || []).filter((x) => x.device_type === 'audio_mixer' || x.device_type === 'audio_processor'));
    } catch (err) {
      setError(apiErrorMessage(err, 'Gagal memuat zona audio'));
    }
  }, [roomId]);

  useEffect(() => {
    load();
  }, [load]);

  const afterCommand = async (key: string, fn: () => Promise<AudioZoneCommandResult>) => {
    const res = await run(key, fn);
    if (res && res.status === 'acked') load();
  };

  const addZone = async () => {
    if (!newName.trim()) return;
    setError(null);
    try {
      await authApi.createAudioZone({ room_id: roomId, zone_name: newName.trim(), device_id: newDevice || null });
      setNewName('');
      setNewDevice('');
      load();
    } catch (err) {
      setError(apiErrorMessage(err, 'Gagal menambah zona'));
    }
  };

  const removeZone = async (z: AudioZone) => {
    if (!window.confirm(`Hapus zona "${z.zone_name}"?`)) return;
    try {
      await authApi.deleteAudioZone(z.id);
      load();
    } catch (err) {
      setError(apiErrorMessage(err, 'Gagal menghapus zona'));
    }
  };

  const lastState = Object.values(states).sort((a, b) => b.at - a.at)[0];

  return (
    <section className="bg-white dark:bg-gray rounded-lg shadow-md p-5 space-y-4">
      <div>
        <h2 className="text-lg font-bold text-black dark:text-white">Zona Speaker</h2>
        <p className="text-xs text-black/60 dark:text-white/60 mt-0.5">
          Zona hanya bisa dikontrol bila terhubung ke perangkat (mixer digital / audio processor).
          Amplifier analog (FC-A5400) diatur manual.
        </p>
      </div>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <CommandDetail state={lastState} />
      {zones.length === 0 ? (
        <p className="text-sm text-black/50 dark:text-white/50">Belum ada zona di ruangan ini.</p>
      ) : (
        <ul className="space-y-3">
          {zones.map((z) => {
            const vol = draftVol[z.id] ?? z.volume;
            const controllable = canControl && !!z.device_id;
            return (
              <li key={z.id} className="p-4 border border-black/10 dark:border-white/10 rounded-lg space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-semibold text-sm text-black dark:text-white">{z.zone_name}</p>
                    <p className="text-xs text-black/50 dark:text-white/50">{z.device_name || 'Tidak terhubung perangkat (manual)'}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <CommandBadge state={states[`z-${z.id}`]} />
                    <button type="button" disabled={!controllable || busy}
                      onClick={() => afterCommand(`z-${z.id}`, () => authApi.setZoneMute(z.id, !z.is_muted))}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold disabled:opacity-50 ${z.is_muted ? 'bg-red-600 text-white' : 'bg-black/5 dark:bg-white/10 text-black/70 dark:text-white/70'}`}>
                      {z.is_muted ? 'MUTED' : 'Mute'}
                    </button>
                    {canEdit && (
                      <button type="button" title="Hapus" onClick={() => removeZone(z)}
                        className="p-1.5 text-black/50 dark:text-white/50 hover:text-red-600 rounded">
                        <i className="ri-delete-bin-line"></i>
                      </button>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <i className="ri-volume-down-line text-black/40 dark:text-white/40"></i>
                  <input type="range" min={0} max={100} value={vol} disabled={!controllable || busy}
                    onChange={(e) => setDraftVol((d) => ({ ...d, [z.id]: Number(e.target.value) }))}
                    onPointerUp={() => afterCommand(`z-${z.id}`, () => authApi.setZoneVolume(z.id, vol))}
                    onKeyUp={() => afterCommand(`z-${z.id}`, () => authApi.setZoneVolume(z.id, vol))}
                    className="flex-1 accent-primary disabled:opacity-50" />
                  <span className="text-xs text-black/60 dark:text-white/60 w-10 text-right">{vol}%</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {AUDIO_ZONE_SOURCE_OPTIONS.map((o) => (
                    <button key={o.value} type="button" disabled={!controllable || busy}
                      onClick={() => afterCommand(`z-${z.id}`, () => authApi.setZoneSource(z.id, o.value as AudioZoneSource))}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border disabled:opacity-50 ${
                        z.input_source === o.value
                          ? 'bg-primary text-white border-primary'
                          : 'bg-black/5 dark:bg-black/40 border-black/10 dark:border-white/10 text-black/70 dark:text-white/70'
                      }`}>
                      {o.label}
                    </button>
                  ))}
                </div>
              </li>
            );
          })}
        </ul>
      )}
      {canEdit && (
        <div className="flex flex-col sm:flex-row gap-2 pt-2 border-t border-black/10 dark:border-white/10">
          <input type="text" placeholder="Nama zona baru" value={newName} onChange={(e) => setNewName(e.target.value)} maxLength={100}
            className="flex-1 px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary dark:text-white/80" />
          <select value={newDevice} onChange={(e) => setNewDevice(e.target.value)}
            className="sm:w-56 px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none dark:text-white/80">
            <option value="">Tanpa perangkat (manual)</option>
            {devices.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
          <button type="button" onClick={addZone} disabled={!newName.trim()}
            className="px-4 py-2 text-sm font-medium text-white bg-primary rounded-lg hover:bg-primary/90 disabled:opacity-50">
            <i className="ri-add-line mr-1"></i>Tambah
          </button>
        </div>
      )}
    </section>
  );
}

export function AudioControlPage() {
  const { rooms, roomId, setRoomId, error: roomsError } = useRoomSelection();
  const [tab, setTab] = useState<Tab>('mixer');
  const [refreshKey, setRefreshKey] = useState(0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Kontrol Audio</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Level & status mic per kursi, mute/unmute (butuh mixer digital), konfigurasi kanal mic.
          </p>
        </div>
        <RoomSelect rooms={rooms} value={roomId} onChange={setRoomId} />
      </div>
      {roomsError && <p className="text-sm text-red-600">{roomsError}</p>}

      <div className="flex gap-1 border-b border-black/10 dark:border-white/10 overflow-x-auto">
        {TABS.map((tb) => (
          <button key={tb.id} type="button" onClick={() => setTab(tb.id)}
            className={`px-4 py-2 text-sm font-medium whitespace-nowrap border-b-2 -mb-px transition-colors ${
              tab === tb.id ? 'border-primary text-primary' : 'border-transparent text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white'
            }`}>
            <i className={`${tb.icon} mr-1.5`}></i>{tb.label}
          </button>
        ))}
      </div>

      {roomId && tab === 'mixer' && <MicMixerPanel key={`${roomId}-${refreshKey}`} roomId={roomId} />}
      {roomId && tab === 'channels' && <AudioChannelEditor roomId={roomId} onSaved={() => setRefreshKey((k) => k + 1)} />}
      {roomId && tab === 'zones' && <ZonesSection roomId={roomId} />}
    </div>
  );
}
