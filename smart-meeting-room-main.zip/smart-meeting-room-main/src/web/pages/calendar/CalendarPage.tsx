import { useEffect, useState, useMemo } from 'react';
import { authApi } from '../../../shared/api/auth';
import { getErrorMessage } from '../../../shared/api/client';
import { parseLocalDate, toLocalDateString, todayLocal } from '../../../shared/utils/date';
import { usePermission } from '../../store/auth.store';
import type {
  CalendarEvent,
  Room,
  BookingStatus,
  DayAgendaItem,
} from '@shared/types';
import { BOOKING_STATUS_OPTIONS, ROOM_TYPE_OPTIONS } from '@shared/types';

type TabKey = 'monthly' | 'daily' | 'per-room';


const TIME_SLOTS: string[] = [];
for (let h = 7; h <= 19; h++) {
  TIME_SLOTS.push(`${String(h).padStart(2, '0')}:00`);
  TIME_SLOTS.push(`${String(h).padStart(2, '0')}:30`);
}
TIME_SLOTS.push('20:00');

const WEEKDAY_LABELS: string[] = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];

const statusBadgeClass = (status: BookingStatus): string => {
  switch (status) {
    case 'pending':
      return 'bg-warning/10 text-warning border-warning/20';
    case 'approved':
      return 'bg-success/10 text-success border-success/20';
    case 'rejected':
      return 'bg-danger/10 text-danger border-danger/20';
    case 'cancelled':
      return 'bg-slate-200/70 text-slate-600 dark:bg-slate-500/20 dark:text-slate-300 border-slate-300/60';
    case 'completed':
      return 'bg-info/10 text-info border-info/20';
    case 'draft':
      return 'bg-gray-200/60 text-gray-600 dark:bg-gray-500/20 dark:text-gray-300 border-gray-300';
    default:
      return 'bg-black/10 text-black/70';
  }
};

const statusDotClass = (status: BookingStatus): string => {
  switch (status) {
    case 'pending':
      return 'bg-warning';
    case 'approved':
      return 'bg-success';
    case 'rejected':
      return 'bg-danger';
    case 'cancelled':
      return 'bg-slate-400';
    case 'completed':
      return 'bg-info';
    case 'draft':
      return 'bg-gray-400';
    default:
      return 'bg-gray-400';
  }
};

const statusLabel = (status: BookingStatus): string => {
  const opt = BOOKING_STATUS_OPTIONS.find((b) => b.value === status);
  return opt?.label || status;
};

const formatDateId = (dateStr: string | Date): string => {
  const d = typeof dateStr === 'string' ? parseLocalDate(dateStr.slice(0, 10)) : dateStr;
  return d.toLocaleDateString('id-ID', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
};

const ymd = (d: Date): string => toLocalDateString(d);

export function CalendarPage() {
  const can = usePermission();
  const canApprove = can('bookings.approve');
  const [activeTab, setActiveTab] = useState<TabKey>('monthly');
  const [rooms, setRooms] = useState<Room[]>([]);
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [currentMonthDate, setCurrentMonthDate] = useState<Date>(new Date());
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedRoomId, setSelectedRoomId] = useState<string>('');

  const [detailModal, setDetailModal] = useState<CalendarEvent | null>(null);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchRooms = async () => {
    try {
      const result = await authApi.listRooms({ per_page: 100 });
      setRooms((result.items ?? []).filter((r) => r.is_active));
    } catch (err) {
      setRooms([]);
      setLoadError(getErrorMessage(err, 'Gagal memuat daftar ruangan'));
    }
  };

  const fetchMonthlyEvents = async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const year = currentMonthDate.getFullYear();
      const month = currentMonthDate.getMonth();
      const start = new Date(year, month, 1);
      const end = new Date(year, month + 1, 0);
      const result = await authApi.getCalendarEvents({
        start_date: ymd(start),
        end_date: ymd(end),
      });
      setEvents(result ?? []);
    } catch (err) {
      setEvents([]);
      setLoadError(getErrorMessage(err, 'Gagal memuat jadwal bulanan'));
    } finally {
      setLoading(false);
    }
  };

  const fetchDailyEvents = async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const date = ymd(selectedDate);
      const result = await authApi.getDayAgenda(date);
      const mapped: CalendarEvent[] = (result ?? []).map((d: DayAgendaItem) => ({
        id: d.id,
        title: d.title,
        start: d.start || `${date}T${d.start_time}`,
        end: d.end || `${date}T${d.end_time}`,
        date,
        room_id: d.room_id,
        room_name: d.room_name,
        building_name: d.building_name,
        status: d.status,
        organizer_name: d.organizer_name,
        participant_count: d.participant_count,
      }));
      setEvents(mapped);
    } catch (err) {
      setEvents([]);
      setLoadError(getErrorMessage(err, 'Gagal memuat agenda harian'));
    } finally {
      setLoading(false);
    }
  };

  const fetchRoomEvents = async () => {
    if (!selectedRoomId) {
      setEvents([]);
      return;
    }
    setLoading(true);
    setLoadError(null);
    try {
      const result = await authApi.getRoomCalendar(selectedRoomId, { date: ymd(currentMonthDate) });
      setEvents(result ?? []);
    } catch (err) {
      setEvents([]);
      setLoadError(getErrorMessage(err, 'Gagal memuat jadwal ruangan'));
    } finally {
      setLoading(false);
    }
  };

  const refetchActive = () => {
    if (activeTab === 'monthly') fetchMonthlyEvents();
    else if (activeTab === 'daily') fetchDailyEvents();
    else if (activeTab === 'per-room') fetchRoomEvents();
  };

  useEffect(() => {
    fetchRooms();
  }, []);

  useEffect(() => {
    if (selectedRoomId === '' && rooms.length > 0) {
      setSelectedRoomId(rooms[0].id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rooms]);

  useEffect(() => {
    if (activeTab === 'monthly') {
      fetchMonthlyEvents();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, currentMonthDate]);

  useEffect(() => {
    if (activeTab === 'daily') {
      fetchDailyEvents();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, selectedDate]);

  useEffect(() => {
    if (activeTab === 'per-room' && selectedRoomId) {
      fetchRoomEvents();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, selectedRoomId, currentMonthDate]);

  const eventsByDate = useMemo(() => {
    const map: Record<string, CalendarEvent[]> = {};
    for (const ev of events) {
      if (!map[ev.date]) map[ev.date] = [];
      map[ev.date].push(ev);
    }
    return map;
  }, [events]);

  const monthGrid = useMemo(() => {
    const year = currentMonthDate.getFullYear();
    const month = currentMonthDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startWeekday = firstDay.getDay();
    const daysInMonth = lastDay.getDate();

    const cells: (Date | null)[] = [];
    for (let i = 0; i < startWeekday; i++) cells.push(null);
    for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));
    while (cells.length % 7 !== 0) cells.push(null);

    const weeks: (Date | null)[][] = [];
    for (let i = 0; i < cells.length; i += 7) {
      weeks.push(cells.slice(i, i + 7));
    }
    return weeks;
  }, [currentMonthDate]);

  const monthLabel = useMemo(() => {
    return currentMonthDate.toLocaleDateString('id-ID', { month: 'long', year: 'numeric' });
  }, [currentMonthDate]);

  const handleStatusAction = async (event: CalendarEvent, action: 'approve' | 'reject' | 'cancel') => {
    try {
      if (action === 'approve') {
        await authApi.approveBooking(event.id);
        showToast('success', 'Pemesanan disetujui');
      } else if (action === 'reject') {
        await authApi.rejectBooking(event.id);
        showToast('success', 'Pemesanan ditolak');
      } else if (action === 'cancel') {
        await authApi.cancelBooking(event.id);
        showToast('success', 'Pemesanan dibatalkan');
      }
      setDetailModal(null);
      refetchActive();
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal mengubah status pemesanan'));
    }
  };

  const tabClass = (tab: TabKey) =>
    `inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
      activeTab === tab
        ? 'bg-primary text-white shadow-sm'
        : 'bg-black/5 dark:bg-white/5 text-black/70 dark:text-white/70 hover:bg-black/10 dark:hover:bg-white/10'
    }`;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Kalender Rapat</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Lihat jadwal pemesanan ruangan rapat dalam berbagai tampilan
          </p>
        </div>
      </div>

      {loadError && (
        <div className="rounded-lg border border-red-200 bg-red-50 dark:bg-red-500/10 dark:border-red-500/20 p-3 text-sm text-red-700 dark:text-red-300 flex items-center justify-between gap-3">
          <span>{loadError}</span>
          <button type="button" onClick={refetchActive} className="font-medium underline shrink-0">
            Coba lagi
          </button>
        </div>
      )}

      <div className="flex flex-wrap gap-2 p-1 bg-black/[0.03] dark:bg-white/[0.03] rounded-xl w-fit">
        <button type="button" onClick={() => setActiveTab('monthly')} className={tabClass('monthly')}>
          <i className="ri-calendar-view-month text-lg"></i>
          <span>Bulanan</span>
        </button>
        <button type="button" onClick={() => setActiveTab('daily')} className={tabClass('daily')}>
          <i className="ri-calendar-todo-line text-lg"></i>
          <span>Harian</span>
        </button>
        <button type="button" onClick={() => setActiveTab('per-room')} className={tabClass('per-room')}>
          <i className="ri-door-open-line text-lg"></i>
          <span>Per Ruangan</span>
        </button>
      </div>

      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
        {activeTab === 'monthly' && (
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setCurrentMonthDate(new Date(currentMonthDate.getFullYear(), currentMonthDate.getMonth() - 1, 1))}
                  className="p-2 rounded-lg text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                  title="Bulan sebelumnya"
                >
                  <i className="ri-arrow-left-s-line text-xl"></i>
                </button>
                <h2 className="text-lg font-bold text-black dark:text-white min-w-[200px] text-center capitalize">
                  {monthLabel}
                </h2>
                <button
                  type="button"
                  onClick={() => setCurrentMonthDate(new Date(currentMonthDate.getFullYear(), currentMonthDate.getMonth() + 1, 1))}
                  className="p-2 rounded-lg text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                  title="Bulan berikutnya"
                >
                  <i className="ri-arrow-right-s-line text-xl"></i>
                </button>
              </div>
              <button
                type="button"
                onClick={() => setCurrentMonthDate(new Date())}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm bg-primary/10 text-primary rounded-lg hover:bg-primary/20 transition-colors font-medium"
              >
                <i className="ri-calendar-today-line"></i>
                Hari ini
              </button>
            </div>

            <div className="overflow-x-auto -mx-6">
              <table className="w-full border-collapse min-w-[600px]">
                <thead>
                  <tr>
                    {WEEKDAY_LABELS.map((w) => (
                      <th
                        key={w}
                        className="py-3 px-2 font-semibold text-xs text-center text-black/60 dark:text-white/60 border-y border-black/10 dark:border-white/10 bg-black/[0.02] dark:bg-white/[0.02]"
                      >
                        {w}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {monthGrid.map((week, wi) => (
                    <tr key={wi}>
                      {week.map((cell, ci) => {
                        const isToday = cell && ymd(cell) === todayLocal();
                        const dayEvents = cell ? eventsByDate[ymd(cell)] || [] : [];
                        return (
                          <td
                            key={ci}
                            className={`align-top border-r border-b border-black/5 dark:border-white/5 p-1.5 ${
                              cell ? 'min-h-[100px]' : 'bg-black/[0.01]'
                            }`}
                            style={{ height: 100, width: '14.28%' }}
                          >
                            {cell && (
                              <div className="h-full w-full flex flex-col">
                                <div className="flex items-center justify-between mb-1">
                                  <span
                                    className={`inline-flex items-center justify-center w-7 h-7 text-xs font-semibold rounded-full ${
                                      isToday
                                        ? 'bg-primary text-white shadow-sm'
                                        : 'text-black/70 dark:text-white/70'
                                    }`}
                                  >
                                    {cell.getDate()}
                                  </span>
                                </div>
                                <div className="space-y-1 flex-1 overflow-hidden">
                                  {dayEvents.slice(0, 3).map((ev) => (
                                    <button
                                      key={ev.id}
                                      type="button"
                                      onClick={() => setDetailModal(ev)}
                                      className="w-full text-left flex items-center gap-1.5 px-1.5 py-1 rounded text-[11px] font-medium hover:bg-black/[0.03] dark:hover:bg-white/[0.03] transition-colors group"
                                      title={`${ev.title} (${statusLabel(ev.status)})`}
                                    >
                                      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${statusDotClass(ev.status)}`}></span>
                                      <span className="truncate text-black/80 dark:text-white/80 group-hover:text-primary transition-colors">
                                        {ev.title}
                                      </span>
                                    </button>
                                  ))}
                                  {dayEvents.length > 3 && (
                                    <div className="text-[10px] text-black/40 px-1.5">
                                      +{dayEvents.length - 3} acara lainnya
                                    </div>
                                  )}
                                </div>
                              </div>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex flex-wrap items-center gap-4 mt-6 pt-4 border-t border-black/10 dark:border-white/10 text-xs">
              <div className="text-sm font-semibold text-black/70 dark:text-white/70">Keterangan Status:</div>
              {BOOKING_STATUS_OPTIONS.map((s) => (
                <div key={s.value} className="inline-flex items-center gap-1.5">
                  <span className={`w-2.5 h-2.5 rounded-full ${statusDotClass(s.value)}`}></span>
                  <span className="text-black/60 dark:text-white/60">{s.label}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'daily' && (
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedDate(new Date(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate() - 1))}
                  className="p-2 rounded-lg text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                >
                  <i className="ri-arrow-left-s-line text-xl"></i>
                </button>
                <div className="relative">
                  <i className="ri-calendar-line absolute left-3 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40"></i>
                  <input
                    type="date"
                    value={ymd(selectedDate)}
                    onChange={(e) => e.target.value && setSelectedDate(parseLocalDate(e.target.value))}
                    className="pl-10 pr-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedDate(new Date(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate() + 1))}
                  className="p-2 rounded-lg text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                >
                  <i className="ri-arrow-right-s-line text-xl"></i>
                </button>
              </div>
              <div className="text-sm font-semibold text-black/80 dark:text-white/80">
                {formatDateId(selectedDate)}
              </div>
            </div>

            {loading ? (
              <div className="py-16 text-center text-black/50 dark:text-white/50">
                <div className="inline-flex items-center gap-2">
                  <svg className="animate-spin h-5 w-5 text-primary" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  <span>Memuat jadwal...</span>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-1">
                  <div className="text-xs font-semibold text-black/60 dark:text-white/60 uppercase tracking-wider mb-3 px-2">
                    Daftar Ruangan
                  </div>
                  <div className="space-y-2 max-h-[700px] overflow-y-auto pr-1">
                    {rooms.map((room) => {
                      const count = events.filter((e) => e.room_id === room.id).length;
                      return (
                        <div
                          key={room.id}
                          className="p-3 rounded-lg border border-black/10 dark:border-white/10 hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors"
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <span className="inline-flex px-1.5 py-0.5 rounded text-[10px] font-semibold bg-primary/10 text-primary">
                              {room.code}
                            </span>
                            <span className="text-xs px-1.5 py-0.5 rounded bg-info/10 text-info">
                              {ROOM_TYPE_OPTIONS.find((r) => r.value === room.room_type)?.label}
                            </span>
                          </div>
                          <div className="font-semibold text-sm text-black/80 dark:text-white/80 mb-0.5">
                            {room.name}
                          </div>
                          <div className="text-xs text-black/50 mb-2">
                            {room.building_name} &middot; Lantai {room.floor || '-'}
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="inline-flex items-center gap-1 text-black/60 dark:text-white/60">
                              <i className="ri-user-3-line"></i>
                              {room.capacity} org
                            </span>
                            <span className={`inline-flex items-center px-2 py-0.5 rounded-full font-semibold ${count > 0 ? 'bg-warning/10 text-warning' : 'bg-success/10 text-success'}`}>
                              {count} acara
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="md:col-span-3 overflow-x-auto">
                  <div className="min-w-[600px]">
                    <div className="grid" style={{ gridTemplateColumns: `80px repeat(${rooms.length}, minmax(120px, 1fr))` }}>
                      <div className="sticky top-0 z-10 bg-white dark:bg-gray"></div>
                      {rooms.map((room) => (
                        <div
                          key={room.id}
                          className="px-2 py-3 border-b border-l border-black/10 dark:border-white/10 bg-black/[0.02] dark:bg-white/[0.02] text-center sticky top-0 z-10 bg-white dark:bg-gray"
                        >
                          <div className="text-[10px] font-semibold text-primary">{room.code}</div>
                          <div className="text-xs font-semibold text-black/80 dark:text-white/80 truncate">
                            {room.name}
                          </div>
                        </div>
                      ))}

                      {TIME_SLOTS.map((time, ti) => {
                        const isHour = time.endsWith(':00');
                        return (
                          <>
                            <div
                              key={`t-${time}`}
                              className={`px-2 py-1 border-b border-r border-black/5 dark:border-white/5 text-[11px] text-black/50 dark:text-white/50 text-right pr-3 ${
                                isHour ? 'font-semibold text-black/70 dark:text-white/70' : 'text-[10px]'
                              }`}
                              style={{ height: 48 }}
                            >
                              {isHour ? time : ''}
                            </div>
                            {rooms.map((room) => {
                              const dateStr = ymd(selectedDate);
                              const roomEvents = events.filter((e) => e.room_id === room.id && e.date === dateStr);
                              return (
                                <div
                                  key={`c-${room.id}-${ti}`}
                                  className="relative border-b border-r border-black/5 dark:border-white/5"
                                  style={{ height: 48 }}
                                >
                                  {roomEvents.map((ev) => {
                                    const [sh, sm] = ev.start.slice(11, 16).split(':').map(Number);
                                    const [eh, em] = ev.end.slice(11, 16).split(':').map(Number);
                                    const startMinutes = sh * 60 + sm;
                                    const endMinutes = eh * 60 + em;
                                    const dayStartMinutes = 7 * 60;
                                    const slotMinutes = ti * 30 + dayStartMinutes;
                                    const evDuration = endMinutes - startMinutes;
                                    if (slotMinutes !== startMinutes) return null;
                                    const topPx = 0;
                                    const heightPx = Math.max(44, (evDuration / 30) * 48 - 4);
                                    return (
                                      <button
                                        key={ev.id}
                                        type="button"
                                        onClick={() => setDetailModal(ev)}
                                        className={`absolute left-1 right-1 rounded-md px-2 py-1 text-left overflow-hidden transition-all hover:shadow-md hover:-translate-y-0.5 z-20 border-l-4 ${statusBadgeClass(ev.status)} bg-opacity-80`}
                                        style={{ top: topPx, height: heightPx }}
                                      >
                                        <div className="text-[11px] font-semibold truncate text-black/90 dark:text-white/90">
                                          {ev.title}
                                        </div>
                                        <div className="text-[10px] opacity-80 truncate">
                                          {ev.start.slice(11, 16)} - {ev.end.slice(11, 16)}
                                        </div>
                                      </button>
                                    );
                                  })}
                                </div>
                              );
                            })}
                          </>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'per-room' && (
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
              <div className="flex items-center gap-2 flex-wrap">
                <label className="text-sm font-semibold text-black/70 dark:text-white/70">
                  Pilih Ruangan:
                </label>
                <select
                  value={selectedRoomId}
                  onChange={(e) => setSelectedRoomId(e.target.value)}
                  className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 min-w-[250px]"
                >
                  <option value="">Pilih ruangan...</option>
                  {rooms.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.code} - {r.name} ({r.building_name})
                    </option>
                  ))}
                </select>
              </div>
              <div className="text-sm text-black/60 dark:text-white/60">
                Total {events.length} acara ditemukan
              </div>
            </div>

            {!selectedRoomId ? (
              <div className="py-16 text-center text-black/50 dark:text-white/50">
                <div className="flex flex-col items-center gap-2">
                  <i className="ri-door-open-line text-4xl text-black/30 dark:text-white/30"></i>
                  <span>Pilih ruangan terlebih dahulu untuk melihat jadwal</span>
                </div>
              </div>
            ) : loading ? (
              <div className="py-16 text-center text-black/50 dark:text-white/50">
                <div className="inline-flex items-center gap-2">
                  <svg className="animate-spin h-5 w-5 text-primary" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  <span>Memuat jadwal ruangan...</span>
                </div>
              </div>
            ) : events.length === 0 ? (
              <div className="py-16 text-center text-black/50 dark:text-white/50">
                <div className="flex flex-col items-center gap-2">
                  <i className="ri-calendar-line text-4xl text-black/30 dark:text-white/30"></i>
                  <span>Tidak ada jadwal untuk ruangan ini</span>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {[...events]
                  .sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start))
                  .map((ev) => (
                    <div
                      key={ev.id}
                      className="flex flex-col sm:flex-row sm:items-center gap-4 p-4 rounded-lg border border-black/10 dark:border-white/10 hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors"
                    >
                      <div className="w-full sm:w-40 shrink-0">
                        <div className="text-sm font-bold text-primary">{formatDateId(ev.date)}</div>
                        <div className="text-xs text-black/50 flex items-center gap-1 mt-1">
                          <i className="ri-time-line"></i>
                          {ev.start.slice(11, 16)} - {ev.end.slice(11, 16)}
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div
                          className="font-semibold text-black/80 dark:text-white/80 cursor-pointer hover:text-primary transition-colors truncate"
                          onClick={() => setDetailModal(ev)}
                        >
                          {ev.title}
                        </div>
                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1 text-xs text-black/50">
                          {ev.organizer_name && (
                            <span className="inline-flex items-center gap-1">
                              <i className="ri-user-line"></i>
                              {ev.organizer_name}
                            </span>
                          )}
                          {ev.participant_count && (
                            <span className="inline-flex items-center gap-1">
                              <i className="ri-team-line"></i>
                              {ev.participant_count} peserta
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${statusBadgeClass(ev.status)}`}>
                          {statusLabel(ev.status)}
                        </span>
                        <button
                          type="button"
                          onClick={() => setDetailModal(ev)}
                          className="p-2 text-black/60 dark:text-white/60 hover:text-info hover:bg-info/10 rounded-lg transition-colors"
                          title="Lihat Detail"
                        >
                          <i className="ri-eye-line"></i>
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        )}
      </div>

      {detailModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={() => setDetailModal(null)}
        >
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-lg overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">Detail Rapat</h2>
              <button
                type="button"
                onClick={() => setDetailModal(null)}
                className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <div className="px-6 py-5 space-y-4 max-h-[70vh] overflow-y-auto">
              <div>
                <h3 className="text-xl font-bold text-black dark:text-white">{detailModal.title}</h3>
                <div className="mt-2">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${statusBadgeClass(detailModal.status)}`}>
                    {statusLabel(detailModal.status)}
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-black/50 mb-0.5">Ruangan</div>
                  <div className="font-medium text-black/80 dark:text-white/80">{detailModal.room_name || '-'}</div>
                  <div className="text-xs text-black/50">{detailModal.building_name || ''}</div>
                </div>
                <div>
                  <div className="text-black/50 mb-0.5">Pemimpin Rapat</div>
                  <div className="font-medium text-black/80 dark:text-white/80">{detailModal.organizer_name || '-'}</div>
                </div>
                <div>
                  <div className="text-black/50 mb-0.5">Tanggal</div>
                  <div className="font-medium text-black/80 dark:text-white/80">{formatDateId(detailModal.date)}</div>
                </div>
                <div>
                  <div className="text-black/50 mb-0.5">Waktu</div>
                  <div className="font-medium text-black/80 dark:text-white/80">
                    {detailModal.start.slice(11, 16)} - {detailModal.end.slice(11, 16)}
                  </div>
                </div>
                <div>
                  <div className="text-black/50 mb-0.5">Peserta</div>
                  <div className="font-medium text-black/80 dark:text-white/80">{detailModal.participant_count || 0} orang</div>
                </div>
              </div>
              {detailModal.description && (
                <div className="pt-2 border-t border-black/10 dark:border-white/10">
                  <div className="text-black/50 text-sm mb-1">Deskripsi / Agenda</div>
                  <p className="text-sm text-black/70 dark:text-white/70">{detailModal.description}</p>
                </div>
              )}
            </div>
            <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex flex-wrap items-center justify-end gap-2">
              {detailModal.status === 'pending' && canApprove && (
                <>
                  <button
                    type="button"
                    onClick={() => handleStatusAction(detailModal, 'approve')}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-white bg-success hover:bg-success/90 rounded-lg transition-colors"
                  >
                    <i className="ri-check-line"></i>
                    Setujui
                  </button>
                  <button
                    type="button"
                    onClick={() => handleStatusAction(detailModal, 'reject')}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-white bg-danger hover:bg-danger/90 rounded-lg transition-colors"
                  >
                    <i className="ri-close-line"></i>
                    Tolak
                  </button>
                </>
              )}
              {(detailModal.status === 'approved' || detailModal.status === 'pending') && canApprove && (

                <button
                  type="button"
                  onClick={() => handleStatusAction(detailModal, 'cancel')}
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-white bg-warning hover:bg-warning/90 rounded-lg transition-colors"
                >
                  <i className="ri-stop-circle-line"></i>
                  Batalkan
                </button>
              )}
              <button
                type="button"
                onClick={() => setDetailModal(null)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div
          className={`fixed top-4 right-4 z-[60] max-w-sm rounded-lg shadow-lg p-4 flex items-start gap-3 ${
            toast.type === 'success'
              ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20'
              : 'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20'
          }`}
        >
          <div className="flex-shrink-0">
            <i
              className={`ri-check-line text-lg ${
                toast.type === 'success' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
              }`}
            ></i>
          </div>
          <p
            className={`flex-1 text-sm font-medium ${
              toast.type === 'success' ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'
            }`}
          >
            {toast.message}
          </p>
          <button
            type="button"
            onClick={() => setToast(null)}
            className={`flex-shrink-0 transition-colors ${
              toast.type === 'success' ? 'text-green-400 hover:text-green-600' : 'text-red-400 hover:text-red-600'
            }`}
          >
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}
    </div>
  );
}
