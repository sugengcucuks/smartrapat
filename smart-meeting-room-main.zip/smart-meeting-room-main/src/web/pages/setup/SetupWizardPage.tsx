import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { setupApi } from '@shared/api/auth';
import type { SetupProfileInput, SetupStatus } from '@shared/api/auth';
import { getErrorMessage } from '@shared/api/client';

const inputCls =
  'w-full px-3 py-2.5 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80';

const STEP_ICONS: Record<string, string> = {
  database: 'ri-database-2-line',
  migrations: 'ri-git-branch-line',
  admin: 'ri-shield-user-line',
  organization: 'ri-building-4-line',
  license: 'ri-key-2-line',
  finalize: 'ri-checkbox-circle-line',
};

const EMPTY_PROFILE: SetupProfileInput = { org_name: '', org_address: '', org_phone: '', org_email: '' };

export function SetupWizardPage() {
  const navigate = useNavigate();
  const [status, setStatus] = useState<SetupStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [profile, setProfile] = useState<SetupProfileInput>(EMPTY_PROFILE);
  const [saving, setSaving] = useState(false);
  const [finishing, setFinishing] = useState(false);
  const [savedMsg, setSavedMsg] = useState<string | null>(null);

  const loadStatus = useCallback(async () => {
    try {
      const s = await setupApi.status();
      setStatus(s);
    } catch (err) {
      setError(getErrorMessage(err, 'Gagal memuat status setup'));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStatus();
  }, [loadStatus]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile.org_name.trim()) {
      setError('Nama organisasi wajib diisi');
      return;
    }
    setError(null);
    setSaving(true);
    try {
      const s = await setupApi.saveProfile({
        ...profile,
        org_name: profile.org_name.trim(),
        org_address: profile.org_address?.trim() || undefined,
        org_phone: profile.org_phone?.trim() || undefined,
        org_email: profile.org_email?.trim() || undefined,
      });
      setStatus(s);
      setSavedMsg('Profil organisasi tersimpan');
      window.setTimeout(() => setSavedMsg(null), 2500);
    } catch (err) {
      setError(getErrorMessage(err, 'Gagal menyimpan profil organisasi'));
    } finally {
      setSaving(false);
    }
  };

  const handleComplete = async () => {
    setError(null);
    setFinishing(true);
    try {
      await setupApi.complete();
      navigate('/dashboard');
    } catch (err) {
      setError(getErrorMessage(err, 'Gagal menyelesaikan setup'));
      setFinishing(false);
    }
  };

  const orgStep = status?.steps.find((s) => s.key === 'organization');
  const otherStepsDone = (status?.steps ?? []).every((s) => s.done || s.key === 'finalize');

  return (
    <div className="min-h-screen w-screen bg-[#f5f7fa] dark:bg-dark flex items-start justify-center px-4 py-10 overflow-y-auto">
      <div className="w-full max-w-2xl">
        {/* Logo & judul ala WordPress */}
        <div className="text-center mb-8">
          <img src="assets/images/favicon.png" alt="Smart Meeting Room" className="w-16 h-16 rounded-xl mx-auto shadow-md" />
          <h1 className="text-2xl font-bold text-black dark:text-white mt-4">Selamat Datang</h1>
          <p className="text-sm text-black/50 dark:text-white/50 mt-1">
            Persiapan Smart Meeting Room Anda — kurang dari 5 menit.
          </p>
        </div>

        <div className="bg-white dark:bg-gray rounded-2xl shadow-xl shadow-black/5 border border-black/10 dark:border-white/10 p-6 sm:p-8 space-y-8">
          {loading ? (
            <div className="py-12 text-center">
              <svg className="animate-spin h-10 w-10 text-primary mx-auto" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
            </div>
          ) : (
            <>
              {/* Daftar langkah ala WordPress */}
              <section>
                <h2 className="text-sm font-bold text-black dark:text-white uppercase tracking-wide mb-4">
                  Langkah Persiapan
                </h2>
                <ul className="space-y-3">
                  {(status?.steps ?? []).map((step, i) => (
                    <li key={step.key} className="flex items-start gap-3">
                      <span
                        className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 font-bold text-sm ${
                          step.done ? 'bg-success text-white' : 'bg-black/5 dark:bg-white/10 text-black/40 dark:text-white/40'
                        }`}
                        title={step.detail}
                      >
                        {step.done ? <i className="ri-check-line text-lg"></i> : i + 1}
                      </span>
                      <div className="min-w-0">
                        <p className={`text-sm font-semibold ${step.done ? 'text-black dark:text-white' : 'text-black/50 dark:text-white/50'}`}>
                          <i className={`${STEP_ICONS[step.key] ?? 'ri-circle-line'} mr-1.5`}></i>
                          {step.label}
                        </p>
                        <p className="text-xs text-black/40 dark:text-white/40 mt-0.5">{step.detail}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              </section>

              {error && (
                <div className="bg-danger/10 text-danger text-sm rounded-lg px-4 py-3">
                  <i className="ri-error-warning-line mr-2"></i>
                  {error}
                </div>
              )}
              {savedMsg && (
                <div className="bg-success/10 text-success text-sm rounded-lg px-4 py-3">
                  <i className="ri-checkbox-circle-line mr-2"></i>
                  {savedMsg}
                </div>
              )}

              {/* Profil organisasi */}
              {!status?.completed && (
                <section>
                  <h2 className="text-sm font-bold text-black dark:text-white uppercase tracking-wide mb-1">
                    Informasi Organisasi
                  </h2>
                  <p className="text-xs text-black/40 dark:text-white/40 mb-4">
                    Nama ini akan tampil pada kiosk, notulen, dan laporan.
                  </p>
                  <form onSubmit={handleSaveProfile} className="space-y-3">
                    <div>
                      <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">
                        Nama Organisasi <span className="text-danger">*</span>
                      </label>
                      <input
                        type="text"
                        value={profile.org_name}
                        onChange={(e) => setProfile({ ...profile, org_name: e.target.value })}
                        placeholder="cth. PT Maju Bersama"
                        className={inputCls}
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">Alamat</label>
                      <input
                        type="text"
                        value={profile.org_address}
                        onChange={(e) => setProfile({ ...profile, org_address: e.target.value })}
                        placeholder="cth. Jl. Sudirman No. 1, Jakarta"
                        className={inputCls}
                      />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">Telepon</label>
                        <input
                          type="tel"
                          value={profile.org_phone}
                          onChange={(e) => setProfile({ ...profile, org_phone: e.target.value })}
                          placeholder="cth. 021-555-0123"
                          className={inputCls}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">Email</label>
                        <input
                          type="email"
                          value={profile.org_email}
                          onChange={(e) => setProfile({ ...profile, org_email: e.target.value })}
                          placeholder="cth. admin@perusahaan.co.id"
                          className={inputCls}
                        />
                      </div>
                    </div>
                    <button
                      type="submit"
                      disabled={saving}
                      className="w-full sm:w-auto px-6 py-2.5 rounded-lg bg-primary text-white text-sm font-semibold shadow-sm shadow-primary/30 hover:bg-primary/90 disabled:opacity-50 transition-colors"
                    >
                      {saving ? 'Menyimpan...' : orgStep?.done ? 'Perbarui Profil' : 'Simpan Profil'}
                    </button>
                  </form>
                </section>
              )}

              {/* Finalisasi ala WordPress "Install WordPress" */}
              {status?.completed ? (
                <div className="bg-success/10 text-success rounded-lg px-4 py-3 text-sm flex items-center justify-between flex-wrap gap-3">
                  <span>
                    <i className="ri-checkbox-circle-line mr-1.5"></i>
                    Setup sudah selesai. Sistem siap digunakan.
                  </span>
                  <button
                    type="button"
                    onClick={() => navigate('/dashboard')}
                    className="px-4 py-1.5 rounded-lg bg-success text-white text-xs font-semibold hover:bg-success/90"
                  >
                    Buka Dashboard
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={handleComplete}
                  disabled={finishing || !otherStepsDone}
                  title={otherStepsDone ? 'Selesaikan setup' : 'Selesaikan langkah di atas terlebih dahulu'}
                  className="w-full py-3 rounded-lg bg-primary text-white text-sm font-bold shadow-md shadow-primary/30 hover:bg-primary/90 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                >
                  {finishing ? 'Menyelesaikan...' : 'Selesaikan Setup'}
                </button>
              )}
            </>
          )}
        </div>

        <p className="text-center text-xs text-black/35 dark:text-white/35 mt-6">
          Smart Meeting Room · Persiapan terinspirasi instalasi WordPress
        </p>
      </div>
    </div>
  );
}
