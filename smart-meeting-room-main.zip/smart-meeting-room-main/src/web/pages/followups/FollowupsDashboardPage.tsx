import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { followupsApi } from '@shared/api/auth';
import type {
  FollowupItem,
  FollowupItemsResponse,
  FollowupStatusFilter,
  FollowupSummary,
} from '@shared/api/auth';
import { getErrorMessage } from '@shared/api/client';

const inputCls =
  'px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80';

const STATUS_STYLE: Record<string, { label: string; cls: string }> = {
  open: { label: 'Terbuka', cls: 'bg-warning/10 text-warning' },
  in_progress: { label: 'Berjalan', cls: 'bg-info/10 text-info' },
  done: { label: 'Selesai', cls: 'bg-success/10 text-success' },
  completed: { label: 'Selesai', cls: 'bg-success/10 text-success' },
  cancelled: { label: 'Dibatalkan', cls: 'bg-black/5 text-black/50 dark:bg-white/10 dark:text-white/50' },
};

const STATUS_FILTERS: { value: FollowupStatusFilter; label: string }[] = [
  { value: 'all', label: 'Semua' },
  { value: 'open', label: 'Terbuka' },
  { value: 'in_progress', label: 'Berjalan' },
  { value: 'done', label: 'Selesai' },
  { value: 'cancelled', label: 'Dibatalkan' },
  { value: 'overdue', label: 'Terlambat' },
  { value: 'due_this_week', label: 'Minggu Ini' },
];

const SUMMARY_CARDS: { key: keyof FollowupSummary; label: string; icon: string; cls: string }[] = [
  { key: 'open', label: 'Terbuka', icon: 'ri-inbox-unarchive-line', cls: 'bg-warning/10 text-warning' },
  { key: 'in_progress', label: 'Berjalan', icon: 'ri-play-circle-line', cls: 'bg-info/10 text-info' },
  { key: 'done', label: 'Selesai', icon: 'ri-checkbox-circle-line', cls: 'bg-success/10 text-success' },
  { key: 'overdue', label: 'Terlambat', icon: 'ri-alarm-warning-line', cls: 'bg-danger/10 text-danger' },
  { key: 'due_today', label: 'Jatuh Tempo Hari Ini', icon: 'ri-calendar-todo-line', cls: 'bg-primary/10 text-primary' },
  { key: 'due_this_week', label: 'Minggu Ini', icon: 'ri-calendar-check-line', cls: 'bg-primary/10 text-primary' },
];

function formatDate(d: string | null | undefined): string {
  if (!d) return '-';
  try {
    return new Date(d + 'T00:00:00').toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch {
    return d;
  }
}

function isOverdue(item: FollowupItem): boolean {
  return !!(item.due_date && item.status !== 'done' && item.status !== 'completed' && item.status !== 'cancelled' && item.due_date < new Date().toISOString().split('T')[0]);
}

export function FollowupsDashboardPage() {
  const navigate = useNavigate();
  const [summary, setSummary] = useState<FollowupSummary | null>(null);
  const [data, setData] = useState<FollowupItemsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<FollowupStatusFilter>('all');
  const [owner, setOwner] = useState('');
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const [savingId, setSavingId] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast(null), 2500);
  };

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [s, list] = await Promise.all([
        followupsApi.summary(),
        followupsApi.items({ status, owner: owner || undefined, q: q.trim() || undefined, page, per_page: 15 }),
      ]);
      setSummary(s);
      setData(list);
    } catch (err) {
      setError(getErrorMessage(err, 'Gagal memuat dashboard tindak lanjut'));
    } finally {
      setLoading(false);
    }
  }, [status, owner, q, page]);

  useEffect(() => {
    const t = window.setTimeout(refresh, q ? 350 : 0);
    return () => window.clearTimeout(t);
  }, [refresh, q]);

  // Ganti filter -> kembali ke halaman 1.
  useEffect(() => {
    setPage(1);
  }, [status, owner, q]);

  const patchItem = async (item: FollowupItem, patch: { status?: string; owner?: string | null; due_date?: string | null }) => {
    setSavingId(item.id);
    try {
      await followupsApi.updateItem(item.id, patch);
      showToast('Tindak lanjut diperbarui');
      await refresh();
    } catch (err) {
      setError(getErrorMessage(err, 'Gagal memperbarui tindak lanjut'));
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-black dark:text-white">Dashboard Tindak Lanjut</h1>
        <p className="text-sm text-black/50 dark:text-white/50 mt-0.5">
          Pantau semua action item dari seluruh rapat di satu tempat.
        </p>
      </div>

      {/* Kartu ringkasan */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        {SUMMARY_CARDS.map((c) => (
          <button
            key={String(c.key)}
            type="button"
            onClick={() => {
              if (c.key === 'open') setStatus('open');
              else if (c.key === 'in_progress') setStatus('in_progress');
              else if (c.key === 'done') setStatus('done');
              else if (c.key === 'overdue') setStatus('overdue');
              else if (c.key === 'due_this_week') setStatus('due_this_week');
            }}
            className="bg-white dark:bg-gray rounded-xl border border-black/10 dark:border-white/10 p-4 text-left hover:shadow-md transition-shadow"
          >
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${c.cls}`}>
              <i className={c.icon}></i>
            </div>
            <p className="text-2xl font-bold text-black dark:text-white mt-2">{summary ? (summary[c.key] as number) : '-'}</p>
            <p className="text-xs text-black/50 dark:text-white/50">{c.label}</p>
          </button>
        ))}
      </div>

      {/* Filter bar */}
      <div className="bg-white dark:bg-gray rounded-xl border border-black/10 dark:border-white/10 p-4 flex flex-wrap items-center gap-3">
        <div className="flex flex-wrap gap-1.5">
          {STATUS_FILTERS.map((f) => (
            <button
              key={f.value}
              type="button"
              onClick={() => setStatus(f.value)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
                status === f.value
                  ? 'bg-primary text-white'
                  : 'bg-black/5 dark:bg-white/10 text-black/60 dark:text-white/60 hover:bg-black/10 dark:hover:bg-white/20'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2 ml-auto">
          <select value={owner} onChange={(e) => setOwner(e.target.value)} className={inputCls}>
            <option value="">Semua Penanggung Jawab</option>
            {(summary?.by_owner ?? []).map((o) => (
              <option key={o.owner} value={o.owner}>
                {o.owner} ({o.total})
              </option>
            ))}
          </select>
          <div className="relative">
            <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-black/30 dark:text-white/30 text-sm"></i>
            <input
              type="text"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Cari tugas..."
              className={`${inputCls} pl-9 w-52`}
            />
          </div>
        </div>
      </div>

      {error && (
        <div className="bg-danger/10 text-danger text-sm rounded-lg px-4 py-3">
          <i className="ri-error-warning-line mr-2"></i>
          {error}
        </div>
      )}

      {/* Daftar item */}
      <div className="bg-white dark:bg-gray rounded-xl border border-black/10 dark:border-white/10 divide-y divide-black/5 dark:divide-white/5">
        {loading && !data ? (
          <div className="py-16 text-center">
            <svg className="animate-spin h-8 w-8 text-primary mx-auto" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
          </div>
        ) : !data || data.items.length === 0 ? (
          <div className="py-16 text-center">
            <i className="ri-checkbox-circle-line text-5xl text-black/15 dark:text-white/15"></i>
            <p className="mt-3 text-sm font-medium text-black/50 dark:text-white/50">Tidak ada tindak lanjut</p>
            <p className="text-xs text-black/40 dark:text-white/40 mt-1">
              Action item dari notulensi rapat akan muncul di sini.
            </p>
          </div>
        ) : (
          data.items.map((item) => {
            const st = STATUS_STYLE[item.status] ?? STATUS_STYLE.open;
            const overdue = isOverdue(item);
            return (
              <div key={item.id} className="p-4 hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors">
                <div className="flex flex-wrap items-start gap-3">
                  <div className="flex-1 min-w-[240px]">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className={`text-sm font-semibold ${item.status === 'done' || item.status === 'completed' || item.status === 'cancelled' ? 'text-black/40 dark:text-white/40 line-through' : 'text-black dark:text-white'}`}>
                        {item.task}
                      </p>
                      <span className={`text-[11px] px-2 py-0.5 rounded-full font-semibold ${st.cls}`}>{st.label}</span>
                      {overdue && (
                        <span className="text-[11px] px-2 py-0.5 rounded-full font-semibold bg-danger/10 text-danger">
                          <i className="ri-alarm-warning-line mr-0.5"></i>Terlambat
                        </span>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => navigate(`/notes/${item.note_id}`)}
                      className="text-xs text-primary hover:underline mt-1 inline-flex items-center gap-1"
                    >
                      <i className="ri-file-text-line"></i>
                      {item.note_title || item.booking_title || 'Notulensi'}
                      {item.meeting_date ? ` · ${formatDate(item.meeting_date)}` : ''}
                      {item.room_name ? ` · ${item.room_name}` : ''}
                    </button>
                  </div>

                  {/* Edit cepat */}
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <input
                      type="text"
                      defaultValue={item.owner ?? ''}
                      placeholder="Penanggung jawab"
                      className={`${inputCls} w-40`}
                      onBlur={(e) => {
                        const v = e.target.value.trim();
                        if (v !== (item.owner ?? '')) patchItem(item, { owner: v || null });
                      }}
                    />
                    <input
                      type="date"
                      defaultValue={item.due_date ?? ''}
                      className={`${inputCls} w-36`}
                      onChange={(e) => {
                        const v = e.target.value;
                        if (v !== (item.due_date ?? '')) patchItem(item, { due_date: v || null });
                      }}
                    />
                    <select
                      value={item.status}
                      disabled={savingId === item.id}
                      onChange={(e) => patchItem(item, { status: e.target.value })}
                      className={inputCls}
                    >
                      <option value="open">Terbuka</option>
                      <option value="in_progress">Berjalan</option>
                      <option value="done">Selesai</option>
                      <option value="cancelled">Dibatalkan</option>
                    </select>
                    {savingId === item.id && (
                      <svg className="animate-spin h-4 w-4 text-primary" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Pagination */}
      {data && data.total_pages > 1 && (
        <div className="flex items-center justify-between text-sm">
          <p className="text-black/50 dark:text-white/50">
            {data.total} item · halaman {data.page} dari {data.total_pages}
          </p>
          <div className="flex gap-2">
            <button
              type="button"
              disabled={page <= 1}
              onClick={() => setPage((p) => p - 1)}
              className="px-3 py-1.5 rounded-lg border border-black/10 dark:border-white/10 disabled:opacity-40 hover:bg-black/5 dark:hover:bg-white/10 dark:text-white/80"
            >
              <i className="ri-arrow-left-s-line"></i> Sebelumnya
            </button>
            <button
              type="button"
              disabled={page >= data.total_pages}
              onClick={() => setPage((p) => p + 1)}
              className="px-3 py-1.5 rounded-lg border border-black/10 dark:border-white/10 disabled:opacity-40 hover:bg-black/5 dark:hover:bg-white/10 dark:text-white/80"
            >
              Berikutnya <i className="ri-arrow-right-s-line"></i>
            </button>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-[70] bg-success text-white text-sm px-4 py-2.5 rounded-lg shadow-lg flex items-center gap-2">
          <i className="ri-checkbox-circle-line"></i>
          {toast}
        </div>
      )}
    </div>
  );
}
