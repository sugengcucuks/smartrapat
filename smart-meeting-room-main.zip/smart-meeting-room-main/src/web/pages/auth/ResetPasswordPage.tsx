import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { authApi } from '@shared/api/auth';
import { getErrorMessage } from '@shared/api/client';
import { PASSWORD_MIN_LENGTH } from '@shared/utils/password';
import { PasswordStrengthMeter } from '../../components/PasswordStrengthMeter';

/** Halaman publik: atur ulang password dari link email (`/reset-password?token=...`). */
export function ResetPasswordPage() {
  const [params] = useSearchParams();
  const token = params.get('token') ?? '';
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (password.length < PASSWORD_MIN_LENGTH) {
      setError(`Password minimal ${PASSWORD_MIN_LENGTH} karakter`);
      return;
    }
    if (password !== confirm) {
      setError('Password dan konfirmasi tidak sama');
      return;
    }
    setLoading(true);
    try {
      await authApi.resetPasswordWithToken(token, password);
      setDone(true);
    } catch (err) {
      setError(getErrorMessage(err, 'Gagal mereset password'));
    } finally {
      setLoading(false);
    }
  };

  const inputCls =
    'w-full h-11 px-3 rounded-lg bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 text-sm text-black dark:text-white outline-none focus:border-primary transition-colors';

  return (
    <div className="min-h-screen w-full bg-[#f5f7fa] dark:bg-dark flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white dark:bg-gray rounded-2xl shadow-xl p-6">
        <h1 className="text-xl font-bold text-black dark:text-white mb-1">Atur Ulang Password</h1>

        {!token ? (
          <div className="mt-4 space-y-4">
            <p className="text-sm text-red-700 dark:text-red-300">Link reset tidak valid: token tidak ditemukan.</p>
            <Link to="/login" className="text-primary text-sm font-semibold hover:underline">Kembali ke halaman masuk</Link>
          </div>
        ) : done ? (
          <div className="mt-4 space-y-4">
            <p className="text-sm text-green-700 dark:text-green-300">
              Password berhasil direset. Silakan masuk dengan password baru Anda.
            </p>
            <Link
              to="/login"
              className="inline-flex items-center justify-center w-full h-11 text-sm font-semibold text-white bg-primary hover:bg-primary/90 rounded-lg"
            >
              Masuk
            </Link>
          </div>
        ) : (
          <>
            <p className="text-sm text-black/60 dark:text-white/60 mb-5">Masukkan password baru untuk akun Anda.</p>
            {error && (
              <div className="mb-4 rounded-lg border border-red-200 bg-red-50 dark:bg-red-500/10 dark:border-red-500/20 p-3 text-sm text-red-700 dark:text-red-300">
                {error}
              </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">Password Baru</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={inputCls}
                  minLength={PASSWORD_MIN_LENGTH}
                  autoComplete="new-password"
                  required
                />
                <PasswordStrengthMeter password={password} />
              </div>
              <div>
                <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">Konfirmasi Password</label>
                <input
                  type="password"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  className={inputCls}
                  minLength={PASSWORD_MIN_LENGTH}
                  autoComplete="new-password"
                  required
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full h-11 text-sm font-semibold text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors disabled:opacity-50"
              >
                {loading ? 'Memproses...' : 'Simpan Password'}
              </button>
            </form>
            <div className="mt-4 text-sm">
              <Link to="/login" className="text-primary hover:underline">Kembali ke halaman masuk</Link>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
