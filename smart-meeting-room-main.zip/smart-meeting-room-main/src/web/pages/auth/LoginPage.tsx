import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '../../store/auth.store';
import { authApi } from '../../../shared/api/auth';
import { getErrorMessage } from '../../../shared/api/client';

export function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { setAuth, setMenu, setLoading, setError, isLoading, error, clearError } = useAuthStore();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotMessage, setForgotMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotLoading(true);
    setForgotMessage(null);
    try {
      const res = await authApi.forgotPassword(forgotEmail.trim());
      setForgotMessage({
        type: 'success',
        text: res?.message || 'Jika email terdaftar, link reset password telah dikirim.',
      });
    } catch (err) {
      setForgotMessage({ type: 'error', text: getErrorMessage(err, 'Gagal mengirim link reset password') });
    } finally {
      setForgotLoading(false);
    }
  };

  const closeForgot = () => {
    if (forgotLoading) return;
    setForgotOpen(false);
    setForgotMessage(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    setLoading(true);

    try {
      const response = await authApi.login({ username, password });
      if (!response.access_token || !response.user) {
        setError('Response login tidak valid');
        setLoading(false);
        return;
      }
      setAuth(response.user, response.access_token, response.refresh_token);

      try {
        const menu = await authApi.getMenu();
        setMenu(menu);
      } catch {
        setMenu([]);
      }
      setLoading(false);

      if (response.user.must_change_password) {
        navigate('/change-password', { replace: true });
        return;
      }
      const from = (location.state as { from?: string } | null)?.from;
      navigate(from && from !== '/login' ? from : '/dashboard', { replace: true });
    } catch (err: unknown) {
      setError(getErrorMessage(err, 'Login gagal'));
      setLoading(false);
    }
  };

  return (
    <div className="h-full lg:h-svh">
      <div
        className="grid h-full bg-primary/80 dark:bg-black bg-no-repeat bg-cover lg:grid-cols-12"
        style={{ backgroundImage: 'url(assets/images/signup-bg.png)' }}
      >
        {/* Left Form Panel */}
        <div className="bg-white dark:bg-gray lg:rounded-r-3xl lg:col-span-6">
          <div className="flex justify-center items-center h-full">
            <div className="p-4 xl:w-3/5">
              <h1 className="text-primary font-bold mb-4 text-2xl md:text-3xl">Selamat Datang.</h1>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 mb-4">
                  <div>
                    <label htmlFor="username" className="text-black/60 dark:text-white/60 font-bold text-sm">
                      Nama Pengguna
                    </label>
                    <input
                      type="text"
                      name="username"
                      id="username"
                      className="form-control"
                      placeholder="Masukkan nama pengguna"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      required
                      autoComplete="username"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between">
                      <label htmlFor="password" className="text-black/60 dark:text-white/60 font-bold text-sm">
                        Kata Sandi
                      </label>
                      <button
                        type="button"
                        onClick={() => {
                          setForgotMessage(null);
                          setForgotOpen(true);
                        }}
                        className="text-primary text-sm font-bold hover:underline"
                      >
                        Lupa Kata Sandi?
                      </button>
                    </div>
                    <div>
                      <input
                        type="password"
                        name="password"
                        id="password"
                        className="form-control"
                        placeholder="Masukkan kata sandi"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        autoComplete="current-password"
                      />
                    </div>
                  </div>


                  <button
                    type="submit"
                    disabled={isLoading}
                    className="text-white bg-primary border border-primary font-bold text-lg rounded-lg px-6 py-2 transition ease-in-out duration-300 hover:bg-white hover:text-primary dark:hover:bg-black dark:hover:text-primary disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {isLoading ? (
                      <>
                        <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                        <span>Memproses...</span>
                      </>
                    ) : (
                      <span>Masuk</span>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>

        {/* Right Overlay Panel */}
        <div className="lg:col-span-6 p-4 hidden lg:block">
          <div className="flex justify-center items-center h-full">
            <div className="p-4 text-center">
              <img src="assets/images/sign-in.png" alt="sign in" className="mx-auto mb-4 w-2/3" />
              <h2 className="text-white font-bold mb-4 text-xl md:text-4xl">Halo!</h2>
              <p className="text-white text-lg mb-4">Masuk untuk mengelola ruang rapat Anda.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Lupa Kata Sandi */}
      {forgotOpen && (
        <div className="fixed inset-0 z-[80] bg-black/50 flex items-center justify-center p-4" onClick={closeForgot}>
          <div
            className="w-full max-w-md bg-white dark:bg-gray rounded-2xl shadow-2xl p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-bold text-black dark:text-white">Lupa Kata Sandi</h3>
                <p className="text-xs text-black/50 dark:text-white/50 mt-0.5">
                  Masukkan email akun Anda. Kami akan mengirim link untuk mengatur ulang kata sandi.
                </p>
              </div>
              <button
                type="button"
                onClick={closeForgot}
                className="w-8 h-8 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5"
                aria-label="Tutup"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            {forgotMessage && (
              <div
                className={`mb-4 rounded-lg p-3 text-sm ${
                  forgotMessage.type === 'success'
                    ? 'bg-green-50 text-green-800 border border-green-200 dark:bg-green-500/10 dark:text-green-300 dark:border-green-500/20'
                    : 'bg-red-50 text-red-700 border border-red-200 dark:bg-red-500/10 dark:text-red-300 dark:border-red-500/20'
                }`}
              >
                {forgotMessage.text}
              </div>
            )}
            <form onSubmit={handleForgot} className="space-y-4">
              <input
                type="email"
                className="form-control"
                placeholder="nama@instansi.go.id"
                value={forgotEmail}
                onChange={(e) => setForgotEmail(e.target.value)}
                required
                autoComplete="email"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={closeForgot}
                  className="px-4 h-10 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 rounded-lg"
                >
                  Tutup
                </button>
                <button
                  type="submit"
                  disabled={forgotLoading}
                  className="px-5 h-10 text-sm font-semibold text-white bg-primary hover:bg-primary/90 rounded-lg disabled:opacity-50"
                >
                  {forgotLoading ? 'Mengirim...' : 'Kirim Link Reset'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Error Alert */}

      {error && (
        <div className="fixed top-4 right-4 z-50 max-w-sm bg-red-50 border border-red-200 rounded-lg shadow-lg p-4 flex items-start gap-3">
          <div className="flex-shrink-0">
            <svg className="w-5 h-5 text-red-500" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
            </svg>
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-red-800">Login Gagal</p>
            <p className="text-sm text-red-700 mt-1">{error}</p>
          </div>
          <button
            type="button"
            onClick={clearError}
            className="flex-shrink-0 text-red-400 hover:text-red-600 transition-colors"
            aria-label="Tutup"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </button>
        </div>
      )}
    </div>
  );
}
