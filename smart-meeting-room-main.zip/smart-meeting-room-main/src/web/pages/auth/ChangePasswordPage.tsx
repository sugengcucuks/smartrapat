import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../store/auth.store';
import { authApi } from '@shared/api/auth';
import { getErrorMessage, signOut } from '@shared/api/client';
import { PASSWORD_MIN_LENGTH } from '@shared/utils/password';
import { PasswordStrengthMeter } from '../../components/PasswordStrengthMeter';

/**
 * Halaman ganti password. Wajib dilalui bila `user.must_change_password` true
 * (mis. akun admin bawaan); semua rute lain diblokir sampai selesai.
 */
export function ChangePasswordPage() {
  const navigate = useNavigate();
  const { user, setTokens, updateUser } = useAuthStore();
  const forced = !!user?.must_change_password;
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (newPassword.length < PASSWORD_MIN_LENGTH) {
      setError(`Password baru minimal ${PASSWORD_MIN_LENGTH} karakter`);
      return;
    }
    if (newPassword !== confirm) {
      setError('Password baru dan konfirmasi tidak sama');
      return;
    }
    if (newPassword === oldPassword) {
      setError('Password baru harus berbeda dari password lama');
      return;
    }
    setLoading(true);
    try {
      const tokens = await authApi.changePassword(oldPassword, newPassword);
      if (tokens?.access_token) {
        setTokens(tokens.access_token, tokens.refresh_token);
      }
      updateUser({ must_change_password: false });
      navigate('/dashboard', { replace: true });
    } catch (err) {
      setError(getErrorMessage(err, 'Gagal mengubah password'));
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/login', { replace: true });
  };

  const inputCls =
    'w-full h-11 px-3 rounded-lg bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 text-sm text-black dark:text-white outline-none focus:border-primary transition-colors';

  return (
    <div className="min-h-screen w-full bg-[#f5f7fa] dark:bg-dark flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white dark:bg-gray rounded-2xl shadow-xl p-6">
        <div className="mb-5">
          <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center mb-3">
            <i className="ri-lock-password-line text-2xl"></i>
          </div>
          <h1 className="text-xl font-bold text-black dark:text-white">Ganti Password</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            {forced
              ? 'Demi keamanan, Anda wajib mengganti password sebelum melanjutkan.'
              : 'Ubah password akun Anda.'}
          </p>
        </div>

        {error && (
          <div className="mb-4 rounded-lg border border-red-200 bg-red-50 dark:bg-red-500/10 dark:border-red-500/20 p-3 text-sm text-red-700 dark:text-red-300">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">Password Lama</label>
            <input
              type="password"
              value={oldPassword}
              onChange={(e) => setOldPassword(e.target.value)}
              className={inputCls}
              autoComplete="current-password"
              required
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">Password Baru</label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className={inputCls}
              placeholder={`Min. ${PASSWORD_MIN_LENGTH} karakter`}
              minLength={PASSWORD_MIN_LENGTH}
              autoComplete="new-password"
              required
            />
            <PasswordStrengthMeter password={newPassword} />
          </div>
          <div>
            <label className="block text-xs font-semibold text-black/70 dark:text-white/70 mb-1.5">Konfirmasi Password Baru</label>
            <input
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              className={inputCls}
              minLength={PASSWORD_MIN_LENGTH}
              autoComplete="new-password"
              required
            />
            {confirm && confirm !== newPassword && (
              <p className="mt-1 text-xs text-danger">Konfirmasi tidak sama</p>
            )}
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full h-11 text-sm font-semibold text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors disabled:opacity-50"
          >
            {loading ? 'Menyimpan...' : 'Simpan Password Baru'}
          </button>
        </form>

        <div className="mt-4 flex justify-between text-sm">
          {!forced ? (
            <button type="button" onClick={() => navigate(-1)} className="text-black/60 dark:text-white/60 hover:underline">
              Kembali
            </button>
          ) : (
            <span />
          )}
          <button type="button" onClick={handleLogout} className="text-danger hover:underline">
            Keluar
          </button>
        </div>
      </div>
    </div>
  );
}
