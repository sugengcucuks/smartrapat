import { useEffect, useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi } from '../../../shared/api/auth';
import { getErrorMessage } from '../../../shared/api/client';
import { parseLocalDate, todayLocal } from '../../../shared/utils/date';
import { useAuthStore, usePermission } from '../../store/auth.store';
import type {
  Booking,
  BookingCreate,
  BookingUpdate,
  BookingStatus,
  Room,
  UserResponse,
  BookingParticipant,
} from '@shared/types';
import { BOOKING_STATUS_OPTIONS } from '@shared/types';

interface BookingFormState {
  title: string;
  room_id: string;
  date: string;
  start_time: string;
  end_time: string;
  participant_count: number;
  description: string;
  participants: BookingParticipant[];
}

const makeInitialForm = (): BookingFormState => ({
  title: '',
  room_id: '',
  date: todayLocal(),
  start_time: '09:00',
  end_time: '10:00',
  participant_count: 5,
  description: '',
  participants: [],
});

export function BookingListPage() {
  const navigate = useNavigate();
  const currentUser = useAuthStore((s) => s.user);
  const can = usePermission();
  const canApprove = can('bookings.approve');
  const canCreate = can(['bookings.create', 'bookings.approve']);
  const canDelete = can('bookings.delete');
  const isOwner = (b: Booking) => !!currentUser && (b.organizer_id === currentUser.id || b.user_id === currentUser.id);
  const canModify = (b: Booking) => canApprove || isOwner(b);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [users, setUsers] = useState<UserResponse[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterRoom, setFilterRoom] = useState('');
  const [filterDateFrom, setFilterDateFrom] = useState('');
  const [filterDateTo, setFilterDateTo] = useState('');
  const [page, setPage] = useState(1);
  const [perPage] = useState(10);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  const [showModal, setShowModal] = useState(false);
  const [editingBooking, setEditingBooking] = useState<Booking | null>(null);
  const [form, setForm] = useState<BookingFormState>(makeInitialForm);
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [newParticipantName, setNewParticipantName] = useState('');
  const [newParticipantEmail, setNewParticipantEmail] = useState('');
  const [newParticipantUserId, setNewParticipantUserId] = useState('');

  const [deleteConfirm, setDeleteConfirm] = useState<Booking | null>(null);
  const [detailModal, setDetailModal] = useState<Booking | null>(null);

  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchRooms = async () => {
    try {
      const result = await authApi.listRooms({ per_page: 100 });
      setRooms(result.items ?? []);
    } catch {
      setRooms([]);
    }
  };

  const fetchUsers = async () => {
    try {
      const result = await authApi.listUsers({ per_page: 100 });
      setUsers(result.items ?? []);
    } catch {
      setUsers([]);
    }
  };

  const fetchBookings = async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const result = await authApi.listBookings({
        page,
        per_page: perPage,
        room_id: filterRoom || undefined,
        status: filterStatus || undefined,
        date_from: filterDateFrom || undefined,
        date_to: filterDateTo || undefined,
      });
      setBookings(result.items ?? []);
      setTotal(result.total ?? 0);
      setTotalPages(result.total_pages ?? 0);
    } catch (err) {
      setBookings([]);
      setTotal(0);
      setTotalPages(0);
      setLoadError(getErrorMessage(err, 'Gagal memuat daftar pemesanan'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRooms();
    fetchUsers();
  }, []);

  useEffect(() => {
    fetchBookings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, filterStatus, filterRoom, filterDateFrom, filterDateTo]);

  // Backend /bookings belum mendukung pencarian teks: filter di sisi klien
  // hanya untuk halaman yang sedang dimuat.
  const visibleBookings = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return bookings;
    return bookings.filter(
      (b) =>
        b.title.toLowerCase().includes(q) ||
        (b.organizer_name ?? '').toLowerCase().includes(q) ||
        (b.room_name ?? '').toLowerCase().includes(q)
    );
  }, [bookings, search]);

  const openCreateModal = () => {
    setEditingBooking(null);
    setForm(makeInitialForm());
    setFormError(null);
    setShowModal(true);
  };

  const openEditModal = (booking: Booking) => {
    setEditingBooking(booking);
    setForm({
      title: booking.title,
      room_id: booking.room_id,
      date: booking.date,
      start_time: String(booking.start_time).slice(0, 5),
      end_time: String(booking.end_time).slice(0, 5),
      participant_count: booking.participant_count,
      description: booking.description || '',
      participants: booking.participants || [],
    });
    setFormError(null);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingBooking(null);
    setForm(makeInitialForm());
    setFormError(null);
    setNewParticipantName('');
    setNewParticipantEmail('');
    setNewParticipantUserId('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (form.start_time >= form.end_time) {
      setFormError('Jam selesai harus lebih besar dari jam mulai');
      return;
    }
    if (!form.room_id) {
      setFormError('Pilih ruangan');
      return;
    }

    setSubmitting(true);
    try {
      if (editingBooking) {
        const data: BookingUpdate = {
          title: form.title,
          room_id: form.room_id,
          date: form.date,
          start_time: form.start_time,
          end_time: form.end_time,
          participant_count: form.participant_count,
          description: form.description || undefined,
          participants: form.participants,
        };
        await authApi.updateBooking(editingBooking.id, data);
        showToast('success', 'Pemesanan berhasil diperbarui');
      } else {
        // Status tidak dikirim: backend menentukan (pending, atau approved bila berwenang).
        const data: BookingCreate = {
          title: form.title,
          room_id: form.room_id,
          date: form.date,
          start_time: form.start_time,
          end_time: form.end_time,
          participant_count: form.participant_count,
          description: form.description || undefined,
          participants: form.participants,
        };
        const created = await authApi.createBooking(data);
        showToast(
          'success',
          created?.status === 'approved' ? 'Pemesanan berhasil dibuat dan disetujui' : 'Pemesanan berhasil dibuat, menunggu persetujuan'
        );
      }
      closeModal();
      fetchBookings();
    } catch (err: unknown) {
      setFormError(getErrorMessage(err, 'Gagal menyimpan pemesanan'));
    } finally {
      setSubmitting(false);
    }
  };

  const handleAction = async (booking: Booking, action: 'approve' | 'reject' | 'cancel' | 'delete') => {
    try {
      if (action === 'delete') {
        await authApi.deleteBooking(booking.id);
        setDeleteConfirm(null);
        showToast('success', 'Pemesanan berhasil dihapus');
      } else if (action === 'approve') {
        await authApi.approveBooking(booking.id);
        showToast('success', 'Pemesanan disetujui');
      } else if (action === 'reject') {
        await authApi.rejectBooking(booking.id);
        showToast('success', 'Pemesanan ditolak');
      } else if (action === 'cancel') {
        await authApi.cancelBooking(booking.id);
        showToast('success', 'Pemesanan dibatalkan');
      }
      fetchBookings();
    } catch (err: unknown) {
      if (action === 'delete') setDeleteConfirm(null);
      showToast('error', getErrorMessage(err, 'Gagal melakukan aksi'));
    }
  };

  const addParticipant = () => {
    if (newParticipantUserId) {
      const user = users.find((u) => u.id === newParticipantUserId);
      if (user && !form.participants.some((p) => p.user_id === user.id)) {
        setForm({
          ...form,
          participants: [
            ...form.participants,
            { name: user.name, email: user.email, user_id: user.id, is_external: false, is_guest: false },
          ],
        });
      }
      setNewParticipantUserId('');
    } else if (newParticipantName && newParticipantEmail) {
      setForm({
        ...form,
        participants: [
          ...form.participants,
          { name: newParticipantName, email: newParticipantEmail, is_external: true, is_guest: true },
        ],
      });
      setNewParticipantName('');
      setNewParticipantEmail('');
    }
  };

  const removeParticipant = (idx: number) => {
    setForm({
      ...form,
      participants: form.participants.filter((_, i) => i !== idx),
    });
  };

  const statusBadgeClass = (status: BookingStatus) => {
    switch (status) {
      case 'pending':
        return 'bg-warning/10 text-warning border-warning/20';
      case 'approved':
        return 'bg-success/10 text-success border-success/20';
      case 'rejected':
        return 'bg-danger/10 text-danger border-danger/20';
      case 'cancelled':
        return 'bg-slate-200/70 text-slate-600 dark:bg-slate-500/20 dark:text-slate-300 border-slate-300/60';
      case 'completed':
        return 'bg-info/10 text-info border-info/20';
      case 'draft':
        return 'bg-gray-200/60 text-gray-600 dark:bg-gray-500/20 dark:text-gray-300 border-gray-300';
      default:
        return 'bg-black/10 text-black/70';
    }
  };

  const statusLabel = useMemo(() => {
    const map = new Map(BOOKING_STATUS_OPTIONS.map((s) => [s.value, s.label]));
    return (val: BookingStatus) => map.get(val) || val;
  }, []);

  const pageNumbers = useMemo(() => {
    const pages: (number | string)[] = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      if (page <= 4) {
        pages.push(1, 2, 3, 4, 5, '...', totalPages);
      } else if (page >= totalPages - 3) {
        pages.push(1, '...', totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages);
      } else {
        pages.push(1, '...', page - 1, page, page + 1, '...', totalPages);
      }
    }
    return pages;
  }, [page, totalPages]);

  const formatDate = (d: string) => {
    const date = parseLocalDate(String(d).slice(0, 10));
    return date.toLocaleDateString('id-ID', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Pemesanan Ruangan Rapat</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Kelola pemesanan dan persetujuan ruangan rapat
          </p>
        </div>
        {canCreate && (
          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors shadow-sm"
          >
            <i className="ri-add-line text-lg"></i>
            <span>Buat Pemesanan</span>
          </button>
        )}
      </div>

      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
        <div className="flex flex-col sm:flex-row gap-3 mb-6 flex-wrap">
          <div className="relative flex-1 max-w-sm">
            <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40"></i>
            <input
              type="text"
              placeholder="Cari di halaman ini (judul, pemesan, ruangan)..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 placeholder:text-black/40 dark:placeholder:text-white/40"
            />
          </div>
          <input
            type="date"
            value={filterDateFrom}
            onChange={(e) => {
              setFilterDateFrom(e.target.value);
              setPage(1);
            }}
            className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
          />
          <input
            type="date"
            value={filterDateTo}
            onChange={(e) => {
              setFilterDateTo(e.target.value);
              setPage(1);
            }}
            className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
          />
          <select
            value={filterStatus}
            onChange={(e) => {
              setFilterStatus(e.target.value);
              setPage(1);
            }}
            className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
          >
            <option value="">Semua Status</option>
            {BOOKING_STATUS_OPTIONS.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </select>
          <select
            value={filterRoom}
            onChange={(e) => {
              setFilterRoom(e.target.value);
              setPage(1);
            }}
            className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
          >
            <option value="">Semua Ruangan</option>
            {rooms.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
          </select>
        </div>

        <div className="overflow-x-auto -mx-6">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-y border-black/10 dark:border-white/10">
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Judul
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Ruangan
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Tanggal / Waktu
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Pemesan
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Status
                </th>
                <th className="text-right py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Aksi
                </th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-black/50 dark:text-white/50">
                    <div className="inline-flex items-center gap-2">
                      <svg className="animate-spin h-5 w-5 text-primary" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      <span>Memuat data...</span>
                    </div>
                  </td>
                </tr>
              ) : loadError ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center">
                    <p className="text-sm text-red-600 dark:text-red-400">{loadError}</p>
                    <button
                      type="button"
                      onClick={fetchBookings}
                      className="mt-3 inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-primary bg-primary/10 hover:bg-primary/15 rounded-lg"
                    >
                      <i className="ri-refresh-line"></i> Coba Lagi
                    </button>
                  </td>
                </tr>
              ) : visibleBookings.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-black/50 dark:text-white/50">
                    <div className="flex flex-col items-center gap-2">
                      <i className="ri-calendar-todo-line text-4xl text-black/30 dark:text-white/30"></i>
                      <span>{search.trim() ? 'Tidak ada pemesanan yang cocok di halaman ini' : 'Belum ada data'}</span>
                    </div>
                  </td>
                </tr>
              ) : (
                visibleBookings.map((booking) => (
                  <tr
                    key={booking.id}
                    className="border-b border-black/5 dark:border-white/5 hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors"
                  >
                    <td className="py-3 px-6">
                      <div className="font-semibold text-black/80 dark:text-white/80 cursor-pointer hover:text-primary transition-colors" onClick={() => setDetailModal(booking)}>
                        {booking.title}
                      </div>
                      <div className="text-xs text-black/50 mt-0.5">
                        {booking.participant_count} peserta
                      </div>
                    </td>
                    <td className="py-3 px-6 whitespace-nowrap">
                      <div className="text-black/80 dark:text-white/80 font-medium">{booking.room_name || '-'}</div>
                      <div className="text-xs text-black/50">{booking.building_name || ''}</div>
                    </td>
                    <td className="py-3 px-6 whitespace-nowrap">
                      <div className="text-black/80 dark:text-white/80">{formatDate(booking.date)}</div>
                      <div className="text-xs text-black/50">
                        <i className="ri-time-line mr-1"></i>
                        {String(booking.start_time).slice(0, 5)} - {String(booking.end_time).slice(0, 5)}
                      </div>
                    </td>
                    <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap">
                      {booking.organizer_name || '-'}
                    </td>
                    <td className="py-3 px-6 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${statusBadgeClass(booking.status)}`}>
                        {statusLabel(booking.status)}
                      </span>
                    </td>
                    <td className="py-3 px-6">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => setDetailModal(booking)}
                          title="Lihat Detail"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-info hover:bg-info/10 rounded-lg transition-colors"
                        >
                          <i className="ri-eye-line"></i>
                        </button>
                        {(booking.status === 'approved' || booking.status === 'pending' || booking.status === 'draft') && (
                          <button
                            type="button"
                            onClick={() => navigate(`/bookings/${booking.id}/meeting`)}
                            title="Masuk Rapat (Live Meeting)"
                            className="p-2 text-black/60 dark:text-white/60 hover:text-primary hover:bg-primary/10 rounded-lg transition-colors"
                          >
                            <i className="ri-video-chat-line"></i>
                          </button>
                        )}
                        {booking.status === 'pending' && canApprove && (
                          <>
                            <button
                              type="button"
                              onClick={() => handleAction(booking, 'approve')}
                              title="Setujui"
                              className="p-2 text-black/60 dark:text-white/60 hover:text-success hover:bg-success/10 rounded-lg transition-colors"
                            >
                              <i className="ri-check-line"></i>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleAction(booking, 'reject')}
                              title="Tolak"
                              className="p-2 text-black/60 dark:text-white/60 hover:text-danger hover:bg-danger/10 rounded-lg transition-colors"
                            >
                              <i className="ri-close-line"></i>
                            </button>
                          </>
                        )}
                        {(booking.status === 'approved' || booking.status === 'pending') && canModify(booking) && (
                          <button
                            type="button"
                            onClick={() => handleAction(booking, 'cancel')}
                            title="Batalkan Booking"
                            className="p-2 text-black/60 dark:text-white/60 hover:text-warning hover:bg-warning/10 rounded-lg transition-colors"
                          >
                            <i className="ri-stop-circle-line"></i>
                          </button>
                        )}
                        {canModify(booking) && (
                        <button
                          type="button"
                          onClick={() => openEditModal(booking)}
                          title="Ubah"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-primary hover:bg-primary/10 rounded-lg transition-colors"
                        >
                          <i className="ri-edit-line"></i>
                        </button>
                        )}
                        {canDelete && (
                        <button
                          type="button"
                          onClick={() => setDeleteConfirm(booking)}
                          title="Hapus"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-danger hover:bg-danger/10 rounded-lg transition-colors"
                        >
                          <i className="ri-delete-bin-line"></i>
                        </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {totalPages > 0 && (
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-6 pt-4 border-t border-black/10 dark:border-white/10">
            <p className="text-sm text-black/60 dark:text-white/60">
              Menampilkan {((page - 1) * perPage) + 1} - {Math.min(page * perPage, total)} dari {total} data
            </p>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <i className="ri-arrow-left-s-line"></i>
              </button>
              {pageNumbers.map((p, idx) =>
                typeof p === 'number' ? (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setPage(p)}
                    className={`w-9 h-9 rounded-lg text-sm font-medium transition-colors ${
                      p === page
                        ? 'bg-primary text-white shadow-sm'
                        : 'text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5'
                    }`}
                  >
                    {p}
                  </button>
                ) : (
                  <span key={idx} className="w-9 h-9 flex items-center justify-center text-sm text-black/40 dark:text-white/40">
                    {p}
                  </span>
                )
              )}
              <button
                type="button"
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <i className="ri-arrow-right-s-line"></i>
              </button>
            </div>
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={closeModal}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">
                {editingBooking ? 'Ubah Pemesanan' : 'Buat Pemesanan Baru'}
              </h2>
              <button
                type="button"
                onClick={closeModal}
                className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <form onSubmit={handleSubmit} className="overflow-y-auto flex-1">
              <div className="px-6 py-5 space-y-4">
                {formError && (
                  <div className="p-3 rounded-lg bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 text-sm">
                    <div className="flex items-start gap-2">
                      <i className="ri-error-warning-line mt-0.5"></i>
                      <span>{formError}</span>
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                    Judul Rapat <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={200}
                    value={form.title}
                    onChange={(e) => setForm({ ...form, title: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    placeholder="Contoh: Rapat Evaluasi Proyek"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      Ruangan <span className="text-red-500">*</span>
                    </label>
                    <select
                      required
                      value={form.room_id}
                      onChange={(e) => setForm({ ...form, room_id: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    >
                      <option value="">Pilih Ruangan</option>
                      {rooms.filter((r) => r.is_active).map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.name} ({r.code}) - Kap. {r.capacity}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      Jumlah Peserta <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      required
                      min={1}
                      value={form.participant_count}
                      onChange={(e) => setForm({ ...form, participant_count: Number(e.target.value) || 1 })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      Tanggal <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="date"
                      required
                      value={form.date}
                      onChange={(e) => setForm({ ...form, date: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                        Jam Mulai <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="time"
                        required
                        value={form.start_time}
                        onChange={(e) => setForm({ ...form, start_time: e.target.value })}
                        className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                        Jam Selesai <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="time"
                        required
                        value={form.end_time}
                        onChange={(e) => setForm({ ...form, end_time: e.target.value })}
                        className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                    Deskripsi
                  </label>
                  <textarea
                    rows={2}
                    maxLength={500}
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 resize-none"
                    placeholder="Deskripsi atau agenda rapat..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-2">
                    Daftar Peserta
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-3">
                    <select
                      value={newParticipantUserId}
                      onChange={(e) => setNewParticipantUserId(e.target.value)}
                      className="px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    >
                      <option value="">Pilih Pengguna Internal</option>
                      {users.map((u) => (
                        <option key={u.id} value={u.id}>
                          {u.name}
                        </option>
                      ))}
                    </select>
                    <input
                      type="text"
                      placeholder="Nama tamu..."
                      value={newParticipantName}
                      onChange={(e) => setNewParticipantName(e.target.value)}
                      className="px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                      disabled={!!newParticipantUserId}
                    />
                    <div className="flex gap-2">
                      <input
                        type="email"
                        placeholder="Email tamu..."
                        value={newParticipantEmail}
                        onChange={(e) => setNewParticipantEmail(e.target.value)}
                        className="flex-1 px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                        disabled={!!newParticipantUserId}
                      />
                      <button
                        type="button"
                        onClick={addParticipant}
                        className="px-3 py-2 bg-primary/10 text-primary rounded-lg hover:bg-primary/20 transition-colors"
                      >
                        <i className="ri-user-add-line"></i>
                      </button>
                    </div>
                  </div>
                  {form.participants.length > 0 && (
                    <div className="space-y-2">
                      {form.participants.map((p, idx) => (
                        <div
                          key={idx}
                          className="flex items-center justify-between px-3 py-2 bg-black/[0.02] dark:bg-white/[0.02] rounded-lg border border-black/10 dark:border-white/10"
                        >
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center text-xs font-semibold text-primary">
                              {p.name.charAt(0)}
                            </div>
                            <div>
                              <div className="text-sm font-medium text-black/80 dark:text-white/80">
                                {p.name}
                                {p.is_external && (
                                  <span className="ml-2 inline-flex px-1.5 py-0.5 text-[10px] rounded bg-warning/10 text-warning font-semibold">
                                    Eksternal
                                  </span>
                                )}
                              </div>
                              <div className="text-xs text-black/50">{p.email}</div>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => removeParticipant(idx)}
                            className="p-1.5 text-black/40 hover:text-danger hover:bg-danger/10 rounded-lg transition-colors"
                          >
                            <i className="ri-close-line"></i>
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                  {form.participants.length === 0 && (
                    <div className="text-sm text-black/40 dark:text-white/40 italic">
                      Belum ada peserta ditambahkan
                    </div>
                  )}
                </div>
              </div>
              <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={closeModal}
                  disabled={submitting}
                  className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors disabled:opacity-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submitting && (
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                  )}
                  <span>Simpan Perubahan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {detailModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setDetailModal(null)}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-lg overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">Detail Pemesanan</h2>
              <button
                type="button"
                onClick={() => setDetailModal(null)}
                className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <div className="px-6 py-5 space-y-4">
              <div>
                <h3 className="text-xl font-bold text-black dark:text-white">{detailModal.title}</h3>
                <div className="mt-1">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${statusBadgeClass(detailModal.status)}`}>
                    {statusLabel(detailModal.status)}
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-black/50 mb-0.5">Ruangan</div>
                  <div className="font-medium text-black/80 dark:text-white/80">{detailModal.room_name || '-'}</div>
                  <div className="text-xs text-black/50">{detailModal.building_name || ''}</div>
                </div>
                <div>
                  <div className="text-black/50 mb-0.5">Pemesan</div>
                  <div className="font-medium text-black/80 dark:text-white/80">{detailModal.organizer_name || '-'}</div>
                </div>
                <div>
                  <div className="text-black/50 mb-0.5">Tanggal</div>
                  <div className="font-medium text-black/80 dark:text-white/80">{formatDate(detailModal.date)}</div>
                </div>
                <div>
                  <div className="text-black/50 mb-0.5">Waktu</div>
                  <div className="font-medium text-black/80 dark:text-white/80">{detailModal.start_time} - {detailModal.end_time}</div>
                </div>
                <div>
                  <div className="text-black/50 mb-0.5">Jumlah Peserta</div>
                  <div className="font-medium text-black/80 dark:text-white/80">{detailModal.participant_count} orang</div>
                </div>
              </div>
              {detailModal.description && (
                <div className="pt-2 border-t border-black/10 dark:border-white/10">
                  <div className="text-black/50 text-sm mb-1">Deskripsi</div>
                  <p className="text-sm text-black/70 dark:text-white/70">{detailModal.description}</p>
                </div>
              )}
              {detailModal.participants && detailModal.participants.length > 0 && (
                <div className="pt-2 border-t border-black/10 dark:border-white/10">
                  <div className="text-black/50 text-sm mb-2">Peserta ({detailModal.participants.length})</div>
                  <div className="space-y-2">
                    {detailModal.participants.map((p, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-[10px] font-semibold text-primary">
                          {p.name.charAt(0)}
                        </div>
                        <span className="text-sm text-black/70 dark:text-white/70">{p.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex items-center justify-end gap-2">
              {detailModal.status === 'pending' && canApprove && (

                <>
                  <button
                    type="button"
                    onClick={() => {
                      handleAction(detailModal, 'approve');
                      setDetailModal(null);
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-white bg-success hover:bg-success/90 rounded-lg transition-colors"
                  >
                    <i className="ri-check-line"></i>
                    Setujui
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      handleAction(detailModal, 'reject');
                      setDetailModal(null);
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-white bg-danger hover:bg-danger/90 rounded-lg transition-colors"
                  >
                    <i className="ri-close-line"></i>
                    Tolak
                  </button>
                </>
              )}
              <button
                type="button"
                onClick={() => setDetailModal(null)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setDeleteConfirm(null)}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-md overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-5">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-500/10 flex items-center justify-center shrink-0">
                  <i className="ri-delete-bin-line text-2xl text-red-600 dark:text-red-400"></i>
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-black dark:text-white">Hapus Pemesanan</h3>
                  <p className="text-sm text-black/60 dark:text-white/60 mt-1">
                    Apakah Anda yakin ingin menghapus pemesanan <span className="font-semibold">{deleteConfirm.title}</span>?
                  </p>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 bg-black/[0.02] dark:bg-white/[0.02] flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => handleAction(deleteConfirm, 'delete')}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors shadow-sm"
              >
                Hapus
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className={`fixed top-4 right-4 z-[60] max-w-sm rounded-lg shadow-lg p-4 flex items-start gap-3 ${
          toast.type === 'success'
            ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20'
            : 'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20'
        }`}>
          <div className="flex-shrink-0">
            <i className={`ri-check-line text-lg ${toast.type === 'success' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}></i>
          </div>
          <p className={`flex-1 text-sm font-medium ${toast.type === 'success' ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>
            {toast.message}
          </p>
          <button
            type="button"
            onClick={() => setToast(null)}
            className={`flex-shrink-0 transition-colors ${toast.type === 'success' ? 'text-green-400 hover:text-green-600' : 'text-red-400 hover:text-red-600'}`}
          >
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}
    </div>
  );
}
