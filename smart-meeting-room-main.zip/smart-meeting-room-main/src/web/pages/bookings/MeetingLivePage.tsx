// Konsol Live Meeting: state rapat dari server, denah kursi + pembicara aktif,
// presensi live, mixer mic, kontrol AV, dan notulensi.
// Kontrak API/WS: docs/architecture/LIVE_MEETING.md
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { liveMeetingApi } from '@shared/api/auth';
import { getErrorMessage } from '@shared/api/client';
import type { LiveMeetingSnapshot, LiveSeat, SeatAssignmentInput } from '@shared/types';
import { useRoomLive } from '../../hooks/useRoomLive';
import { SeatMap, SeatLegend } from '../../components/live/SeatMap';
import { ParticipantList } from '../../components/live/ParticipantList';
import { MeetingTimer } from '../../components/live/MeetingTimer';
import { SeatAssignmentPanel } from '../../components/live/SeatAssignmentPanel';
import { LiveTranscriptPanel } from '../../components/live/LiveTranscriptPanel';
import { MicMixerPanel, RoomControlPanel } from '../../components/av';
import { dbToLevel, hhmm } from '../../components/live/liveUtils';

type SideTab = 'participants' | 'audio' | 'av' | 'notes';
type Toast = { type: 'success' | 'error' | 'info'; message: string };

const POLL_MS = 15000;

const STATUS_BADGE: Record<string, { label: string; cls: string; icon: string }> = {
  scheduled: { label: 'Terjadwal', cls: 'bg-info/10 text-info', icon: 'ri-calendar-event-line' },
  live: { label: 'Berlangsung', cls: 'bg-danger/10 text-danger', icon: 'ri-record-circle-fill' },
  ended: { label: 'Selesai', cls: 'bg-black/5 dark:bg-white/10 text-black/60 dark:text-white/60', icon: 'ri-checkbox-circle-line' },
};

function formatDate(d: string) {
  const dt = new Date(`${d}T00:00:00`);
  if (Number.isNaN(dt.getTime())) return d;
  return dt.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

export function MeetingLivePage() {
  const { id: bookingId } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [snap, setSnap] = useState<LiveMeetingSnapshot | null>(null);
  const [serverOffset, setServerOffset] = useState(0);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<{ status?: number; message: string } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [toast, setToast] = useState<Toast | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [tab, setTab] = useState<SideTab>('participants');
  const [selectedSeatId, setSelectedSeatId] = useState<string | null>(null);
  const [confirmEnd, setConfirmEnd] = useState(false);
  const toastTimer = useRef<number | null>(null);

  const showToast = useCallback((type: Toast['type'], message: string) => {
    setToast({ type, message });
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 3500);
  }, []);

  const applySnapshot = useCallback((s: LiveMeetingSnapshot) => {
    setSnap(s);
    const st = Date.parse(s.server_time);
    if (!Number.isNaN(st)) setServerOffset(st - Date.now());
  }, []);

  const load = useCallback(
    async (silent = false) => {
      if (!bookingId) return;
      if (!silent) setLoading(true);
      try {
        const s = await liveMeetingApi.getLive(bookingId);
        applySnapshot(s);
        setLoadError(null);
      } catch (err) {
        const status = (err as { response?: { status?: number } })?.response?.status;
        // Polling senyap: jangan timpa tampilan yang sudah ada karena gangguan sesaat.
        if (!silent || status === 403 || status === 404) {
          setLoadError({
            status,
            message:
              status === 404
                ? 'Rapat tidak ditemukan'
                : status === 403
                  ? 'Anda tidak berhak membuka konsol rapat ini'
                  : getErrorMessage(err, 'Gagal memuat data rapat'),
          });
        }
      } finally {
        if (!silent) setLoading(false);
      }
    },
    [bookingId, applySnapshot]
  );

  useEffect(() => {
    load();
  }, [load]);

  const roomId = snap?.booking.room_id ?? '';
  const live = useRoomLive(roomId);

  // Event WS -> muat ulang snapshot (digabung agar tidak membanjiri server).
  const reloadTimer = useRef<number | null>(null);
  const scheduleReload = useCallback(() => {
    if (reloadTimer.current) return;
    reloadTimer.current = window.setTimeout(() => {
      reloadTimer.current = null;
      load(true);
    }, 400);
  }, [load]);

  useEffect(() => {
    if (!roomId) return;
    const events = ['attendance_changed', 'seats_changed', 'meeting_status', 'recording_status', 'snapshot'];
    const offs = events.map((ev) =>
      live.subscribe(ev, (data: { booking_id?: string } | null) => {
        if (!data?.booking_id || data.booking_id === bookingId) scheduleReload();
      })
    );
    return () => offs.forEach((off) => off && off());
  }, [roomId, bookingId, live.subscribe, scheduleReload]); // eslint-disable-line react-hooks/exhaustive-deps

  // Polling cadangan (tetap jalan walau WS terhubung, lebih jarang).
  useEffect(() => {
    if (!bookingId) return;
    const t = window.setInterval(() => {
      if (document.visibilityState === 'visible') load(true);
    }, live.connected ? POLL_MS * 4 : POLL_MS);
    return () => window.clearInterval(t);
  }, [bookingId, load, live.connected]);

  useEffect(
    () => () => {
      if (toastTimer.current) window.clearTimeout(toastTimer.current);
      if (reloadTimer.current) window.clearTimeout(reloadTimer.current);
    },
    []
  );

  // ===== Turunan data =====
  const seats: LiveSeat[] = useMemo(() => snap?.seats ?? [], [snap]);
  const attendedIds = useMemo(
    () => new Set((snap?.participants ?? []).filter((p) => p.attended).map((p) => p.id)),
    [snap]
  );
  const seatByChannelNo = useMemo(() => {
    const m = new Map<number, LiveSeat>();
    seats.forEach((s) => s.channel && m.set(s.channel.channel_no, s));
    return m;
  }, [seats]);
  const activeSeatIds = useMemo(() => {
    const ids = new Set<string>((live.activeSeats ?? []).map(String));
    (live.activeChannels ?? []).forEach((ch) => {
      const s = seatByChannelNo.get(Number(ch));
      if (s) ids.add(s.id);
    });
    return ids;
  }, [live.activeSeats, live.activeChannels, seatByChannelNo]);
  const activeParticipantIds = useMemo(() => {
    const ids = new Set<string>((live.activeParticipants ?? []).map(String));
    seats.forEach((s) => {
      if (activeSeatIds.has(s.id) && s.assignment?.participant_id) ids.add(s.assignment.participant_id);
    });
    return ids;
  }, [live.activeParticipants, seats, activeSeatIds]);
  const hasLevels = live.connected && Object.keys(live.levels ?? {}).length > 0;
  const levelFor = useCallback(
    (s: { channel?: { channel_no: number } | null }) => {
      if (!hasLevels || !s.channel) return null;
      const lv = (live.levels as Record<number, number>)[s.channel.channel_no];
      return lv === undefined ? 0 : dbToLevel(lv);
    },
    [hasLevels, live.levels]
  );
  const seatsByChannel = useMemo(() => {
    const out: Record<number, { label: string; name?: string }> = {};
    seats.forEach((s) => {
      if (s.channel) out[s.channel.channel_no] = { label: s.label, name: s.assignment?.name ?? undefined };
    });
    return out;
  }, [seats]);
  const activeSpeakers = useMemo(
    () => seats.filter((s) => activeSeatIds.has(s.id)).map((s) => s.assignment?.name ?? `Kursi ${s.label}`),
    [seats, activeSeatIds]
  );
  const selectedSeat = seats.find((s) => s.id === selectedSeatId) ?? null;
  const transcriptParticipants = useMemo(
    () => (snap?.participants ?? []).map((p) => ({ id: p.id, name: p.name })),
    [snap]
  );

  // ===== Aksi =====
  const runAction = async (key: string, fn: () => Promise<LiveMeetingSnapshot>, okMsg: string) => {
    if (!bookingId) return;
    setBusy(key);
    setActionError(null);
    try {
      applySnapshot(await fn());
      showToast('success', okMsg);
    } catch (err) {
      const msg = getErrorMessage(err, 'Aksi gagal');
      setActionError(msg);
      showToast('error', msg);
    } finally {
      setBusy(null);
    }
  };

  const saveAssignment = async (input: SeatAssignmentInput, okMsg: string) => {
    if (!bookingId) return;
    setBusy('seat');
    try {
      await liveMeetingApi.saveSeatAssignments(bookingId, [input]);
      await load(true);
      showToast('success', okMsg);
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal menyimpan penempatan kursi'));
    } finally {
      setBusy(null);
    }
  };

  const autoFill = async () => {
    if (!bookingId) return;
    setBusy('auto');
    try {
      const res = await liveMeetingApi.autoSeatAssignments(bookingId, 'attended_first');
      await load(true);
      showToast(
        res.assigned ? 'success' : 'info',
        res.assigned ? `${res.assigned} peserta ditempatkan otomatis` : 'Tidak ada peserta/kursi kosong untuk diisi'
      );
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal mengisi kursi otomatis'));
    } finally {
      setBusy(null);
    }
  };

  // ===== Render =====
  if (loading && !snap) {
    return (
      <div className="flex items-center justify-center h-64 text-black/50 dark:text-white/50 gap-2">
        <i className="ri-loader-4-line animate-spin text-2xl"></i> Memuat konsol rapat...
      </div>
    );
  }

  if (!snap) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-3 text-center">
        <i className={`${loadError?.status === 403 ? 'ri-lock-line' : 'ri-calendar-close-line'} text-5xl text-black/30 dark:text-white/30`}></i>
        <p className="text-black/70 dark:text-white/70">{loadError?.message ?? 'Rapat tidak ditemukan'}</p>
        <div className="flex gap-2">
          {loadError && loadError.status !== 403 && loadError.status !== 404 && (
            <button type="button" onClick={() => load()} className="px-4 py-2 bg-primary/10 text-primary rounded-lg text-sm font-medium">
              Coba lagi
            </button>
          )}
          <button type="button" onClick={() => navigate('/bookings')} className="px-4 py-2 bg-primary text-white rounded-lg text-sm font-medium">
            Kembali ke Daftar Booking
          </button>
        </div>
      </div>
    );
  }

  const b = snap.booking;
  const canControl = snap.permissions.can_control;
  const status = STATUS_BADGE[b.meeting_status] ?? STATUS_BADGE.scheduled;
  const isEnded = b.meeting_status === 'ended';
  const isLive = b.meeting_status === 'live';

  return (
    <div className="space-y-5">
      {/* ===== HEADER ===== */}
      <div className="bg-white dark:bg-gray border border-black/10 dark:border-white/10 rounded-xl shadow-sm p-4">
        <div className="flex flex-col lg:flex-row lg:items-center gap-4">
          <div className="flex items-start gap-3 flex-1 min-w-0">
            <button
              type="button"
              onClick={() => navigate('/bookings')}
              className="p-2 rounded-lg bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 text-black/60 dark:text-white/60"
              title="Kembali"
            >
              <i className="ri-arrow-left-line text-xl"></i>
            </button>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-xl md:text-2xl font-bold text-black dark:text-white truncate">{b.title}</h1>
                <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${status.cls}`}>
                  <i className={`${status.icon} ${isLive ? 'animate-pulse' : ''}`}></i>
                  {status.label}
                </span>
                {live.connected ? (
                  <span className="inline-flex items-center gap-1 text-xs text-success" title="Terhubung ke kanal live ruangan">
                    <i className="ri-wifi-line"></i> Live
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-xs text-black/40 dark:text-white/40" title="Data diperbarui berkala">
                    <i className="ri-refresh-line"></i> Berkala
                  </span>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-x-4 mt-1 text-sm text-black/60 dark:text-white/60">
                <span><i className="ri-map-pin-line mr-1"></i>{b.room_name ?? '-'}</span>
                <span><i className="ri-calendar-line mr-1"></i>{formatDate(b.date)}</span>
                <span>
                  <i className="ri-time-line mr-1"></i>
                  {hhmm(b.start_time)} – {hhmm(b.end_time)}
                  {b.extended_minutes > 0 && (
                    <span className="text-warning"> (diperpanjang {b.extended_minutes} menit)</span>
                  )}
                </span>
                <span><i className="ri-user-star-line mr-1"></i>{b.organizer_name ?? '-'}</span>
                <span><i className="ri-team-line mr-1"></i>{snap.attendance.attended}/{snap.attendance.total} hadir</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <MeetingTimer booking={b} serverOffsetMs={serverOffset} compact />
            {canControl && !isEnded && (
              <div className="flex flex-wrap gap-2">
                {!isLive && (
                  <button
                    type="button"
                    disabled={!!busy}
                    onClick={() => runAction('start', () => liveMeetingApi.startMeeting(b.id), 'Rapat dimulai')}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-success hover:bg-success/90 rounded-lg disabled:opacity-50"
                  >
                    <i className={busy === 'start' ? 'ri-loader-4-line animate-spin' : 'ri-play-circle-line'}></i>
                    Mulai
                  </button>
                )}
                {[15, 30].map((m) => (
                  <button
                    key={m}
                    type="button"
                    disabled={!!busy}
                    onClick={() => runAction(`extend${m}`, () => liveMeetingApi.extendMeeting(b.id, m), `Rapat diperpanjang ${m} menit`)}
                    className="inline-flex items-center gap-1 px-3 py-2 text-sm font-medium text-info bg-info/10 hover:bg-info/20 rounded-lg disabled:opacity-50"
                    title={`Perpanjang ${m} menit`}
                  >
                    <i className={busy === `extend${m}` ? 'ri-loader-4-line animate-spin' : 'ri-add-line'}></i>
                    {m} mnt
                  </button>
                ))}
                {isLive && (
                  <button
                    type="button"
                    disabled={!!busy}
                    onClick={() => setConfirmEnd(true)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-danger hover:bg-danger/90 rounded-lg disabled:opacity-50"
                  >
                    <i className="ri-stop-circle-line"></i>
                    Akhiri
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
        {actionError && (
          <div className="mt-3 flex items-start gap-2 p-3 rounded-lg bg-danger/10 text-danger text-sm" role="alert">
            <i className="ri-error-warning-line mt-0.5"></i>
            <span className="flex-1">{actionError}</span>
            <button type="button" onClick={() => setActionError(null)} title="Tutup">
              <i className="ri-close-line"></i>
            </button>
          </div>
        )}
        {isEnded && (
          <div className="mt-3 p-3 rounded-lg bg-black/5 dark:bg-white/5 text-sm text-black/60 dark:text-white/60">
            Rapat telah diakhiri. Penempatan kursi dikunci; notulensi tetap dapat dilengkapi di tab Notulensi.
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* ===== DENAH ===== */}
        <div className="lg:col-span-7 xl:col-span-8 space-y-4">
          <div className="bg-white dark:bg-gray border border-black/10 dark:border-white/10 rounded-xl shadow-sm p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="text-base font-bold text-black dark:text-white">Denah Kursi & Mic</h2>
                <p className="text-xs text-black/50 dark:text-white/50">
                  {activeSpeakers.length > 0 ? (
                    <span className="text-success font-semibold">
                      <i className="ri-mic-fill mr-1"></i>Sedang bicara: {activeSpeakers.join(', ')}
                    </span>
                  ) : canControl && !isEnded ? (
                    'Klik kursi untuk menempatkan peserta.'
                  ) : (
                    'Klik kursi untuk melihat detail.'
                  )}
                </p>
              </div>
              <div className="flex gap-2">
                {snap.permissions.can_edit_layout && (
                  <Link
                    to={`/rooms/${b.room_id}/layout`}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg"
                  >
                    <i className="ri-layout-4-line"></i>
                    Atur Denah
                  </Link>
                )}
                {canControl && !isEnded && seats.length > 0 && (
                  <button
                    type="button"
                    disabled={!!busy}
                    onClick={autoFill}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-primary bg-primary/10 hover:bg-primary/20 rounded-lg disabled:opacity-50"
                    title="Tempatkan peserta yang belum punya kursi (yang sudah hadir lebih dulu)"
                  >
                    <i className={busy === 'auto' ? 'ri-loader-4-line animate-spin' : 'ri-magic-line'}></i>
                    Isi otomatis
                  </button>
                )}
              </div>
            </div>

            {seats.length === 0 ? (
              <div className="rounded-xl border border-dashed border-black/10 dark:border-white/10 p-8 text-center text-sm text-black/60 dark:text-white/60">
                <i className="ri-layout-4-line text-4xl block mb-2 text-black/30 dark:text-white/30"></i>
                Ruangan ini belum memiliki denah kursi.
                {snap.permissions.can_edit_layout ? (
                  <>
                    {' '}
                    <Link to={`/rooms/${b.room_id}/layout`} className="text-primary font-semibold">
                      Buat denah & petakan mic
                    </Link>
                  </>
                ) : (
                  ' Hubungi admin ruangan untuk membuat denah.'
                )}
              </div>
            ) : (
              <>
                <SeatMap
                  seats={seats}
                  layout={snap.layout}
                  mode="view"
                  selectedId={selectedSeatId}
                  onSelect={setSelectedSeatId}
                  activeSeatIds={activeSeatIds}
                  attendedIds={attendedIds}
                  levelFor={hasLevels ? levelFor : undefined}
                  showAttendance
                  ariaLabel={`Denah kursi ${b.room_name ?? ''}`}
                />
                <SeatLegend showAttendance />
              </>
            )}
          </div>

          {selectedSeat && (
            <SeatAssignmentPanel
              seat={selectedSeat}
              participants={snap.participants}
              canEdit={canControl && !isEnded}
              busy={busy === 'seat'}
              onClose={() => setSelectedSeatId(null)}
              onSave={(input) => saveAssignment(input, `Kursi ${selectedSeat.label} disimpan`)}
              onClear={() => saveAssignment({ seat_id: selectedSeat.id }, `Kursi ${selectedSeat.label} dikosongkan`)}
            />
          )}
        </div>

        {/* ===== TAB SAMPING ===== */}
        <div className="lg:col-span-5 xl:col-span-4">
          <div className="bg-white dark:bg-gray border border-black/10 dark:border-white/10 rounded-xl shadow-sm">
            <div className="flex border-b border-black/10 dark:border-white/10 overflow-x-auto">
              {(
                [
                  ['participants', 'Peserta', 'ri-team-line'],
                  ['audio', 'Mic & Audio', 'ri-mic-line'],
                  ['av', 'Kontrol AV', 'ri-remote-control-line'],
                  ['notes', 'Notulensi', 'ri-file-text-line'],
                ] as [SideTab, string, string][]
              ).map(([k, label, icon]) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => setTab(k)}
                  className={`flex-1 flex flex-col items-center justify-center gap-0.5 px-1 py-2 text-xs font-medium whitespace-nowrap border-b-2 ${
                    tab === k
                      ? 'border-primary text-primary'
                      : 'text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white'
                  }`}
                  style={tab === k ? undefined : { borderBottomColor: 'transparent' }}
                >
                  <i className={`${icon} text-lg leading-none`}></i>
                  {label}
                </button>
              ))}
            </div>
            <div className="p-4">
              {tab === 'participants' && (
                <ParticipantList
                  participants={snap.participants}
                  highlightIds={activeParticipantIds}
                  onSelectSeat={(sid) => setSelectedSeatId(sid)}
                />
              )}
              {tab === 'audio' && (
                <div className="space-y-3">
                  {snap.audio_channels.length === 0 && (
                    <p className="text-sm text-black/60 dark:text-white/60">
                      Kanal mic ruangan belum dikonfigurasi.
                      {snap.permissions.can_edit_layout && (
                        <>
                          {' '}
                          <Link to={`/rooms/${b.room_id}/layout`} className="text-primary font-semibold">Atur di denah</Link>
                        </>
                      )}
                    </p>
                  )}
                  <MicMixerPanel roomId={b.room_id} seatsByChannel={seatsByChannel} compact live={live} />
                </div>
              )}
              {tab === 'av' && <RoomControlPanel roomId={b.room_id} compact live={live} />}
              {/* Tetap terpasang saat tab lain dibuka agar rekaman/stream notulensi tidak terputus. */}
              <div style={tab === 'notes' ? undefined : { display: 'none' }}>
                <LiveTranscriptPanel
                  bookingId={b.id}
                  roomId={b.room_id}
                  canEdit={snap.permissions.can_edit_notes}
                  subscribe={live.subscribe}
                  participants={transcriptParticipants}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ===== KONFIRMASI AKHIRI ===== */}
      {confirmEnd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" role="dialog" aria-modal="true">
          <div className="w-full max-w-md bg-white dark:bg-gray rounded-xl shadow-xl p-6 space-y-4">
            <div className="flex items-start gap-3">
              <span className="w-10 h-10 shrink-0 rounded-full bg-danger/10 text-danger flex items-center justify-center">
                <i className="ri-stop-circle-line text-xl"></i>
              </span>
              <div>
                <h3 className="text-lg font-bold text-black dark:text-white">Akhiri rapat?</h3>
                <p className="text-sm text-black/60 dark:text-white/60 mt-1">
                  Status rapat menjadi selesai, ruangan kembali tersedia di layar pintu, dan rekaman yang masih berjalan
                  dihentikan.
                </p>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmEnd(false)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 rounded-lg"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={!!busy}
                onClick={async () => {
                  await runAction('end', () => liveMeetingApi.endMeeting(b.id), 'Rapat diakhiri');
                  setConfirmEnd(false);
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-danger rounded-lg disabled:opacity-50"
              >
                {busy === 'end' && <i className="ri-loader-4-line animate-spin"></i>}
                Akhiri Rapat
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div
          className={`fixed bottom-5 right-6 z-50 flex items-center gap-2 px-4 py-3 rounded-lg shadow-lg text-sm font-medium text-white ${
            toast.type === 'success' ? 'bg-success' : toast.type === 'error' ? 'bg-danger' : 'bg-info'
          }`}
          role="status"
        >
          <i className={toast.type === 'success' ? 'ri-check-line' : toast.type === 'error' ? 'ri-error-warning-line' : 'ri-information-line'}></i>
          {toast.message}
        </div>
      )}
    </div>
  );
}

export default MeetingLivePage;
