import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi } from '../../../shared/api/auth';
import { getErrorMessage } from '../../../shared/api/client';
import { todayLocal } from '../../../shared/utils/date';
import type {
  Room,
  BookingCreate,
  RoomType,
  BookingParticipant,
  UserResponse,
} from '@shared/types';

interface BookingFormState {
  title: string;
  room_id: string;
  date: string;
  start_time: string;
  end_time: string;
  participant_count: number;
  description: string;
  participants: BookingParticipant[];
}

const makeInitialForm = (): BookingFormState => ({
  title: '',
  room_id: '',
  date: todayLocal(),
  start_time: '09:00',
  end_time: '10:00',
  participant_count: 5,
  description: '',
  participants: [],
});

const ROOM_TYPE_LABELS: Record<RoomType, string> = {
  meeting: 'Rapat',
  training: 'Pelatihan',
  aula: 'Aula',
  office: 'Kantor',
};

export function NewBookingPage() {
  const navigate = useNavigate();
  const [rooms, setRooms] = useState<Room[]>([]);
  const [users, setUsers] = useState<UserResponse[]>([]);
  const [form, setForm] = useState<BookingFormState>(makeInitialForm);
  const [roomsError, setRoomsError] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [loading, setLoading] = useState(true);

  const [newParticipantName, setNewParticipantName] = useState('');
  const [newParticipantEmail, setNewParticipantEmail] = useState('');
  const [newParticipantUserId, setNewParticipantUserId] = useState('');

  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchRooms = async () => {
    setLoading(true);
    setRoomsError(null);
    try {
      // Hanya ruangan yang bisa dipesan (status available).
      const result = await authApi.listRooms({ per_page: 100, status: 'available' });
      setRooms((result.items ?? []).filter((r) => r.is_active));
    } catch (err) {
      setRooms([]);
      setRoomsError(getErrorMessage(err, 'Gagal memuat daftar ruangan'));
    } finally {
      setLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      const result = await authApi.listUsers({ per_page: 100 });
      setUsers(result.items);
    } catch {
      setUsers([]);
    }
  };

  useEffect(() => {
    fetchRooms();
    fetchUsers();
  }, []);

  const selectedRoom = rooms.find((r) => r.id === form.room_id);

  const addParticipant = () => {
    if (newParticipantUserId) {
      const user = users.find((u) => u.id === newParticipantUserId);
      if (user && !form.participants.some((p) => p.user_id === user.id)) {
        setForm({
          ...form,
          participants: [
            ...form.participants,
            { name: user.name, email: user.email, user_id: user.id, is_external: false, is_guest: false },
          ],
        });
      }
      setNewParticipantUserId('');
    } else if (newParticipantName && newParticipantEmail) {
      setForm({
        ...form,
        participants: [
          ...form.participants,
          { name: newParticipantName, email: newParticipantEmail, is_external: true, is_guest: true },
        ],
      });
      setNewParticipantName('');
      setNewParticipantEmail('');
    }
  };

  const removeParticipant = (idx: number) => {
    setForm({
      ...form,
      participants: form.participants.filter((_, i) => i !== idx),
    });
  };

  const handleSubmit = async (e: React.FormEvent, asDraft = false) => {
    e.preventDefault();
    setFormError(null);

    if (!form.title.trim()) {
      setFormError('Judul rapat wajib diisi');
      return;
    }
    if (!form.room_id) {
      setFormError('Pilih ruangan terlebih dahulu');
      return;
    }
    if (form.start_time >= form.end_time) {
      setFormError('Jam selesai harus lebih besar dari jam mulai');
      return;
    }

    setSubmitting(true);
    try {
      const data: BookingCreate = {
        title: form.title,
        room_id: form.room_id,
        date: form.date,
        start_time: form.start_time,
        end_time: form.end_time,
        participant_count: form.participant_count,
        description: form.description || undefined,
        participants: form.participants,
      };
      // Draf dikirim eksplisit; selain itu status ditentukan backend (pending / approved).
      if (asDraft) data.status = 'draft';
      const created = await authApi.createBooking(data);
      showToast(
        'success',
        asDraft
          ? 'Pemesanan disimpan sebagai draf'
          : created?.status === 'approved'
            ? 'Pemesanan berhasil dibuat dan disetujui'
            : 'Pemesanan berhasil diajukan, menunggu persetujuan'
      );
      setTimeout(() => navigate('/bookings'), 1000);
    } catch (err: unknown) {
      setFormError(getErrorMessage(err, 'Gagal menyimpan pemesanan'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={() => navigate('/bookings')}
          className="p-2 rounded-lg text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
        >
          <i className="ri-arrow-left-line text-lg"></i>
        </button>
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Booking Ruangan Cepat</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Isi formulir di bawah untuk memesan ruangan rapat
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <form className="bg-white dark:bg-gray rounded-lg shadow-md p-6 space-y-5">
            {formError && (
              <div className="p-3 rounded-lg bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 text-sm">
                <div className="flex items-start gap-2">
                  <i className="ri-error-warning-line mt-0.5"></i>
                  <span>{formError}</span>
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-semibold text-black/80 dark:text-white mb-2">
                Judul Rapat <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                maxLength={200}
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="Contoh: Rapat Evaluasi Kinerja Bulanan"
                className="w-full px-4 py-3 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-black/80 dark:text-white mb-2">
                  Tanggal <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <i className="ri-calendar-line absolute left-3 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40"></i>
                  <input
                    type="date"
                    required
                    value={form.date}
                    onChange={(e) => setForm({ ...form, date: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-semibold text-black/80 dark:text-white mb-2">
                    Mulai <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <i className="ri-time-line absolute left-3 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40"></i>
                    <input
                      type="time"
                      required
                      value={form.start_time}
                      onChange={(e) => setForm({ ...form, start_time: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-black/80 dark:text-white mb-2">
                    Selesai <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <i className="ri-time-line absolute left-3 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40"></i>
                    <input
                      type="time"
                      required
                      value={form.end_time}
                      onChange={(e) => setForm({ ...form, end_time: e.target.value })}
                      className="w-full pl-10 pr-4 py-3 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    />
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-black/80 dark:text-white mb-2">
                  Jumlah Peserta <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <i className="ri-user-3-line absolute left-3 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40"></i>
                  <input
                    type="number"
                    required
                    min={1}
                    value={form.participant_count}
                    onChange={(e) => setForm({ ...form, participant_count: Number(e.target.value) || 1 })}
                    className="w-full pl-10 pr-4 py-3 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-black/80 dark:text-white mb-2">
                Deskripsi / Agenda
              </label>
              <textarea
                rows={4}
                maxLength={500}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="Tuliskan agenda atau catatan tambahan untuk rapat ini..."
                className="w-full px-4 py-3 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 resize-none"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-black/80 dark:text-white mb-2">
                Daftar Peserta
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-3">
                <select
                  value={newParticipantUserId}
                  onChange={(e) => setNewParticipantUserId(e.target.value)}
                  className="px-4 py-2.5 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                >
                  <option value="">Pilih Pengguna Internal</option>
                  {users.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  placeholder="Nama tamu eksternal..."
                  value={newParticipantName}
                  onChange={(e) => setNewParticipantName(e.target.value)}
                  disabled={!!newParticipantUserId}
                  className="px-4 py-2.5 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 disabled:opacity-50"
                />
                <div className="flex gap-2">
                  <input
                    type="email"
                    placeholder="Email tamu..."
                    value={newParticipantEmail}
                    onChange={(e) => setNewParticipantEmail(e.target.value)}
                    disabled={!!newParticipantUserId}
                    className="flex-1 px-4 py-2.5 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 disabled:opacity-50"
                  />
                  <button
                    type="button"
                    onClick={addParticipant}
                    className="px-4 py-2.5 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors shadow-sm"
                  >
                    <i className="ri-add-line"></i>
                  </button>
                </div>
              </div>
              {form.participants.length > 0 && (
                <div className="space-y-2">
                  {form.participants.map((p, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between px-4 py-3 bg-black/[0.02] dark:bg-white/[0.02] rounded-lg border border-black/10 dark:border-white/10"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-sm font-semibold text-primary">
                          {p.name.charAt(0)}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-black/80 dark:text-white/80 flex items-center gap-2">
                            {p.name}
                            {p.is_external && (
                              <span className="inline-flex px-2 py-0.5 text-[10px] rounded bg-warning/10 text-warning font-semibold">
                                Eksternal
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-black/50">{p.email}</div>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeParticipant(idx)}
                        className="p-2 text-black/40 hover:text-danger hover:bg-danger/10 rounded-lg transition-colors"
                      >
                        <i className="ri-close-line"></i>
                      </button>
                    </div>
                  ))}
                </div>
              )}
              {form.participants.length === 0 && (
                <div className="text-sm text-black/40 dark:text-white/40 italic py-4 text-center border border-dashed border-black/10 dark:border-white/10 rounded-lg">
                  Belum ada peserta ditambahkan
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-black/10 dark:border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center justify-end gap-3">
              <button
                type="button"
                onClick={(e) => handleSubmit(e, true)}
                disabled={submitting}
                className="px-5 py-2.5 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors disabled:opacity-50"
              >
                Simpan Sebagai Draf
              </button>
              <button
                type="button"
                onClick={(e) => handleSubmit(e, false)}
                disabled={submitting || loading}
                className="inline-flex items-center justify-center gap-2 px-6 py-2.5 text-sm font-semibold text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submitting && (
                  <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                )}
                <i className="ri-send-plane-line"></i>
                <span>Ajukan Pemesanan</span>
              </button>
            </div>
          </form>
        </div>

        <div className="space-y-4">
          <div className="bg-white dark:bg-gray rounded-lg shadow-md p-5">
            <h3 className="font-bold text-black dark:text-white mb-3 flex items-center gap-2">
              <i className="ri-door-open-line text-primary"></i>
              Pilih Ruangan
            </h3>
            {loading ? (
              <div className="py-8 text-center text-black/50 text-sm">Memuat ruangan...</div>
            ) : roomsError ? (
              <div className="py-8 text-center text-sm">
                <p className="text-red-600 dark:text-red-400">{roomsError}</p>
                <button type="button" onClick={fetchRooms} className="mt-2 text-primary underline font-medium">
                  Coba lagi
                </button>
              </div>
            ) : rooms.length === 0 ? (
              <div className="py-8 text-center text-black/50 text-sm">Belum ada ruangan tersedia</div>
            ) : (

              <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1 -mr-1">
                {rooms.map((room) => {
                  const isSelected = form.room_id === room.id;
                  const isCapOk = room.capacity >= form.participant_count;
                  return (
                    <button
                      key={room.id}
                      type="button"
                      onClick={() => setForm({ ...form, room_id: room.id })}
                      className={`w-full text-left p-4 rounded-lg border transition-all ${
                        isSelected
                          ? 'border-primary bg-primary/5 shadow-sm'
                          : 'border-black/10 dark:border-white/10 hover:border-primary/40 hover:bg-black/[0.02] dark:hover:bg-white/[0.02]'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="inline-flex px-1.5 py-0.5 rounded text-[10px] font-semibold bg-primary/10 text-primary">
                              {room.code}
                            </span>
                            <span className="text-xs px-1.5 py-0.5 rounded bg-info/10 text-info">
                              {ROOM_TYPE_LABELS[room.room_type]}
                            </span>
                          </div>
                          <div className="font-semibold text-sm text-black/80 dark:text-white/80 truncate">
                            {room.name}
                          </div>
                          <div className="text-xs text-black/50 mt-0.5">
                            {room.building_name} &middot; Lantai {room.floor || '-'}
                          </div>
                          <div className="flex items-center gap-3 mt-2 text-xs">
                            <span className="inline-flex items-center gap-1 text-black/60">
                              <i className="ri-user-3-line"></i>
                              {room.capacity} org
                              {!isCapOk && (
                                <span className="text-danger ml-1">(kurang)</span>
                              )}
                            </span>
                          </div>
                          {room.facilities?.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-2">
                              {room.facilities.slice(0, 4).map((f, idx) => (
                                <span key={idx} className="inline-block px-1.5 py-0.5 text-[10px] rounded bg-black/5 dark:bg-white/5 text-black/60 dark:text-white/60">
                                  {f}
                                </span>
                              ))}
                              {room.facilities.length > 4 && (
                                <span className="inline-block px-1.5 py-0.5 text-[10px] rounded bg-black/5 dark:bg-white/5 text-black/40">
                                  +{room.facilities.length - 4}
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                        {isSelected && (
                          <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center shrink-0 mt-1">
                            <i className="ri-check-line text-white text-xs"></i>
                          </div>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {selectedRoom && (
            <div className="bg-white dark:bg-gray rounded-lg shadow-md p-5">
              <h3 className="font-bold text-black dark:text-white mb-3 flex items-center gap-2">
                <i className="ri-information-line text-info"></i>
                Detail Ruangan
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-black/50">Kapasitas</span>
                  <span className="font-medium text-black/80 dark:text-white/80">{selectedRoom.capacity} orang</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-black/50">Lantai</span>
                  <span className="font-medium text-black/80 dark:text-white/80">{selectedRoom.floor || '-'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-black/50">Tipe</span>
                  <span className="font-medium text-black/80 dark:text-white/80">{ROOM_TYPE_LABELS[selectedRoom.room_type]}</span>
                </div>
                {selectedRoom.facilities?.length > 0 && (
                  <div className="pt-2 border-t border-black/10 dark:border-white/10">
                    <span className="text-black/50 text-xs">Fasilitas:</span>
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {selectedRoom.facilities.map((f, idx) => (
                        <span key={idx} className="inline-block px-2 py-0.5 text-[11px] rounded bg-primary/10 text-primary">
                          {f}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {toast && (
        <div className={`fixed top-4 right-4 z-[60] max-w-sm rounded-lg shadow-lg p-4 flex items-start gap-3 ${
          toast.type === 'success'
            ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20'
            : 'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20'
        }`}>
          <div className="flex-shrink-0">
            <i className={`ri-check-line text-lg ${toast.type === 'success' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}></i>
          </div>
          <p className={`flex-1 text-sm font-medium ${toast.type === 'success' ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>
            {toast.message}
          </p>
          <button
            type="button"
            onClick={() => setToast(null)}
            className={`flex-shrink-0 transition-colors ${toast.type === 'success' ? 'text-green-400 hover:text-green-600' : 'text-red-400 hover:text-red-600'}`}
          >
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}
    </div>
  );
}
