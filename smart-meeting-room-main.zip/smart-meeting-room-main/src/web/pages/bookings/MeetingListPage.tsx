import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi } from '@shared/api/auth';
import { getErrorMessage } from '@shared/api/client';
import { addDaysLocal, parseLocalDate, todayLocal } from '@shared/utils/date';
import type { Booking } from '@shared/types';

const STATUS_LABEL: Record<string, string> = {
  pending: 'Menunggu Persetujuan',
  approved: 'Disetujui',
  rejected: 'Ditolak',
  cancelled: 'Dibatalkan',
  completed: 'Selesai',
  draft: 'Draf',
};

const STATUS_COLOR: Record<string, string> = {
  pending: 'bg-warning/15 text-warning border-warning/30',
  approved: 'bg-success/15 text-success border-success/30',
  rejected: 'bg-danger/15 text-danger border-danger/30',
  cancelled: 'bg-black/10 text-black/60 dark:bg-white/10 dark:text-white/60 border-transparent',
  completed: 'bg-indigo-500/15 text-indigo-500 border-indigo-500/30',
  draft: 'bg-info/15 text-info border-info/30',
};

export function MeetingListPage() {
  const navigate = useNavigate();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [today, setToday] = useState(() => todayLocal());
  const [filter, setFilter] = useState<'all' | 'today' | 'upcoming'>('today');

  const loadBookings = async () => {
    setLoading(true);
    setLoadError(null);
    try {
      let from: string | undefined = undefined;
      let to: string | undefined = undefined;
      if (filter === 'today') {
        from = today;
        to = today;
      } else if (filter === 'upcoming') {
        from = today;
        to = addDaysLocal(today, 14);
      }
      const res = await authApi.listBookings({
        page: 1,
        per_page: 100,
        date_from: from,
        date_to: to,
      });
      setBookings(res?.items ?? []);
    } catch (err) {
      setBookings([]);
      setLoadError(getErrorMessage(err, 'Gagal memuat data rapat'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBookings();
  }, [filter, today]);

  const displayDate = parseLocalDate(today).toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const canJoin = (status: string) => ['pending', 'approved', 'draft'].includes(status);

  const isOngoing = (b: Booking): boolean => {
    try {
      if (!b.date || !b.start_time || !b.end_time) return false;
      const [sH, sM] = (b.start_time as string).split(':').map(Number);
      const [eH, eM] = (b.end_time as string).split(':').map(Number);
      const now = new Date();
      const start = parseLocalDate(String(b.date).slice(0, 10));
      start.setHours(sH, sM, 0, 0);
      const end = parseLocalDate(String(b.date).slice(0, 10));
      end.setHours(eH, eM, 0, 0);
      return now >= start && now <= end;
    } catch {
      return false;
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white flex items-center gap-3">
            <span className="inline-flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-indigo-500 text-white">
              <i className="ri-video-chat-line text-xl"></i>
            </span>
            Live Meeting
          </h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Kelola dan masuk ke sesi rapat yang sedang berlangsung / akan datang.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex items-center gap-1 p-1 rounded-lg bg-black/5 dark:bg-white/5">
            {(['today', 'upcoming', 'all'] as const).map((opt) => (
              <button
                key={opt}
                type="button"
                onClick={() => setFilter(opt)}
                className={`px-3 h-8 rounded-md text-sm font-medium transition-colors ${
                  filter === opt
                    ? 'bg-white dark:bg-gray text-primary shadow-sm'
                    : 'text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white'
                }`}
              >
                {opt === 'today' ? 'Hari Ini' : opt === 'upcoming' ? '14 Hari Ke Depan' : 'Semua'}
              </button>
            ))}
          </div>
          <input
            type="date"
            value={today}
            onChange={(e) => setToday(e.target.value)}
            className="h-10 px-3 rounded-lg bg-white dark:bg-gray border border-black/10 dark:border-white/10 text-sm text-black dark:text-white outline-none focus:border-primary transition-colors"
          />
          <button
            type="button"
            onClick={loadBookings}
            className="h-10 w-10 rounded-lg bg-primary/10 text-primary hover:bg-primary/15 transition-colors"
            title="Refresh"
          >
            <i className="ri-refresh-line"></i>
          </button>
        </div>
      </div>

      {filter === 'today' && (
        <div className="bg-white dark:bg-gray rounded-xl shadow-sm border border-black/10 dark:border-white/10 p-5">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500/20 to-primary/20 flex items-center justify-center">
              <i className="ri-calendar-check-line text-xl text-primary"></i>
            </div>
            <div>
              <h3 className="text-lg font-bold text-black dark:text-white">{displayDate}</h3>
              <p className="text-sm text-black/60 dark:text-white/60">
                Total <b>{bookings.length}</b> rapat hari ini · {bookings.filter((b) => canJoin(b.status)).length} bisa masuk · {bookings.filter((b) => isOngoing(b)).length} sedang berlangsung
              </p>
            </div>
          </div>
        </div>
      )}

      {loading ? (
        <div className="py-20 flex flex-col items-center gap-3 text-black/40 dark:text-white/40">
          <svg className="animate-spin h-10 w-10 text-primary" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
          </svg>
          <p className="text-sm">Memuat data rapat...</p>
        </div>
      ) : loadError ? (
        <div className="bg-white dark:bg-gray rounded-xl shadow-sm border border-black/10 dark:border-white/10 py-16 text-center px-6">
          <p className="text-sm text-red-600 dark:text-red-400">{loadError}</p>
          <button
            type="button"
            onClick={loadBookings}
            className="mt-3 inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-primary bg-primary/10 hover:bg-primary/15 rounded-lg"
          >
            <i className="ri-refresh-line"></i> Coba Lagi
          </button>
        </div>
      ) : bookings.length === 0 ? (
        <div className="bg-white dark:bg-gray rounded-xl shadow-sm border border-black/10 dark:border-white/10 py-20 flex flex-col items-center gap-3 text-center px-6">
          <div className="w-20 h-20 rounded-full bg-primary/5 flex items-center justify-center">
            <i className="ri-video-off-line text-4xl text-primary/40"></i>
          </div>
          <h3 className="text-lg font-bold text-black dark:text-white">Tidak Ada Rapat</h3>
          <p className="text-sm text-black/60 dark:text-white/60 max-w-md">
            Tidak ada rapat yang ditemukan untuk filter {filter === 'today' ? 'hari ini' : filter === 'upcoming' ? 'periode 14 hari ke depan' : 'semua waktu'}.
            Buat pemesanan rapat baru untuk mulai.
          </p>
          <button
            type="button"
            onClick={() => navigate('/bookings/new')}
            className="mt-2 px-5 h-10 text-sm font-semibold text-white bg-primary hover:bg-primary/90 rounded-lg shadow-sm shadow-primary/30 transition-colors flex items-center gap-2"
          >
            <i className="ri-add-line"></i>
            <span>Buat Pemesanan Rapat Baru</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {bookings.map((b) => {
            const ongoing = isOngoing(b);
            const joinable = canJoin(b.status);
            return (
              <div
                key={b.id}
                className={`bg-white dark:bg-gray rounded-xl shadow-sm border overflow-hidden transition-all hover:shadow-md ${
                  ongoing
                    ? 'border-primary/50 ring-2 ring-primary/10'
                    : 'border-black/10 dark:border-white/10'
                }`}
              >
                {ongoing && (
                  <div className="px-4 py-2 bg-gradient-to-r from-danger to-indigo-500 text-white text-xs font-semibold flex items-center gap-2">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
                    </span>
                    SEDANG BERLANGSUNG
                  </div>
                )}
                <div className="p-5 space-y-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <h3 className="font-bold text-black dark:text-white truncate" title={b.title}>
                        {b.title}
                      </h3>
                      <p className="text-xs text-black/50 dark:text-white/50 mt-0.5">
                        #{b.id?.slice(0, 8)}
                      </p>
                    </div>
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold border shrink-0 ${STATUS_COLOR[b.status || 'pending'] || ''}`}>
                      {STATUS_LABEL[b.status || 'pending']}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="space-y-0.5">
                      <p className="text-xs text-black/40 dark:text-white/40">Tanggal</p>
                      <p className="text-black/80 dark:text-white/80 font-medium">
                        {b.date ? parseLocalDate(String(b.date).slice(0, 10)).toLocaleDateString(
'id-ID', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'}
                      </p>
                    </div>
                    <div className="space-y-0.5">
                      <p className="text-xs text-black/40 dark:text-white/40">Waktu</p>
                      <p className="text-black/80 dark:text-white/80 font-medium flex items-center gap-1">
                        <i className="ri-time-line text-[13px]"></i>
                        {b.start_time || '--:--'} - {b.end_time || '--:--'}
                      </p>
                    </div>
                    <div className="space-y-0.5">
                      <p className="text-xs text-black/40 dark:text-white/40">Ruangan</p>
                      <p className="text-black/80 dark:text-white/80 font-medium flex items-center gap-1 truncate" title={b.room_name}>
                        <i className="ri-door-open-line text-[13px]"></i>
                        {b.room_name || '-'}
                      </p>
                    </div>
                    <div className="space-y-0.5">
                      <p className="text-xs text-black/40 dark:text-white/40">Peserta</p>
                      <p className="text-black/80 dark:text-white/80 font-medium flex items-center gap-1">
                        <i className="ri-team-line text-[13px]"></i>
                        {b.participant_count ?? 0} orang
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <div className="w-7 h-7 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
                      <i className="ri-user-line text-sm"></i>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs text-black/40 dark:text-white/40">Penyelenggara</p>
                      <p className="text-sm text-black/80 dark:text-white/80 font-medium truncate" title={b.organizer_name}>
                        {b.organizer_name || '-'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pt-3 border-t border-black/10 dark:border-white/10">
                    <button
                      type="button"
                      onClick={() => navigate(`/bookings/${b.id}`)}
                      className="flex-1 h-10 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors flex items-center justify-center gap-2"
                    >
                      <i className="ri-eye-line"></i>
                      Detail
                    </button>
                    <button
                      type="button"
                      onClick={() => navigate(`/bookings/${b.id}/meeting`)}
                      disabled={!joinable}
                      className={`flex-[1.5] h-10 text-sm font-semibold rounded-lg transition-all flex items-center justify-center gap-2 ${
                        ongoing
                          ? 'bg-gradient-to-r from-danger to-indigo-500 hover:from-danger/90 hover:to-indigo-500/90 text-white shadow-sm shadow-danger/30 animate-pulse'
                          : joinable
                          ? 'text-white bg-primary hover:bg-primary/90 shadow-sm shadow-primary/30'
                          : 'bg-black/5 dark:bg-white/5 text-black/40 dark:text-white/40 cursor-not-allowed'
                      }`}
                    >
                      <i className="ri-video-chat-line"></i>
                      <span>{ongoing ? 'MASUK RAPAT SEKARANG' : joinable ? 'Masuk Rapat' : 'Tidak Bisa Masuk'}</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
