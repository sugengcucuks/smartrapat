import { useEffect, useMemo, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { authApi } from '../../../shared/api/auth';
import { KIOSK_UNPAIRED_EVENT, apiErrorMessage, kioskSession } from '../../../shared/api/kiosk';
import type {
  DoorDisplayRoomStatus,
  WelcomeMessageResponse,
  DoorAvailableSlotsResponse,
  TimeSlot,
  PresensiScanResponse,
} from '@shared/types';
import { useQrScanner } from '../../hooks/useQrScanner';
import { playSuccessChime, playErrorChime, playDuplicateChime } from '../../utils/chime';

interface ScanResult extends PresensiScanResponse {
  at: number;
}

export function PublicRoomDisplayPage() {
  const { room_code } = useParams<{ room_code: string }>();
  const [data, setData] = useState<DoorDisplayRoomStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [nowTick, setNowTick] = useState(0);

  const [remainingSeconds, setRemainingSeconds] = useState(0);
  const [totalSeconds, setTotalSeconds] = useState(0);
  const [ended, setEnded] = useState(false);

  // ===== WEBSOCKET STATE =====
  const [wsConnected, setWsConnected] = useState(false);
  const [wsReconnecting, setWsReconnecting] = useState(false);
  const [wsAttempt, setWsAttempt] = useState(0);
  const wsRef = useRef<WebSocket | null>(null);
  const wsPingRef = useRef<number | null>(null);
  const wsReconnectRef = useRef<number | null>(null);

  // ===== INTERACTIVE STATE =====
  const [toast, setToast] = useState<{ id: number; type: 'success' | 'error' | 'info' | 'warning'; message: string; sub?: string } | null>(null);
  const toastTimerRef = useRef<number | null>(null);
  const [welcomeMessage, setWelcomeMessage] = useState<WelcomeMessageResponse | null>(null);

  // ===== AVAILABLE SLOTS MODAL =====
  const [showSlotsModal, setShowSlotsModal] = useState(false);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [availableSlots, setAvailableSlots] = useState<DoorAvailableSlotsResponse | null>(null);

  // ===== BOOKING MODAL (QUICK BOOK FROM SLOT) =====
  const [showBookModal, setShowBookModal] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<TimeSlot | null>(null);
  const [bookingTitle, setBookingTitle] = useState('');
  const [bookingBookedBy, setBookingBookedBy] = useState('');
  const [bookingSubmitting, setBookingSubmitting] = useState(false);

  // ===== EXTEND MODAL =====
  const [showExtendModal, setShowExtendModal] = useState(false);
  const [extendSubmitting, setExtendSubmitting] = useState(false);

  // ===== CANCEL MODAL =====
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelSubmitting, setCancelSubmitting] = useState(false);

  // ===== ACTION LOADING =====
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // ===== PRESENSI QR =====
  const [showScanModal, setShowScanModal] = useState(false);
  const [manualCode, setManualCode] = useState('');
  const [scanSubmitting, setScanSubmitting] = useState(false);
  const [lastScan, setLastScan] = useState<ScanResult | null>(null);
  const [welcomeBanner, setWelcomeBanner] = useState<ScanResult | null>(null);
  const [attendance, setAttendance] = useState<{ attended: number; total: number } | null>(null);
  const [scanHistory, setScanHistory] = useState<ScanResult[]>([]);
  const scanVideoRef = useRef<HTMLVideoElement>(null);
  const welcomeTimerRef = useRef<number | null>(null);

  // ===== KIOSK SECURITY: PAIRING GATE (DSP-09) =====
  // Kiosk dianggap terpasang bila punya token kiosk (hasil POST /door-display/pair).
  const [paired, setPaired] = useState(() => (room_code ? !!kioskSession.getToken(room_code) : false));
  const [hasMasterPin, setHasMasterPin] = useState(() =>
    room_code ? kioskSession.hasMasterPin(room_code) : false
  );
  // PIN untuk aksi sensitif (perpanjang / batalkan) bila ruangan memakai Master PIN.
  const [actionPin, setActionPin] = useState('');
  const [pairInput, setPairInput] = useState('');
  const [pairSubmitting, setPairSubmitting] = useState(false);
  const [pairError, setPairError] = useState<string | null>(null);

  // ===== KIOSK SECURITY: EARLY RELEASE VIA PIN (DSP-07) =====
  const [showReleaseModal, setShowReleaseModal] = useState(false);
  const [releasePin, setReleasePin] = useState('');
  const [releaseSubmitting, setReleaseSubmitting] = useState(false);

  const pushToast = (
    type: 'success' | 'error' | 'info' | 'warning',
    message: string,
    sub?: string
  ) => {
    if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
    setToast({ id: Date.now(), type, message, sub });
    toastTimerRef.current = window.setTimeout(() => setToast(null), 4500);
  };

  // ===== FETCH INITIAL DATA (HTTP fallback sebelum WS connect pertama) =====
  const fetchInitial = async () => {
    if (!room_code) return;
    setLoading(true);
    try {
      const [status, welcome] = await Promise.all([
        authApi.getDoorDisplayStatus(room_code),
        authApi.getWelcomeMessage(room_code).catch(() => null),
      ]);
      setData(status);
      setError(null);
      initTimer(status);
      if (welcome) setWelcomeMessage(welcome);

      // Muat live counter kehadiran bila ada rapat yang sedang berjalan.
      const currentBookingId = status.current_meeting?.booking_id;
      if (currentBookingId) {
        authApi
          .getBookingAttendance(currentBookingId, room_code)
          .then((att) =>
            setAttendance({ attended: att.attended_count, total: att.total_participants })
          )
          .catch(() => {});
      }
    } catch (err: any) {
      console.error(err);
      if (err?.response?.status === 401) return; // ditangani event kiosk-unpaired
      setError(apiErrorMessage(err, 'Gagal memuat status ruangan. Pastikan kode ruangan benar.'));
    } finally {
      setLoading(false);
    }
  };

  // ===== WEBSOCKET CONNECTION & RECONNECT =====
  const closeWs = (silent = true) => {
    if (wsPingRef.current) {
      window.clearInterval(wsPingRef.current);
      wsPingRef.current = null;
    }
    if (wsReconnectRef.current) {
      window.clearTimeout(wsReconnectRef.current);
      wsReconnectRef.current = null;
    }
    if (wsRef.current) {
      try {
        wsRef.current.onclose = null;
        wsRef.current.onerror = null;
        wsRef.current.onopen = null;
        wsRef.current.onmessage = null;
        wsRef.current.close();
      } catch {}
      wsRef.current = null;
    }
    if (!silent) setWsConnected(false);
  };

  const connectWs = () => {
    if (!room_code) return;
    closeWs(false);
    setWsReconnecting(true);

    try {
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const host =
        import.meta.env.VITE_WS_HOST ||
        `${window.location.hostname}:${import.meta.env.VITE_API_PORT || '8000'}`;
      const basePath = import.meta.env.VITE_API_BASE_URL || '/api/v1';
      const kioskToken = kioskSession.getToken(room_code);
      if (!kioskToken) {
        unpairKiosk('Sesi kiosk tidak ditemukan. Pasangkan ulang kiosk.');
        return;
      }
      const url = `${proto}//${host}${basePath}/ws/door-display/${encodeURIComponent(room_code)}?kiosk_token=${encodeURIComponent(kioskToken)}`;

      const ws = new WebSocket(url);
      wsRef.current = ws;

      ws.onopen = () => {
        setWsConnected(true);
        setWsReconnecting(false);
        setWsAttempt(0);
        // Send ping every 25s to keep alive
        wsPingRef.current = window.setInterval(() => {
          try {
            if (wsRef.current?.readyState === WebSocket.OPEN) {
              wsRef.current.send(JSON.stringify({ type: 'ping', ts: Date.now() }));
            }
          } catch {}
        }, 25000);
      };

      ws.onmessage = (evt) => {
        try {
          const msg = JSON.parse(evt.data);
          const ev = msg.event || msg.type;

          if (ev === 'connected') {
            pushToast('success', 'Display terhubung ke server', 'WebSocket realtime aktif');
          }

          if (ev === 'status_changed' && msg.data) {
            const next = msg.data as DoorDisplayRoomStatus;
            setData(next);
            initTimer(next);
            const cid = next.current_meeting?.booking_id;
            if (cid) {
              authApi
                .getBookingAttendance(cid, room_code)
                .then((att) =>
                  setAttendance({ attended: att.attended_count, total: att.total_participants })
                )
                .catch(() => {});
            } else {
              setAttendance(null);
            }
          }

          if (ev === 'booking_created') {
            pushToast('success', msg.data?.title ? `Rapat "${msg.data.title}" dimulai` : 'Rapat baru telah ditambahkan', 'Jadwal diperbarui otomatis');
          }
          if (ev === 'booking_extended') {
            pushToast('info', msg.data?.new_end_time ? `Waktu rapat diperpanjang sampai ${msg.data.new_end_time}` : 'Waktu rapat diperpanjang', 'Berhasil extend jadwal');
          }
          if (ev === 'booking_cancelled') {
            pushToast('warning', 'Rapat telah dibatalkan', 'Jadwal diperbarui otomatis');
          }
          if (ev === 'attendance_changed') {
            setAttendance({
              attended: msg.attended_count ?? 0,
              total: msg.total_participants ?? 0,
            });
            if (msg.data) {
              setData(msg.data as DoorDisplayRoomStatus);
              initTimer(msg.data as DoorDisplayRoomStatus);
            }
          }
          if (ev === 'error' && (msg.type === 'auth_error' || msg.code === 'KIOSK_UNPAIRED')) {
            unpairKiosk(msg.message || 'Sesi kiosk berakhir. Pasangkan ulang kiosk.');
            return;
          }
          if (ev === 'error') {
            pushToast('error', msg.message || 'Terjadi kesalahan server');
            if (msg.type === 'room_not_found') {
              setError(msg.message || 'Ruangan tidak ditemukan');
            }
          }
        } catch (parseErr) {
          console.warn('WS parse error:', parseErr);
        }
      };

      ws.onerror = () => {
        // handled in onclose below
      };

      ws.onclose = () => {
        setWsConnected(false);
        if (wsPingRef.current) {
          window.clearInterval(wsPingRef.current);
          wsPingRef.current = null;
        }
        // Schedule reconnect 4s exponential backoff up to 15s
        setWsAttempt((prev) => {
          const next = prev + 1;
          const delay = Math.min(4000 + next * 2000, 15000);
          setWsReconnecting(true);
          wsReconnectRef.current = window.setTimeout(() => connectWs(), delay);
          return next;
        });
      };
    } catch (err) {
      console.error('ws connect error', err);
      setWsConnected(false);
      setWsReconnecting(true);
      wsReconnectRef.current = window.setTimeout(() => connectWs(), 5000);
    }
  };

  // ===== KIOSK: KEMBALI KE LAYAR PAIRING (token tidak valid / key diganti) =====
  function unpairKiosk(reason?: string) {
    if (room_code) kioskSession.clear(room_code);
    closeWs(false);
    setPaired(false);
    setHasMasterPin(false);
    setData(null);
    setLoading(true);
    setError(null);
    setPairError(reason || 'Sesi kiosk berakhir. Masukkan pairing key lagi.');
  }

  useEffect(() => {
    const onUnpaired = (e: Event) => {
      const rc = (e as CustomEvent<{ roomCode: string | null }>).detail?.roomCode;
      if (!rc || rc === room_code) unpairKiosk();
    };
    window.addEventListener(KIOSK_UNPAIRED_EVENT, onUnpaired);
    return () => window.removeEventListener(KIOSK_UNPAIRED_EVENT, onUnpaired);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [room_code]);

  useEffect(() => {
    if (!paired) return undefined;
    fetchInitial();
    return () => {
      closeWs(false);
      if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [room_code, paired]);

  useEffect(() => {
    if (!loading && !error && room_code && paired) {
      connectWs();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, error, room_code, paired]);

  useEffect(() => {
    const t = setInterval(() => setNowTick((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, []);

  const initTimer = (d: DoorDisplayRoomStatus) => {
    if (!d.current_meeting) {
      setRemainingSeconds(0);
      setTotalSeconds(0);
      setEnded(false);
      return;
    }
    try {
      const now = new Date();
      const [h, m] = d.current_meeting.end_time.split(':').map(Number);
      const [sh, sm] = d.current_meeting.start_time.split(':').map(Number);
      const end = new Date();
      end.setHours(h, m, 0, 0);
      const start = new Date();
      start.setHours(sh, sm, 0, 0);

      const remain = Math.max(0, Math.floor((end.getTime() - now.getTime()) / 1000));
      const total = Math.max(1, Math.floor((end.getTime() - start.getTime()) / 1000));

      setRemainingSeconds(remain);
      setTotalSeconds(total);
      setEnded(remain <= 0);
    } catch {
      setRemainingSeconds(0);
      setTotalSeconds(0);
    }
  };

  useEffect(() => {
    if (ended || !data?.current_meeting) return;
    const i = setInterval(() => {
      setRemainingSeconds((s) => {
        if (s <= 1) {
          setEnded(true);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(i);
  }, [ended, data?.current_meeting]);

  const currentClock = useMemo(() => {
    void nowTick;
    return new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }, [nowTick]);

  const currentDate = useMemo(() => {
    return new Date().toLocaleDateString('id-ID', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  }, []);

  const progressPct = totalSeconds > 0 ? Math.min(100, Math.max(0, 100 - (remainingSeconds / totalSeconds) * 100)) : 0;

  const formatHMS = (sec: number) => {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const statusConfig = useMemo(() => {
    switch (data?.room_status) {
      case 'occupied':
        return {
          label: 'DIGUNAKAN',
          pillBg: 'bg-rose-600',
          text: 'text-rose-600',
          icon: 'ri-door-lock-box-line',
          ledBg: 'bg-rose-600',
          ringColor: '#E11D48',
          ringTrack: '#FECDD3',
          chipBg: 'bg-rose-50 border border-rose-200 text-rose-700',
          accent: '#E11D48',
          accentSoft: '#FFF1F2',
          badgeBg: 'bg-rose-600 text-white',
          iconBg: 'bg-rose-100 text-rose-600 border-rose-200',
          fullBg: 'bg-gradient-to-br from-slate-950 via-slate-900 to-rose-950',
          bg: 'bg-rose-950/60',
          border: 'border-rose-500/60',
          cardBg: 'bg-white/5 border-white/10',
          shadowCard: 'shadow-2xl shadow-rose-950/40',
        };
      case 'soon':
        return {
          label: 'AKAN DIGUNAKAN',
          pillBg: 'bg-amber-500',
          text: 'text-amber-600',
          icon: 'ri-alarm-warning-line',
          ledBg: 'bg-amber-500',
          ringColor: '#D97706',
          ringTrack: '#FDE68A',
          chipBg: 'bg-amber-50 border border-amber-200 text-amber-700',
          accent: '#D97706',
          accentSoft: '#FFFBEB',
          badgeBg: 'bg-amber-500 text-white',
          iconBg: 'bg-amber-100 text-amber-600 border-amber-200',
          fullBg: 'bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950',
          bg: 'bg-amber-950/60',
          border: 'border-amber-500/60',
          cardBg: 'bg-white/5 border-white/10',
          shadowCard: 'shadow-2xl shadow-amber-950/40',
        };
      case 'available':
      default:
        return {
          label: 'TERSEDIA',
          pillBg: 'bg-emerald-600',
          text: 'text-emerald-600',
          icon: 'ri-door-open-line',
          ledBg: 'bg-emerald-600',
          ringColor: '#059669',
          ringTrack: '#A7F3D0',
          chipBg: 'bg-emerald-50 border border-emerald-200 text-emerald-700',
          accent: '#059669',
          accentSoft: '#ECFDF5',
          badgeBg: 'bg-emerald-600 text-white',
          iconBg: 'bg-emerald-100 text-emerald-600 border-emerald-200',
          fullBg: 'bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950',
          bg: 'bg-emerald-950/60',
          border: 'border-emerald-500/60',
          cardBg: 'bg-white/5 border-white/10',
          shadowCard: 'shadow-2xl shadow-emerald-950/40',
        };
    }
  }, [data?.room_status]);

  const nextUpcoming = data?.next_upcoming ?? [];
  const nextMeetingMinutes = useMemo(() => {
    void nowTick;
    if (!nextUpcoming[0]) return null;
    try {
      const now = new Date();
      const [h, m] = nextUpcoming[0].start_time.split(':').map(Number);
      const s = new Date();
      s.setHours(h, m, 0, 0);
      const diff = Math.max(0, Math.floor((s.getTime() - now.getTime()) / 60000));
      return diff;
    } catch {
      return null;
    }
  }, [nextUpcoming, nowTick]);

  // ===== ACTION: QUICK BOOK DURASI TERTENTU =====
  const quickBookNow = async (minutes: number) => {
    if (!room_code || actionLoading) return;
    const now = new Date();
    const hh = now.getHours().toString().padStart(2, '0');
    const mm = now.getMinutes().toString().padStart(2, '0');
    const startTime = `${hh}:${mm}`;
    const title = minutes >= 60 ? `Rapat Singkat ${minutes / 60} Jam` : `Rapat Singkat ${minutes} Menit`;
    const bookedBy = 'Pengguna Kios';

    setActionLoading(`book-${minutes}`);
    try {
      const res = await authApi.quickBookRoom(room_code, {
        title,
        start_time: startTime,
        duration_minutes: minutes,
        booked_by: bookedBy,
        participant_count: 1,
      });
      if (res.success) {
        pushToast('success', res.message || `Booking ${minutes} menit berhasil`, `ID: ${res.booking_id?.slice(0, 8) || '...'}`);
      } else {
        const conflict = res.conflict_booking;
        pushToast(
          'error',
          res.message || 'Gagal booking ruangan',
          conflict ? `Bentrok dgn "${conflict.title}" ${conflict.start_time}-${conflict.end_time}` : undefined
        );
      }
    } catch (err: any) {
      pushToast('error', apiErrorMessage(err, 'Gagal booking, coba beberapa saat lagi'));
    } finally {
      setActionLoading(null);
    }
  };

  // ===== ACTION: LOAD AVAILABLE SLOTS + OPEN MODAL =====
  const openSlotsModal = async () => {
    if (!room_code) return;
    setShowSlotsModal(true);
    setSlotsLoading(true);
    try {
      const res = await authApi.getAvailableSlots(room_code, {
        interval_minutes: 30,
        day_start: '07:00',
        day_end: '20:00',
      });
      setAvailableSlots(res);
    } catch {
      pushToast('error', 'Gagal memuat daftar slot tersedia');
      setAvailableSlots(null);
    } finally {
      setSlotsLoading(false);
    }
  };

  const selectSlotForBooking = (slot: TimeSlot) => {
    if (!slot.available) {
      pushToast('warning', 'Slot ini sudah terbooking', slot.title || 'Silakan pilih slot lain');
      return;
    }
    setSelectedSlot(slot);
    setBookingTitle(`Rapat ${slot.start} - ${slot.end}`);
    setBookingBookedBy('Pengguna Kios');
    setShowBookModal(true);
  };

  const submitSlotBooking = async () => {
    if (!room_code || !selectedSlot || !bookingTitle.trim()) return;
    setBookingSubmitting(true);
    try {
      const [sh, sm] = selectedSlot.start.split(':').map(Number);
      const [eh, em] = selectedSlot.end.split(':').map(Number);
      const duration = (eh * 60 + em) - (sh * 60 + sm);

      const res = await authApi.quickBookRoom(room_code, {
        title: bookingTitle.trim(),
        start_time: selectedSlot.start,
        duration_minutes: Math.max(5, duration),
        booked_by: bookingBookedBy.trim() || 'Pengguna Kios',
        participant_count: 1,
      });
      if (res.success) {
        pushToast('success', res.message || 'Booking slot berhasil', `${selectedSlot.start} - ${selectedSlot.end}`);
        setShowBookModal(false);
        setSelectedSlot(null);
        setShowSlotsModal(false);
      } else {
        pushToast(
          'error',
          res.message || 'Gagal booking',
          res.conflict_booking ? `Bentrok: ${res.conflict_booking.title}` : undefined
        );
      }
    } catch (err: any) {
      pushToast('error', apiErrorMessage(err, 'Gagal booking slot'));
    } finally {
      setBookingSubmitting(false);
    }
  };

  // ===== ACTION: EXTEND BOOKING =====
  const submitExtend = async (minutes = 15) => {
    const bookingId = data?.current_meeting?.booking_id;
    if (!bookingId) return;
    setExtendSubmitting(true);
    try {
      const res = await authApi.extendDoorBooking(bookingId, minutes, room_code, actionPin || undefined);
      if (res.success) {
        pushToast('success', res.message || `Berhasil menambah ${minutes} menit`, res.new_end_time ? `Selesai: ${res.new_end_time}` : undefined);
        setShowExtendModal(false);
        setActionPin('');
      } else {
        pushToast('error', res.message || 'Gagal extend waktu rapat');
      }
    } catch (err: any) {
      pushToast('error', apiErrorMessage(err, 'Gagal extend'));
      setActionPin('');
    } finally {
      setExtendSubmitting(false);
    }
  };

  // ===== ACTION: CANCEL BOOKING =====
  const submitCancel = async () => {
    const bookingId = data?.current_meeting?.booking_id;
    if (!room_code || !bookingId) return;
    setCancelSubmitting(true);
    try {
      const res = await authApi.cancelDoorBooking(room_code, bookingId, actionPin || undefined);
      if (res.success) {
        pushToast('warning', res.message || 'Rapat telah dibatalkan');
        setShowCancelModal(false);
        setActionPin('');
      } else {
        pushToast('error', res.message || 'Gagal membatalkan rapat');
      }
    } catch (err: any) {
      pushToast('error', apiErrorMessage(err, 'Gagal membatalkan'));
      setActionPin('');
    } finally {
      setCancelSubmitting(false);
    }
  };

  // ===== PRESENSI: PROSES KODE TIKET =====
  const showWelcome = (entry: ScanResult) => {
    if (welcomeTimerRef.current) window.clearTimeout(welcomeTimerRef.current);
    setWelcomeBanner(entry);
    welcomeTimerRef.current = window.setTimeout(() => setWelcomeBanner(null), 6000);
  };

  const submitScan = async (rawCode: string) => {
    const code = rawCode.trim();
    if (!code || scanSubmitting) return;
    setScanSubmitting(true);
    try {
      const res = await authApi.scanTicket({ code, room_code: room_code || undefined }, room_code);
      const entry: ScanResult = { ...res, at: Date.now() };
      setLastScan(entry);
      setScanHistory((prev) => [entry, ...prev].slice(0, 8));
      setAttendance({ attended: res.attended_count, total: res.total_participants });
      if (res.already_checked_in) {
        playDuplicateChime();
      } else {
        playSuccessChime();
        showWelcome(entry);
        setShowScanModal(false);
      }
    } catch (err: any) {
      const status = err?.response?.status;
      const failed: ScanResult = {
        success: false,
        message: apiErrorMessage(err, 'Kode tiket tidak dikenal'),
        participant_id: '',
        participant_name: '',
        booking_id: '',
        booking_title: '',
        attended: false,
        already_checked_in: false,
        checked_in_at: null,
        attended_count: 0,
        total_participants: 0,
        at: Date.now(),
      };
      if (status === 409) playDuplicateChime();
      else playErrorChime();
      setLastScan(failed);
      setScanHistory((prev) => [failed, ...prev].slice(0, 8));
    } finally {
      setScanSubmitting(false);
    }
  };

  const { status: scannerStatus, error: scannerError } = useQrScanner({
    videoRef: scanVideoRef,
    active: showScanModal,
    onDetected: (code) => submitScan(code),
  });

  // Auto-tutup pesan hasil scan setelah beberapa detik.
  useEffect(() => {
    if (!lastScan) return;
    const t = window.setTimeout(() => setLastScan(null), 5000);
    return () => window.clearTimeout(t);
  }, [lastScan]);

  useEffect(() => {
    return () => {
      if (welcomeTimerRef.current) window.clearTimeout(welcomeTimerRef.current);
    };
  }, []);

  // ===== KIOSK: SUBMIT PAIRING KEY (DSP-09) =====
  const submitPairing = async () => {
    const key = pairInput.trim().toUpperCase();
    if (!room_code || !key || pairSubmitting) return;
    setPairSubmitting(true);
    setPairError(null);
    try {
      const res = await authApi.pairKiosk(room_code, key);
      if (res.paired && res.kiosk_token) {
        // Token disimpan oleh authApi.pairKiosk (localStorage kiosk_token_<room>).
        setHasMasterPin(!!res.has_master_pin);
        setPairInput('');
        setPaired(true);
      } else {
        setPairError('Pairing gagal. Periksa kembali kode pairing.');
      }
    } catch (err: any) {
      setPairError(apiErrorMessage(err, 'Pairing key salah atau tidak valid untuk ruangan ini.'));
    } finally {
      setPairSubmitting(false);
    }
  };

  // ===== KIOSK: EARLY RELEASE DENGAN PIN (DSP-07) =====
  const submitEarlyRelease = async () => {
    const bookingId = data?.current_meeting?.booking_id;
    const pin = releasePin.trim();
    if (!bookingId || !pin || releaseSubmitting) return;
    setReleaseSubmitting(true);
    try {
      const res = await authApi.earlyReleaseBooking(bookingId, pin, room_code);
      pushToast(
        'success',
        res.message || 'Rapat diakhiri lebih awal',
        res.title ? `"${res.title}" • Ruangan kembali tersedia` : undefined
      );
      setShowReleaseModal(false);
      setReleasePin('');
    } catch (err: any) {
      pushToast('error', apiErrorMessage(err, 'PIN salah atau gagal mengakhiri rapat'));
      setReleasePin('');
    } finally {
      setReleaseSubmitting(false);
    }
  };

  if (!paired) {
    return (
      <div className="min-h-screen w-screen bg-gray flex items-center justify-center p-8">
        <div className="max-w-lg w-full bg-white/5 border border-white/10 rounded-[32px] p-10 text-center shadow-2xl">
          <div className="w-24 h-24 mx-auto rounded-[28px] bg-primary/20 border-2 border-primary/40 flex items-center justify-center mb-6">
            <i className="ri-shield-keyhole-line text-5xl text-primary"></i>
          </div>
          <h1 className="text-4xl font-black text-white mb-3">Kiosk Belum Dipasangkan</h1>
          <p className="text-white/60 text-lg mb-8 leading-relaxed">
            Masukkan <b className="text-white">Pairing Key</b> dari halaman{' '}
            <b className="text-white">Ruangan → Kiosk Security</b> di Admin Dashboard untuk
            mengaktifkan display pintu ruangan ini.
          </p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              submitPairing();
            }}
          >
            <input
              type="text"
              value={pairInput}
              onChange={(e) => setPairInput(e.target.value.toUpperCase())}
              placeholder="RM-XXXXXX"
              autoFocus
              maxLength={10}
              className="w-full px-6 py-5 text-3xl font-mono tracking-[0.25em] text-center uppercase rounded-2xl bg-black/40 border-2 border-white/15 text-white outline-none focus:border-primary transition-colors placeholder:text-white/25 placeholder:tracking-[0.2em] mb-4"
            />
            {pairError && (
              <div className="mb-4 p-4 rounded-2xl bg-danger/15 border border-danger/30 text-danger text-base font-semibold text-left flex items-start gap-2">
                <i className="ri-error-warning-line text-xl mt-0.5 shrink-0"></i>
                <span>{pairError}</span>
              </div>
            )}
            <button
              type="submit"
              disabled={pairSubmitting || pairInput.trim().length < 8}
              className="w-full py-5 rounded-2xl bg-gradient-to-r from-primary to-indigo-600 text-white font-black text-xl hover:from-primary/90 hover:to-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-[0.98] flex items-center justify-center gap-3 shadow-xl"
            >
              {pairSubmitting ? (
                <svg className="animate-spin h-6 w-6" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
              ) : (
                <i className="ri-links-line text-2xl"></i>
              )}
              {pairSubmitting ? 'Memeriksa...' : 'Pasangkan Kiosk'}
            </button>
          </form>
          {room_code && (
            <p className="text-white/30 text-sm mt-6">
              Kode ruangan: <code className="bg-white/10 px-2 py-0.5 rounded">{room_code}</code>
            </p>
          )}
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen w-screen bg-gray dark:bg-gray flex items-center justify-center">
        <div className="flex flex-col items-center gap-4 text-white/80">
          <svg className="animate-spin h-10 w-10 text-primary" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
          </svg>
          <p className="text-lg font-medium">Memuat status ruangan...</p>
          {room_code && <p className="text-sm text-white/50">Kode ruangan: {room_code}</p>}
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen w-screen bg-gray dark:bg-gray flex items-center justify-center p-8">
        <div className="max-w-md w-full bg-white/5 border border-white/10 rounded-2xl p-8 text-center">
          <i className="ri-error-warning-line text-6xl text-danger mb-4"></i>
          <h1 className="text-2xl font-bold text-white mb-2">Kesalahan</h1>
          <p className="text-white/70 mb-6">{error || 'Data ruangan tidak tersedia'}</p>
          {room_code && <p className="text-sm text-white/40 mb-4">Kode ruangan: <code className="bg-white/10 px-2 py-1 rounded">{room_code}</code></p>}
          <button
            onClick={fetchInitial}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary text-white rounded-xl font-medium hover:bg-primary/90 transition-colors"
          >
            <i className="ri-refresh-line"></i>
            Coba Lagi
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen w-screen ${statusConfig.fullBg} text-white flex flex-col overflow-hidden relative transition-all duration-700`}>
      {/* ===== LED STATUS STRIP (EVOKO LISO 3-WAY AURA) ===== */}
      <div className={`h-4 w-full ${statusConfig.ledBg} transition-colors duration-500`} style={{ boxShadow: `0 12px 80px ${statusConfig.ringColor}, 0 -4px 30px ${statusConfig.ringColor}88` }} />

      {/* ===== TOAST AREA ===== */}
      {toast && (
        <div
          key={toast.id}
          className={`fixed top-10 right-10 z-[999] max-w-md w-full rounded-3xl shadow-2xl p-5 border flex items-start gap-4 animate-[slideIn_0.3s_ease-out] backdrop-blur-xl ${
            toast.type === 'success'
              ? 'bg-emerald-950/80 border-emerald-400/50'
              : toast.type === 'error'
                ? 'bg-rose-950/80 border-rose-400/50'
                : toast.type === 'warning'
                  ? 'bg-amber-950/80 border-amber-400/50'
                  : 'bg-sky-950/80 border-sky-400/50'
          }`}
        >
          <div className={`w-12 h-12 shrink-0 rounded-2xl flex items-center justify-center ${
            toast.type === 'success' ? 'bg-emerald-500/25' :
            toast.type === 'error' ? 'bg-rose-500/25' :
            toast.type === 'warning' ? 'bg-amber-500/25' : 'bg-sky-500/25'
          }`}>
            <i className={`${
              toast.type === 'success' ? 'ri-checkbox-circle-fill text-emerald-300' :
              toast.type === 'error' ? 'ri-error-warning-fill text-rose-300' :
              toast.type === 'warning' ? 'ri-alert-fill text-amber-300' :
              'ri-information-fill text-sky-300'
            } text-2xl`}></i>
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-black text-white text-lg">{toast.message}</div>
            {toast.sub && <div className="text-sm opacity-80 mt-1 text-white/80">{toast.sub}</div>}
          </div>
          <button
            type="button"
            onClick={() => setToast(null)}
            className="shrink-0 text-white/60 hover:text-white transition-colors p-1"
          >
            <i className="ri-close-line text-2xl"></i>
          </button>
        </div>
      )}

      {/* ===== HEADER (JOAN 6 / EVOKO STYLE) ===== */}
      <header className="flex items-center justify-between px-10 sm:px-16 py-8 border-b border-white/10">
        <div className="flex items-center gap-7">
          <div className={`w-24 h-24 rounded-[28px] border-3 ${statusConfig.border} flex items-center justify-center shadow-2xl bg-black/25 backdrop-blur-md`} style={{ borderWidth: 3 }}>
            <i className={`${statusConfig.icon} text-5xl`} style={{ color: statusConfig.accent }}></i>
          </div>
          <div>
            <div className="text-sm uppercase tracking-[0.35em] text-white/50 font-black mb-1.5">RUANG RAPAT</div>
            <h1 className="text-5xl sm:text-7xl font-black text-white leading-none drop-shadow-2xl">{data.room_name}</h1>
            <div className="flex flex-wrap items-center gap-3 mt-4">
              <span className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-white/10 border-2 border-white/20 text-white font-black text-base backdrop-blur-md">
                <i className="ri-hashtag text-xl"></i>
                {data.room_code}
              </span>
              <span className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-white/10 border-2 border-white/20 text-white font-black text-base backdrop-blur-md">
                <i className="ri-team-line text-xl"></i>
                {data.capacity} Orang
              </span>
              <span className={`inline-flex items-center gap-2 px-5 py-2 rounded-full border-2 font-black text-base backdrop-blur-md ${statusConfig.bg} ${statusConfig.border}`} style={{ color: statusConfig.accent }}>
                <span className="relative flex h-2.5 w-2.5 mr-1">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75" style={{ background: statusConfig.accent }}></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5" style={{ background: statusConfig.accent }}></span>
                </span>
                {statusConfig.label}
              </span>
            </div>
          </div>
        </div>
        <div className="text-right hidden sm:block">
          <div className="text-7xl sm:text-8xl font-black font-mono tracking-tight text-white leading-none drop-shadow-2xl">{currentClock}</div>
          <div className="text-2xl text-white/70 mt-3 font-bold">{currentDate}</div>
          <button
            type="button"
            onClick={() => {
              setLastScan(null);
              setManualCode('');
              setShowScanModal(true);
            }}
            className="mt-5 inline-flex items-center gap-3 px-7 py-4 rounded-full font-black text-xl bg-white text-slate-900 hover:bg-white/95 shadow-[0_18px_50px_rgba(255,255,255,0.25)] transition-all hover:scale-[1.03] active:scale-95"
          >
            <i className="ri-qr-scan-2-line text-2xl text-emerald-600"></i>
            PRESENSI QR
          </button>
        </div>
      </header>

      {/* ===== LIVE COUNTER KEHADIRAN ===== */}
      {attendance && attendance.total > 0 && (
        <div className="mx-10 sm:mx-16 mt-6 flex items-center justify-between gap-6 px-8 py-5 rounded-[28px] bg-black/35 backdrop-blur-2xl border-2 border-emerald-400/30 shadow-2xl">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-[20px] bg-emerald-500/25 border-2 border-emerald-300/40 flex items-center justify-center">
              <i className="ri-user-follow-fill text-3xl text-emerald-300"></i>
            </div>
            <div>
              <div className="text-sm uppercase tracking-[0.25em] text-emerald-200/80 font-black">
                KEHADIRAN PESERTA
              </div>
              <div className="text-3xl font-black text-white leading-tight">
                {attendance.attended} <span className="text-white/50">/ {attendance.total} peserta hadir</span>
              </div>
            </div>
          </div>
          <div className="flex-1 max-w-md h-4 rounded-full bg-white/10 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-500 transition-all duration-700"
              style={{ width: `${Math.min(100, (attendance.attended / attendance.total) * 100)}%` }}
            />
          </div>
          <div className="text-4xl font-black text-emerald-300 shrink-0">
            {Math.round((attendance.attended / attendance.total) * 100)}%
          </div>
        </div>
      )}

      {/* ===== WELCOME BANNER - DARK HIGH CONTRAST (FIX BUTA TEXT) ===== */}
      {welcomeMessage && (welcomeMessage.show_custom_message || welcomeMessage.custom_message) && (
        <div className="mx-10 sm:mx-16 mt-8 p-7 rounded-[32px] bg-black/35 backdrop-blur-2xl border-2 border-white/20 shadow-2xl">
          <div className="flex items-start gap-5">
            <div className="w-16 h-16 shrink-0 rounded-[24px] bg-white/15 border-2 border-white/25 flex items-center justify-center">
              <i className="ri-heart-pulse-fill text-4xl text-white"></i>
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-3xl sm:text-4xl font-black text-white leading-tight drop-shadow-lg">{welcomeMessage.custom_message || welcomeMessage.title}</div>
              {welcomeMessage.subtitle && (
                <div className="text-white/80 mt-3 text-2xl font-semibold leading-snug">{welcomeMessage.subtitle}</div>
              )}
              {welcomeMessage.footer_text && (
                <div className="text-white/60 mt-4 text-sm uppercase tracking-[0.25em] font-black">{welcomeMessage.footer_text}</div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ===== BANNER SAMBUTAN PRESENSI (TAMPIL 6 DETIK) ===== */}
      {welcomeBanner && (
        <div className="mx-10 sm:mx-16 mt-8 p-8 rounded-[32px] bg-gradient-to-r from-emerald-600/40 to-teal-600/30 backdrop-blur-2xl border-2 border-emerald-300/50 shadow-2xl animate-[fadeIn_0.3s_ease-out]">
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 shrink-0 rounded-[28px] bg-emerald-500/30 border-2 border-emerald-200/50 flex items-center justify-center">
              <i className="ri-checkbox-circle-fill text-5xl text-emerald-200"></i>
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm uppercase tracking-[0.3em] text-emerald-100/80 font-black mb-2">
                SELAMAT DATANG
              </div>
              <div className="text-5xl sm:text-6xl font-black text-white leading-tight drop-shadow-2xl truncate">
                {welcomeBanner.participant_name}
              </div>
              <div className="text-white/85 mt-3 text-2xl font-semibold truncate">
                {welcomeBanner.booking_title}
                {welcomeBanner.room_name ? ` • ${welcomeBanner.room_name}` : ''}
              </div>
              {welcomeBanner.seat && (
                <div className="mt-4 inline-flex items-center gap-3 px-5 py-2 rounded-2xl bg-white/15 border border-white/30 text-white text-2xl font-black">
                  <i className="ri-armchair-line text-3xl"></i>
                  Silakan duduk di Kursi {welcomeBanner.seat.label}
                </div>
              )}
            </div>
            <div className="shrink-0 text-right">
              <div className="text-sm uppercase tracking-[0.2em] text-emerald-100/70 font-black mb-2">
                KEHADIRAN
              </div>
              <div className="text-6xl font-black text-white leading-none">
                {welcomeBanner.attended_count}
                <span className="text-3xl text-white/60">/{welcomeBanner.total_participants}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== MAIN CONTENT ===== */}
      <main className="flex-1 px-10 sm:px-16 py-10 flex flex-col gap-8 overflow-y-auto">

        {/* ===== OCCUPIED STATE - JOAN 6 ENTERPRISE DISPLAY (PASSIVE, NO DANGEROUS ACTIONS!) ===== */}
        {data.room_status === 'occupied' && data.current_meeting && (
          <div className={`grid grid-cols-1 lg:grid-cols-5 gap-8 ${statusConfig.shadowCard}`}>
            {/* PANEL KIRI - GIANT CIRCULAR TIMER + STATUS (40%) */}
            <div className={`lg:col-span-2 rounded-[48px] border-2 p-12 flex flex-col items-center justify-center relative ${statusConfig.cardBg}`}>
              <div className="absolute top-8 left-8 inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-black/30 backdrop-blur-md border-2 border-white/15">
                <span className="relative flex h-3 w-3 mr-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75" style={{ background: statusConfig.accent }}></span>
                  <span className="relative inline-flex rounded-full h-3 w-3" style={{ background: statusConfig.accent }}></span>
                </span>
                <span className="text-sm font-black uppercase tracking-[0.25em]" style={{ color: statusConfig.accent }}>SEDANG BERLANGSUNG</span>
              </div>
              <div className="text-sm uppercase tracking-[0.4em] text-white/60 font-black mb-10">SISA WAKTU RAPAT</div>

              {/* GIANT CIRCULAR TIMER 320px */}
              <div className="relative" style={{ width: 320, height: 320 }}>
                <svg width={320} height={320} className="-rotate-90 drop-shadow-2xl">
                  <circle
                    cx={160}
                    cy={160}
                    r={149}
                    fill="none"
                    stroke={statusConfig.ringTrack}
                    strokeWidth={22}
                  />
                  <circle
                    cx={160}
                    cy={160}
                    r={149}
                    fill="none"
                    stroke={statusConfig.ringColor}
                    strokeWidth={22}
                    strokeLinecap="round"
                    strokeDasharray={2 * Math.PI * 149}
                    strokeDashoffset={(2 * Math.PI * 149) - (progressPct / 100) * (2 * Math.PI * 149)}
                    style={{ transition: 'stroke-dashoffset 1s linear', filter: `drop-shadow(0 0 15px ${statusConfig.ringColor})` }}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div className="text-2xl font-black mb-4" style={{ color: statusConfig.accent }}>
                    {progressPct.toFixed(0)}% SELESAI
                  </div>
                  <div className={`font-black font-mono tracking-tight leading-none mb-6 drop-shadow-2xl ${
                    ended ? 'text-rose-300' : remainingSeconds < 300 ? 'text-amber-300' : 'text-white'
                  }`} style={{ fontSize: 62 }}>
                    {formatHMS(remainingSeconds)}
                  </div>
                  {ended ? (
                    <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-rose-500/20 border-2 border-rose-300/40 text-rose-200 text-base font-black backdrop-blur-md">
                      <i className="ri-time-line text-2xl"></i>
                      WAKTU HABIS
                    </div>
                  ) : remainingSeconds < 300 ? (
                    <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-amber-500/20 border-2 border-amber-300/40 text-amber-200 text-base font-black backdrop-blur-md">
                      <i className="ri-alarm-warning-line text-2xl"></i>
                      KURANG DARI 5 MENIT!
                    </div>
                  ) : (
                    <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-black/30 backdrop-blur-md border border-white/15 text-white text-base font-black">
                      <i className="ri-time-line text-xl" style={{ color: statusConfig.accent }}></i>
                      Selesai pukul {data.current_meeting.end_time} WIB
                    </div>
                  )}
                </div>
              </div>

              {/* NOTE: EXTEND / END HANYA ADA DI HALAMAN ADMIN MINTA LOGIN (SECURITY!) */}
              <div className="mt-12 w-full p-5 rounded-3xl bg-black/25 border border-white/10 backdrop-blur-md">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 shrink-0 rounded-2xl bg-white/10 border border-white/15 flex items-center justify-center">
                    <i className="ri-shield-check-fill text-3xl" style={{ color: statusConfig.accent }}></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xl font-black text-white mb-1.5">Kontrol Rapat Terproteksi</div>
                    <div className="text-white/60 text-base leading-snug">
                      Perpanjangan durasi & pengakhiran rapat hanya dapat dilakukan melalui Dashboard Admin terotentikasi untuk mencegah tindakan yang tidak diinginkan dari luar ruangan.
                    </div>
                  </div>
                </div>
              </div>

              {/* DSP-07: EARLY RELEASE VIA MASTER PIN */}
              <button
                type="button"
                onClick={() => {
                  setReleasePin('');
                  setShowReleaseModal(true);
                }}
                className="mt-4 w-full py-5 rounded-3xl bg-white/10 hover:bg-white/15 border-2 border-white/15 hover:border-emerald-300/40 font-black text-xl text-white transition-all active:scale-[0.98] flex items-center justify-center gap-3 backdrop-blur-md"
              >
                <i className="ri-door-open-fill text-2xl text-emerald-300"></i>
                Buka Ruangan Lebih Awal (PIN)
              </button>
            </div>

            {/* PANEL KANAN - INFORMASI RAPAT LENGKAP (60%) */}
            <div className={`lg:col-span-3 rounded-[48px] border-2 p-12 flex flex-col gap-10 ${statusConfig.cardBg}`}>
              <div>
                <div className="inline-flex items-center gap-3 px-5 py-3 rounded-full bg-black/30 backdrop-blur-md border-2 border-white/15 mb-7">
                  <i className="ri-video-chat-fill text-3xl" style={{ color: statusConfig.accent }}></i>
                  <span className="text-base font-black uppercase tracking-widest text-white/80">INFORMASI RAPAT SAAT INI</span>
                </div>
                <h2 className="text-6xl sm:text-7xl font-black text-white leading-[1.05] break-words mb-10 drop-shadow-2xl">
                  {data.current_meeting.title}
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                  <div className="p-7 rounded-[28px] bg-black/25 backdrop-blur-md border-2 border-white/10">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 rounded-[20px] bg-primary/30 border border-primary/50 flex items-center justify-center">
                        <i className="ri-user-3-fill text-primary text-2xl"></i>
                      </div>
                      <div className="text-sm uppercase tracking-[0.25em] text-primary-200/70 font-black">PENYELENGGARA</div>
                    </div>
                    <div className="font-black text-white text-3xl leading-tight truncate">{data.current_meeting.host_name}</div>
                  </div>
                  <div className="p-7 rounded-[28px] bg-black/25 backdrop-blur-md border-2 border-white/10">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 rounded-[20px] bg-sky-500/30 border border-sky-300/50 flex items-center justify-center">
                        <i className="ri-time-fill text-sky-200 text-2xl"></i>
                      </div>
                      <div className="text-sm uppercase tracking-[0.25em] text-sky-200/70 font-black">WAKTU</div>
                    </div>
                    <div className="font-black text-white text-3xl leading-tight">
                      {data.current_meeting.start_time}
                    </div>
                    <div className="text-white/60 text-2xl font-bold mt-1">
                      s/d {data.current_meeting.end_time} WIB
                    </div>
                  </div>
                  <div className="p-7 rounded-[28px] bg-black/25 backdrop-blur-md border-2 border-white/10">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 rounded-[20px] bg-emerald-500/30 border border-emerald-300/50 flex items-center justify-center">
                        <i className="ri-team-fill text-emerald-200 text-2xl"></i>
                      </div>
                      <div className="text-sm uppercase tracking-[0.25em] text-emerald-200/70 font-black">PESERTA</div>
                    </div>
                    <div className="font-black text-white text-3xl leading-tight">{data.current_meeting.participants_count} Orang</div>
                    <div className="text-white/60 text-xl font-bold mt-1">terkonfirmasi</div>
                  </div>
                </div>
              </div>

              {/* NEXT MEETING TIMELINE */}
              {nextUpcoming.length > 0 && (
                <div className="mt-auto pt-10 border-t border-white/10">
                  <div className="flex items-center gap-4 mb-8">
                    <div className="w-14 h-14 rounded-[22px] bg-warning/20 border-2 border-warning/40 flex items-center justify-center backdrop-blur-md">
                      <i className="ri-arrow-right-circle-fill text-3xl text-warning"></i>
                    </div>
                    <div>
                      <div className="text-2xl font-black text-white">JADWAL SELANJUTNYA</div>
                      <div className="text-white/60 text-lg">Rapat berikutnya yang akan menggunakan ruangan ini</div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    {nextUpcoming.slice(0, 2).map((m, i) => (
                      <div
                        key={m.booking_id}
                        className="flex items-center gap-6 p-7 rounded-[32px] bg-black/25 backdrop-blur-md border-2 border-white/10 hover:border-white/20 transition-all"
                      >
                        <div className="shrink-0 text-center px-6 py-4 rounded-[24px] bg-primary/20 border-2 border-primary/40 min-w-[140px] backdrop-blur-md">
                          <div className="text-4xl font-black text-primary leading-none">{m.start_time}</div>
                          <div className="text-sm text-white/60 mt-2 font-black">s/d {m.end_time}</div>
                        </div>
                        <div className="w-1.5 h-20 rounded-full shrink-0" style={{ background: `linear-gradient(to bottom, ${statusConfig.accent}, #38bdf8)` }} />
                        <div className="flex-1 min-w-0">
                          <div className="font-black text-white text-3xl truncate mb-1.5">{m.title}</div>
                          <div className="text-white/60 text-xl font-medium flex items-center gap-2">
                            <i className="ri-user-3-fill text-lg"></i>
                            <span className="truncate">{m.host_name}</span>
                          </div>
                        </div>
                        {i === 0 && nextMeetingMinutes !== null && nextMeetingMinutes <= 120 && (
                          <div className="shrink-0 px-6 py-4 rounded-[24px] bg-warning/15 border-2 border-warning/40 backdrop-blur-md">
                            <div className="text-xs uppercase tracking-[0.2em] text-warning/80 font-black mb-1">MULAI DALAM</div>
                            <div className="text-3xl font-black text-warning leading-none">
                              {nextMeetingMinutes < 60
                                ? `${nextMeetingMinutes} mnt`
                                : `${Math.floor(nextMeetingMinutes / 60)}j ${nextMeetingMinutes % 60 > 0 ? `${nextMeetingMinutes % 60}mnt` : ''}`
                              }
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ===== AVAILABLE / SOON STATE - EVOKO LISO GREEN STATUS ===== */}
        {(data.room_status === 'available' || data.room_status === 'soon') && (
          <>
            {/* GIANT HERO STATUS */}
            <div className={`rounded-[48px] border-2 p-12 sm:p-20 text-center relative overflow-hidden ${statusConfig.cardBg} ${statusConfig.shadowCard}`}>
              <div className="absolute top-10 left-10 inline-flex items-center gap-3 px-5 py-3 rounded-full bg-black/30 backdrop-blur-md border-2 border-white/15">
                <i className={`${statusConfig.icon} text-3xl`} style={{ color: statusConfig.accent }}></i>
                <span className="text-base font-black uppercase tracking-[0.3em]" style={{ color: statusConfig.accent }}>STATUS RUANGAN</span>
              </div>
              <div className={`w-48 h-48 mx-auto rounded-[40px] border-4 flex items-center justify-center mb-12 shadow-2xl relative ${statusConfig.border}`} style={{ background: `linear-gradient(135deg, ${statusConfig.ringTrack}, rgba(0,0,0,0.2))` }}>
                <div className={`absolute inset-0 rounded-[40px] opacity-20 animate-pulse`} style={{ background: statusConfig.accent }} />
                <i className={`${statusConfig.icon} text-[9rem] relative z-10 drop-shadow-2xl`} style={{ color: statusConfig.accent }}></i>
              </div>
              <div className="text-sm uppercase tracking-[0.5em] font-black mb-6" style={{ color: statusConfig.accent }}>
                ● {statusConfig.label} ●
              </div>
              <h2 className="text-6xl sm:text-8xl font-black text-white mb-8 leading-tight drop-shadow-2xl">
                {data.room_status === 'soon'
                  ? 'Akan Segera Digunakan'
                  : 'Siap Digunakan Kapan Saja'
                }
              </h2>
              <p className="text-3xl text-white/70 max-w-4xl mx-auto leading-relaxed font-semibold">
                {data.room_status === 'soon' && nextMeetingMinutes !== null
                  ? `Rapat berikutnya akan dimulai dalam ${nextMeetingMinutes} menit. Silakan persiapkan ruangan dan pastikan tidak ada aktivitas yang mengganggu.`
                  : 'Ruangan ini saat ini tidak ada pemakaian. Anda dapat melakukan pemesanan cepat secara langsung melalui tombol di bawah ini.'
                }
              </p>
            </div>

            {/* BOOKING CEPAT ACTION BAR */}
            <div className={`rounded-[48px] border-2 p-10 sm:p-12 ${statusConfig.cardBg} ${statusConfig.shadowCard}`}>
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8">
                <div className="flex-1 max-w-2xl">
                  <div className="inline-flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-success/20 border-2 border-success/40 text-emerald-200 text-xs font-black uppercase tracking-widest mb-5 backdrop-blur-md">
                    <i className="ri-calendar-check-fill text-2xl"></i>
                    BOOKING CEPAT LANGSUNG DARI DISPLAY
                  </div>
                  <h3 className="text-4xl sm:text-5xl font-black text-white mb-3 leading-tight">Booking Ruangan Sekarang</h3>
                  <p className="text-white/70 text-xl font-medium">Pilih durasi cepat di samping untuk pemesanan instan, atau lihat daftar slot lengkap untuk waktu spesifik.</p>
                </div>
                <div className="flex flex-wrap gap-4">
                  {[15, 30, 60].map((mins) => (
                    <button
                      key={mins}
                      type="button"
                      onClick={() => quickBookNow(mins)}
                      disabled={actionLoading === `book-${mins}` || data.room_status === 'soon'}
                      className="group relative inline-flex items-center gap-3 py-6 px-10 rounded-full font-black text-2xl bg-gradient-to-r from-emerald-400 to-teal-500 text-emerald-950 hover:from-emerald-300 hover:to-teal-400 disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_18px_50px_rgba(16,185,129,0.45)] transition-all hover:scale-[1.03] active:scale-95"
                    >
                      {actionLoading === `book-${mins}` ? (
                        <svg className="animate-spin h-7 w-7" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                      ) : (
                        <i className={`${mins === 60 ? 'ri-time-fill' : 'ri-timer-flash-fill'} text-3xl`}></i>
                      )}
                      {mins === 60 ? '1 Jam' : mins === 30 ? '30 Menit' : '15 Menit'}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={openSlotsModal}
                    disabled={!!actionLoading}
                    className="inline-flex items-center gap-3 py-6 px-10 rounded-full font-black text-2xl bg-white text-slate-900 hover:bg-white/95 disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_18px_50px_rgba(255,255,255,0.25)] transition-all hover:scale-[1.03] active:scale-95"
                  >
                    <i className="ri-calendar-view-fill text-3xl text-emerald-600"></i>
                    Slot Lainnya
                  </button>
                </div>
              </div>
            </div>

            {/* UPCOMING SCHEDULE TIMELINE */}
            {nextUpcoming.length > 0 && (
              <div className={`rounded-[48px] border-2 p-10 sm:p-12 ${statusConfig.cardBg} ${statusConfig.shadowCard}`}>
                <div className="flex items-center gap-5 mb-10">
                  <div className="w-16 h-16 rounded-[28px] bg-primary/25 border-2 border-primary/45 flex items-center justify-center backdrop-blur-md">
                    <i className="ri-calendar-schedule-fill text-4xl text-primary"></i>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-4xl sm:text-5xl font-black text-white mb-1">Jadwal Hari Ini</h3>
                    <p className="text-white/60 text-2xl font-medium">{nextUpcoming.length} rapat berikutnya terjadwal di {data.room_name}</p>
                  </div>
                </div>
                <div className="space-y-5">
                  {nextUpcoming.slice(0, 3).map((m, i) => (
                    <div
                      key={m.booking_id}
                      className="flex flex-col sm:flex-row sm:items-center gap-6 p-8 rounded-[40px] bg-black/25 backdrop-blur-md border-2 border-white/10 hover:border-white/20 hover:bg-black/35 transition-all"
                    >
                      <div className="sm:w-40 text-left sm:text-center shrink-0">
                        <div className="text-5xl font-black text-primary leading-none drop-shadow-lg">{m.start_time}</div>
                        <div className="text-2xl text-white/60 mt-3 font-black">
                          <i className="ri-arrow-right-line mr-1.5 text-xl"></i>
                          {m.end_time} WIB
                        </div>
                        {i === 0 && nextMeetingMinutes !== null && (
                          <div className="mt-4 inline-flex items-center gap-2 px-5 py-3 rounded-full bg-warning/15 border-2 border-warning/35 text-warning text-base font-black backdrop-blur-md">
                            <i className="ri-alarm-fill text-2xl"></i>
                            {nextMeetingMinutes < 60
                              ? `${nextMeetingMinutes} menit lagi`
                              : `${Math.floor(nextMeetingMinutes / 60)}j ${nextMeetingMinutes % 60 > 0 ? `${nextMeetingMinutes % 60}mnt` : ''} lagi`
                            }
                          </div>
                        )}
                      </div>
                      <div className="hidden sm:block w-2 h-28 rounded-2xl shrink-0" style={{ background: `linear-gradient(to bottom, ${statusConfig.accent}, #6366f1, #38bdf8)` }} />
                      <div className="flex-1 min-w-0">
                        <div className="text-4xl font-black text-white truncate mb-2 drop-shadow-lg">{m.title}</div>
                        <div className="text-white/65 text-2xl font-medium flex items-center gap-2.5">
                          <i className="ri-user-3-fill text-xl"></i>
                          <span className="truncate">{m.host_name}</span>
                        </div>
                      </div>
                      <div className={`h-4 sm:h-28 w-full sm:w-4 rounded-2xl ${
                        i === 0 ? 'bg-warning' : i === 1 ? 'bg-primary' : 'bg-emerald-400'
                      }`} style={{ boxShadow: `0 0 25px currentColor` }}></div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {nextUpcoming.length === 0 && (
              <div className={`rounded-[48px] border-2 p-16 text-center ${statusConfig.cardBg} ${statusConfig.shadowCard}`}>
                <i className="ri-calendar-todo-fill text-[10rem] mb-6 drop-shadow-2xl" style={{ color: statusConfig.accent, opacity: 0.4 }}></i>
                <h3 className="text-5xl font-black text-white/80 mb-4 leading-tight">Tidak Ada Jadwal Lain Hari Ini</h3>
                <p className="text-white/60 text-3xl font-semibold max-w-3xl mx-auto leading-relaxed">Ruangan ini bebas digunakan untuk sisa hari ini. Silakan lakukan pemesanan kapan saja melalui tombol booking cepat di atas.</p>
              </div>
            )}
          </>
        )}

      </main>

      {/* ===== FOOTER ===== */}
      <footer className="px-10 sm:px-16 py-6 border-t border-white/10 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <button
          type="button"
          onClick={() => {
            setLastScan(null);
            setManualCode('');
            setShowScanModal(true);
          }}
          className="sm:hidden inline-flex items-center justify-center gap-3 px-7 py-4 rounded-full font-black text-lg bg-white text-slate-900 shadow-lg transition-all active:scale-95"
        >
          <i className="ri-qr-scan-2-line text-2xl text-emerald-600"></i>
          PRESENSI QR
        </button>
        <div className="flex items-center gap-3 text-white/40 text-sm">
          <i className="ri-building-4-line text-lg"></i>
          <span className="font-semibold">Smart Meeting Room</span>
          <span className="text-white/20">•</span>
          <span>Display Pintu Otomatis</span>
        </div>
        <div className="flex items-center gap-4 text-sm flex-wrap">
          <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full border transition-colors ${
            wsConnected
              ? 'bg-success/10 text-success border-success/30'
              : wsReconnecting
                ? 'bg-warning/10 text-warning border-warning/30'
                : 'bg-danger/10 text-danger border-danger/30'
          }`}>
            <span className="relative flex h-2 w-2">
              {wsConnected && (
                <>
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                </>
              )}
              {!wsConnected && (
                <span className={`inline-flex rounded-full h-2 w-2 ${wsReconnecting ? 'bg-yellow-500 animate-pulse' : 'bg-red-500'}`}></span>
              )}
            </span>
            <span className="font-semibold">
              {wsConnected
                ? 'WS Terhubung (Realtime)'
                : wsReconnecting
                  ? wsAttempt > 0
                    ? `Reconnecting... (x${wsAttempt})`
                    : 'Menghubungkan...'
                  : 'Terputus'}
            </span>
          </div>
          <div className="text-white/30 font-mono text-xs">
            {import.meta.env.VITE_APP_VERSION || 'v1.0'}
          </div>
        </div>
      </footer>

      {/* ===== MODAL: AVAILABLE SLOTS ===== */}
      {showSlotsModal && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 sm:p-8 bg-black/70 backdrop-blur-sm" onClick={() => setShowSlotsModal(false)}>
          <div
            className="w-full max-w-4xl max-h-[85vh] bg-gray rounded-3xl border border-white/10 shadow-2xl overflow-hidden flex flex-col animate-[fadeIn_0.2s_ease-out]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-6 border-b border-white/10">
              <div>
                <h2 className="text-2xl font-black text-white">Slot Tersedia Hari Ini</h2>
                <p className="text-white/50 text-sm mt-1">
                  {availableSlots
                    ? `${availableSlots.total_available} slot kosong • ${availableSlots.interval_minutes} menit / slot • ${availableSlots.day_start} - ${availableSlots.day_end}`
                    : 'Memuat daftar slot ruangan...'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowSlotsModal(false)}
                className="p-2.5 rounded-xl text-white/60 hover:text-white hover:bg-white/10 transition-colors"
              >
                <i className="ri-close-line text-2xl"></i>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
              {slotsLoading ? (
                <div className="flex flex-col items-center justify-center py-16 gap-3 text-white/50">
                  <svg className="animate-spin h-9 w-9 text-primary" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  <p>Memuat slot tersedia...</p>
                </div>
              ) : availableSlots ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                  {availableSlots.slots.map((slot, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => selectSlotForBooking(slot)}
                      disabled={!slot.available}
                      className={`p-4 rounded-2xl border text-left transition-all ${
                        slot.available
                          ? 'bg-success/10 border-success/30 hover:bg-success/15 hover:border-success/50 hover:scale-[1.03] cursor-pointer text-success/90'
                          : 'bg-white/[0.03] border-white/10 text-white/30 cursor-not-allowed opacity-60'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className={`text-xs font-bold uppercase tracking-wider ${slot.available ? 'text-success' : 'text-white/20'}`}>
                          {slot.available ? 'KOSONG' : 'TERISI'}
                        </span>
                        <i className={`${slot.available ? 'ri-checkbox-circle-line text-success' : 'ri-lock-line text-white/20'} text-lg`}></i>
                      </div>
                      <div className={`text-xl font-black ${slot.available ? 'text-white' : 'text-white/20'}`}>
                        {slot.start}
                      </div>
                      <div className={`text-xs font-medium ${slot.available ? 'text-success/70' : 'text-white/15'}`}>
                        s/d {slot.end}
                      </div>
                      {!slot.available && slot.title && (
                        <div className="mt-2 pt-2 border-t border-white/5 text-[11px] font-medium text-white/30 truncate">
                          {slot.title}
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-white/50">
                  <i className="ri-error-warning-line text-5xl mb-3 text-danger/60"></i>
                  <p>Gagal memuat slot. Tutup modal lalu coba lagi.</p>
                </div>
              )}
            </div>
            <div className="p-5 border-t border-white/10 flex items-center justify-between bg-white/[0.02]">
              <p className="text-xs text-white/40 max-w-md">
                💡 Klik slot berwarna hijau (kosong) untuk langsung booking pada waktu tersebut
              </p>
              <button
                type="button"
                onClick={() => setShowSlotsModal(false)}
                className="px-5 py-2.5 rounded-xl bg-white/10 text-white hover:bg-white/15 font-semibold transition-colors"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== MODAL: BOOK SLOT ===== */}
      {showBookModal && selectedSlot && (
        <div className="fixed inset-0 z-[1001] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={() => setShowBookModal(false)}>
          <div
            className="w-full max-w-md bg-gray rounded-3xl border border-white/10 shadow-2xl overflow-hidden animate-[fadeIn_0.2s_ease-out]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b border-white/10">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-success/20 flex items-center justify-center">
                  <i className="ri-calendar-check-fill text-success text-xl"></i>
                </div>
                <div>
                  <h2 className="text-xl font-black text-white">Booking Slot</h2>
                  <p className="text-white/50 text-sm">{selectedSlot.start} - {selectedSlot.end}</p>
                </div>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-white/80 mb-1.5">Judul Rapat</label>
                <input
                  type="text"
                  value={bookingTitle}
                  onChange={(e) => setBookingTitle(e.target.value)}
                  placeholder="Masukkan judul rapat..."
                  autoFocus
                  className="w-full px-4 py-3 rounded-xl bg-black/30 border border-white/10 text-white outline-none focus:border-primary transition-colors"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-white/80 mb-1.5">Atas Nama</label>
                <input
                  type="text"
                  value={bookingBookedBy}
                  onChange={(e) => setBookingBookedBy(e.target.value)}
                  placeholder="Nama pembooking..."
                  className="w-full px-4 py-3 rounded-xl bg-black/30 border border-white/10 text-white outline-none focus:border-primary transition-colors"
                />
              </div>
              <div className="p-3 rounded-xl bg-primary/10 border border-primary/20 text-xs text-primary/80 space-y-1">
                <div className="flex justify-between">
                  <span>Durasi:</span>
                  <span className="font-bold">
                    {(() => {
                      const [sh, sm] = selectedSlot.start.split(':').map(Number);
                      const [eh, em] = selectedSlot.end.split(':').map(Number);
                      const mins = (eh * 60 + em) - (sh * 60 + sm);
                      return mins >= 60 ? `${Math.floor(mins / 60)} jam ${mins % 60 > 0 ? `${mins % 60} mnt` : ''}` : `${mins} menit`;
                    })()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Tanggal:</span>
                  <span className="font-bold">{currentDate}</span>
                </div>
              </div>
            </div>
            <div className="p-5 border-t border-white/10 flex justify-end gap-2.5 bg-white/[0.02]">
              <button
                type="button"
                onClick={() => setShowBookModal(false)}
                disabled={bookingSubmitting}
                className="px-5 py-2.5 rounded-xl bg-white/10 text-white hover:bg-white/15 font-semibold transition-colors disabled:opacity-50"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={submitSlotBooking}
                disabled={bookingSubmitting || !bookingTitle.trim()}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-success to-emerald-600 text-white hover:from-success/90 hover:to-emerald-500 font-bold transition-all disabled:opacity-50 inline-flex items-center gap-2 shadow-lg shadow-success/20"
              >
                {bookingSubmitting && (
                  <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                )}
                <i className="ri-check-line"></i>
                Konfirmasi Booking
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== MODAL: EXTEND 15/30 ===== */}
      {showExtendModal && (
        <div className="fixed inset-0 z-[1001] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={() => setShowExtendModal(false)}>
          <div
            className="w-full max-w-md bg-gray rounded-3xl border border-white/10 shadow-2xl overflow-hidden animate-[fadeIn_0.2s_ease-out]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b border-white/10">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-warning/20 flex items-center justify-center">
                  <i className="ri-time-line text-warning text-xl"></i>
                </div>
                <div>
                  <h2 className="text-xl font-black text-white">Perpanjang Waktu Rapat</h2>
                  <p className="text-white/50 text-sm">Tambah durasi rapat yang sedang berlangsung</p>
                </div>
              </div>
            </div>
            <div className="p-6 space-y-3">
              {hasMasterPin && (
                <input
                  type="password"
                  inputMode="numeric"
                  autoComplete="off"
                  value={actionPin}
                  onChange={(e) => setActionPin(e.target.value.replace(/[^0-9]/g, '').slice(0, 8))}
                  placeholder="Master PIN ruangan"
                  className="w-full px-5 py-3 text-xl font-mono tracking-[0.4em] text-center rounded-2xl bg-black/40 border-2 border-white/15 text-white outline-none focus:border-warning transition-colors placeholder:text-white/25 placeholder:tracking-normal placeholder:text-base placeholder:font-sans"
                />
              )}
              {[15, 30, 60].map((mins) => (
                <button
                  key={mins}
                  type="button"
                  onClick={() => submitExtend(mins)}
                  disabled={extendSubmitting || (hasMasterPin && actionPin.length < 4)}
                  className="w-full p-4 rounded-2xl border border-white/10 bg-white/[0.03] hover:bg-warning/10 hover:border-warning/30 transition-all disabled:opacity-50 flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${mins === 60 ? 'bg-info/20 text-info' : mins === 30 ? 'bg-primary/20 text-primary' : 'bg-success/20 text-success'}`}>
                      <i className={`${mins === 60 ? 'ri-time-zone-line' : 'ri-timer-flash-line'} text-xl`}></i>
                    </div>
                    <div className="text-left">
                      <div className="font-bold text-white text-lg">+ {mins === 60 ? '1 Jam' : `${mins} Menit`}</div>
                      <div className="text-xs text-white/50">Perpanjangan waktu rapat</div>
                    </div>
                  </div>
                  <i className="ri-arrow-right-s-line text-white/30 group-hover:text-warning group-hover:translate-x-0.5 transition-all text-2xl"></i>
                </button>
              ))}
            </div>
            <div className="p-5 border-t border-white/10 flex justify-end bg-white/[0.02]">
              <button
                type="button"
                onClick={() => setShowExtendModal(false)}
                disabled={extendSubmitting}
                className="px-5 py-2.5 rounded-xl bg-white/10 text-white hover:bg-white/15 font-semibold transition-colors disabled:opacity-50"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== MODAL: CANCEL CONFIRM ===== */}
      {showCancelModal && (
        <div className="fixed inset-0 z-[1001] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={() => setShowCancelModal(false)}>
          <div
            className="w-full max-w-md bg-gray rounded-3xl border border-white/10 shadow-2xl overflow-hidden animate-[fadeIn_0.2s_ease-out]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b border-white/10">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-danger/20 flex items-center justify-center">
                  <i className="ri-error-warning-fill text-danger text-xl"></i>
                </div>
                <div>
                  <h2 className="text-xl font-black text-white">Batalkan Rapat?</h2>
                  <p className="text-white/50 text-sm">Aksi ini akan membatalkan rapat yang sedang berlangsung</p>
                </div>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div className="p-4 rounded-2xl bg-danger/10 border border-danger/30 text-sm">
                <div className="font-bold text-danger/90 mb-1.5">⚠️ Konfirmasi Pembatalan</div>
                {data.current_meeting && (
                  <div className="text-white/70 space-y-1">
                    <div className="flex justify-between">
                      <span className="text-white/50">Rapat:</span>
                      <span className="font-semibold text-white truncate max-w-[200px]">{data.current_meeting.title}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-white/50">Waktu:</span>
                      <span className="font-semibold">{data.current_meeting.start_time} - {data.current_meeting.end_time}</span>
                    </div>
                  </div>
                )}
                <div className="mt-3 text-xs text-white/60 border-t border-danger/20 pt-3">
                  Setelah dibatalkan, status ruangan akan otomatis menjadi "TERSEDIA" dan slot waktu menjadi kosong untuk booking lain.
                </div>
              </div>
              {hasMasterPin && (
                <input
                  type="password"
                  inputMode="numeric"
                  autoComplete="off"
                  value={actionPin}
                  onChange={(e) => setActionPin(e.target.value.replace(/[^0-9]/g, '').slice(0, 8))}
                  placeholder="Master PIN ruangan"
                  className="w-full px-5 py-3 text-xl font-mono tracking-[0.4em] text-center rounded-2xl bg-black/40 border-2 border-white/15 text-white outline-none focus:border-warning transition-colors placeholder:text-white/25 placeholder:tracking-normal placeholder:text-base placeholder:font-sans"
                />
              )}
            </div>
            <div className="p-5 border-t border-white/10 flex justify-end gap-2.5 bg-white/[0.02]">
              <button
                type="button"
                onClick={() => setShowCancelModal(false)}
                disabled={cancelSubmitting}
                className="px-5 py-2.5 rounded-xl bg-white/10 text-white hover:bg-white/15 font-semibold transition-colors disabled:opacity-50"
              >
                Jangan Batal
              </button>
              <button
                type="button"
                onClick={submitCancel}
                disabled={cancelSubmitting || (hasMasterPin && actionPin.length < 4)}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-danger to-rose-600 text-white hover:from-danger/90 hover:to-rose-500 font-bold transition-all disabled:opacity-50 inline-flex items-center gap-2 shadow-lg shadow-danger/20"
              >
                {cancelSubmitting && (
                  <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                )}
                <i className="ri-stop-circle-line"></i>
                Ya, Batalkan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== MODAL: EARLY RELEASE PIN (DSP-07) ===== */}
      {showReleaseModal && data.current_meeting && (
        <div className="fixed inset-0 z-[1050] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={() => setShowReleaseModal(false)}>
          <div
            className="w-full max-w-md bg-gray rounded-3xl border border-white/10 shadow-2xl overflow-hidden animate-[fadeIn_0.2s_ease-out]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b border-white/10 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                <i className="ri-key-2-fill text-emerald-300 text-xl"></i>
              </div>
              <div>
                <h2 className="text-xl font-black text-white">Akhiri Rapat Lebih Awal</h2>
                <p className="text-white/50 text-sm">Masukkan Master PIN kiosk untuk konfirmasi</p>
              </div>
            </div>
            <form
              className="p-6 space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                submitEarlyRelease();
              }}
            >
              <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 text-sm text-white/70">
                Rapat <b className="text-white">{data.current_meeting.title}</b> akan langsung
                diakhiri dan status ruangan menjadi <b className="text-emerald-300">TERSEDIA</b>.
              </div>
              <input
                type="password"
                inputMode="numeric"
                autoComplete="off"
                value={releasePin}
                onChange={(e) => setReleasePin(e.target.value.replace(/[^0-9]/g, '').slice(0, 8))}
                placeholder="PIN (4-8 digit)"
                autoFocus
                className="w-full px-5 py-4 text-2xl font-mono tracking-[0.4em] text-center rounded-2xl bg-black/40 border-2 border-white/15 text-white outline-none focus:border-emerald-400 transition-colors placeholder:text-white/25 placeholder:tracking-normal placeholder:text-base placeholder:font-sans"
              />
              <div className="flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowReleaseModal(false)}
                  disabled={releaseSubmitting}
                  className="px-5 py-2.5 rounded-xl bg-white/10 text-white hover:bg-white/15 font-semibold transition-colors disabled:opacity-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={releaseSubmitting || releasePin.length < 4}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:from-emerald-400 hover:to-teal-500 font-bold transition-all disabled:opacity-50 inline-flex items-center gap-2 shadow-lg"
                >
                  {releaseSubmitting && (
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                  )}
                  <i className="ri-check-line"></i>
                  Konfirmasi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===== MODAL: SCANNER PRESENSI QR ===== */}
      {showScanModal && (
        <div
          className="fixed inset-0 z-[1100] flex items-center justify-center p-4 sm:p-8 bg-black/80 backdrop-blur-sm"
          onClick={() => setShowScanModal(false)}
        >
          <div
            className="w-full max-w-3xl bg-gray rounded-[32px] border-2 border-white/15 shadow-2xl overflow-hidden animate-[fadeIn_0.2s_ease-out]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-7 border-b border-white/10">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-[20px] bg-emerald-500/20 border-2 border-emerald-300/40 flex items-center justify-center">
                  <i className="ri-qr-scan-2-line text-3xl text-emerald-300"></i>
                </div>
                <div>
                  <h2 className="text-3xl font-black text-white">Presensi Kehadiran</h2>
                  <p className="text-white/60 text-lg">
                    Arahkan QR tiket peserta ke kamera{data?.room_name ? ` • ${data.room_name}` : ''}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowScanModal(false)}
                className="p-3 rounded-xl text-white/60 hover:text-white hover:bg-white/10 transition-colors"
              >
                <i className="ri-close-line text-3xl"></i>
              </button>
            </div>

            <div className="p-7 grid grid-cols-1 lg:grid-cols-2 gap-7">
              <div>
                <div className="relative rounded-[28px] overflow-hidden bg-black aspect-square">
                  <video ref={scanVideoRef} className="w-full h-full object-cover" muted playsInline />
                  {scannerStatus === 'scanning' && (
                    <div className="absolute inset-0 pointer-events-none">
                      <div className="absolute inset-16 border-4 border-white/70 rounded-3xl" />
                      <div className="absolute left-16 right-16 h-1.5 bg-emerald-400 shadow-[0_0_25px_6px_rgba(16,185,129,0.85)] animate-[scanline_2.4s_ease-in-out_infinite]" />
                    </div>
                  )}
                  {scannerStatus === 'starting' && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-white/70 bg-black/50">
                      <svg className="animate-spin h-10 w-10" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      <span className="text-lg font-semibold">Menyalakan kamera...</span>
                    </div>
                  )}
                  {scannerStatus === 'error' && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-rose-300 bg-black/70 p-8 text-center">
                      <i className="ri-error-warning-line text-5xl"></i>
                      <span className="text-lg font-semibold">{scannerError}</span>
                      <span className="text-sm text-white/60">Gunakan input kode manual di samping.</span>
                    </div>
                  )}
                </div>

                <form
                  className="mt-5 flex gap-3"
                  onSubmit={(e) => {
                    e.preventDefault();
                    submitScan(manualCode);
                    setManualCode('');
                  }}
                >
                  <input
                    type="text"
                    value={manualCode}
                    onChange={(e) => setManualCode(e.target.value.toUpperCase())}
                    placeholder="KODE TIKET"
                    autoFocus
                    className="flex-1 px-5 py-4 text-xl font-mono rounded-2xl bg-black/30 border-2 border-white/15 text-white outline-none focus:border-emerald-400 transition-colors placeholder:text-white/30"
                  />
                  <button
                    type="submit"
                    disabled={scanSubmitting || !manualCode.trim()}
                    className="px-7 py-4 rounded-2xl bg-white text-slate-900 font-black text-xl hover:bg-white/90 disabled:opacity-50 transition-colors"
                  >
                    {scanSubmitting ? '...' : 'OK'}
                  </button>
                </form>
              </div>

              <div className="flex flex-col gap-4">
                <div
                  className={`rounded-[28px] border-2 p-7 flex-1 flex flex-col justify-center ${
                    lastScan
                      ? lastScan.success && !lastScan.already_checked_in
                        ? 'bg-emerald-950/60 border-emerald-400/50'
                        : lastScan.success
                          ? 'bg-amber-950/60 border-amber-400/50'
                          : 'bg-rose-950/60 border-rose-400/50'
                      : 'bg-black/25 border-white/10'
                  }`}
                >
                  {!lastScan ? (
                    <div className="text-center">
                      <i className="ri-qr-scan-line text-6xl text-white/25"></i>
                      <div className="text-2xl font-black text-white/70 mt-4">Menunggu Scan</div>
                      <div className="text-white/50 mt-2">Hasil presensi akan tampil di sini</div>
                    </div>
                  ) : (
                    <div>
                      <i
                        className={`text-6xl ${
                          lastScan.success && !lastScan.already_checked_in
                            ? 'ri-checkbox-circle-fill text-emerald-300'
                            : lastScan.success
                              ? 'ri-error-warning-fill text-amber-300'
                              : 'ri-close-circle-fill text-rose-300'
                        }`}
                      ></i>
                      <div className="text-2xl font-black text-white mt-4 leading-tight">
                        {lastScan.message}
                      </div>
                      {lastScan.booking_title && (
                        <div className="text-white/70 text-lg mt-2">{lastScan.booking_title}</div>
                      )}
                      {lastScan.success && lastScan.seat && (
                        <div className="text-emerald-200 text-xl font-black mt-2">
                          <i className="ri-armchair-line mr-2"></i>
                          Silakan duduk di Kursi {lastScan.seat.label}
                        </div>
                      )}
                      {lastScan.total_participants > 0 && (
                        <div className="mt-4 inline-flex items-center gap-2 px-5 py-3 rounded-full bg-white/10 border border-white/20 text-white font-black text-xl">
                          <i className="ri-team-line text-2xl"></i>
                          {lastScan.attended_count}/{lastScan.total_participants} hadir
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {scanHistory.length > 0 && (
                  <div className="rounded-[28px] bg-black/25 border-2 border-white/10 p-5">
                    <div className="text-sm uppercase tracking-[0.25em] text-white/50 font-black mb-3">
                      Riwayat Scan
                    </div>
                    <ul className="space-y-2 max-h-52 overflow-y-auto">
                      {scanHistory.map((h, i) => (
                        <li key={`${h.at}-${i}`} className="flex items-center gap-3 text-white/80">
                          <i
                            className={`text-xl ${
                              h.success && !h.already_checked_in
                                ? 'ri-checkbox-circle-fill text-emerald-300'
                                : h.success
                                  ? 'ri-error-warning-line text-amber-300'
                                  : 'ri-close-circle-fill text-rose-300'
                            }`}
                          ></i>
                          <span className="flex-1 truncate font-semibold">
                            {h.participant_name || h.message}
                          </span>
                          <span className="text-xs text-white/40 font-mono">
                            {new Date(h.at).toLocaleTimeString('id-ID', {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => setShowScanModal(false)}
                  className="py-5 rounded-2xl bg-white/10 text-white font-black text-xl hover:bg-white/15 transition-colors"
                >
                  Selesai
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
