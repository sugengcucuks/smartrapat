import { useCallback, useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { authApi } from '../../../shared/api/auth';
import { getErrorMessage } from '../../../shared/api/client';
import type { PresensiScanResponse } from '@shared/types';
import { useQrScanner } from '../../hooks/useQrScanner';
import { playSuccessChime, playErrorChime, playDuplicateChime } from '../../utils/chime';

interface ScanResult extends PresensiScanResponse {
  at: number;
}

export function PresensiScannerPage() {
  const [searchParams] = useSearchParams();
  const roomCode = searchParams.get('room') || undefined;

  const videoRef = useRef<HTMLVideoElement>(null);
  const [manualCode, setManualCode] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [lastResult, setLastResult] = useState<ScanResult | null>(null);
  const [history, setHistory] = useState<ScanResult[]>([]);
  const [cameraOn, setCameraOn] = useState(true);

  const submitCode = useCallback(
    async (rawCode: string) => {
      const code = rawCode.trim();
      if (!code || submitting) return;
      setSubmitting(true);
      try {
        const res = await authApi.scanTicket({ code, room_code: roomCode });
        playSuccessChime();
        const entry: ScanResult = { ...res, at: Date.now() };
        setLastResult(entry);
        setHistory((prev) => [entry, ...prev].slice(0, 20));
      } catch (err: unknown) {
        const status = (err as { response?: { status?: number } }).response?.status;
        // detail bisa string, {code, message}, atau array validasi -> selalu jadikan teks.
        const detail = getErrorMessage(err, 'Gagal memproses kode tiket.');

        const failed: ScanResult = {
          success: false,
          message: detail,
          participant_id: '',
          participant_name: '',
          booking_id: '',
          booking_title: '',
          attended: false,
          already_checked_in: false,
          checked_in_at: null,
          attended_count: 0,
          total_participants: 0,
          at: Date.now(),
        };
        if (status === 409) playDuplicateChime();
        else playErrorChime();
        setLastResult(failed);
        setHistory((prev) => [failed, ...prev].slice(0, 20));
      } finally {
        setSubmitting(false);
      }
    },
    [roomCode, submitting]
  );

  const { status: scannerStatus, error: scannerError } = useQrScanner({
    videoRef,
    active: cameraOn,
    onDetected: (code) => submitCode(code),
  });

  useEffect(() => {
    if (lastResult) {
      const t = window.setTimeout(() => setLastResult(null), 6000);
      return () => window.clearTimeout(t);
    }
  }, [lastResult]);

  const ok = lastResult?.success && !lastResult.already_checked_in;
  const duplicate = lastResult?.success && lastResult.already_checked_in;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Scanner Presensi QR</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Arahkan QR tiket peserta ke kamera, atau ketik kode tiket secara manual
            {roomCode ? ` • Ruangan ${roomCode}` : ''}
          </p>
        </div>
        <button
          type="button"
          onClick={() => setCameraOn((v) => !v)}
          className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            cameraOn
              ? 'bg-black/5 dark:bg-white/10 text-black dark:text-white hover:bg-black/10'
              : 'bg-primary text-white hover:bg-primary/90'
          }`}
        >
          <i className={cameraOn ? 'ri-camera-off-line text-lg' : 'ri-camera-line text-lg'}></i>
          {cameraOn ? 'Matikan Kamera' : 'Nyalakan Kamera'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* KAMERA */}
        <div className="bg-white dark:bg-gray rounded-lg shadow-md p-5">
          <div className="relative rounded-xl overflow-hidden bg-black aspect-video">
            <video ref={videoRef} className="w-full h-full object-cover" muted playsInline />
            {cameraOn && scannerStatus === 'scanning' && (
              <div className="absolute inset-0 pointer-events-none">
                <div className="absolute inset-12 border-4 border-white/70 rounded-2xl" />
                <div className="absolute left-12 right-12 h-1 bg-success shadow-[0_0_18px_4px_rgba(16,185,129,0.8)] animate-[scanline_2.4s_ease-in-out_infinite]" />
              </div>
            )}
            {!cameraOn && (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white/60 gap-2">
                <i className="ri-camera-off-line text-5xl"></i>
                <span className="text-sm">Kamera dimatikan</span>
              </div>
            )}
            {cameraOn && scannerStatus === 'starting' && (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white/70 gap-2 bg-black/50">
                <svg className="animate-spin h-8 w-8" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                <span className="text-sm">Menyalakan kamera...</span>
              </div>
            )}
            {cameraOn && scannerStatus === 'error' && (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-danger gap-2 bg-black/60 p-6 text-center">
                <i className="ri-error-warning-line text-5xl"></i>
                <span className="text-sm">{scannerError}</span>
              </div>
            )}
          </div>

          <form
            className="mt-5 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              submitCode(manualCode);
              setManualCode('');
            }}
          >
            <input
              type="text"
              value={manualCode}
              onChange={(e) => setManualCode(e.target.value.toUpperCase())}
              placeholder="Ketik kode tiket, mis. TC-7KQ4MZ"
              className="flex-1 px-4 py-3 font-mono rounded-lg bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 text-black dark:text-white outline-none focus:border-primary transition-colors"
            />
            <button
              type="submit"
              disabled={submitting || !manualCode.trim()}
              className="px-5 py-3 rounded-lg bg-primary text-white font-semibold hover:bg-primary/90 disabled:opacity-50 transition-colors inline-flex items-center gap-2"
            >
              {submitting ? (
                <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
              ) : (
                <i className="ri-check-line text-lg"></i>
              )}
              Proses
            </button>
          </form>
        </div>

        {/* HASIL & RIWAYAT */}
        <div className="space-y-6">
          <div
            className={`rounded-lg shadow-md p-6 border-2 transition-colors ${
              ok
                ? 'bg-success/5 border-success/40'
                : duplicate
                  ? 'bg-warning/5 border-warning/40'
                  : lastResult
                    ? 'bg-danger/5 border-danger/40'
                    : 'bg-white dark:bg-gray border-transparent'
            }`}
          >
            {!lastResult ? (
              <div className="text-center py-10">
                <i className="ri-qr-scan-2-line text-6xl text-black/20 dark:text-white/20"></i>
                <h3 className="text-lg font-bold text-black dark:text-white mt-4">Menunggu Scan</h3>
                <p className="text-sm text-black/60 dark:text-white/60 mt-1">
                  Hasil validasi tiket akan muncul di sini
                </p>
              </div>
            ) : (
              <>
                <div className="flex items-start gap-4">
                  <div
                    className={`w-14 h-14 shrink-0 rounded-2xl flex items-center justify-center ${
                      ok ? 'bg-success/20 text-success' : duplicate ? 'bg-warning/20 text-warning' : 'bg-danger/20 text-danger'
                    }`}
                  >
                    <i
                      className={`text-3xl ${
                        ok
                          ? 'ri-checkbox-circle-fill'
                          : duplicate
                            ? 'ri-error-warning-fill'
                            : 'ri-close-circle-fill'
                      }`}
                    ></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div
                      className={`text-xl font-black ${
                        ok ? 'text-success' : duplicate ? 'text-warning' : 'text-danger'
                      }`}
                    >
                      {ok ? 'PRESENSI BERHASIL' : duplicate ? 'SUDAH PRESENSI' : 'TIKET DITOLAK'}
                    </div>
                    <p className="text-black dark:text-white font-semibold mt-1">{lastResult.message}</p>
                    {lastResult.booking_title && (
                      <div className="mt-3 space-y-1 text-sm text-black/60 dark:text-white/60">
                        <div className="flex items-center gap-2">
                          <i className="ri-video-chat-line"></i>
                          {lastResult.booking_title}
                        </div>
                        {lastResult.room_name && (
                          <div className="flex items-center gap-2">
                            <i className="ri-door-open-line"></i>
                            {lastResult.room_name}
                          </div>
                        )}
                        <div className="flex items-center gap-2">
                          <i className="ri-team-line"></i>
                          {lastResult.attended_count}/{lastResult.total_participants} peserta hadir
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                {lastResult.participant_name && (
                  <div className="mt-5 p-4 rounded-xl bg-black/5 dark:bg-white/5 text-center">
                    <div className="text-xs uppercase tracking-widest text-black/50 dark:text-white/50 font-bold">
                      Peserta
                    </div>
                    <div className="text-2xl font-black text-black dark:text-white mt-1">
                      {lastResult.participant_name}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>

          <div className="bg-white dark:bg-gray rounded-lg shadow-md p-5">
            <h3 className="text-sm font-bold text-black dark:text-white mb-3 flex items-center gap-2">
              <i className="ri-history-line text-lg"></i>
              Riwayat Scan Sesi Ini
            </h3>
            {history.length === 0 ? (
              <p className="text-sm text-black/50 dark:text-white/50 py-4 text-center">
                Belum ada scan pada sesi ini
              </p>
            ) : (
              <ul className="divide-y divide-black/5 dark:divide-white/5 max-h-80 overflow-y-auto">
                {history.map((h, i) => (
                  <li key={`${h.at}-${i}`} className="py-2.5 flex items-center gap-3">
                    <i
                      className={`text-lg shrink-0 ${
                        h.success
                          ? h.already_checked_in
                            ? 'ri-error-warning-line text-warning'
                            : 'ri-checkbox-circle-fill text-success'
                          : 'ri-close-circle-fill text-danger'
                      }`}
                    ></i>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-black dark:text-white truncate">
                        {h.participant_name || h.message}
                      </div>
                      {h.booking_title && (
                        <div className="text-xs text-black/50 dark:text-white/50 truncate">
                          {h.booking_title}
                        </div>
                      )}
                    </div>
                    <span className="text-xs text-black/40 dark:text-white/40 shrink-0 font-mono">
                      {new Date(h.at).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
