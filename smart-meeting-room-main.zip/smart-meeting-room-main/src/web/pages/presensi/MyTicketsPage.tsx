import { useEffect, useMemo, useState } from 'react';
import QRCode from 'qrcode';
import { authApi } from '../../../shared/api/auth';
import { getErrorMessage } from '../../../shared/api/client';
import type { TicketItem } from '@shared/types';

function TicketQr({ value, size = 220 }: { value: string; size?: number }) {
  const [dataUrl, setDataUrl] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    QRCode.toDataURL(value, {
      width: size,
      margin: 1,
      errorCorrectionLevel: 'M',
      color: { dark: '#0f172a', light: '#ffffff' },
    })
      .then((url) => {
        if (!cancelled) setDataUrl(url);
      })
      .catch(() => {
        if (!cancelled) setDataUrl(null);
      });
    return () => {
      cancelled = true;
    };
  }, [value, size]);

  if (!dataUrl) {
    return (
      <div
        className="animate-pulse rounded-xl bg-black/10 dark:bg-white/10"
        style={{ width: size, height: size }}
      />
    );
  }

  return <img src={dataUrl} alt={`QR ${value}`} width={size} height={size} className="rounded-xl bg-white p-2" />;
}

function formatDate(d: string) {
  return new Date(`${d}T00:00:00`).toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
}

export function MyTicketsPage() {
  const [items, setItems] = useState<TicketItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [includePast, setIncludePast] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTicket, setActiveTicket] = useState<TicketItem | null>(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await authApi.getMyTickets({ include_past: includePast });
      setItems(res.items || []);
      setError(null);
    } catch (err) {
      setItems([]);
      setError(getErrorMessage(err, 'Gagal memuat daftar tiket. Coba muat ulang halaman.'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [includePast]);

  const grouped = useMemo(() => {
    const map = new Map<string, TicketItem[]>();
    for (const t of items) {
      const list = map.get(t.booking_id) || [];
      list.push(t);
      map.set(t.booking_id, list);
    }
    return Array.from(map.entries());
  }, [items]);

  const attendedTotal = items.filter((t) => t.attended).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Tiket Presensi Saya</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Tunjukkan kode QR pada scanner di pintu ruangan untuk mencatat kehadiran
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="px-4 py-2 rounded-lg bg-success/10 border border-success/20 text-success text-sm font-semibold">
            {attendedTotal} / {items.length} tiket sudah presensi
          </div>
          <label className="inline-flex items-center gap-2 text-sm text-black/70 dark:text-white/70 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={includePast}
              onChange={(e) => setIncludePast(e.target.checked)}
              className="w-4 h-4 accent-primary"
            />
            Tampilkan tiket lampau
          </label>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-lg bg-danger/10 border border-danger/20 text-danger text-sm flex items-center gap-2">
          <i className="ri-error-warning-line text-lg"></i>
          {error}
        </div>
      )}

      {loading ? (
        <div className="bg-white dark:bg-gray rounded-lg shadow-md p-16 flex flex-col items-center gap-3 text-black/50 dark:text-white/50">
          <svg className="animate-spin h-9 w-9 text-primary" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
          </svg>
          <p className="text-sm">Memuat tiket...</p>
        </div>
      ) : grouped.length === 0 ? (
        <div className="bg-white dark:bg-gray rounded-lg shadow-md p-16 text-center">
          <i className="ri-qr-code-line text-6xl text-black/20 dark:text-white/20"></i>
          <h3 className="text-lg font-bold text-black dark:text-white mt-4">Belum Ada Tiket</h3>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Tiket presensi otomatis dibuat saat Anda diundang atau membuat pemesanan ruangan.
          </p>
        </div>
      ) : (
        <div className="space-y-5">
          {grouped.map(([bookingId, tickets]) => {
            const head = tickets[0];
            return (
              <div key={bookingId} className="bg-white dark:bg-gray rounded-lg shadow-md overflow-hidden">
                <div className="p-5 border-b border-black/10 dark:border-white/10 flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h2 className="text-lg font-bold text-black dark:text-white truncate">{head.booking_title}</h2>
                    <div className="flex flex-wrap items-center gap-3 mt-2 text-sm text-black/60 dark:text-white/60">
                      <span className="inline-flex items-center gap-1.5">
                        <i className="ri-calendar-line"></i>
                        {formatDate(head.date)}
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <i className="ri-time-line"></i>
                        {head.start_time} - {head.end_time}
                      </span>
                      {head.room_name && (
                        <span className="inline-flex items-center gap-1.5">
                          <i className="ri-door-open-line"></i>
                          {head.room_name}
                          {head.room_code ? ` (${head.room_code})` : ''}
                        </span>
                      )}
                      <span className="inline-flex items-center gap-1.5">
                        <i className="ri-team-line"></i>
                        {head.attended_count}/{head.total_participants} hadir
                      </span>
                    </div>
                  </div>
                  <span className="px-3 py-1 rounded-full text-xs font-semibold bg-primary/10 text-primary border border-primary/20">
                    {tickets.length} tiket
                  </span>
                </div>

                <div className="p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {tickets.map((t) => (
                    <button
                      key={t.participant_id}
                      type="button"
                      onClick={() => setActiveTicket(t)}
                      className={`text-left p-4 rounded-xl border transition-all hover:shadow-lg ${
                        t.attended
                          ? 'bg-success/5 border-success/25 hover:border-success/50'
                          : 'bg-black/[0.02] dark:bg-white/[0.03] border-black/10 dark:border-white/10 hover:border-primary/50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-mono font-bold text-black dark:text-white">{t.ticket_code}</span>
                        {t.attended ? (
                          <span className="inline-flex items-center gap-1 text-xs font-semibold text-success">
                            <i className="ri-checkbox-circle-fill"></i>
                            Hadir
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs font-semibold text-warning">
                            <i className="ri-time-line"></i>
                            Belum
                          </span>
                        )}
                      </div>
                      <div className="flex justify-center">
                        <TicketQr value={t.ticket_code} size={140} />
                      </div>
                      <div className="mt-3 text-center text-xs text-black/50 dark:text-white/50">
                        {t.attended && t.checked_in_at
                          ? `Presensi ${new Date(t.checked_in_at).toLocaleTimeString('id-ID', {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}`
                          : 'Klik untuk perbesar QR'}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {activeTicket && (
        <div
          className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
          onClick={() => setActiveTicket(null)}
        >
          <div
            className="w-full max-w-sm bg-white dark:bg-gray rounded-2xl shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 text-center">
              <div className="text-sm uppercase tracking-widest text-black/50 dark:text-white/50 font-bold">
                Tiket Presensi
              </div>
              <h3 className="text-xl font-bold text-black dark:text-white mt-1 mb-4">
                {activeTicket.booking_title}
              </h3>
              <div className="flex justify-center">
                <TicketQr value={activeTicket.ticket_code} size={260} />
              </div>
              <div className="mt-4 font-mono text-2xl font-black tracking-[0.3em] text-black dark:text-white">
                {activeTicket.ticket_code}
              </div>
              <div className="mt-4 text-sm text-black/60 dark:text-white/60 space-y-1">
                <div>{formatDate(activeTicket.date)}</div>
                <div>
                  {activeTicket.start_time} - {activeTicket.end_time}
                  {activeTicket.room_name ? ` • ${activeTicket.room_name}` : ''}
                </div>
              </div>
              {activeTicket.attended && (
                <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-success/10 border border-success/25 text-success text-sm font-semibold">
                  <i className="ri-checkbox-circle-fill"></i>
                  Sudah presensi
                </div>
              )}
            </div>
            <div className="p-4 border-t border-black/10 dark:border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveTicket(null)}
                className="px-5 py-2.5 rounded-xl bg-black/5 dark:bg-white/10 text-black dark:text-white font-semibold hover:bg-black/10 dark:hover:bg-white/15 transition-colors"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
