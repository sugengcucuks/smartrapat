import { useEffect, useMemo, useState } from 'react';
import { authApi } from '../../../shared/api/auth';
import type {
  Device,
  DeviceCommandAction,
  DeviceCreate,
  DeviceHealthSummary,
  DeviceStatus,
  DeviceType,
  DeviceUpdate,
  Room,
} from '@shared/types';
import { DEVICE_STATUS_OPTIONS, DEVICE_TYPE_OPTIONS, deviceTypeLabel } from '@shared/types';
import { useAuthStore } from '../../store/auth.store';
import { apiErrorMessage, hasPermission, useAvCommands } from '../../components/av/avUtils';
import { CommandBadge } from '../../components/av/CommandFeedback';

interface DeviceFormState {
  code: string;
  name: string;
  device_type: DeviceType;
  location_id: string;
  ip_address: string;
  mac_address: string;
  firmware_version: string;
  status: DeviceStatus;
  config: string;
}

const INITIAL_FORM: DeviceFormState = {
  code: '',
  name: '',
  device_type: 'tv',
  location_id: '',
  ip_address: '',
  mac_address: '',
  firmware_version: '',
  status: 'offline',
  config: '{}',
};

const EMPTY_HEALTH: DeviceHealthSummary = {
  count_total: 0, count_online: 0, count_offline: 0, count_error: 0, count_maintenance: 0, list_per_room: [],
};

const STATUS_BADGE: Record<DeviceStatus, string> = {
  online: 'bg-green-100 text-green-700 dark:bg-green-500/10 dark:text-green-400',
  offline: 'bg-gray-100 text-gray-700 dark:bg-gray-500/10 dark:text-gray-400',
  error: 'bg-red-100 text-red-700 dark:bg-red-500/10 dark:text-red-400',
  maintenance: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-500/10 dark:text-yellow-400',
};

const STATUS_LABEL: Record<DeviceStatus, string> = {
  online: 'Online', offline: 'Offline', error: 'Error', maintenance: 'Maintenance',
};

const COMMANDS: { action: DeviceCommandAction; label: string; icon: string; onlyTypes?: string[] }[] = [
  { action: 'power-on', label: 'Hidupkan', icon: 'ri-power-line' },
  { action: 'power-off', label: 'Matikan', icon: 'ri-shut-down-line' },
  { action: 'restart', label: 'Restart', icon: 'ri-restart-line' },
  { action: 'lock', label: 'Kunci', icon: 'ri-lock-line', onlyTypes: ['door_lock'] },
  { action: 'unlock', label: 'Buka kunci', icon: 'ri-lock-unlock-line', onlyTypes: ['door_lock'] },
];

const CONFIG_HINT: Partial<Record<DeviceType, string>> = {
  videowall_controller: 'Opsional: {"presets": [...], "sources": [...], "panels": ["TV-PANEL-1", ...]} — kosong = preset default wall 3x2 & HDMI 1-4',
  audio_mixer: '{"driver": "xair", "max_channels": 16}',
};

const inputCls = 'w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80';

export function DeviceListPage() {
  const user = useAuthStore((s) => s.user);
  const canWrite = hasPermission(user, 'devices.write');
  const canControl = hasPermission(user, 'devices.control');

  const [items, setItems] = useState<Device[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [health, setHealth] = useState<DeviceHealthSummary>(EMPTY_HEALTH);
  const [loading, setLoading] = useState(false);
  const [listError, setListError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterRoom, setFilterRoom] = useState('');
  const [page, setPage] = useState(1);
  const [perPage] = useState(10);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Device | null>(null);
  const [form, setForm] = useState<DeviceFormState>(INITIAL_FORM);
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<Device | null>(null);
  const { states: cmdStates, run: runCommand } = useAvCommands();

  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 4000);
  };

  const fetchData = async () => {
    setLoading(true);
    setListError(null);
    try {
      const params: Record<string, unknown> = { page, per_page: perPage };
      if (search.trim()) params.search = search.trim();
      if (filterType) params.device_type = filterType;
      if (filterStatus) params.status = filterStatus;
      if (filterRoom) params.room_id = filterRoom;
      const result = await authApi.listDevices(params);
      setItems(result.items);
      setTotal(result.total);
      setTotalPages(result.total_pages);
    } catch (err) {
      setItems([]);
      setTotal(0);
      setTotalPages(0);
      setListError(apiErrorMessage(err, 'Gagal memuat perangkat'));
    } finally {
      setLoading(false);
    }
  };

  const fetchHealth = async () => {
    try {
      setHealth(await authApi.getDeviceHealth());
    } catch (err) {
      console.error(err);
    }
  };

  const fetchRooms = async () => {
    try {
      const result = await authApi.listRooms({ per_page: 100 });
      setRooms(result.items);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchRooms();
    fetchHealth();
    // Status online/offline berasal dari agent (health poll ~30 dtk) -> segarkan ringkasan berkala.
    const timer = setInterval(fetchHealth, 30000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    fetchData();
  }, [page, filterType, filterStatus, filterRoom]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(1);
      fetchData();
    }, 400);
    return () => clearTimeout(timer);
  }, [search]);

  const openCreateModal = () => {
    setEditing(null);
    setForm(INITIAL_FORM);
    setFormError(null);
    setShowModal(true);
  };

  const openEditModal = (item: Device) => {
    setEditing(item);
    setForm({
      code: item.code,
      name: item.name,
      device_type: item.device_type as DeviceType,
      location_id: item.location_id || '',
      ip_address: item.ip_address || '',
      mac_address: item.mac_address || '',
      firmware_version: item.firmware_version || '',
      status: item.status,
      config: JSON.stringify(item.config || {}, null, 2),
    });
    setFormError(null);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditing(null);
    setForm(INITIAL_FORM);
    setFormError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    let config: Record<string, unknown>;
    try {
      const parsed: unknown = JSON.parse(form.config.trim() || '{}');
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('bukan objek');
      config = parsed as Record<string, unknown>;
    } catch {
      setFormError('Config harus JSON objek yang valid, mis. {"driver": "xair"}');
      return;
    }
    setSubmitting(true);
    try {
      if (editing) {
        const data: DeviceUpdate = {
          code: form.code,
          name: form.name,
          device_type: form.device_type,
          location_id: form.location_id || null,
          ip_address: form.ip_address || null,
          mac_address: form.mac_address || null,
          firmware_version: form.firmware_version || null,
          config,
        };
        if (form.status !== editing.status) data.status = form.status;
        await authApi.updateDevice(editing.id, data);
        showToast('success', 'Perangkat berhasil diperbarui');
      } else {
        const data: DeviceCreate = {
          code: form.code,
          name: form.name,
          device_type: form.device_type,
          location_id: form.location_id || null,
          ip_address: form.ip_address || null,
          mac_address: form.mac_address || null,
          firmware_version: form.firmware_version || null,
          config,
        };
        await authApi.createDevice(data);
        showToast('success', 'Perangkat berhasil ditambahkan');
      }
      closeModal();
      fetchData();
      fetchHealth();
    } catch (err: unknown) {
      setFormError(apiErrorMessage(err, 'Gagal menyimpan perangkat'));
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (item: Device) => {
    try {
      await authApi.deleteDevice(item.id);
      showToast('success', 'Perangkat berhasil dihapus');
      setDeleteConfirm(null);
      fetchData();
      fetchHealth();
    } catch (err) {
      showToast('error', apiErrorMessage(err, 'Gagal menghapus perangkat'));
      setDeleteConfirm(null);
    }
  };

  const handleCommand = async (item: Device, action: DeviceCommandAction, label: string) => {
    let httpError = '';
    const res = await runCommand(`${item.id}:${action}`, async () => {
      try {
        return await authApi.deviceCommand(item.id, action);
      } catch (err) {
        httpError = apiErrorMessage(err, `${label} gagal`);
        throw err;
      }
    });
    if (!res) {
      showToast('error', httpError || `${label} gagal`);
    } else if (res.status === 'acked') {
      showToast('success', `${label} ${item.name}: berhasil`);
      fetchData();
    } else if (res.status === 'timeout') {
      showToast('error', `${label} ${item.name}: agent tidak merespons (cek device agent & devices.yaml)`);
    } else {
      showToast('error', `${label} ${item.name}: ${res.error || 'gagal'}`);
    }
  };

  const pageNumbers = useMemo(() => {
    const pages: (number | string)[] = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else if (page <= 4) {
      pages.push(1, 2, 3, 4, 5, '...', totalPages);
    } else if (page >= totalPages - 3) {
      pages.push(1, '...', totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages);
    } else {
      pages.push(1, '...', page - 1, page, page + 1, '...', totalPages);
    }
    return pages;
  }, [page, totalPages]);

  const formatLastSeen = (d?: string | null) => {
    if (!d) return 'Belum pernah';
    const date = new Date(d);
    const diff = (Date.now() - date.getTime()) / 1000;
    if (diff < 60) return 'Baru saja';
    if (diff < 3600) return `${Math.floor(diff / 60)} menit lalu`;
    return `${date.toLocaleDateString('id-ID')} ${date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}`;
  };

  const cards: { label: string; value: number; icon: string; cls: string }[] = [
    { label: 'Online', value: health.count_online, icon: 'ri-checkbox-circle-line', cls: 'bg-green-100 dark:bg-green-500/10 text-green-600 dark:text-green-400' },
    { label: 'Offline', value: health.count_offline, icon: 'ri-indeterminate-circle-line', cls: 'bg-gray-100 dark:bg-gray-500/10 text-gray-600 dark:text-gray-400' },
    { label: 'Error', value: health.count_error, icon: 'ri-error-warning-line', cls: 'bg-red-100 dark:bg-red-500/10 text-red-600 dark:text-red-400' },
    { label: 'Maintenance', value: health.count_maintenance, icon: 'ri-settings-3-line', cls: 'bg-yellow-100 dark:bg-yellow-500/10 text-yellow-600 dark:text-yellow-400' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Daftar Perangkat IoT</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Status online/offline dilaporkan otomatis oleh device agent ({health.count_total} perangkat)
          </p>
        </div>
        {canWrite && (
          <button type="button" onClick={openCreateModal}
            className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors shadow-sm">
            <i className="ri-add-line text-lg"></i>
            <span>Tambah Perangkat</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((c) => (
          <div key={c.label} className="bg-white dark:bg-gray rounded-lg shadow-md p-5 flex items-center gap-4">
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${c.cls}`}>
              <i className={`${c.icon} text-2xl`}></i>
            </div>
            <div>
              <p className="text-sm text-black/60 dark:text-white/60">{c.label}</p>
              <h3 className="text-2xl font-bold text-black dark:text-white">{c.value}</h3>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1 max-w-sm">
            <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40"></i>
            <input type="text" placeholder="Cari kode, nama, IP..." value={search} onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 placeholder:text-black/40 dark:placeholder:text-white/40" />
          </div>
          <select value={filterType} onChange={(e) => { setFilterType(e.target.value); setPage(1); }}
            className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80">
            <option value="">Semua Tipe</option>
            {DEVICE_TYPE_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
          <select value={filterStatus} onChange={(e) => { setFilterStatus(e.target.value); setPage(1); }}
            className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80">
            <option value="">Semua Status</option>
            {DEVICE_STATUS_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
          <select value={filterRoom} onChange={(e) => { setFilterRoom(e.target.value); setPage(1); }}
            className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80">
            <option value="">Semua Ruangan</option>
            {rooms.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
          </select>
        </div>

        {listError && (
          <div className="mb-4 p-3 rounded-lg bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 text-sm">
            <i className="ri-error-warning-line mr-1"></i>{listError}
          </div>
        )}

        <div className="overflow-x-auto -mx-6">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-y border-black/10 dark:border-white/10">
                {['Kode', 'Nama', 'Tipe', 'IP Address', 'Ruangan', 'Status', 'Terakhir Terlihat'].map((h) => (
                  <th key={h} className="text-left py-3 px-4 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">{h}</th>
                ))}
                <th className="text-right py-3 px-4 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-black/50 dark:text-white/50">
                    <i className="ri-loader-4-line animate-spin mr-2"></i>Memuat data...
                  </td>
                </tr>
              ) : items.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-black/50 dark:text-white/50">
                    <div className="flex flex-col items-center gap-2">
                      <i className="ri-monitor-line text-4xl text-black/30 dark:text-white/30"></i>
                      <span>Tidak ada data perangkat</span>
                    </div>
                  </td>
                </tr>
              ) : (
                items.map((item) => {
                  const commands = COMMANDS.filter((c) => !c.onlyTypes || c.onlyTypes.includes(item.device_type));
                  const pending = commands.map((c) => cmdStates[`${item.id}:${c.action}`]).find(Boolean);
                  return (
                    <tr key={item.id} className="border-b border-black/5 dark:border-white/5 hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors">
                      <td className="py-3 px-4 text-black/80 dark:text-white/80 font-medium whitespace-nowrap font-mono">{item.code}</td>
                      <td className="py-3 px-4 text-black/80 dark:text-white/80 whitespace-nowrap">
                        {item.name}
                        {item.last_action && <p className="text-[11px] text-black/40 dark:text-white/40 max-w-[220px] truncate" title={item.last_action}>{item.last_action}</p>}
                      </td>
                      <td className="py-3 px-4 text-black/60 dark:text-white/60 whitespace-nowrap">{deviceTypeLabel(item.device_type)}</td>
                      <td className="py-3 px-4 text-black/60 dark:text-white/60 whitespace-nowrap font-mono">{item.ip_address || '-'}</td>
                      <td className="py-3 px-4 text-black/60 dark:text-white/60 whitespace-nowrap">{item.room_name || '-'}</td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${STATUS_BADGE[item.status] || STATUS_BADGE.offline}`}>
                          {STATUS_LABEL[item.status] || item.status}
                        </span>
                        {item.live?.power && (
                          <span className="ml-2 text-xs text-black/50 dark:text-white/50">daya {item.live.power === 'on' ? 'nyala' : 'mati'}</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-black/60 dark:text-white/60 whitespace-nowrap">{formatLastSeen(item.last_seen)}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center justify-end gap-1">
                          {pending && <CommandBadge state={pending} />}
                          {canControl && commands.map((c) => (
                            <button key={c.action} type="button" title={c.label}
                              disabled={cmdStates[`${item.id}:${c.action}`]?.status === 'pending'}
                              onClick={() => handleCommand(item, c.action, c.label)}
                              className="p-2 text-black/60 dark:text-white/60 hover:text-primary hover:bg-primary/10 rounded-lg transition-colors disabled:opacity-40">
                              <i className={c.icon}></i>
                            </button>
                          ))}
                          {canWrite && (
                            <>
                              <button type="button" onClick={() => openEditModal(item)} title="Ubah"
                                className="p-2 text-black/60 dark:text-white/60 hover:text-primary hover:bg-primary/10 rounded-lg transition-colors">
                                <i className="ri-edit-line"></i>
                              </button>
                              <button type="button" onClick={() => setDeleteConfirm(item)} title="Hapus"
                                className="p-2 text-black/60 dark:text-white/60 hover:text-red-600 hover:bg-red-500/10 rounded-lg transition-colors">
                                <i className="ri-delete-bin-line"></i>
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {totalPages > 0 && (
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-6 pt-4 border-t border-black/10 dark:border-white/10">
            <p className="text-sm text-black/60 dark:text-white/60">
              Menampilkan {((page - 1) * perPage) + 1} - {Math.min(page * perPage, total)} dari {total} data
            </p>
            <div className="flex items-center gap-1">
              <button type="button" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                <i className="ri-arrow-left-s-line"></i>
              </button>
              {pageNumbers.map((p, idx) =>
                typeof p === 'number' ? (
                  <button key={idx} type="button" onClick={() => setPage(p)}
                    className={`w-9 h-9 rounded-lg text-sm font-medium transition-colors ${p === page ? 'bg-primary text-white shadow-sm' : 'text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5'}`}>
                    {p}
                  </button>
                ) : (
                  <span key={idx} className="w-9 h-9 flex items-center justify-center text-sm text-black/40 dark:text-white/40">{p}</span>
                )
              )}
              <button type="button" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page === totalPages}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                <i className="ri-arrow-right-s-line"></i>
              </button>
            </div>
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={closeModal}>
          <div className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">{editing ? 'Ubah Perangkat' : 'Tambah Perangkat'}</h2>
              <button type="button" onClick={closeModal} className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <form onSubmit={handleSubmit} className="overflow-y-auto flex-1">
              <div className="px-6 py-5 space-y-4">
                {formError && (
                  <div className="p-3 rounded-lg bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 text-sm">
                    <div className="flex items-start gap-2"><i className="ri-error-warning-line mt-0.5"></i><span>{formError}</span></div>
                  </div>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Kode <span className="text-red-500">*</span></label>
                    <input type="text" required maxLength={30} value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} className={inputCls} />
                    <p className="text-[11px] text-black/40 dark:text-white/40 mt-1">Harus sama dengan `code` di agent/devices.yaml</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Nama <span className="text-red-500">*</span></label>
                    <input type="text" required maxLength={150} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputCls} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Tipe Perangkat</label>
                    <select value={form.device_type} onChange={(e) => setForm({ ...form, device_type: e.target.value as DeviceType })} className={inputCls}>
                      {DEVICE_TYPE_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Ruangan</label>
                    <select value={form.location_id} onChange={(e) => setForm({ ...form, location_id: e.target.value })} className={inputCls}>
                      <option value="">Tidak ditetapkan</option>
                      {rooms.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">IP Address</label>
                    <input type="text" value={form.ip_address} onChange={(e) => setForm({ ...form, ip_address: e.target.value })} className={inputCls} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">MAC Address</label>
                    <input type="text" value={form.mac_address} onChange={(e) => setForm({ ...form, mac_address: e.target.value })} className={inputCls} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Firmware</label>
                    <input type="text" value={form.firmware_version} onChange={(e) => setForm({ ...form, firmware_version: e.target.value })} className={inputCls} />
                  </div>
                  {editing && (
                    <div>
                      <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Status</label>
                      <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as DeviceStatus })} className={inputCls}>
                        {DEVICE_STATUS_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                      </select>
                      <p className="text-[11px] text-black/40 dark:text-white/40 mt-1">Online/offline diperbarui otomatis oleh agent; ubah manual hanya untuk Maintenance.</p>
                    </div>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Config (JSON)</label>
                  <textarea rows={4} value={form.config} onChange={(e) => setForm({ ...form, config: e.target.value })}
                    className={`${inputCls} font-mono text-xs`} spellCheck={false} />
                  {CONFIG_HINT[form.device_type] && (
                    <p className="text-[11px] text-black/40 dark:text-white/40 mt-1">{CONFIG_HINT[form.device_type]}</p>
                  )}
                </div>
              </div>
              <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex items-center justify-end gap-3">
                <button type="button" onClick={closeModal} disabled={submitting}
                  className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors disabled:opacity-50">
                  Batal
                </button>
                <button type="submit" disabled={submitting}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed">
                  {submitting && <i className="ri-loader-4-line animate-spin"></i>}
                  <span>Simpan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-md overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="px-6 py-5">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-500/10 flex items-center justify-center shrink-0">
                  <i className="ri-delete-bin-line text-2xl text-red-600 dark:text-red-400"></i>
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-black dark:text-white">Hapus Perangkat</h3>
                  <p className="text-sm text-black/60 dark:text-white/60 mt-1">
                    Apakah Anda yakin ingin menghapus <span className="font-semibold">{deleteConfirm.name}</span>?
                  </p>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 bg-black/[0.02] dark:bg-white/[0.02] flex items-center justify-end gap-3">
              <button type="button" onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors">
                Batal
              </button>
              <button type="button" onClick={() => handleDelete(deleteConfirm)}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors shadow-sm">
                Hapus
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className={`fixed top-4 right-4 z-[60] max-w-sm rounded-lg shadow-lg p-4 flex items-start gap-3 ${
          toast.type === 'success' ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20' :
            'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20'
        }`}>
          <div className="flex-shrink-0">
            {toast.type === 'success' ? <i className="ri-check-line text-lg text-green-600 dark:text-green-400"></i> :
              <i className="ri-error-warning-line text-lg text-red-600 dark:text-red-400"></i>}
          </div>
          <p className={`flex-1 text-sm font-medium ${toast.type === 'success' ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>
            {toast.message}
          </p>
          <button type="button" onClick={() => setToast(null)}
            className={`flex-shrink-0 transition-colors ${toast.type === 'success' ? 'text-green-400 hover:text-green-600' : 'text-red-400 hover:text-red-600'}`}>
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}
    </div>
  );
}
