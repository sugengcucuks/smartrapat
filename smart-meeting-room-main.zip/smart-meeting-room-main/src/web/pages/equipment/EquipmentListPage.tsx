import { useEffect, useState, useMemo } from 'react';
import { authApi } from '../../../shared/api/auth';
import { getErrorMessage } from '../../../shared/api/client';
import { usePermission } from '../../store/auth.store';
import type {
  Equipment,
  EquipmentCreate,
  EquipmentUpdate,
  Room,
  EquipmentCategory,
  EquipmentStatus,
} from '@shared/types';
import {
  EQUIPMENT_CATEGORY_OPTIONS,
  EQUIPMENT_STATUS_OPTIONS,
} from '@shared/types';

interface EquipmentFormState {
  code: string;
  name: string;
  category: EquipmentCategory;
  brand: string;
  model: string;
  serial_number: string;
  purchase_date: string;
  warranty_until: string;
  status: EquipmentStatus;
  room_id: string;
  notes: string;
}

const INITIAL_FORM: EquipmentFormState = {
  code: '',
  name: '',
  category: 'display',
  brand: '',
  model: '',
  serial_number: '',
  purchase_date: '',
  warranty_until: '',
  status: 'active',
  room_id: '',
  notes: '',
};

const STATUS_BADGE_COLOR: Record<EquipmentStatus, string> = {
  active: 'bg-green-100 text-green-700 dark:bg-green-500/10 dark:text-green-400',
  maintenance: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-500/10 dark:text-yellow-400',
  broken: 'bg-red-100 text-red-700 dark:bg-red-500/10 dark:text-red-400',
  disposed: 'bg-gray-100 text-gray-700 dark:bg-gray-500/10 dark:text-gray-400',
};

const categoryLabel = (c: string) => EQUIPMENT_CATEGORY_OPTIONS.find((o) => o.value === c)?.label || c;
const statusLabel = (s: string) => EQUIPMENT_STATUS_OPTIONS.find((o) => o.value === s)?.label || s;

export function EquipmentListPage() {
  const can = usePermission();
  const canWrite = can('devices.write');
  const [items, setItems] = useState<Equipment[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterRoom, setFilterRoom] = useState('');
  const [page, setPage] = useState(1);
  const [perPage] = useState(10);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Equipment | null>(null);
  const [form, setForm] = useState<EquipmentFormState>(INITIAL_FORM);
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [deleteConfirm, setDeleteConfirm] = useState<Equipment | null>(null);
  const [assignModal, setAssignModal] = useState<Equipment | null>(null);
  const [assignRoomId, setAssignRoomId] = useState('');

  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchData = async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const params: Record<string, unknown> = { page, per_page: perPage };
      if (search.trim()) params.search = search.trim();
      if (filterCategory) params.category = filterCategory;
      if (filterStatus) params.status = filterStatus;
      if (filterRoom) params.room_id = filterRoom;
      const result = await authApi.listEquipment(params);
      setItems(result.items);
      setTotal(result.total);
      setTotalPages(result.total_pages);
    } catch (err) {
      setItems([]);
      setTotal(0);
      setTotalPages(0);
      setLoadError(getErrorMessage(err, 'Gagal memuat daftar perangkat'));
    } finally {
      setLoading(false);
    }
  };

  const fetchRooms = async () => {
    try {
      const result = await authApi.listRooms({ per_page: 100 });
      setRooms(result.items);
    } catch {
      // Daftar ruangan hanya untuk pilihan lokasi; biarkan kosong bila gagal.
      setRooms([]);
    }
  };

  useEffect(() => {
    fetchRooms();
  }, []);

  useEffect(() => {
    fetchData();
  }, [page, filterCategory, filterStatus, filterRoom]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(1);
      fetchData();
    }, 400);
    return () => clearTimeout(timer);
  }, [search]);

  const openCreateModal = () => {
    setEditing(null);
    setForm(INITIAL_FORM);
    setFormError(null);
    setShowModal(true);
  };

  const openEditModal = (item: Equipment) => {
    setEditing(item);
    setForm({
      code: item.code,
      name: item.name,
      category: item.category,
      brand: item.brand || '',
      model: item.model || '',
      serial_number: item.serial_number || '',
      purchase_date: item.purchase_date || '',
      warranty_until: item.warranty_until || '',
      status: item.status,
      room_id: item.room_id || '',
      notes: item.notes || '',
    });
    setFormError(null);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditing(null);
    setForm(INITIAL_FORM);
    setFormError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSubmitting(true);
    try {
      if (editing) {
        const data: EquipmentUpdate = {
          code: form.code,
          name: form.name,
          category: form.category,
          brand: form.brand || undefined,
          model: form.model || undefined,
          serial_number: form.serial_number || undefined,
          purchase_date: form.purchase_date || undefined,
          warranty_until: form.warranty_until || undefined,
          status: form.status,
          room_id: form.room_id || null,
          notes: form.notes || undefined,
        };
        await authApi.updateEquipment(editing.id, data);
        showToast('success', 'Perangkat berhasil diperbarui');
      } else {
        const data: EquipmentCreate = {
          code: form.code,
          name: form.name,
          category: form.category,
          brand: form.brand || undefined,
          model: form.model || undefined,
          serial_number: form.serial_number || undefined,
          purchase_date: form.purchase_date || undefined,
          warranty_until: form.warranty_until || undefined,
          status: form.status,
          room_id: form.room_id || null,
          notes: form.notes || undefined,
        };
        await authApi.createEquipment(data);
        showToast('success', 'Perangkat berhasil ditambahkan');
      }
      closeModal();
      fetchData();
    } catch (err: unknown) {
      setFormError(getErrorMessage(err, 'Gagal menyimpan perangkat'));
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (item: Equipment) => {
    try {
      await authApi.deleteEquipment(item.id);
      showToast('success', 'Perangkat berhasil dihapus');
      setDeleteConfirm(null);
      fetchData();
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal menghapus perangkat'));
      setDeleteConfirm(null);
    }
  };

  const openAssignModal = (item: Equipment) => {
    setAssignModal(item);
    setAssignRoomId(item.room_id || '');
  };

  const handleAssign = async () => {
    if (!assignModal) return;
    try {
      await authApi.assignEquipmentRoom(assignModal.id, assignRoomId || null);
      showToast('success', 'Lokasi perangkat berhasil diperbarui');
      setAssignModal(null);
      fetchData();
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal menetapkan lokasi'));
    }
  };

  const pageNumbers = useMemo(() => {
    const pages: (number | string)[] = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else if (page <= 4) {
      pages.push(1, 2, 3, 4, 5, '...', totalPages);
    } else if (page >= totalPages - 3) {
      pages.push(1, '...', totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages);
    } else {
      pages.push(1, '...', page - 1, page, page + 1, '...', totalPages);
    }
    return pages;
  }, [page, totalPages]);

  const getRoomName = (id: string | null | undefined) => {
    if (!id) return '-';
    const r = rooms.find((x) => x.id === id);
    return r ? r.name : (id ? '-' : '-');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Daftar Perangkat AV</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">Kelola inventaris perangkat audio visual</p>
        </div>
        {canWrite && (
          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors shadow-sm"
          >
            <i className="ri-add-line text-lg"></i>
            <span>Tambah Perangkat</span>
          </button>
        )}
      </div>

      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1 max-w-sm">
            <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40"></i>
            <input
              type="text"
              placeholder="Cari kode, nama..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 placeholder:text-black/40 dark:placeholder:text-white/40"
            />
          </div>
          <select
            value={filterCategory}
            onChange={(e) => { setFilterCategory(e.target.value); setPage(1); }}
            className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
          >
            <option value="">Semua Kategori</option>
            {EQUIPMENT_CATEGORY_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
          <select
            value={filterStatus}
            onChange={(e) => { setFilterStatus(e.target.value); setPage(1); }}
            className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
          >
            <option value="">Semua Status</option>
            {EQUIPMENT_STATUS_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
          <select
            value={filterRoom}
            onChange={(e) => { setFilterRoom(e.target.value); setPage(1); }}
            className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
          >
            <option value="">Semua Ruangan</option>
            {rooms.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
          </select>
        </div>

        <div className="overflow-x-auto -mx-6">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-y border-black/10 dark:border-white/10">
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">Kode</th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">Nama</th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">Kategori</th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">Merk</th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">Status</th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">Lokasi Ruangan</th>
                <th className="text-right py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-black/50 dark:text-white/50">
                    <div className="inline-flex items-center gap-2">
                      <svg className="animate-spin h-5 w-5 text-primary" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      <span>Memuat data...</span>
                    </div>
                  </td>
                </tr>
              ) : loadError ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center">
                    <p className="text-sm text-red-600 dark:text-red-400">{loadError}</p>
                    <button
                      type="button"
                      onClick={fetchData}
                      className="mt-3 inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-primary bg-primary/10 hover:bg-primary/15 rounded-lg"
                    >
                      <i className="ri-refresh-line"></i> Coba Lagi
                    </button>
                  </td>
                </tr>
              ) : items.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-black/50 dark:text-white/50">
                    <div className="flex flex-col items-center gap-2">
                      <i className="ri-tools-line text-4xl text-black/30 dark:text-white/30"></i>
                      <span>Belum ada data</span>
                    </div>
                  </td>
                </tr>
              ) : (
                items.map((item) => (
                  <tr key={item.id} className="border-b border-black/5 dark:border-white/5 hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors">
                    <td className="py-3 px-6 text-black/80 dark:text-white/80 font-medium whitespace-nowrap">{item.code}</td>
                    <td className="py-3 px-6 text-black/80 dark:text-white/80 whitespace-nowrap">{item.name}</td>
                    <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap">{categoryLabel(item.category)}</td>
                    <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap">{item.brand || '-'}</td>
                    <td className="py-3 px-6 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${STATUS_BADGE_COLOR[item.status] || STATUS_BADGE_COLOR.disposed}`}>
                        {statusLabel(item.status)}
                      </span>
                    </td>
                    <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap">{item.room_name || getRoomName(item.room_id)}</td>
                    <td className="py-3 px-6">
                      <div className="flex items-center justify-end gap-1">
                        {canWrite && (<>
                        <button type="button" onClick={() => openAssignModal(item)} title="Assign Ruangan" className="p-2 text-black/60 dark:text-white/60 hover:text-info hover:bg-info/10 rounded-lg transition-colors">
                          <i className="ri-route-line"></i>
                        </button>
                        <button type="button" onClick={() => openEditModal(item)} title="Ubah" className="p-2 text-black/60 dark:text-white/60 hover:text-primary hover:bg-primary/10 rounded-lg transition-colors">
                          <i className="ri-edit-line"></i>
                        </button>
                        <button type="button" onClick={() => setDeleteConfirm(item)} title="Hapus" className="p-2 text-black/60 dark:text-white/60 hover:text-danger hover:bg-danger/10 rounded-lg transition-colors">
                          <i className="ri-delete-bin-line"></i>
                        </button>
                        </>)}

                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {totalPages > 0 && (
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-6 pt-4 border-t border-black/10 dark:border-white/10">
            <p className="text-sm text-black/60 dark:text-white/60">
              Menampilkan {((page - 1) * perPage) + 1} - {Math.min(page * perPage, total)} dari {total} data
            </p>
            <div className="flex items-center gap-1">
              <button type="button" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                <i className="ri-arrow-left-s-line"></i>
              </button>
              {pageNumbers.map((p, idx) =>
                typeof p === 'number' ? (
                  <button key={idx} type="button" onClick={() => setPage(p)}
                    className={`w-9 h-9 rounded-lg text-sm font-medium transition-colors ${p === page ? 'bg-primary text-white shadow-sm' : 'text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5'}`}>
                    {p}
                  </button>
                ) : (
                  <span key={idx} className="w-9 h-9 flex items-center justify-center text-sm text-black/40 dark:text-white/40">{p}</span>
                )
              )}
              <button type="button" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page === totalPages}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                <i className="ri-arrow-right-s-line"></i>
              </button>
            </div>
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={closeModal}>
          <div className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">{editing ? 'Ubah Perangkat' : 'Tambah Perangkat'}</h2>
              <button type="button" onClick={closeModal} className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <form onSubmit={handleSubmit} className="overflow-y-auto flex-1">
              <div className="px-6 py-5 space-y-4">
                {formError && (
                  <div className="p-3 rounded-lg bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 text-sm">
                    <div className="flex items-start gap-2"><i className="ri-error-warning-line mt-0.5"></i><span>{formError}</span></div>
                  </div>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Kode <span className="text-red-500">*</span></label>
                    <input type="text" required value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Nama <span className="text-red-500">*</span></label>
                    <input type="text" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Kategori</label>
                    <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value as EquipmentCategory })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80">
                      {EQUIPMENT_CATEGORY_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Status</label>
                    <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as EquipmentStatus })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80">
                      {EQUIPMENT_STATUS_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Merk</label>
                    <input type="text" value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Model</label>
                    <input type="text" value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Serial Number</label>
                    <input type="text" value={form.serial_number} onChange={(e) => setForm({ ...form, serial_number: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Lokasi Ruangan</label>
                    <select value={form.room_id} onChange={(e) => setForm({ ...form, room_id: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80">
                      <option value="">Tidak ditetapkan</option>
                      {rooms.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Tanggal Pembelian</label>
                    <input type="date" value={form.purchase_date} onChange={(e) => setForm({ ...form, purchase_date: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Garansi Sampai</label>
                    <input type="date" value={form.warranty_until} onChange={(e) => setForm({ ...form, warranty_until: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Catatan</label>
                    <textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"></textarea>
                  </div>
                </div>
              </div>
              <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex items-center justify-end gap-3">
                <button type="button" onClick={closeModal} disabled={submitting}
                  className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors disabled:opacity-50">
                  Batal
                </button>
                <button type="submit" disabled={submitting}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed">
                  {submitting && (
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                  )}
                  <span>Simpan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {assignModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setAssignModal(null)}>
          <div className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-md overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">Assign Ruangan</h2>
              <button type="button" onClick={() => setAssignModal(null)} className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <div className="px-6 py-5 space-y-4">
              <p className="text-sm text-black/60 dark:text-white/60">
                Tetapkan lokasi ruangan untuk <span className="font-semibold">{assignModal.name}</span>
              </p>
              <div>
                <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Pilih Ruangan</label>
                <select value={assignRoomId} onChange={(e) => setAssignRoomId(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80">
                  <option value="">Tidak ditetapkan (lepas ruangan)</option>
                  {rooms.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                </select>
              </div>
            </div>
            <div className="px-6 py-4 bg-black/[0.02] dark:bg-white/[0.02] flex items-center justify-end gap-3">
              <button type="button" onClick={() => setAssignModal(null)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors">
                Batal
              </button>
              <button type="button" onClick={handleAssign}
                className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm">
                Simpan
              </button>
            </div>
          </div>
        </div>
      )}

      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-md overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="px-6 py-5">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-500/10 flex items-center justify-center shrink-0">
                  <i className="ri-delete-bin-line text-2xl text-red-600 dark:text-red-400"></i>
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-black dark:text-white">Hapus Perangkat</h3>
                  <p className="text-sm text-black/60 dark:text-white/60 mt-1">
                    Apakah Anda yakin ingin menghapus <span className="font-semibold">{deleteConfirm.name}</span>?
                  </p>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 bg-black/[0.02] dark:bg-white/[0.02] flex items-center justify-end gap-3">
              <button type="button" onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors">
                Batal
              </button>
              <button type="button" onClick={() => handleDelete(deleteConfirm)}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors shadow-sm">
                Hapus
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className={`fixed top-4 right-4 z-[60] max-w-sm rounded-lg shadow-lg p-4 flex items-start gap-3 ${
          toast.type === 'success' ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20' :
            'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20'
        }`}>
          <div className="flex-shrink-0">
            {toast.type === 'success' ? <i className="ri-check-line text-lg text-green-600 dark:text-green-400"></i> :
              <i className="ri-error-warning-line text-lg text-red-600 dark:text-red-400"></i>}
          </div>
          <p className={`flex-1 text-sm font-medium ${toast.type === 'success' ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>
            {toast.message}
          </p>
          <button type="button" onClick={() => setToast(null)}
            className={`flex-shrink-0 transition-colors ${toast.type === 'success' ? 'text-green-400 hover:text-green-600' : 'text-red-400 hover:text-red-600'}`}>
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}
    </div>
  );
}
