import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { authApi } from '../../../shared/api/auth';
import { useAuthStore } from '../../store/auth.store';
import { signOut } from '@shared/api/client';
import type { Room, RoomStatus } from '@shared/types';

const STATUS_STYLES: Record<RoomStatus, string> = {
  AVAILABLE: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
  OCCUPIED: 'bg-red-500/15 text-red-400 border-red-500/30',
  RESERVED: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
  MAINTENANCE: 'bg-slate-500/15 text-slate-400 border-slate-500/30',
};

const STATUS_LABELS: Record<RoomStatus, string> = {
  AVAILABLE: 'Tersedia',
  OCCUPIED: 'Dipakai',
  RESERVED: 'Direservasi',
  MAINTENANCE: 'Perawatan',
};

const STATUS_DOTS: Record<RoomStatus, string> = {
  AVAILABLE: 'bg-emerald-400',
  OCCUPIED: 'bg-red-400',
  RESERVED: 'bg-amber-400',
  MAINTENANCE: 'bg-slate-400',
};

export function MobileRoomListPage() {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const { user } = useAuthStore();
  const navigate = useNavigate();

  const loadRooms = () => {
    setLoading(true);
    setError(null);
    authApi
      .listRooms({ page: 1, per_page: 100 })
      .then((res) => setRooms(res.items.filter((r) => r.is_active)))
      .catch(() => setError('Gagal memuat daftar ruangan'))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadRooms();
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return rooms;
    return rooms.filter(
      (r) =>
        r.name.toLowerCase().includes(q) ||
        r.code.toLowerCase().includes(q) ||
        (r.building_name || '').toLowerCase().includes(q)
    );
  }, [rooms, search]);

  const handleLogout = async () => {
    await signOut();
    navigate('/login', { replace: true });
  };

  return (
    <div className="min-h-svh bg-slate-950 text-slate-100">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-slate-900/95 backdrop-blur border-b border-slate-800">
        <div className="max-w-lg mx-auto px-4 pt-4 pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="h-9 w-9 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center">
                <span className="text-emerald-400 font-bold text-sm">SMR</span>
              </div>
              <div>
                <h1 className="font-bold text-lg leading-tight">Smart Meeting Room</h1>
                <p className="text-xs text-slate-400 leading-tight">Kontrol Ruang Rapat</p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="h-10 px-3 rounded-xl bg-slate-800 text-slate-300 text-sm font-medium active:bg-slate-700"
            >
              Keluar
            </button>
          </div>

          {/* Search */}
          <div className="mt-3">
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Cari ruangan, gedung, atau kode..."
              className="w-full h-11 px-4 rounded-xl bg-slate-800 border border-slate-700 text-base placeholder:text-slate-500 focus:outline-none focus:border-emerald-500/50"
            />
          </div>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-4 pb-8">
        {user && (
          <p className="text-xs text-slate-500 mb-3">
            Masuk sebagai <span className="text-slate-300 font-medium">{user.name || user.username}</span>
          </p>
        )}

        {loading && (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <svg className="animate-spin h-8 w-8 text-emerald-400" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
            <p className="text-sm text-slate-400">Memuat ruangan...</p>
          </div>
        )}

        {!loading && error && (
          <div className="rounded-2xl bg-red-500/10 border border-red-500/30 p-4 text-center">
            <p className="text-red-400 text-sm mb-3">{error}</p>
            <button
              onClick={loadRooms}
              className="h-10 px-4 rounded-xl bg-red-500/20 text-red-300 text-sm font-medium active:bg-red-500/30"
            >
              Coba Lagi
            </button>
          </div>
        )}

        {!loading && !error && filtered.length === 0 && (
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-8 text-center">
            <p className="text-slate-400 text-sm">
              {search ? `Tidak ada ruangan yang cocok dengan "${search}"` : 'Belum ada ruangan terdaftar'}
            </p>
          </div>
        )}

        {!loading && !error && filtered.length > 0 && (
          <ul className="space-y-3">
            {filtered.map((room) => (
              <li key={room.id}>
                <Link
                  to={`/m/room/${room.code}`}
                  className="block rounded-2xl bg-slate-900 border border-slate-800 p-4 active:bg-slate-800/70 active:scale-[0.99] transition"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <h2 className="font-semibold text-base truncate">{room.name}</h2>
                      <p className="text-xs text-slate-400 mt-0.5">
                        {room.code}
                        {room.building_name ? ` · ${room.building_name}` : ''}
                        {room.floor != null ? ` · Lantai ${room.floor}` : ''}
                      </p>
                    </div>
                    <span
                      className={`shrink-0 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-medium ${STATUS_STYLES[room.status]}`}
                    >
                      <span className={`h-1.5 w-1.5 rounded-full ${STATUS_DOTS[room.status]}`} />
                      {STATUS_LABELS[room.status]}
                    </span>
                  </div>
                  <div className="mt-3 flex items-center justify-between">
                    <div className="flex items-center gap-3 text-xs text-slate-500">
                      <span className="inline-flex items-center gap-1">
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                        </svg>
                        {room.capacity} org
                      </span>
                      {(room.facilities || []).slice(0, 2).map((f) => (
                        <span key={f} className="truncate max-w-28">{f}</span>
                      ))}
                    </div>
                    <span className="text-emerald-400 text-sm font-medium inline-flex items-center gap-1">
                      Kontrol
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                      </svg>
                    </span>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
}
