import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { authApi } from '../../../shared/api/auth';
import type { CalendarEvent, Room, RoomStatus } from '@shared/types';
import { RoomControlPanel } from '../../components/av/RoomControlPanel';
import { MicMixerPanel } from '../../components/av/MicMixerPanel';
import { useRoomLive } from '../../hooks/useRoomLive';

const STATUS_STYLES: Record<RoomStatus, string> = {
  AVAILABLE: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
  OCCUPIED: 'bg-red-500/15 text-red-400 border-red-500/30',
  RESERVED: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
  MAINTENANCE: 'bg-slate-500/15 text-slate-400 border-slate-500/30',
};

const STATUS_LABELS: Record<RoomStatus, string> = {
  AVAILABLE: 'Tersedia',
  OCCUPIED: 'Dipakai',
  RESERVED: 'Direservasi',
  MAINTENANCE: 'Perawatan',
};

function fmtTime(v: string | undefined): string {
  if (!v) return '';
  if (/^\d{2}:\d{2}/.test(v)) return v.slice(0, 5);
  const d = new Date(v);
  if (!isNaN(d.getTime())) {
    return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
  }
  return v;
}

function todayISO(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function MobileRoomControlPage() {
  const { room_code } = useParams<{ room_code: string }>();

  const [room, setRoom] = useState<Room | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [bookings, setBookings] = useState<CalendarEvent[]>([]);
  // Satu koneksi WS live dipakai bersama panel videowall & mic.
  const live = useRoomLive(room?.id);

  const loadData = useCallback(async () => {
    if (!room_code) return;
    setLoading(true);
    setLoadError(null);
    try {
      const res = await authApi.listRooms({ page: 1, per_page: 100 });
      const found = res.items.find((r) => r.code.toLowerCase() === room_code.toLowerCase());
      if (!found) {
        setLoadError(`Ruangan dengan kode "${room_code}" tidak ditemukan`);
        setRoom(null);
        return;
      }
      setRoom(found);
      try {
        setBookings(await authApi.getRoomCalendar(found.id, { date: todayISO() }));
      } catch {
        setBookings([]);
      }
    } catch {
      setLoadError('Gagal memuat data ruangan');
    } finally {
      setLoading(false);
    }
  }, [room_code]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const { current, next } = useMemo(() => {
    const now = new Date();
    const active = bookings.filter((b) => b.status !== 'cancelled');
    const cur = active.find((b) => {
      const s = new Date(b.start);
      const e = new Date(b.end);
      return now >= s && now <= e;
    });
    const nx = active
      .filter((b) => new Date(b.start) > now)
      .sort((a, b) => new Date(a.start).getTime() - new Date(b.start).getTime())[0];
    return { current: cur, next: nx };
  }, [bookings]);

  if (loading) {
    return (
      <div className="min-h-svh bg-slate-950 text-slate-100 flex flex-col items-center justify-center gap-3">
        <svg className="animate-spin h-8 w-8 text-emerald-400" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
        </svg>
        <p className="text-sm text-slate-400">Memuat panel kontrol...</p>
      </div>
    );
  }

  if (loadError || !room) {
    return (
      <div className="min-h-svh bg-slate-950 text-slate-100 flex flex-col items-center justify-center px-6 gap-4">
        <p className="text-red-400 text-sm text-center">{loadError || 'Ruangan tidak ditemukan'}</p>
        <Link
          to="/m"
          className="h-11 px-5 rounded-xl bg-slate-800 text-slate-200 text-sm font-medium inline-flex items-center"
        >
          Kembali ke Daftar Ruangan
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-svh bg-slate-950 text-slate-100 pb-24">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-slate-900/95 backdrop-blur border-b border-slate-800">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
          <Link
            to="/m"
            className="h-10 w-10 shrink-0 rounded-xl bg-slate-800 flex items-center justify-center active:bg-slate-700"
            aria-label="Kembali"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
            </svg>
          </Link>
          <div className="min-w-0 flex-1">
            <h1 className="font-bold text-lg leading-tight truncate">{room.name}</h1>
            <p className="text-xs text-slate-400 leading-tight truncate">
              {room.code}
              {room.building_name ? ` · ${room.building_name}` : ''}
            </p>
          </div>
          <span className={`shrink-0 px-2.5 py-1 rounded-full border text-xs font-medium ${STATUS_STYLES[room.status]}`}>
            {STATUS_LABELS[room.status]}
          </span>
          <button
            onClick={loadData}
            disabled={loading}
            className="h-10 w-10 shrink-0 rounded-xl bg-slate-800 flex items-center justify-center active:bg-slate-700 disabled:opacity-50"
            aria-label="Muat ulang"
          >
            <svg className={`w-5 h-5 text-slate-300 ${loading ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </button>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-4 space-y-4">
        {/* Jadwal hari ini */}
        <section className="rounded-2xl bg-slate-900 border border-slate-800 p-4">
          <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-3">Rapat Hari Ini</h2>
          {current ? (
            <div className="flex items-center gap-3">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="font-semibold text-sm truncate">{current.title}</p>
                <p className="text-xs text-slate-400">
                  Berlangsung · {fmtTime(current.start)}–{fmtTime(current.end)}
                  {current.organizer_name ? ` · ${current.organizer_name}` : ''}
                </p>
              </div>
            </div>
          ) : next ? (
            <div className="flex items-center gap-3">
              <span className="h-2.5 w-2.5 rounded-full bg-amber-400 shrink-0" />
              <div className="min-w-0 flex-1">
                <p className="font-semibold text-sm truncate">{next.title}</p>
                <p className="text-xs text-slate-400">
                  Berikutnya · {fmtTime(next.start)}–{fmtTime(next.end)}
                  {next.organizer_name ? ` · ${next.organizer_name}` : ''}
                </p>
              </div>
            </div>
          ) : (
            <p className="text-sm text-slate-500">Tidak ada rapat terjadwal hari ini</p>
          )}
        </section>

        <RoomControlPanel roomId={room.id} compact variant="dark" live={live} />
        <MicMixerPanel roomId={room.id} compact variant="dark" live={live} />
      </main>

    </div>
  );
}
