import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi } from '@shared/api/auth';
import type { NoteExportFormat } from '@shared/api/auth';
import type { MeetingNote, MeetingNoteCreate, Room } from '@shared/types';
import { useAuthStore } from '../../store/auth.store';
import { apiErrorMessage } from './noteUtils';

interface NoteFormState {
  title: string;
  room_id: string;
  date: string;
  start_time: string;
  end_time: string;
  participantsText: string;
}

const today = () => new Date().toISOString().split('T')[0];

const INITIAL_FORM: NoteFormState = {
  title: '',
  room_id: '',
  date: today(),
  start_time: '09:00',
  end_time: '10:00',
  participantsText: '',
};

const inputCls =
  'w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80';

export function NotesListPage() {
  const navigate = useNavigate();
  const user = useAuthStore((s) => s.user);
  const perms = user?.permissions ?? [];
  const canWrite = perms.includes('*') || perms.includes('notes.write');

  const [items, setItems] = useState<MeetingNote[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [filterRoom, setFilterRoom] = useState('');
  const [filterStatus, setFilterStatus] = useState<'' | 'draft' | 'final'>('');
  const [filterDateFrom, setFilterDateFrom] = useState('');
  const [filterDateTo, setFilterDateTo] = useState('');
  const [page, setPage] = useState(1);
  const perPage = 10;
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState<NoteFormState>(INITIAL_FORM);
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<MeetingNote | null>(null);
  const [exporting, setExporting] = useState<string | null>(null);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    window.setTimeout(() => setToast(null), type === 'error' ? 6000 : 3000);
  };

  const fetchData = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const result = await authApi.listNotes({
        page,
        per_page: perPage,
        search: search.trim() || undefined,
        room_id: filterRoom || undefined,
        status: filterStatus || undefined,
        date_from: filterDateFrom || undefined,
        date_to: filterDateTo || undefined,
      });
      setItems(result.items);
      setTotal(result.total);
      setTotalPages(result.total_pages);
    } catch (err) {
      setItems([]);
      setTotal(0);
      setTotalPages(0);
      setLoadError(apiErrorMessage(err, 'Gagal memuat daftar notulensi'));
    } finally {
      setLoading(false);
    }
  }, [page, search, filterRoom, filterStatus, filterDateFrom, filterDateTo]);

  useEffect(() => {
    authApi
      .listRooms({ per_page: 100 })
      .then((r) => setRooms(r.items))
      .catch(() => setRooms([]));
  }, []);

  useEffect(() => {
    const t = window.setTimeout(fetchData, search ? 350 : 0);
    return () => window.clearTimeout(t);
  }, [fetchData, search]);

  const openCreateModal = () => {
    setForm({ ...INITIAL_FORM, date: today(), room_id: rooms[0]?.id || '' });
    setFormError(null);
    setShowModal(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.start_time >= form.end_time) {
      setFormError('Jam selesai harus setelah jam mulai');
      return;
    }
    setFormError(null);
    setSubmitting(true);
    try {
      const data: MeetingNoteCreate = {
        title: form.title.trim(),
        room_id: form.room_id,
        date: form.date,
        start_time: form.start_time,
        end_time: form.end_time,
        participants: form.participantsText.split(',').map((s) => s.trim()).filter(Boolean),
        action_items: [],
      };
      const created = await authApi.createNote(data);
      setShowModal(false);
      showToast('success', 'Notulensi dibuat');
      navigate(`/notes/${created.id}`);
    } catch (err) {
      setFormError(apiErrorMessage(err, 'Gagal menyimpan notulensi'));
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (n: MeetingNote) => {
    try {
      await authApi.deleteNote(n.id);
      showToast('success', 'Notulensi dihapus');
      setDeleteConfirm(null);
      fetchData();
    } catch (err) {
      setDeleteConfirm(null);
      showToast('error', apiErrorMessage(err, 'Gagal menghapus notulensi'));
    }
  };

  const handleExport = async (n: MeetingNote, format: NoteExportFormat) => {
    setExporting(`${n.id}-${format}`);
    try {
      await authApi.exportNote(n.id, format);
    } catch (err) {
      showToast('error', apiErrorMessage(err, `Gagal mengunduh ${format.toUpperCase()}`));
    } finally {
      setExporting(null);
    }
  };

  const pageNumbers = useMemo(() => {
    const pages: (number | string)[] = [];
    if (totalPages <= 7) { for (let i = 1; i <= totalPages; i++) pages.push(i); }
    else if (page <= 4) pages.push(1, 2, 3, 4, 5, '...', totalPages);
    else if (page >= totalPages - 3) pages.push(1, '...', totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages);
    else pages.push(1, '...', page - 1, page, page + 1, '...', totalPages);
    return pages;
  }, [page, totalPages]);

  const truncate = (text?: string, max = 100) => {
    if (!text) return <span className="text-black/30 dark:text-white/30 italic">Belum ada ringkasan</span>;
    return text.length <= max ? text : `${text.substring(0, max)}…`;
  };
  const formatDate = (d: string) => new Date(`${d}T00:00:00`).toLocaleDateString('id-ID');
  const formatTime = (t: string) => (t || '').slice(0, 5);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Notulensi & Ringkasan Rapat</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">Transkrip otomatis, ringkasan AI lokal, tindak lanjut, dan export notulen</p>
        </div>
        {canWrite && (
          <button type="button" onClick={openCreateModal}
            className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors shadow-sm">
            <i className="ri-add-line text-lg"></i>
            <span>Notulensi Manual</span>
          </button>
        )}
      </div>

      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
        <div className="flex flex-col lg:flex-row gap-3 mb-6">
          <div className="relative flex-1 max-w-sm">
            <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40"></i>
            <input type="text" placeholder="Cari judul rapat..." value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              className="w-full pl-10 pr-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 placeholder:text-black/40 dark:placeholder:text-white/40" />
          </div>
          <select value={filterRoom} onChange={(e) => { setFilterRoom(e.target.value); setPage(1); }} className={`${inputCls} lg:w-48`}>
            <option value="">Semua Ruangan</option>
            {rooms.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
          </select>
          <select value={filterStatus} onChange={(e) => { setFilterStatus(e.target.value as '' | 'draft' | 'final'); setPage(1); }} className={`${inputCls} lg:w-36`}>
            <option value="">Semua Status</option>
            <option value="draft">Draft</option>
            <option value="final">Final</option>
          </select>
          <div className="flex items-center gap-2">
            <input type="date" value={filterDateFrom} onChange={(e) => { setFilterDateFrom(e.target.value); setPage(1); }} className={inputCls} />
            <span className="text-black/40 dark:text-white/40">-</span>
            <input type="date" value={filterDateTo} onChange={(e) => { setFilterDateTo(e.target.value); setPage(1); }} className={inputCls} />
          </div>
        </div>

        {loadError && (
          <div className="mb-4 p-3 rounded-lg bg-danger/10 border border-danger/20 text-danger text-sm flex items-center gap-2">
            <i className="ri-error-warning-line"></i><span className="flex-1">{loadError}</span>
            <button type="button" onClick={fetchData} className="underline">Coba lagi</button>
          </div>
        )}

        <div className="overflow-x-auto -mx-6">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-y border-black/10 dark:border-white/10 text-left text-black/80 dark:text-white/70">
                <th className="py-3 px-6 font-semibold whitespace-nowrap">Judul Rapat</th>
                <th className="py-3 px-4 font-semibold whitespace-nowrap">Ruangan</th>
                <th className="py-3 px-4 font-semibold whitespace-nowrap">Tanggal</th>
                <th className="py-3 px-4 font-semibold whitespace-nowrap">Status</th>
                <th className="py-3 px-4 font-semibold whitespace-nowrap max-w-xs">Ringkasan</th>
                <th className="py-3 px-4 font-semibold whitespace-nowrap text-center">Transkrip</th>
                <th className="py-3 px-4 font-semibold whitespace-nowrap text-center">Tindak Lanjut</th>
                <th className="py-3 px-6 font-semibold whitespace-nowrap text-right">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={8} className="py-12 text-center text-black/50 dark:text-white/50">
                  <i className="ri-loader-4-line animate-spin text-primary mr-2"></i>Memuat data...
                </td></tr>
              ) : items.length === 0 ? (
                <tr><td colSpan={8} className="py-12 text-center text-black/50 dark:text-white/50">
                  <i className="ri-file-text-line text-4xl text-black/30 dark:text-white/30 block mb-2"></i>
                  {loadError ? 'Data tidak dapat dimuat' : 'Belum ada notulensi. Notulensi dibuat otomatis saat rekaman rapat dimulai.'}
                </td></tr>
              ) : (
                items.map((n) => (
                  <tr key={n.id} onClick={() => navigate(`/notes/${n.id}`)}
                    className="border-b border-black/5 dark:border-white/5 hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors cursor-pointer">
                    <td className="py-3 px-6 text-black/80 dark:text-white/80 font-medium">{n.title}</td>
                    <td className="py-3 px-4 text-black/60 dark:text-white/60 whitespace-nowrap">{n.room_name || '-'}</td>
                    <td className="py-3 px-4 text-black/60 dark:text-white/60 whitespace-nowrap">
                      {formatDate(n.date)}<br /><span className="text-xs">{formatTime(n.start_time)} – {formatTime(n.end_time)}</span>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      {n.status === 'final' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-success/10 text-success"><i className="ri-lock-line"></i> Final</span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-warning/10 text-warning">Draft</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-black/60 dark:text-white/60 max-w-xs">{truncate(n.summary)}</td>
                    <td className="py-3 px-4 text-center whitespace-nowrap text-black/60 dark:text-white/60">
                      {n.segment_count ?? 0}
                      {n.transcript_processing && <i className="ri-loader-4-line animate-spin text-info ml-1" title="Sedang ditranskrip"></i>}
                    </td>
                    <td className="py-3 px-4 text-center whitespace-nowrap">
                      <span className="inline-flex px-2.5 py-0.5 rounded-full text-xs font-semibold bg-warning/10 text-warning">{(n.action_items || []).length}</span>
                    </td>
                    <td className="py-3 px-6" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-0.5">
                        <button type="button" onClick={() => navigate(`/notes/${n.id}`)} title="Buka"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-primary hover:bg-primary/10 rounded-lg"><i className="ri-eye-line"></i></button>
                        <button type="button" onClick={() => handleExport(n, 'docx')} title="Unduh DOCX" disabled={!!exporting}
                          className="p-2 text-black/60 dark:text-white/60 hover:text-blue-600 hover:bg-blue-600/10 rounded-lg disabled:opacity-40">
                          <i className={exporting === `${n.id}-docx` ? 'ri-loader-4-line animate-spin' : 'ri-file-word-line'}></i></button>
                        <button type="button" onClick={() => handleExport(n, 'pdf')} title="Unduh PDF" disabled={!!exporting}
                          className="p-2 text-black/60 dark:text-white/60 hover:text-red-600 hover:bg-red-600/10 rounded-lg disabled:opacity-40">
                          <i className={exporting === `${n.id}-pdf` ? 'ri-loader-4-line animate-spin' : 'ri-file-pdf-line'}></i></button>
                        {canWrite && n.status !== 'final' && (
                          <button type="button" onClick={() => setDeleteConfirm(n)} title="Hapus"
                            className="p-2 text-black/60 dark:text-white/60 hover:text-danger hover:bg-danger/10 rounded-lg"><i className="ri-delete-bin-line"></i></button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {totalPages > 0 && (
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-6 pt-4 border-t border-black/10 dark:border-white/10">
            <p className="text-sm text-black/60 dark:text-white/60">Menampilkan {(page - 1) * perPage + 1} - {Math.min(page * perPage, total)} dari {total} data</p>
            <div className="flex items-center gap-1">
              <button type="button" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40"><i className="ri-arrow-left-s-line"></i></button>
              {pageNumbers.map((p, idx) => typeof p === 'number' ? (
                <button key={idx} type="button" onClick={() => setPage(p)}
                  className={`w-9 h-9 rounded-lg text-sm font-medium ${p === page ? 'bg-primary text-white shadow-sm' : 'text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5'}`}>{p}</button>
              ) : (
                <span key={idx} className="w-9 h-9 flex items-center justify-center text-sm text-black/40 dark:text-white/40">{p}</span>
              ))}
              <button type="button" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page === totalPages}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40"><i className="ri-arrow-right-s-line"></i></button>
            </div>
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setShowModal(false)}>
          <div className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-xl max-h-[90vh] overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">Notulensi Manual</h2>
              <button type="button" onClick={() => setShowModal(false)} className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5"><i className="ri-close-line text-xl"></i></button>
            </div>
            <form onSubmit={handleSubmit} className="overflow-y-auto flex-1">
              <div className="px-6 py-5 space-y-4">
                <p className="text-xs text-black/50 dark:text-white/50">
                  Untuk rapat yang dipesan lewat aplikasi, notulensi dibuat otomatis dari halaman Live Meeting.
                  Gunakan formulir ini untuk rapat di luar pemesanan (mis. lalu unggah rekamannya).
                </p>
                {formError && (
                  <div className="p-3 rounded-lg bg-danger/10 border border-danger/20 text-danger text-sm">{formError}</div>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Judul Rapat <span className="text-red-500">*</span></label>
                    <input type="text" required maxLength={200} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className={inputCls} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Ruangan</label>
                    <select value={form.room_id} onChange={(e) => setForm({ ...form, room_id: e.target.value })} className={inputCls}>
                      <option value="">-</option>
                      {rooms.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Tanggal</label>
                    <input type="date" required value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className={inputCls} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Jam Mulai</label>
                    <input type="time" required value={form.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} className={inputCls} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Jam Selesai</label>
                    <input type="time" required value={form.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} className={inputCls} />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Peserta <span className="text-xs text-black/40">(pisahkan dengan koma)</span></label>
                    <input type="text" value={form.participantsText} placeholder="Contoh: Budi, Siti, Andi"
                      onChange={(e) => setForm({ ...form, participantsText: e.target.value })} className={inputCls} />
                  </div>
                </div>
              </div>
              <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex items-center justify-end gap-3">
                <button type="button" onClick={() => setShowModal(false)} disabled={submitting}
                  className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 rounded-lg disabled:opacity-50">Batal</button>
                <button type="submit" disabled={submitting}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg shadow-sm disabled:opacity-50">
                  {submitting && <i className="ri-loader-4-line animate-spin"></i>} Simpan & Buka
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-md overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="px-6 py-5 flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-danger/10 flex items-center justify-center shrink-0">
                <i className="ri-delete-bin-line text-2xl text-danger"></i>
              </div>
              <div>
                <h3 className="text-lg font-bold text-black dark:text-white">Hapus Notulensi</h3>
                <p className="text-sm text-black/60 dark:text-white/60 mt-1">
                  Hapus <span className="font-semibold">{deleteConfirm.title}</span> beserta transkripnya? Tindakan ini tidak dapat dibatalkan.
                </p>
              </div>
            </div>
            <div className="px-6 py-4 bg-black/[0.02] dark:bg-white/[0.02] flex items-center justify-end gap-3">
              <button type="button" onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 rounded-lg">Batal</button>
              <button type="button" onClick={() => handleDelete(deleteConfirm)}
                className="px-4 py-2 text-sm font-medium text-white bg-danger hover:bg-danger/90 rounded-lg shadow-sm">Hapus</button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className={`fixed top-4 right-4 z-[60] max-w-sm rounded-lg shadow-lg p-4 flex items-start gap-3 ${
          toast.type === 'success' ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20' : 'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20'}`}>
          <i className={toast.type === 'success' ? 'ri-check-line text-lg text-green-600' : 'ri-error-warning-line text-lg text-red-600'}></i>
          <p className={`flex-1 text-sm font-medium ${toast.type === 'success' ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>{toast.message}</p>
          <button type="button" onClick={() => setToast(null)} className="text-black/40 hover:text-black/70"><i className="ri-close-line"></i></button>
        </div>
      )}
    </div>
  );
}

export default NotesListPage;
