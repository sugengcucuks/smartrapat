import type { ActionItem, NoteSegment, RecordingStatus } from '@shared/types';
import { getErrorMessage } from '@shared/api/client';

/** Pesan error dari respons API (detail string / {code, message} / validasi). */
export function apiErrorMessage(err: unknown, fallback: string): string {
  return getErrorMessage(err, fallback);
}

/** ms -> "mm:ss" atau "h:mm:ss". */
export function formatMs(ms: number | null | undefined): string {
  const total = Math.max(0, Math.floor((ms ?? 0) / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const mm = String(m).padStart(2, '0');
  const ss = String(s).padStart(2, '0');
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

const SPEAKER_COLORS = [
  'bg-primary/10 text-primary',
  'bg-success/10 text-success',
  'bg-warning/10 text-warning',
  'bg-info/10 text-info',
  'bg-primary/10 text-primary',
  'bg-danger/10 text-danger',
  'bg-black/5 text-black/70 dark:bg-white/10 dark:text-white/80',
  'bg-primary/5 text-black/80 dark:text-white/80',
];

export function speakerColor(name: string | null | undefined): string {
  const s = name || 'Peserta';
  let hash = 0;
  for (let i = 0; i < s.length; i++) hash = s.charCodeAt(i) + ((hash << 5) - hash);
  return SPEAKER_COLORS[Math.abs(hash) % SPEAKER_COLORS.length];
}

export const RECORDING_STATUS_LABEL: Record<RecordingStatus, { label: string; cls: string }> = {
  idle: { label: 'Belum merekam', cls: 'bg-black/5 text-black/60 dark:bg-white/10 dark:text-white/60' },
  recording: { label: 'Merekam', cls: 'bg-danger/10 text-danger' },
  paused: { label: 'Dijeda', cls: 'bg-warning/10 text-warning' },
  stopped: { label: 'Dihentikan', cls: 'bg-black/5 text-black/60 dark:bg-white/10 dark:text-white/60' },
  processing: { label: 'Memproses transkrip', cls: 'bg-info/10 text-info' },
  done: { label: 'Selesai', cls: 'bg-success/10 text-success' },
  failed: { label: 'Gagal', cls: 'bg-danger/10 text-danger' },
  completed: { label: 'Selesai', cls: 'bg-success/10 text-success' },
  error: { label: 'Error', cls: 'bg-danger/10 text-danger' },
};

export const ACTION_STATUS_STYLE: Record<ActionItem['status'], { label: string; cls: string }> = {
  open: { label: 'Terbuka', cls: 'bg-black/5 text-black/70 dark:bg-white/10 dark:text-white/70' },
  pending: { label: 'Terbuka', cls: 'bg-black/5 text-black/70 dark:bg-white/10 dark:text-white/70' },
  in_progress: { label: 'Berjalan', cls: 'bg-info/10 text-info' },
  done: { label: 'Selesai', cls: 'bg-success/10 text-success' },
  completed: { label: 'Selesai', cls: 'bg-success/10 text-success' },
  cancelled: { label: 'Dibatalkan', cls: 'bg-danger/10 text-danger' },
};

/**
 * Urutan segmen: per sesi rekaman (urutan kemunculan rekaman), lalu start_ms.
 * `order` menyimpan indeks rekaman dan diperbarui bila ada rekaman baru.
 */
export function sortSegments(list: NoteSegment[], order: Map<string, number>): NoteSegment[] {
  for (const s of list) {
    const key = s.recording_id || 'manual';
    if (!order.has(key)) order.set(key, order.size);
  }
  return [...list].sort((a, b) => {
    const ra = order.get(a.recording_id || 'manual') ?? 0;
    const rb = order.get(b.recording_id || 'manual') ?? 0;
    if (ra !== rb) return ra - rb;
    if (a.start_ms !== b.start_ms) return a.start_ms - b.start_ms;
    return (a.created_at || '').localeCompare(b.created_at || '');
  });
}

/** Gabungkan segmen baru/terkoreksi (atau hapus bila `deleted`). */
export function upsertSegments(prev: NoteSegment[], incoming: NoteSegment[], order: Map<string, number>): NoteSegment[] {
  if (incoming.length === 0) return prev;
  const map = new Map(prev.map((s) => [s.id, s]));
  for (const s of incoming) {
    if (s.deleted) map.delete(s.id);
    else map.set(s.id, { ...map.get(s.id), ...s });
  }
  return sortSegments([...map.values()], order);
}

/** Pilih mimeType MediaRecorder yang didukung (Chrome/Edge: webm, Firefox: ogg, Safari/iPad: mp4). */
export function pickRecorderMime(): { mime: string; ext: string } | null {
  if (typeof window === 'undefined' || typeof MediaRecorder === 'undefined') return null;
  const candidates: [string, string][] = [
    ['audio/webm;codecs=opus', 'webm'],
    ['audio/ogg;codecs=opus', 'ogg'],
    ['audio/webm', 'webm'],
    ['audio/mp4', 'mp4'],
  ];
  for (const [mime, ext] of candidates) {
    if (MediaRecorder.isTypeSupported?.(mime)) return { mime, ext };
  }
  return { mime: '', ext: 'webm' };
}

export function newUid(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-8xxx-xxxxxxxxxxxx'.replace(/x/g, () => Math.floor(Math.random() * 16).toString(16));
}
