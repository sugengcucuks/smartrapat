import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { authApi } from '@shared/api/auth';
import type { NoteExportFormat } from '@shared/api/auth';
import type {
  ActionItem,
  ActionItemStatus,
  LlmStatus,
  MeetingNote,
  NoteSegment,
  NoteSummaryTopic,
  SttStatus,
} from '@shared/types';
import { ACTION_ITEM_STATUS_OPTIONS } from '@shared/types';
import { useAuthStore } from '../../store/auth.store';
import { LiveTranscriptPanel } from '../../components/live/LiveTranscriptPanel';
import { ACTION_STATUS_STYLE, apiErrorMessage, formatMs, speakerColor } from './noteUtils';

const inputCls =
  'w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80';

interface SummaryDraft {
  ringkasan: string;
  pokok_bahasan: NoteSummaryTopic[];
  keputusan: string[];
}

function draftFromNote(n: MeetingNote): SummaryDraft {
  const sj = n.summary_json ?? {};
  return {
    ringkasan: sj.ringkasan ?? n.summary ?? '',
    pokok_bahasan: (sj.pokok_bahasan ?? []).map((p) => ({ judul: p.judul ?? '', uraian: p.uraian ?? '' })),
    keputusan: [...(sj.keputusan ?? n.decisions ?? [])],
  };
}

function hasPerm(perms: string[] | undefined, code: string): boolean {
  return !!perms && (perms.includes('*') || perms.includes(code));
}

export function NoteDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const user = useAuthStore((s) => s.user);
  const [note, setNote] = useState<MeetingNote | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [stt, setStt] = useState<SttStatus | null>(null);
  const [llm, setLlm] = useState<LlmStatus | null>(null);
  const [draft, setDraft] = useState<SummaryDraft>({ ringkasan: '', pokok_bahasan: [], keputusan: [] });
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [includeTranscript, setIncludeTranscript] = useState(false);
  const [newItem, setNewItem] = useState<{ task: string; owner: string; due_date: string }>({ task: '', owner: '', due_date: '' });
  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    window.setTimeout(() => setToast(null), type === 'error' ? 7000 : 3500);
  };

  const applyNote = useCallback((n: MeetingNote) => {
    setNote(n);
    setDraft(draftFromNote(n));
    setDirty(false);
  }, []);

  const fetchDetail = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setLoadError(null);
    try {
      applyNote(await authApi.getNoteDetail(id));
    } catch (err) {
      setLoadError(apiErrorMessage(err, 'Gagal memuat notulensi'));
    } finally {
      setLoading(false);
    }
  }, [id, applyNote]);

  useEffect(() => {
    fetchDetail();
    authApi.getSttStatus().then(setStt).catch(() => undefined);
    authApi.getLlmStatus().then(setLlm).catch(() => undefined);
  }, [fetchDetail]);

  const canWrite = hasPerm(user?.permissions, 'notes.write');
  const canEdit = !!note && (canWrite || note.created_by === user?.id);
  const isFinal = note?.status === 'final';
  const editable = canEdit && !isFinal;

  const run = async (key: string, fn: () => Promise<void>, fallback: string) => {
    setBusy(key);
    try {
      await fn();
    } catch (err) {
      showToast('error', apiErrorMessage(err, fallback));
    } finally {
      setBusy(null);
    }
  };

  const handleSummarize = () => {
    if (!note) return;
    if (dirty && !window.confirm('Perubahan ringkasan yang belum disimpan akan diganti hasil AI. Lanjutkan?')) return;
    run('summarize', async () => {
      applyNote(await authApi.summarizeNote(note.id));
      showToast('success', 'Ringkasan AI selesai dibuat. Periksa & koreksi sebelum finalisasi.');
    }, 'Gagal membuat ringkasan AI');
  };

  const handleSaveSummary = () => {
    if (!note) return;
    run('save', async () => {
      const cleaned = {
        ringkasan: draft.ringkasan.trim(),
        pokok_bahasan: draft.pokok_bahasan.filter((p) => p.judul.trim() || p.uraian.trim()),
        keputusan: draft.keputusan.map((k) => k.trim()).filter(Boolean),
      };
      applyNote(await authApi.updateNote(note.id, { summary_json: cleaned }));
      showToast('success', 'Ringkasan disimpan');
    }, 'Gagal menyimpan ringkasan');
  };

  const handleFinalize = () => {
    if (!note) return;
    if (dirty) {
      showToast('error', 'Simpan perubahan ringkasan terlebih dahulu');
      return;
    }
    if (!window.confirm('Finalisasi notulensi? Setelah final, isi tidak dapat diubah kecuali dibuka kembali.')) return;
    run('finalize', async () => {
      applyNote(await authApi.finalizeNote(note.id));
      showToast('success', 'Notulensi difinalisasi');
    }, 'Gagal memfinalisasi');
  };

  const handleReopen = () => {
    if (!note) return;
    run('reopen', async () => {
      applyNote(await authApi.reopenNote(note.id));
      showToast('success', 'Notulensi dibuka kembali (draft)');
    }, 'Gagal membuka kembali notulensi');
  };

  const handleExport = (fmt: NoteExportFormat) => {
    if (!note) return;
    run(`export-${fmt}`, async () => {
      await authApi.exportNote(note.id, fmt, includeTranscript);
    }, `Gagal mengunduh ${fmt.toUpperCase()}`);
  };

  // --- action items ---
  const replaceItem = (item: ActionItem) =>
    setNote((n) => (n ? { ...n, action_items: n.action_items.map((a) => (a.id === item.id ? item : a)) } : n));

  const updateItem = (item: ActionItem, patch: Partial<ActionItem>) => {
    if (!note || !item.id) return;
    run(`item-${item.id}`, async () => {
      replaceItem(await authApi.updateNoteActionItem(note.id, item.id!, patch));
    }, 'Gagal memperbarui action item');
  };

  const deleteItem = (item: ActionItem) => {
    if (!note || !item.id || !window.confirm(`Hapus action item "${item.task}"?`)) return;
    run(`item-${item.id}`, async () => {
      await authApi.deleteNoteActionItem(note.id, item.id!);
      setNote((n) => (n ? { ...n, action_items: n.action_items.filter((a) => a.id !== item.id) } : n));
    }, 'Gagal menghapus action item');
  };

  const addItem = () => {
    if (!note || !newItem.task.trim()) return;
    run('item-new', async () => {
      const created = await authApi.addNoteActionItem(note.id, {
        task: newItem.task.trim(),
        owner: newItem.owner.trim() || null,
        due_date: newItem.due_date || null,
        status: 'open',
      });
      setNote((n) => (n ? { ...n, action_items: [...n.action_items, created] } : n));
      setNewItem({ task: '', owner: '', due_date: '' });
    }, 'Gagal menambah action item');
  };

  const setDraftField = (patch: Partial<SummaryDraft>) => {
    setDraft((d) => ({ ...d, ...patch }));
    setDirty(true);
  };

  const formatDate = (d: string) =>
    new Date(`${d}T00:00:00`).toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const formatTime = (t: string) => (t || '').slice(0, 5);
  const formatDateTime = (s?: string | null) => (s ? new Date(s).toLocaleString('id-ID') : '-');

  const sttBadge = useMemo(() => {
    if (!stt) return null;
    if (!stt.engine_available) return { cls: 'bg-danger/10 text-danger', label: 'STT tidak tersedia', title: stt.engine_error ?? '' };
    if (stt.last_error) return { cls: 'bg-warning/10 text-warning', label: `STT ${stt.model}`, title: `Error terakhir: ${stt.last_error}` };
    return { cls: 'bg-success/10 text-success', label: `STT ${stt.model} (${stt.device})`, title: `Antrean: ${stt.queue_size}` };
  }, [stt]);
  const llmBadge = useMemo(() => {
    if (!llm) return null;
    if (!llm.reachable) return { cls: 'bg-danger/10 text-danger', label: 'AI (Ollama) offline', title: llm.error ?? '' };
    if (!llm.model_available) return { cls: 'bg-warning/10 text-warning', label: `Model ${llm.model} belum diunduh`, title: `Jalankan: ollama pull ${llm.model}` };
    return { cls: 'bg-success/10 text-success', label: `AI ${llm.model}`, title: llm.base_url };
  }, [llm]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24 text-black/50 dark:text-white/50 gap-2">
        <i className="ri-loader-4-line animate-spin text-xl text-primary"></i> Memuat notulensi…
      </div>
    );
  }

  if (loadError || !note) {
    return (
      <div className="flex flex-col items-center justify-center py-24 gap-3 text-black/60 dark:text-white/60">
        <i className="ri-file-warning-line text-4xl"></i>
        <p>{loadError ?? 'Notulensi tidak ditemukan'}</p>
        <div className="flex gap-2">
          <button type="button" onClick={() => navigate('/notes')} className="px-4 py-2 text-sm rounded-lg bg-black/5 dark:bg-white/10">Kembali</button>
          <button type="button" onClick={fetchDetail} className="px-4 py-2 text-sm rounded-lg bg-primary text-white">Coba lagi</button>
        </div>
      </div>
    );
  }

  const aiItems = note.action_items.filter((a) => a.source === 'ai').length;
  const peserta = note.summary_json?.peserta_aktif ?? [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
        <div className="min-w-0">
          <button type="button" onClick={() => navigate('/notes')} className="text-sm text-black/50 dark:text-white/50 hover:text-primary mb-1 inline-flex items-center gap-1">
            <i className="ri-arrow-left-line"></i> Daftar notulensi
          </button>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-2xl font-bold text-black dark:text-white break-words">{note.title}</h1>
            {isFinal ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-success/10 text-success"><i className="ri-lock-line"></i> Final</span>
            ) : (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-warning/10 text-warning">Draft</span>
            )}
          </div>
          <div className="flex flex-wrap gap-2 mt-2">
            {sttBadge && <span title={sttBadge.title} className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${sttBadge.cls}`}><i className="ri-mic-2-line"></i> {sttBadge.label}</span>}
            {llmBadge && <span title={llmBadge.title} className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${llmBadge.cls}`}><i className="ri-sparkling-2-line"></i> {llmBadge.label}</span>}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {editable && (
            <button type="button" onClick={handleSummarize} disabled={!!busy || (note.segment_count ?? 0) === 0}
              title={(note.segment_count ?? 0) === 0 ? 'Belum ada transkrip' : 'Ringkas transkrip dengan AI lokal'}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg bg-primary text-white hover:bg-primary/90 disabled:opacity-50">
              {busy === 'summarize' ? <i className="ri-loader-4-line animate-spin"></i> : <i className="ri-sparkling-2-line"></i>}
              {busy === 'summarize' ? 'Meringkas… (bisa beberapa menit)' : note.summary_json ? 'Ringkas Ulang dengan AI' : 'Ringkas dengan AI'}
            </button>
          )}
          {canEdit && !isFinal && (
            <button type="button" onClick={handleFinalize} disabled={!!busy}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg bg-success text-white hover:bg-success/90 disabled:opacity-50">
              <i className="ri-checkbox-circle-line"></i> Finalisasi
            </button>
          )}
          {isFinal && canWrite && (
            <button type="button" onClick={handleReopen} disabled={!!busy}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg bg-black/5 dark:bg-white/10 text-black/70 dark:text-white/80 hover:bg-black/10 disabled:opacity-50">
              <i className="ri-lock-unlock-line"></i> Buka Kembali
            </button>
          )}
          <div className="flex items-center gap-1 rounded-lg border border-black/10 dark:border-white/10 p-1">
            <button type="button" onClick={() => handleExport('pdf')} disabled={!!busy}
              className="inline-flex items-center gap-1 px-3 py-1.5 text-sm rounded-md text-red-600 hover:bg-red-600/10 disabled:opacity-50">
              {busy === 'export-pdf' ? <i className="ri-loader-4-line animate-spin"></i> : <i className="ri-file-pdf-line"></i>} PDF
            </button>
            <button type="button" onClick={() => handleExport('docx')} disabled={!!busy}
              className="inline-flex items-center gap-1 px-3 py-1.5 text-sm rounded-md text-blue-600 hover:bg-blue-600/10 disabled:opacity-50">
              {busy === 'export-docx' ? <i className="ri-loader-4-line animate-spin"></i> : <i className="ri-file-word-line"></i>} DOCX
            </button>
            <label className="inline-flex items-center gap-1 px-2 text-xs text-black/60 dark:text-white/60 cursor-pointer" title="Lampirkan transkrip lengkap">
              <input type="checkbox" checked={includeTranscript} onChange={(e) => setIncludeTranscript(e.target.checked)} /> + transkrip
            </label>
          </div>
        </div>
      </div>

      {/* Metadata */}
      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
        <Meta label="Hari / Tanggal" value={formatDate(note.date)} icon="ri-calendar-line" />
        <Meta label="Waktu" value={`${formatTime(note.start_time)} – ${formatTime(note.end_time)}`} icon="ri-time-line" />
        <Meta label="Ruangan" value={note.room_name || '-'} icon="ri-door-open-line" />
        <Meta label="Notulis" value={note.created_by_name || '-'} icon="ri-user-line" />
        {note.booking_title && <Meta label="Booking" value={note.booking_title} icon="ri-bookmark-line" />}
        <Meta label="Transkrip" value={`${note.segment_count ?? 0} segmen${note.transcript_processing ? ' (sedang diproses)' : ''}`} icon="ri-chat-voice-line" />
        {note.generated_at && <Meta label="Ringkasan AI" value={`${note.ai_model ?? '-'} · ${formatDateTime(note.generated_at)}`} icon="ri-sparkling-2-line" />}
        {isFinal && <Meta label="Difinalisasi" value={`${note.finalized_by_name ?? '-'} · ${formatDateTime(note.finalized_at)}`} icon="ri-lock-line" />}
        <div className="sm:col-span-2 lg:col-span-4">
          <p className="text-xs text-black/50 dark:text-white/50 mb-1">Peserta</p>
          <div className="flex flex-wrap gap-1.5">
            {note.participants.length === 0 && <span className="text-black/40 dark:text-white/40">-</span>}
            {note.participants.map((p, i) => (
              <span key={i} className="px-2 py-0.5 rounded-full text-xs bg-primary/10 text-primary">{p}</span>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Ringkasan */}
        <div className="xl:col-span-2 space-y-6">
          <div className="bg-white dark:bg-gray rounded-lg shadow-md p-5 space-y-5">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-semibold text-black dark:text-white flex items-center gap-2"><i className="ri-file-text-line text-primary"></i> Ringkasan & Keputusan</h2>
              {editable && (
                <button type="button" onClick={handleSaveSummary} disabled={!dirty || !!busy}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium rounded-lg bg-primary text-white hover:bg-primary/90 disabled:opacity-40">
                  {busy === 'save' ? <i className="ri-loader-4-line animate-spin"></i> : <i className="ri-save-line"></i>} Simpan
                </button>
              )}
            </div>
            {!note.summary_json && !note.summary && (
              <p className="text-sm text-black/50 dark:text-white/50">
                Belum ada ringkasan. {editable ? 'Klik "Ringkas dengan AI" setelah transkrip tersedia, atau tulis manual di bawah.' : ''}
              </p>
            )}

            <section>
              <label className="block text-xs font-semibold uppercase tracking-wide text-black/50 dark:text-white/50 mb-1.5">Ringkasan</label>
              {editable ? (
                <textarea rows={8} value={draft.ringkasan} onChange={(e) => setDraftField({ ringkasan: e.target.value })} className={inputCls}
                  placeholder="Ringkasan jalannya rapat (pisahkan paragraf dengan baris kosong)" />
              ) : (
                <div className="text-sm text-black/80 dark:text-white/80 whitespace-pre-wrap leading-relaxed">{draft.ringkasan || '-'}</div>
              )}
            </section>

            <section>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold uppercase tracking-wide text-black/50 dark:text-white/50">Pokok Bahasan</label>
                {editable && (
                  <button type="button" onClick={() => setDraftField({ pokok_bahasan: [...draft.pokok_bahasan, { judul: '', uraian: '' }] })}
                    className="text-xs text-primary hover:underline"><i className="ri-add-line"></i> Tambah</button>
                )}
              </div>
              {draft.pokok_bahasan.length === 0 && <p className="text-sm text-black/40 dark:text-white/40">-</p>}
              <ol className="space-y-3">
                {draft.pokok_bahasan.map((p, i) => (
                  <li key={i} className="flex gap-2">
                    <span className="text-sm text-black/40 dark:text-white/40 pt-2 w-5">{i + 1}.</span>
                    {editable ? (
                      <div className="flex-1 space-y-1.5">
                        <input value={p.judul} placeholder="Judul" className={inputCls}
                          onChange={(e) => setDraftField({ pokok_bahasan: draft.pokok_bahasan.map((x, j) => (j === i ? { ...x, judul: e.target.value } : x)) })} />
                        <textarea rows={2} value={p.uraian} placeholder="Uraian" className={inputCls}
                          onChange={(e) => setDraftField({ pokok_bahasan: draft.pokok_bahasan.map((x, j) => (j === i ? { ...x, uraian: e.target.value } : x)) })} />
                      </div>
                    ) : (
                      <div className="flex-1 text-sm">
                        <p className="font-medium text-black/80 dark:text-white/80">{p.judul}</p>
                        <p className="text-black/60 dark:text-white/60 whitespace-pre-wrap">{p.uraian}</p>
                      </div>
                    )}
                    {editable && (
                      <button type="button" title="Hapus" onClick={() => setDraftField({ pokok_bahasan: draft.pokok_bahasan.filter((_, j) => j !== i) })}
                        className="p-1.5 h-fit rounded text-black/40 hover:text-danger hover:bg-danger/10"><i className="ri-delete-bin-line"></i></button>
                    )}
                  </li>
                ))}
              </ol>
            </section>

            <section>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold uppercase tracking-wide text-black/50 dark:text-white/50">Keputusan</label>
                {editable && (
                  <button type="button" onClick={() => setDraftField({ keputusan: [...draft.keputusan, ''] })}
                    className="text-xs text-primary hover:underline"><i className="ri-add-line"></i> Tambah</button>
                )}
              </div>
              {draft.keputusan.length === 0 && <p className="text-sm text-black/40 dark:text-white/40">-</p>}
              <ol className="space-y-2">
                {draft.keputusan.map((k, i) => (
                  <li key={i} className="flex gap-2 items-start">
                    <span className="text-sm text-black/40 dark:text-white/40 pt-2 w-5">{i + 1}.</span>
                    {editable ? (
                      <textarea rows={1} value={k} className={inputCls}
                        onChange={(e) => setDraftField({ keputusan: draft.keputusan.map((x, j) => (j === i ? e.target.value : x)) })} />
                    ) : (
                      <p className="flex-1 text-sm text-black/80 dark:text-white/80 pt-1.5">{k}</p>
                    )}
                    {editable && (
                      <button type="button" title="Hapus" onClick={() => setDraftField({ keputusan: draft.keputusan.filter((_, j) => j !== i) })}
                        className="p-1.5 rounded text-black/40 hover:text-danger hover:bg-danger/10"><i className="ri-delete-bin-line"></i></button>
                    )}
                  </li>
                ))}
              </ol>
            </section>

            {peserta.length > 0 && (
              <section>
                <label className="block text-xs font-semibold uppercase tracking-wide text-black/50 dark:text-white/50 mb-1.5">Peserta aktif berbicara</label>
                <div className="flex flex-wrap gap-1.5">
                  {peserta.map((p) => <span key={p} className={`px-2 py-0.5 rounded-full text-xs ${speakerColor(p)}`}>{p}</span>)}
                </div>
              </section>
            )}
          </div>

          {/* Action items */}
          <div className="bg-white dark:bg-gray rounded-lg shadow-md p-5">
            <h2 className="font-semibold text-black dark:text-white flex items-center gap-2 mb-3">
              <i className="ri-task-line text-primary"></i> Tindak Lanjut
              <span className="text-xs font-normal text-black/40 dark:text-white/40">({note.action_items.length}{aiItems ? `, ${aiItems} dari AI` : ''})</span>
            </h2>
            <div className="overflow-x-auto -mx-5">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-y border-black/10 dark:border-white/10 text-left text-black/70 dark:text-white/70">
                    <th className="py-2 px-5 font-semibold">Tugas</th>
                    <th className="py-2 px-3 font-semibold">PIC</th>
                    <th className="py-2 px-3 font-semibold">Tenggat</th>
                    <th className="py-2 px-3 font-semibold">Status</th>
                    <th className="py-2 px-5"></th>
                  </tr>
                </thead>
                <tbody>
                  {note.action_items.length === 0 && (
                    <tr><td colSpan={5} className="py-6 text-center text-black/40 dark:text-white/40">Belum ada tindak lanjut</td></tr>
                  )}
                  {note.action_items.map((a) => (
                    <ActionRow key={a.id} item={a} editable={editable} busy={busy === `item-${a.id}`}
                      onChange={(patch) => updateItem(a, patch)} onDelete={() => deleteItem(a)} />
                  ))}
                  {editable && (
                    <tr className="border-t border-black/5 dark:border-white/5">
                      <td className="py-2 px-5"><input value={newItem.task} placeholder="Tugas baru…" className={inputCls}
                        onChange={(e) => setNewItem({ ...newItem, task: e.target.value })}
                        onKeyDown={(e) => { if (e.key === 'Enter') addItem(); }} /></td>
                      <td className="py-2 px-3"><input value={newItem.owner} placeholder="PIC" className={inputCls}
                        onChange={(e) => setNewItem({ ...newItem, owner: e.target.value })} /></td>
                      <td className="py-2 px-3"><input type="date" value={newItem.due_date} className={inputCls}
                        onChange={(e) => setNewItem({ ...newItem, due_date: e.target.value })} /></td>
                      <td className="py-2 px-3" colSpan={2}>
                        <button type="button" onClick={addItem} disabled={!newItem.task.trim() || !!busy}
                          className="inline-flex items-center gap-1 px-3 py-2 text-sm font-medium rounded-lg bg-primary text-white hover:bg-primary/90 disabled:opacity-40">
                          <i className="ri-add-line"></i> Tambah
                        </button>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Transkrip */}
        <div className="xl:col-span-1">
          {note.booking_id ? (
            <LiveTranscriptPanel
              bookingId={note.booking_id}
              roomId={note.room_id}
              canEdit={canEdit}
              maxHeight="42rem"
              onSegmentCountChange={(count) =>
                setNote((cur) => (cur && cur.segment_count !== count ? { ...cur, segment_count: count } : cur))
              }
            />
          ) : (
            <StandaloneTranscript note={note} canEdit={editable} onChanged={fetchDetail} />
          )}
        </div>
      </div>

      {toast && (
        <div className={`fixed top-4 right-4 z-[60] max-w-sm rounded-lg shadow-lg p-4 flex items-start gap-3 ${
          toast.type === 'success' ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20' : 'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20'}`}>
          <i className={toast.type === 'success' ? 'ri-check-line text-lg text-green-600' : 'ri-error-warning-line text-lg text-red-600'}></i>
          <p className={`flex-1 text-sm font-medium ${toast.type === 'success' ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>{toast.message}</p>
          <button type="button" onClick={() => setToast(null)} className="text-black/40 hover:text-black/70"><i className="ri-close-line"></i></button>
        </div>
      )}
    </div>
  );
}

function Meta({ label, value, icon }: { label: string; value: string; icon: string }) {
  return (
    <div className="flex gap-2">
      <i className={`${icon} text-black/40 dark:text-white/40 mt-0.5`}></i>
      <div className="min-w-0">
        <p className="text-xs text-black/50 dark:text-white/50">{label}</p>
        <p className="font-medium text-black/80 dark:text-white/80 break-words">{value}</p>
      </div>
    </div>
  );
}

function ActionRow({ item, editable, busy, onChange, onDelete }: {
  item: ActionItem;
  editable: boolean;
  busy: boolean;
  onChange: (patch: Partial<ActionItem>) => void;
  onDelete: () => void;
}) {
  const [task, setTask] = useState(item.task);
  const [owner, setOwner] = useState(item.owner ?? '');
  useEffect(() => { setTask(item.task); setOwner(item.owner ?? ''); }, [item.task, item.owner]);
  const style = ACTION_STATUS_STYLE[item.status] ?? ACTION_STATUS_STYLE.open;
  const cell = 'px-2 py-1.5 text-sm bg-transparent border border-transparent hover:border-black/10 focus:border-primary rounded outline-none w-full dark:text-white/80';
  return (
    <tr className="border-b border-black/5 dark:border-white/5 align-top">
      <td className="py-2 px-5">
        <div className="flex items-start gap-1.5">
          {item.source === 'ai' && <span title="Dari ringkasan AI" className="mt-1.5 text-[10px] px-1.5 rounded bg-primary/10 text-primary">AI</span>}
          {editable ? (
            <input value={task} className={cell} onChange={(e) => setTask(e.target.value)}
              onBlur={() => { if (task.trim() && task !== item.task) onChange({ task: task.trim() }); }} />
          ) : <span className="py-1.5 text-black/80 dark:text-white/80">{item.task}</span>}
        </div>
      </td>
      <td className="py-2 px-3 min-w-[8rem]">
        {editable ? (
          <input value={owner} placeholder="-" className={cell} onChange={(e) => setOwner(e.target.value)}
            onBlur={() => { if (owner !== (item.owner ?? '')) onChange({ owner: owner.trim() || null }); }} />
        ) : <span className="text-black/70 dark:text-white/70">{item.owner || '-'}</span>}
      </td>
      <td className="py-2 px-3 min-w-[9rem]">
        {editable ? (
          <input type="date" value={item.due_date ?? ''} className={cell} onChange={(e) => onChange({ due_date: e.target.value || null })} />
        ) : <span className="text-black/70 dark:text-white/70">{item.due_date ? new Date(`${item.due_date}T00:00:00`).toLocaleDateString('id-ID') : '-'}</span>}
      </td>
      <td className="py-2 px-3">
        {editable ? (
          <select value={item.status === 'pending' ? 'open' : item.status === 'completed' ? 'done' : item.status}
            onChange={(e) => onChange({ status: e.target.value as ActionItemStatus })}
            className={`px-2 py-1 rounded-full text-xs font-medium border-0 outline-none ${style.cls}`}>
            {ACTION_ITEM_STATUS_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        ) : <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${style.cls}`}>{style.label}</span>}
      </td>
      <td className="py-2 px-5 text-right">
        {busy ? <i className="ri-loader-4-line animate-spin text-black/40"></i> : editable && (
          <button type="button" title="Hapus" onClick={onDelete} className="p-1.5 rounded text-black/40 hover:text-danger hover:bg-danger/10">
            <i className="ri-delete-bin-line"></i>
          </button>
        )}
      </td>
    </tr>
  );
}

/** Transkrip untuk notulen tanpa booking: daftar segmen + unggah rekaman. */
function StandaloneTranscript({ note, canEdit, onChanged }: { note: MeetingNote; canEdit: boolean; onChanged: () => void }) {
  const [segments, setSegments] = useState<NoteSegment[]>([]);
  const [processing, setProcessing] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const res = await authApi.listNoteSegments(note.id);
      setSegments(res.items);
      setProcessing(res.transcript_processing);
      return res.transcript_processing;
    } catch (err) {
      setError(apiErrorMessage(err, 'Gagal memuat transkrip'));
      return false;
    }
  }, [note.id]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    if (!processing) return;
    const t = window.setInterval(async () => {
      const still = await load();
      if (!still) onChanged();
    }, 3000);
    return () => window.clearInterval(t);
  }, [processing, load, onChanged]);

  const upload = async (file: File | null) => {
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      const fd = new FormData();
      fd.append('audio_file', file);
      await authApi.transcribeAudio(note.id, fd);
      setProcessing(true);
    } catch (err) {
      setError(apiErrorMessage(err, 'Gagal mengunggah rekaman'));
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="bg-white dark:bg-gray rounded-lg shadow-md">
      <div className="px-4 py-3 border-b border-black/10 dark:border-white/10 flex items-center gap-2">
        <h3 className="font-semibold text-black dark:text-white flex items-center gap-2"><i className="ri-mic-line text-primary"></i> Transkrip</h3>
        {processing && <span className="text-xs text-info inline-flex items-center gap-1"><i className="ri-loader-4-line animate-spin"></i> Mentranskrip…</span>}
        {canEdit && (
          <label className={`ml-auto inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium rounded-lg bg-primary text-white hover:bg-primary/90 cursor-pointer ${uploading ? 'opacity-50 pointer-events-none' : ''}`}>
            {uploading ? <i className="ri-loader-4-line animate-spin"></i> : <i className="ri-upload-2-line"></i>} Unggah rekaman
            <input type="file" className="hidden" accept="audio/*,.wav,.mp3,.m4a,.ogg,.opus,.webm,.flac,.mp4,.aac"
              onChange={(e) => upload(e.target.files?.[0] ?? null)} />
          </label>
        )}
      </div>
      {error && <p className="mx-4 mt-3 text-xs text-red-600">{error}</p>}
      <div className="p-4 space-y-3 max-h-[42rem] overflow-y-auto">
        {segments.length === 0 ? (
          <p className="py-8 text-center text-sm text-black/40 dark:text-white/40">Belum ada transkrip.</p>
        ) : segments.map((s) => (
          <div key={s.id} className="flex gap-3">
            <span className="text-[11px] font-mono text-black/40 dark:text-white/40 w-12 text-right pt-0.5">{formatMs(s.start_ms)}</span>
            <div className="flex-1">
              <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${speakerColor(s.speaker_name)}`}>{s.speaker_name || 'Peserta'}</span>
              <p className="text-sm text-black/80 dark:text-white/80 mt-0.5 whitespace-pre-wrap">{s.text}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default NoteDetailPage;
