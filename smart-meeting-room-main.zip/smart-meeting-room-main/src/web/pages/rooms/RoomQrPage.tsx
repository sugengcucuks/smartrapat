import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import QRCode from 'qrcode';
import { authApi } from '../../../shared/api/auth';
import { getErrorMessage } from '../../../shared/api/client';
import type { Room } from '@shared/types';

function useRoomByCode(code: string | undefined) {
  const [room, setRoom] = useState<Room | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!code) return;
    let cancelled = false;
    setError(null);
    // Backend belum punya GET /rooms/by-code: cari lewat filter `search` lalu cocokkan kode persis.
    authApi
      .findRoomByCode(code)
      .then((found) => {
        if (cancelled) return;
        if (!found) {
          setError('Ruangan tidak ditemukan');
          return;
        }
        setRoom(found);
      })
      .catch((err) => {
        if (!cancelled) setError(getErrorMessage(err, 'Gagal memuat data ruangan'));
      });
    return () => {
      cancelled = true;
    };
  }, [code]);

  return { room, error };
}

function useQrDataUrl(value: string | null, size = 360) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    if (!value) {
      setUrl(null);
      return;
    }
    QRCode.toDataURL(value, {
      width: size,
      margin: 2,
      color: { dark: '#0f172a', light: '#ffffff' },
      errorCorrectionLevel: 'M',
    })
      .then(setUrl)
      .catch(() => setUrl(null));
  }, [value, size]);
  return url;
}

function QrCard({ title, subtitle, url, qr }: { title: string; subtitle: string; url: string; qr: string | null }) {
  return (
    <div className="bg-white border border-black/10 dark:border-white/10 rounded-2xl p-6 flex flex-col items-center text-center shadow-sm">
      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-semibold uppercase tracking-wide">
        {title}
      </span>
      <p className="mt-2 text-sm text-black/60 dark:text-white/60">{subtitle}</p>
      <div className="mt-4 p-3 bg-white rounded-xl border border-black/10">
        {qr ? (
          <img src={qr} alt={`QR ${title}`} className="w-56 h-56" />
        ) : (
          <div className="w-56 h-56 flex items-center justify-center text-black/40 dark:text-white/40 text-sm">
            Membuat QR...
          </div>
        )}
      </div>
      <p className="mt-3 text-xs text-black/50 dark:text-white/50 break-all max-w-60">{url}</p>
    </div>
  );
}

export function RoomQrPage() {
  const { room_code } = useParams<{ room_code: string }>();
  const navigate = useNavigate();
  const { room, error } = useRoomByCode(room_code);

  const baseUrl = `${window.location.protocol}//${window.location.host}`;
  const controlUrl = room ? `${baseUrl}/m/room/${room.code}` : null;
  const displayUrl = room ? `${baseUrl}/public/display/${room.code}` : null;
  const controlQr = useQrDataUrl(controlUrl);
  const displayQr = useQrDataUrl(displayUrl);

  if (error) {
    return (
      <div className="p-8 text-center">
        <p className="text-danger mb-4">{error}</p>
        <button
          onClick={() => navigate('/rooms')}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors"
        >
          Kembali
        </button>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6 print:hidden">
          <div>
            <h1 className="text-xl md:text-2xl font-bold text-black dark:text-white">
              QR Ruangan {room ? `- ${room.name}` : ''}
            </h1>
            <p className="text-sm text-black/60 dark:text-white/60 mt-1">
              Cetak dan tempel di depan ruangan. Scan untuk kontrol mobile atau buka door display.
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => navigate('/rooms')}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors"
            >
              Kembali
            </button>
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors shadow-sm"
            >
              <i className="ri-printer-line"></i>
              Cetak
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <QrCard
            title="Kontrol Mobile"
            subtitle="Scan untuk membuka panel kontrol ruangan ini di HP (butuh login)"
            url={controlUrl || ''}
            qr={controlQr}
          />
          <QrCard
            title="Door Display"
            subtitle="Scan untuk membuka layar status ruangan (untuk tablet di depan ruangan)"
            url={displayUrl || ''}
            qr={displayQr}
          />
        </div>

        {room && (
          <div className="mt-6 text-center text-xs text-black/50 dark:text-white/50 print:hidden">
            Kode ruangan: <span className="font-semibold">{room.code}</span>
            {room.building_name ? ` · ${room.building_name}` : ''}
            {room.floor != null ? ` · Lantai ${room.floor}` : ''}
          </div>
        )}
      </div>
    </div>
  );
}
