// Editor denah kursi & pemetaan mic ruangan.
// Kursi diseret di kanvas 16:10 (snap 1%), tiap kursi dipetakan ke satu kanal mic
// (mis. "Mic 3 · M118-A CH3"). Disimpan batch via PUT /rooms/{id}/seats.
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { authApi, liveMeetingApi } from '@shared/api/auth';
import { getErrorMessage } from '@shared/api/client';
import type { AudioChannel, RoomSeatInput, RoomSeatMap, SeatLayoutShape, SeatLayoutType, SeatType } from '@shared/types';
import { useAuthStore, userHasPermission } from '../../store/auth.store';
import { SeatMap, SeatLegend } from '../../components/live/SeatMap';
import type { SeatMapSeat } from '../../components/live/SeatMap';
import { SEAT_TYPES, channelLabel, seatTypeMeta } from '../../components/live/liveUtils';
import { AudioChannelEditor } from '../../components/av';

interface EditSeat extends SeatMapSeat {
  audio_channel_id: string | null;
  isNew?: boolean;
}

const LAYOUTS: { value: SeatLayoutType; label: string; hint: string; icon: string }[] = [
  { value: 'u_shape', label: 'Huruf U', hint: 'Pimpinan di alas U, terbuka ke layar', icon: 'ri-layout-bottom-2-line' },
  { value: 'boardroom', label: 'Boardroom', hint: 'Meja panjang, pimpinan di ujung', icon: 'ri-layout-row-line' },
  { value: 'classroom', label: 'Kelas', hint: 'Baris menghadap meja pimpinan', icon: 'ri-layout-grid-line' },
  { value: 'circle', label: 'Melingkar', hint: 'Meja bundar/oval', icon: 'ri-donut-chart-line' },
];

const inputCls =
  'w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary dark:text-white/80';

let tempSeq = 0;

function toEditSeats(map: RoomSeatMap): EditSeat[] {
  return map.seats.map((s) => ({ ...s, audio_channel_id: s.audio_channel_id }));
}

export function RoomLayoutPage() {
  const { roomId } = useParams<{ roomId: string }>();
  const navigate = useNavigate();
  const user = useAuthStore((s) => s.user);
  const canEdit = userHasPermission(user, 'rooms.write');

  const [map, setMap] = useState<RoomSeatMap | null>(null);
  const [seats, setSeats] = useState<EditSeat[]>([]);
  const [layout, setLayout] = useState<SeatLayoutShape | null>(null);
  const [channels, setChannels] = useState<AudioChannel[]>([]);
  const [channelsNote, setChannelsNote] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [dirty, setDirty] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [genOpen, setGenOpen] = useState(false);
  const [channelsOpen, setChannelsOpen] = useState(false);
  const [gen, setGen] = useState({ layout: 'u_shape' as SeatLayoutType, count: 16, chair_count: 1, link_channels: true });

  const applyMap = useCallback((m: RoomSeatMap, extraChannels?: AudioChannel[] | null) => {
    setMap(m);
    setSeats(toEditSeats(m));
    setLayout(m.layout);
    const chs = extraChannels && extraChannels.length ? extraChannels : m.audio_channels;
    setChannels([...chs].sort((a, b) => a.channel_no - b.channel_no));
    setDirty(false);
  }, []);

  const load = useCallback(async () => {
    if (!roomId) return;
    setLoading(true);
    setLoadError(null);
    try {
      const m = await liveMeetingApi.getRoomSeats(roomId);
      let extra: AudioChannel[] | null = null;
      try {
        extra = await authApi.listAudioChannels(roomId);
        setChannelsNote(null);
      } catch (err) {
        const status = (err as { response?: { status?: number } })?.response?.status;
        extra = null;
        setChannelsNote(status === 404 || status === 405 ? 'Kanal mic belum dikonfigurasi' : null);
      }
      applyMap(m, extra);
      setGen((g) => ({ ...g, count: Math.min(64, Math.max(1, m.seats.length || m.capacity || 16)) }));
    } catch (err) {
      setLoadError(getErrorMessage(err, 'Gagal memuat denah ruangan'));
    } finally {
      setLoading(false);
    }
  }, [roomId, applyMap]);

  useEffect(() => {
    load();
  }, [load]);

  // Setelah kanal mic diubah: muat ulang daftar kanal saja (perubahan denah tetap).
  const refreshChannels = useCallback(async () => {
    if (!roomId) return;
    try {
      const chs = await authApi.listAudioChannels(roomId);
      setChannels([...chs].sort((a, b) => a.channel_no - b.channel_no));
      setChannelsNote(null);
      // Kanal yang dihapus otomatis terlepas dari kursi.
      const ids = new Set(chs.map((c) => c.id));
      setSeats((prev) =>
        prev.map((s) => (s.audio_channel_id && !ids.has(s.audio_channel_id) ? { ...s, audio_channel_id: null } : s))
      );
    } catch {
      /* abaikan; daftar lama tetap dipakai */
    }
  }, [roomId]);

  useEffect(() => {
    if (!dirty) return;
    const warn = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [dirty]);

  const channelById = useMemo(() => new Map(channels.map((c) => [c.id, c])), [channels]);
  const seatsView: EditSeat[] = useMemo(
    () => seats.map((s) => ({ ...s, channel: s.audio_channel_id ? channelById.get(s.audio_channel_id) ?? null : null })),
    [seats, channelById]
  );
  const selected = seatsView.find((s) => s.id === selectedId) ?? null;
  const seatByChannel = useMemo(() => {
    const m = new Map<string, EditSeat>();
    seats.forEach((s) => s.audio_channel_id && m.set(s.audio_channel_id, s));
    return m;
  }, [seats]);

  const problems = useMemo(() => {
    const out: string[] = [];
    const nos = new Map<number, number>();
    seats.forEach((s) => nos.set(s.seat_no, (nos.get(s.seat_no) ?? 0) + 1));
    nos.forEach((n, no) => n > 1 && out.push(`Nomor kursi ${no} dipakai ${n} kali`));
    if (seats.some((s) => !s.label.trim())) out.push('Ada kursi tanpa label');
    return out;
  }, [seats]);

  const patchSeat = (id: string, patch: Partial<EditSeat>) => {
    setSeats((prev) => prev.map((s) => (s.id === id ? { ...s, ...patch } : s)));
    setDirty(true);
  };

  const moveSeat = (id: string, x: number, y: number) => {
    setSeats((prev) => {
      const cur = prev.find((s) => s.id === id);
      if (!cur || (cur.pos_x === x && cur.pos_y === y)) return prev;
      return prev.map((s) => (s.id === id ? { ...s, pos_x: x, pos_y: y } : s));
    });
    setDirty(true);
  };

  const nudgeSeat = (id: string, dx: number, dy: number) => {
    const clamp = (v: number) => Math.max(0, Math.min(100, Math.round(v)));
    setSeats((prev) => prev.map((s) => (s.id === id ? { ...s, pos_x: clamp(s.pos_x + dx), pos_y: clamp(s.pos_y + dy) } : s)));
    setDirty(true);
  };

  const setSeatChannel = (id: string, channelId: string | null) => {
    setSeats((prev) =>
      prev.map((s) => {
        if (s.id === id) return { ...s, audio_channel_id: channelId };
        // Satu kanal hanya untuk satu kursi: lepas dari kursi lain.
        if (channelId && s.audio_channel_id === channelId) return { ...s, audio_channel_id: null };
        return s;
      })
    );
    setDirty(true);
  };

  const addSeat = () => {
    const nextNo = seats.reduce((m, s) => Math.max(m, s.seat_no), 0) + 1;
    const used = new Set(seats.map((s) => s.audio_channel_id).filter(Boolean));
    const freeCh = channels.find((c) => c.channel_no === nextNo && !used.has(c.id)) ?? null;
    const id = `new-${Date.now()}-${tempSeq++}`;
    setSeats((prev) => [
      ...prev,
      {
        id,
        isNew: true,
        seat_no: nextNo,
        label: String(nextNo),
        seat_type: 'delegate',
        pos_x: 50,
        pos_y: 50,
        rotation: 0,
        audio_channel_id: freeCh?.id ?? null,
      },
    ]);
    setSelectedId(id);
    setDirty(true);
  };

  const removeSeat = (id: string) => {
    setSeats((prev) => prev.filter((s) => s.id !== id));
    setSelectedId(null);
    setDirty(true);
  };

  const save = async () => {
    if (!roomId || problems.length) return;
    setSaving(true);
    setMessage(null);
    try {
      const items: RoomSeatInput[] = seats.map((s) => ({
        ...(s.isNew ? {} : { id: s.id }),
        seat_no: s.seat_no,
        label: s.label.trim(),
        seat_type: s.seat_type,
        pos_x: s.pos_x,
        pos_y: s.pos_y,
        rotation: s.rotation,
        audio_channel_id: s.audio_channel_id,
      }));
      const m = await liveMeetingApi.saveRoomSeats(roomId, items, layout ?? undefined);
      applyMap(m, channels);
      setSelectedId(null);
      setMessage({ type: 'success', text: `Denah disimpan (${m.seats.length} kursi)` });
    } catch (err) {
      setMessage({ type: 'error', text: getErrorMessage(err, 'Gagal menyimpan denah') });
    } finally {
      setSaving(false);
    }
  };

  const generate = async () => {
    if (!roomId) return;
    setSaving(true);
    setMessage(null);
    try {
      const m = await liveMeetingApi.generateRoomSeats(roomId, gen);
      applyMap(m, null);
      setSelectedId(null);
      setGenOpen(false);
      setChannelsNote(m.audio_channels.length ? null : 'Kanal mic belum dikonfigurasi');
      setMessage({
        type: 'success',
        text:
          `Denah ${m.seats.length} kursi dibuat` +
          (m.channels_created ? `, ${m.channels_created} kanal mic default dibuat (M118-A/B)` : ''),
      });
    } catch (err) {
      setMessage({ type: 'error', text: getErrorMessage(err, 'Gagal membuat denah') });
    } finally {
      setSaving(false);
    }
  };

  if (loading && !map) {
    return (
      <div className="flex items-center justify-center h-64 gap-2 text-black/50 dark:text-white/50">
        <i className="ri-loader-4-line animate-spin text-2xl"></i> Memuat denah...
      </div>
    );
  }
  if (!map) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-3 text-center">
        <i className="ri-layout-4-line text-5xl text-black/30 dark:text-white/30"></i>
        <p className="text-black/70 dark:text-white/70">{loadError ?? 'Ruangan tidak ditemukan'}</p>
        <button type="button" onClick={() => navigate('/rooms')} className="px-4 py-2 bg-primary text-white rounded-lg text-sm font-medium">
          Kembali ke Ruangan
        </button>
      </div>
    );
  }

  const usedCount = seats.filter((s) => s.audio_channel_id).length;

  return (
    <div className="space-y-5">
      {/* ===== HEADER ===== */}
      <div className="flex flex-col md:flex-row md:items-center gap-3">
        <div className="flex items-start gap-3 flex-1 min-w-0">
          <button
            type="button"
            onClick={() => {
              if (!dirty || window.confirm('Perubahan denah belum disimpan. Tinggalkan halaman?')) navigate('/rooms');
            }}
            className="p-2 rounded-lg bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 text-black/60 dark:text-white/60"
            title="Kembali"
          >
            <i className="ri-arrow-left-line text-xl"></i>
          </button>
          <div className="min-w-0">
            <h1 className="text-2xl font-bold text-black dark:text-white truncate" title={map.room_name}>
              Denah & Mic · {map.room_name}
            </h1>
            <p className="text-sm text-black/60 dark:text-white/60">
              {seats.length} kursi · {usedCount}/{channels.length} kanal mic terpetakan · kapasitas {map.capacity}
            </p>
          </div>
        </div>
        {canEdit && (
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setGenOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-primary bg-primary/10 hover:bg-primary/20 rounded-lg"
            >
              <i className="ri-magic-line"></i>
              Buat Denah Otomatis
            </button>
            <button
              type="button"
              onClick={addSeat}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg"
            >
              <i className="ri-add-line"></i>
              Tambah Kursi
            </button>
            {/* Selalu dirender (disabled bila tidak ada perubahan) agar tata letak tidak bergeser saat menyeret. */}
            <button
              type="button"
              disabled={!dirty || saving}
              onClick={() => {
                applyMap(map, channels);
                setSelectedId(null);
              }}
              className="px-3 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 rounded-lg disabled:opacity-50"
            >
              Batalkan
            </button>
            <button
              type="button"
              disabled={!dirty || saving || problems.length > 0}
              onClick={save}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-primary hover:bg-primary/90 rounded-lg disabled:opacity-50"
            >
              <i className={saving ? 'ri-loader-4-line animate-spin' : 'ri-save-line'}></i>
              Simpan Denah
              <span
                className="inline-block w-2 h-2 rounded-full bg-warning"
                style={{ opacity: dirty ? 1 : 0 }}
                title={dirty ? 'Ada perubahan yang belum disimpan' : undefined}
                aria-label={dirty ? 'belum disimpan' : undefined}
              ></span>
            </button>
          </div>
        )}
      </div>

      {message && (
        <div
          className={`flex items-start gap-2 p-3 rounded-lg text-sm ${message.type === 'success' ? 'bg-success/10 text-success' : 'bg-danger/10 text-danger'}`}
          role={message.type === 'error' ? 'alert' : 'status'}
        >
          <i className={message.type === 'success' ? 'ri-check-line mt-0.5' : 'ri-error-warning-line mt-0.5'}></i>
          <span className="flex-1">{message.text}</span>
          <button type="button" onClick={() => setMessage(null)} title="Tutup">
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}
      {problems.length > 0 && (
        <div className="p-3 rounded-lg bg-warning/10 text-warning text-sm">{problems.join(' · ')}</div>
      )}
      {!canEdit && (
        <div className="p-3 rounded-lg bg-info/10 text-info text-sm">
          Mode lihat saja — perlu izin <b>Kelola Ruangan</b> untuk mengubah denah.
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* ===== KANVAS ===== */}
        <div className="lg:col-span-8 space-y-3">
          <div className="bg-white dark:bg-gray border border-black/10 dark:border-white/10 rounded-xl shadow-sm p-4 space-y-3">
            <SeatMap
              seats={seatsView}
              layout={layout}
              mode={canEdit ? 'edit' : 'view'}
              selectedId={selectedId}
              onSelect={setSelectedId}
              onMove={canEdit ? moveSeat : undefined}
              onNudge={canEdit ? nudgeSeat : undefined}
              showNames={false}
              ariaLabel={`Editor denah ${map.room_name}`}
            />
            <div className="flex flex-wrap items-center justify-between gap-2">
              <SeatLegend />
              {canEdit && (
                <span className="text-xs text-black/50 dark:text-white/50">
                  Seret kursi untuk memindahkan · panah keyboard = geser 1% (Shift = 5%)
                </span>
              )}
            </div>
          </div>

          <div className="bg-white dark:bg-gray border border-black/10 dark:border-white/10 rounded-xl shadow-sm">
            <button
              type="button"
              onClick={() => setChannelsOpen((v) => !v)}
              className="w-full flex items-center justify-between px-4 py-3 text-sm font-bold text-black dark:text-white"
              aria-expanded={channelsOpen}
            >
              <span>
                <i className="ri-mic-2-line mr-2 text-primary"></i>
                Kanal Mic Ruangan ({channels.length})
              </span>
              <i className={channelsOpen ? 'ri-arrow-up-s-line' : 'ri-arrow-down-s-line'}></i>
            </button>
            {channelsOpen && (
              <div className="px-4 pb-4">
                <AudioChannelEditor roomId={map.room_id} onSaved={refreshChannels} />
              </div>
            )}
          </div>
        </div>

        {/* ===== INSPEKTOR ===== */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white dark:bg-gray border border-black/10 dark:border-white/10 rounded-xl shadow-sm p-4 space-y-3">
            <h2 className="text-base font-bold text-black dark:text-white">
              {selected ? `Kursi ${selected.label}` : 'Detail Kursi'}
            </h2>
            {!selected ? (
              <p className="text-sm text-black/50 dark:text-white/50">Pilih kursi di denah atau di daftar untuk mengubahnya.</p>
            ) : (
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <label className="block">
                    <span className="block text-xs font-medium text-black/60 dark:text-white/60 mb-1">No. kursi</span>
                    <input
                      type="number"
                      min={1}
                      max={999}
                      disabled={!canEdit}
                      value={selected.seat_no}
                      onChange={(e) => patchSeat(selected.id, { seat_no: Math.max(1, Number(e.target.value) || 1) })}
                      className={inputCls}
                    />
                  </label>
                  <label className="block">
                    <span className="block text-xs font-medium text-black/60 dark:text-white/60 mb-1">Label</span>
                    <input
                      maxLength={50}
                      disabled={!canEdit}
                      value={selected.label}
                      onChange={(e) => patchSeat(selected.id, { label: e.target.value })}
                      className={inputCls}
                    />
                  </label>
                </div>
                <label className="block">
                  <span className="block text-xs font-medium text-black/60 dark:text-white/60 mb-1">Jenis kursi</span>
                  <select
                    disabled={!canEdit}
                    value={selected.seat_type}
                    onChange={(e) => patchSeat(selected.id, { seat_type: e.target.value as SeatType })}
                    className={inputCls}
                  >
                    {SEAT_TYPES.map((t) => (
                      <option key={t.value} value={t.value}>
                        {t.label}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block">
                  <span className="block text-xs font-medium text-black/60 dark:text-white/60 mb-1">Kanal mic</span>
                  <select
                    disabled={!canEdit || channels.length === 0}
                    value={selected.audio_channel_id ?? ''}
                    onChange={(e) => setSeatChannel(selected.id, e.target.value || null)}
                    className={inputCls}
                    aria-label="Kanal mic"
                  >
                    <option value="">— Tanpa mic —</option>
                    {channels.map((c) => {
                      const other = seatByChannel.get(c.id);
                      return (
                        <option key={c.id} value={c.id}>
                          {channelLabel(c)}
                          {other && other.id !== selected.id ? ` (dipakai Kursi ${other.label})` : ''}
                          {!c.enabled ? ' [nonaktif]' : ''}
                        </option>
                      );
                    })}
                  </select>
                  {channels.length === 0 && (
                    <span className="block text-xs text-warning mt-1">
                      {channelsNote ?? 'Kanal mic belum dikonfigurasi'} — atur di <b>Kanal Mic Ruangan</b>, atau gunakan <b>Buat Denah Otomatis</b> dengan opsi
                      "buat kanal mic" untuk membuat Mic 1..N (M118-A CH1–8, M118-B CH1–8).
                    </span>
                  )}
                </label>
                <div>
                  <span className="block text-xs font-medium text-black/60 dark:text-white/60 mb-1">
                    Arah hadap ({selected.rotation}°)
                  </span>
                  <div className="flex items-center gap-2">
                    {(
                      [
                        [0, 'ri-arrow-up-line', 'Atas'],
                        [90, 'ri-arrow-right-line', 'Kanan'],
                        [180, 'ri-arrow-down-line', 'Bawah'],
                        [270, 'ri-arrow-left-line', 'Kiri'],
                      ] as [number, string, string][]
                    ).map(([deg, icon, label]) => (
                      <button
                        key={deg}
                        type="button"
                        disabled={!canEdit}
                        onClick={() => patchSeat(selected.id, { rotation: deg })}
                        title={`Menghadap ${label}`}
                        className={`p-2 rounded-lg ${
                          selected.rotation === deg ? 'bg-primary text-white' : 'bg-black/5 dark:bg-white/5 text-black/60 dark:text-white/60'
                        }`}
                      >
                        <i className={icon}></i>
                      </button>
                    ))}
                    <input
                      type="number"
                      min={0}
                      max={359}
                      disabled={!canEdit}
                      value={selected.rotation}
                      onChange={(e) => patchSeat(selected.id, { rotation: ((Number(e.target.value) || 0) % 360 + 360) % 360 })}
                      className={`${inputCls} w-20`}
                      aria-label="Rotasi (derajat)"
                    />
                  </div>
                </div>
                <div className="text-xs text-black/50 dark:text-white/50">
                  Posisi: x {selected.pos_x}% · y {selected.pos_y}%
                </div>
                {canEdit && (
                  <button
                    type="button"
                    onClick={() => removeSeat(selected.id)}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-danger bg-danger/10 hover:bg-danger/20 rounded-lg"
                  >
                    <i className="ri-delete-bin-line"></i>
                    Hapus kursi
                  </button>
                )}
              </div>
            )}
          </div>

          <div className="bg-white dark:bg-gray border border-black/10 dark:border-white/10 rounded-xl shadow-sm">
            <div className="px-4 py-3 border-b border-black/10 dark:border-white/10 text-sm font-bold text-black dark:text-white">
              Pemetaan Kursi → Mic
            </div>
            <ul className="overflow-y-auto divide-y divide-black/5 dark:divide-white/5" style={{ maxHeight: 384 }}>
              {seatsView.length === 0 && (
                <li className="px-4 py-6 text-center text-sm text-black/50 dark:text-white/50">Belum ada kursi</li>
              )}
              {[...seatsView]
                .sort((a, b) => a.seat_no - b.seat_no)
                .map((s) => {
                  const meta = seatTypeMeta(s.seat_type);
                  return (
                    <li key={s.id}>
                      <button
                        type="button"
                        onClick={() => setSelectedId(s.id)}
                        className={`w-full flex items-center gap-3 px-4 py-2 text-left text-sm ${
                          selectedId === s.id ? 'bg-primary/10' : 'hover:bg-black/5 dark:hover:bg-white/5'
                        }`}
                      >
                        <span
                          className="w-7 h-7 shrink-0 rounded-full flex items-center justify-center text-xs font-bold text-white"
                          style={{ background: meta.color }}
                        >
                          {s.seat_no}
                        </span>
                        <span className="flex-1 min-w-0">
                          <span className="block font-medium text-black dark:text-white truncate">
                            Kursi {s.label} <span className="text-xs text-black/50 dark:text-white/50">· {meta.label}</span>
                          </span>
                          <span className={`block text-xs ${s.channel ? 'text-black/60 dark:text-white/60' : 'text-warning'}`}>
                            <i className="ri-mic-line mr-1"></i>
                            {channelLabel(s.channel)}
                          </span>
                        </span>
                      </button>
                    </li>
                  );
                })}
            </ul>
          </div>
        </div>
      </div>

      {/* ===== DIALOG GENERATE ===== */}
      {genOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" role="dialog" aria-modal="true">
          <div className="w-full max-w-lg bg-white dark:bg-gray rounded-xl shadow-xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-black dark:text-white">Buat Denah Otomatis</h3>
              <button type="button" onClick={() => setGenOpen(false)} title="Tutup" className="text-black/50 dark:text-white/50">
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {LAYOUTS.map((l) => (
                <button
                  key={l.value}
                  type="button"
                  onClick={() => setGen((g) => ({ ...g, layout: l.value }))}
                  className={`p-3 rounded-lg border text-left ${
                    gen.layout === l.value
                      ? 'border-primary bg-primary/10'
                      : 'border-black/10 dark:border-white/10 hover:bg-black/5 dark:hover:bg-white/5'
                  }`}
                >
                  <i className={`${l.icon} text-xl text-primary`}></i>
                  <span className="block text-sm font-semibold text-black dark:text-white">{l.label}</span>
                  <span className="block text-xs text-black/50 dark:text-white/50">{l.hint}</span>
                </button>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <label className="block">
                <span className="block text-xs font-medium text-black/60 dark:text-white/60 mb-1">Jumlah kursi</span>
                <input
                  type="number"
                  min={1}
                  max={64}
                  value={gen.count}
                  onChange={(e) => setGen((g) => ({ ...g, count: Math.max(1, Math.min(64, Number(e.target.value) || 1)) }))}
                  className={inputCls}
                />
              </label>
              <label className="block">
                <span className="block text-xs font-medium text-black/60 dark:text-white/60 mb-1">Kursi pimpinan</span>
                <input
                  type="number"
                  min={0}
                  max={4}
                  value={gen.chair_count}
                  onChange={(e) => setGen((g) => ({ ...g, chair_count: Math.max(0, Math.min(4, Number(e.target.value) || 0)) }))}
                  className={inputCls}
                />
              </label>
            </div>
            <label className="flex items-start gap-2 text-sm text-black/70 dark:text-white/70">
              <input
                type="checkbox"
                checked={gen.link_channels}
                onChange={(e) => setGen((g) => ({ ...g, link_channels: e.target.checked }))}
                className="mt-1"
              />
              <span>
                Petakan kursi n → Mic n
                {channels.length === 0 && ' (kanal mic default Mic 1..N akan dibuat: M118-A CH1–8, M118-B CH1–8)'}
              </span>
            </label>
            <div className="p-3 rounded-lg bg-warning/10 text-warning text-xs">
              Denah yang ada akan diganti, termasuk penempatan kursi pada rapat terjadwal di ruangan ini.
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setGenOpen(false)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 rounded-lg"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={saving}
                onClick={generate}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-primary rounded-lg disabled:opacity-50"
              >
                {saving && <i className="ri-loader-4-line animate-spin"></i>}
                Buat Denah
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default RoomLayoutPage;
