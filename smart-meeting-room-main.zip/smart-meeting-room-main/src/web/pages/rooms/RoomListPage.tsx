import { useEffect, useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi } from '../../../shared/api/auth';
import { getErrorMessage } from '../../../shared/api/client';
import { usePermission } from '../../store/auth.store';
import type {
  Room,
  RoomCreate,
  RoomUpdate,
  Building,
  RoomType,
} from '@shared/types';
import { ROOM_TYPE_OPTIONS, ROOM_FACILITIES } from '@shared/types';

interface RoomFormState {
  code: string;
  name: string;
  building_id: string;
  floor: number;
  capacity: number;
  room_type: RoomType;
  description: string;
  facilities: string[];
  is_active: boolean;
}

const INITIAL_FORM: RoomFormState = {
  code: '',
  name: '',
  building_id: '',
  floor: 1,
  capacity: 10,
  room_type: 'meeting',
  description: '',
  facilities: [],
  is_active: true,
};

export function RoomListPage() {
  const navigate = useNavigate();
  const can = usePermission();
  const canWrite = can('rooms.write');
  const canManageDisplay = can(['rooms.write', 'door_display.manage']);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [buildings, setBuildings] = useState<Building[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [filterBuilding, setFilterBuilding] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('');
  const [filterMinCapacity, setFilterMinCapacity] = useState('');
  const [page, setPage] = useState(1);
  const [perPage] = useState(10);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  const [showModal, setShowModal] = useState(false);
  const [editingRoom, setEditingRoom] = useState<Room | null>(null);
  const [form, setForm] = useState<RoomFormState>(INITIAL_FORM);
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [deleteConfirm, setDeleteConfirm] = useState<Room | null>(null);

  // === Kiosk Security (ADM-03/04) ===
  const [kioskRoom, setKioskRoom] = useState<Room | null>(null);
  const [kioskKey, setKioskKey] = useState<string>('');
  const [kioskPin, setKioskPin] = useState('');
  const [kioskSubmitting, setKioskSubmitting] = useState(false);
  const [kioskKeyRegenerating, setKioskKeyRegenerating] = useState(false);
  const [kioskCopied, setKioskCopied] = useState(false);

  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchBuildings = async () => {
    try {
      const result = await authApi.listBuildings();
      setBuildings(result ?? []);
    } catch {
      // Hanya untuk filter & pilihan gedung.
      setBuildings([]);
    }
  };

  const fetchRooms = async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const result = await authApi.listRooms({
        page,
        per_page: perPage,
        search: search.trim() || undefined,
        building_id: filterBuilding || undefined,
        room_type: filterType || undefined,
        status: filterStatus || undefined,
        capacity_min: filterMinCapacity ? Number(filterMinCapacity) : undefined,
      });
      setRooms(result.items ?? []);
      setTotal(result.total ?? 0);
      setTotalPages(result.total_pages ?? 0);
    } catch (err) {
      setRooms([]);
      setTotal(0);
      setTotalPages(0);
      setLoadError(getErrorMessage(err, 'Gagal memuat daftar ruangan'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBuildings();
  }, []);

  useEffect(() => {
    fetchRooms();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, filterBuilding, filterType, filterStatus, filterMinCapacity]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(1);
      fetchRooms();
    }, 400);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  const openCreateModal = () => {
    setEditingRoom(null);
    setForm(INITIAL_FORM);
    setFormError(null);
    setShowModal(true);
  };

  const openEditModal = (room: Room) => {
    setEditingRoom(room);
    setForm({
      code: room.code,
      name: room.name,
      building_id: room.building_id || '',
      floor: room.floor || 1,
      capacity: room.capacity,
      room_type: room.room_type,
      description: room.description || '',
      facilities: room.facilities || [],
      is_active: room.is_active,
    });
    setFormError(null);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingRoom(null);
    setForm(INITIAL_FORM);
    setFormError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSubmitting(true);

    try {
      if (editingRoom) {
        const wasMaintenance = String(editingRoom.status).toLowerCase() === 'maintenance';
        const data: RoomUpdate = {
          code: form.code,
          name: form.name,
          building_id: form.building_id || undefined,
          floor: form.floor,
          capacity: form.capacity,
          room_type: form.room_type,
          description: form.description || undefined,
          facilities: form.facilities,
        };
        // Pertahankan status "maintenance" kecuali ruangan dinonaktifkan.
        data.status = !form.is_active ? 'disabled' : wasMaintenance ? 'maintenance' : 'available';
        await authApi.updateRoom(editingRoom.id, data);
        showToast('success', 'Ruangan berhasil diperbarui');
      } else {
        const data: RoomCreate = {
          code: form.code,
          name: form.name,
          building_id: form.building_id || undefined,
          floor: form.floor,
          capacity: form.capacity,
          room_type: form.room_type,
          description: form.description || undefined,
          facilities: form.facilities,
          is_active: form.is_active,
        };
        await authApi.createRoom(data);
        showToast('success', 'Ruangan berhasil ditambahkan');
      }
      closeModal();
      fetchRooms();
    } catch (err: unknown) {
      setFormError(getErrorMessage(err, 'Gagal menyimpan ruangan'));
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleStatus = async (room: Room) => {
    try {
      await authApi.updateRoom(room.id, { is_active: !room.is_active });
      showToast('success', `Status ruangan diubah menjadi ${!room.is_active ? 'Aktif' : 'Nonaktif'}`);
      fetchRooms();
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal mengubah status ruangan'));
    }
  };

  // === Kiosk Security: handlers (ADM-03 regenerate key / ADM-04 set PIN) ===
  const openKioskModal = async (room: Room) => {
    setKioskRoom(room);
    setKioskKey('');
    setKioskPin('');
    setKioskCopied(false);
    // Pairing key tidak lagi ada di list/detail ruangan; ambil lewat endpoint khusus admin.
    try {
      const res = await authApi.getRoomPairingKey(room.id);
      setKioskKey(res?.pairing_key || '');
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal memuat pairing key'));
    }
  };

  const handleRegenerateKey = async () => {
    if (!kioskRoom || kioskKeyRegenerating) return;
    setKioskKeyRegenerating(true);
    try {
      const res = await authApi.regeneratePairingKey(kioskRoom.id);
      setKioskKey(res.pairing_key);
      setKioskCopied(false);
      showToast('success', 'Pairing key kiosk berhasil diperbarui');
      fetchRooms();
    } catch (err: unknown) {
      showToast('error', getErrorMessage(err, 'Gagal memperbarui pairing key'));
    } finally {
      setKioskKeyRegenerating(false);
    }
  };

  const handleSetPin = async () => {
    if (!kioskRoom || kioskSubmitting) return;
    if (!/^[0-9]{6,8}$/.test(kioskPin)) {
      showToast('error', 'PIN harus 6-8 digit angka');
      return;
    }
    setKioskSubmitting(true);
    try {
      await authApi.setMasterPin(kioskRoom.id, kioskPin);
      setKioskPin('');
      showToast('success', 'Master PIN kiosk berhasil disimpan');
      fetchRooms();
    } catch (err: unknown) {
      showToast('error', getErrorMessage(err, 'Gagal menyimpan Master PIN'));
    } finally {
      setKioskSubmitting(false);
    }
  };

  const handleCopyKey = async () => {
    try {
      await navigator.clipboard.writeText(kioskKey);
      setKioskCopied(true);
      window.setTimeout(() => setKioskCopied(false), 2000);
    } catch {
      setKioskCopied(false);
    }
  };

  const handleDelete = async (room: Room) => {
    try {
      await authApi.deleteRoom(room.id);
      showToast('success', 'Ruangan berhasil dihapus');
      setDeleteConfirm(null);
      fetchRooms();
    } catch (err: unknown) {
      showToast('error', getErrorMessage(err, 'Gagal menghapus ruangan'));
      setDeleteConfirm(null);
    }
  };

  const toggleFacility = (facility: string) => {
    setForm((prev) => ({
      ...prev,
      facilities: prev.facilities.includes(facility)
        ? prev.facilities.filter((f) => f !== facility)
        : [...prev.facilities, facility],
    }));
  };

  const roomTypeLabel = useMemo(() => {
    const map = new Map(ROOM_TYPE_OPTIONS.map((r) => [r.value, r.label]));
    return (val: RoomType) => map.get(val) || val;
  }, []);

  const statusBadgeClass = (status: Room['status']) => {
    switch (String(status).toLowerCase()) {
      case 'available':
        return 'bg-success/10 text-success';
      case 'occupied':
        return 'bg-warning/10 text-warning';
      case 'maintenance':
        return 'bg-danger/10 text-danger';
      case 'reserved':
        return 'bg-info/10 text-info';
      default:
        return 'bg-black/10 text-black/70';
    }
  };

  const statusLabel = (status: Room['status']) => {
    switch (String(status).toLowerCase()) {
      case 'available':
        return 'Tersedia';
      case 'occupied':
        return 'Digunakan';
      case 'maintenance':
        return 'Perawatan';
      case 'reserved':
        return 'Dipesan';
      case 'disabled':
        return 'Nonaktif';
      default:
        return status;
    }
  };

  const buildingName = (id?: string) => buildings.find((b) => b.id === id)?.name || '-';

  const pageNumbers = useMemo(() => {
    const pages: (number | string)[] = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      if (page <= 4) {
        pages.push(1, 2, 3, 4, 5, '...', totalPages);
      } else if (page >= totalPages - 3) {
        pages.push(1, '...', totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages);
      } else {
        pages.push(1, '...', page - 1, page, page + 1, '...', totalPages);
      }
    }
    return pages;
  }, [page, totalPages]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Daftar Ruangan Rapat</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Kelola ruangan rapat dan fasilitasnya
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => navigate('/rooms/buildings')}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors"
          >
            <i className="ri-building-2-line"></i>
            <span>Kelola Gedung</span>
          </button>
          {canWrite && (
            <button
              type="button"
              onClick={openCreateModal}
              className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors shadow-sm"
            >
              <i className="ri-add-line text-lg"></i>
              <span>Tambah Ruangan</span>
            </button>
          )}
        </div>
      </div>

      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
        <div className="flex flex-col sm:flex-row gap-3 mb-6 flex-wrap">
          <div className="relative flex-1 max-w-sm">
            <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40"></i>
            <input
              type="text"
              placeholder="Cari kode, nama ruangan..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 placeholder:text-black/40 dark:placeholder:text-white/40"
            />
          </div>
          <select
            value={filterBuilding}
            onChange={(e) => {
              setFilterBuilding(e.target.value);
              setPage(1);
            }}
            className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
          >
            <option value="">Semua Gedung</option>
            {buildings.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
          <select
            value={filterType}
            onChange={(e) => {
              setFilterType(e.target.value);
              setPage(1);
            }}
            className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
          >
            <option value="">Semua Tipe</option>
            {ROOM_TYPE_OPTIONS.map((r) => (
              <option key={r.value} value={r.value}>
                {r.label}
              </option>
            ))}
          </select>
          <select
            value={filterStatus}
            onChange={(e) => {
              setFilterStatus(e.target.value);
              setPage(1);
            }}
            className="px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
          >
            <option value="">Semua Status</option>
            <option value="available">Tersedia</option>
            <option value="maintenance">Perawatan</option>
            <option value="disabled">Nonaktif</option>
          </select>
          <input
            type="number"
            min={1}
            placeholder="Kapasitas min."
            value={filterMinCapacity}
            onChange={(e) => {
              setFilterMinCapacity(e.target.value);
              setPage(1);
            }}
            className="w-32 px-4 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
          />
        </div>

        <div className="overflow-x-auto -mx-6">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-y border-black/10 dark:border-white/10">
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Kode
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Nama Ruangan
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Gedung / Lantai
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Kapasitas
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Tipe
                </th>
                <th className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Status
                </th>
                <th className="text-right py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">
                  Aksi
                </th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-black/50 dark:text-white/50">
                    <div className="inline-flex items-center gap-2">
                      <svg className="animate-spin h-5 w-5 text-primary" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      <span>Memuat data...</span>
                    </div>
                  </td>
                </tr>
              ) : loadError ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center">
                    <p className="text-sm text-red-600 dark:text-red-400">{loadError}</p>
                    <button
                      type="button"
                      onClick={fetchRooms}
                      className="mt-3 inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-primary bg-primary/10 hover:bg-primary/15 rounded-lg"
                    >
                      <i className="ri-refresh-line"></i> Coba Lagi
                    </button>
                  </td>
                </tr>
              ) : rooms.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-black/50 dark:text-white/50">
                    <div className="flex flex-col items-center gap-2">
                      <i className="ri-door-open-line text-4xl text-black/30 dark:text-white/30"></i>
                      <span>Belum ada data</span>
                    </div>
                  </td>
                </tr>
              ) : (
                rooms.map((room) => (
                  <tr
                    key={room.id}
                    className="border-b border-black/5 dark:border-white/5 hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors"
                  >
                    <td className="py-3 px-6 whitespace-nowrap">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-semibold bg-primary/10 text-primary">
                        {room.code}
                      </span>
                    </td>
                    <td className="py-3 px-6 text-black/80 dark:text-white/80 font-medium whitespace-nowrap">
                      {room.name}
                    </td>
                    <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap">
                      <div>{room.building_name || buildingName(room.building_id)}</div>
                      <div className="text-xs text-black/40">Lantai {room.floor || '-'}</div>
                    </td>
                    <td className="py-3 px-6 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1 text-black/60 dark:text-white/60">
                        <i className="ri-user-3-line"></i>
                        {room.capacity} orang
                      </span>
                    </td>
                    <td className="py-3 px-6 whitespace-nowrap">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-info/10 text-info">
                        {roomTypeLabel(room.room_type)}
                      </span>
                    </td>
                    <td className="py-3 px-6 whitespace-nowrap">
                      <label className="inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          className="sr-only peer"
                          checked={room.is_active}
                          disabled={!canWrite}
                          onChange={() => handleToggleStatus(room)}
                        />
                        <div className="relative w-11 h-6 bg-black/15 dark:bg-white/15 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-success"></div>
                        <div className="ml-2">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${statusBadgeClass(room.status)}`}>
                            {statusLabel(room.status)}
                          </span>
                        </div>
                      </label>
                    </td>
                    <td className="py-3 px-6">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => navigate(`/rooms/qr/${room.code}`)}
                          title="QR Ruangan (Kontrol Mobile & Door Display)"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-info hover:bg-info/10 rounded-lg transition-colors"
                        >
                          <i className="ri-qr-code-line"></i>
                        </button>
                        <button
                          type="button"
                          onClick={() => navigate(`/rooms/${room.id}/layout`)}
                          title="Denah & Mic"
                          aria-label="Denah & Mic"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-primary hover:bg-primary/10 rounded-lg transition-colors"
                        >
                          <i className="ri-layout-4-line"></i>
                        </button>
                        {canManageDisplay && (
                        <button
                          type="button"
                          onClick={() => openKioskModal(room)}
                          title="Kiosk Security (Pairing & PIN)"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-success hover:bg-success/10 rounded-lg transition-colors"
                        >
                          <i className="ri-shield-keyhole-line"></i>
                        </button>
                        )}
                        {canWrite && (<>
                        <button
                          type="button"
                          onClick={() => openEditModal(room)}
                          title="Ubah Ruangan"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-primary hover:bg-primary/10 rounded-lg transition-colors"
                        >
                          <i className="ri-edit-line"></i>
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteConfirm(room)}
                          title="Hapus"
                          className="p-2 text-black/60 dark:text-white/60 hover:text-danger hover:bg-danger/10 rounded-lg transition-colors"
                        >
                          <i className="ri-delete-bin-line"></i>
                        </button>
                        </>)}

                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {totalPages > 0 && (
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-6 pt-4 border-t border-black/10 dark:border-white/10">
            <p className="text-sm text-black/60 dark:text-white/60">
              Menampilkan {((page - 1) * perPage) + 1} - {Math.min(page * perPage, total)} dari {total} data
            </p>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <i className="ri-arrow-left-s-line"></i>
              </button>
              {pageNumbers.map((p, idx) =>
                typeof p === 'number' ? (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setPage(p)}
                    className={`w-9 h-9 rounded-lg text-sm font-medium transition-colors ${
                      p === page
                        ? 'bg-primary text-white shadow-sm'
                        : 'text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5'
                    }`}
                  >
                    {p}
                  </button>
                ) : (
                  <span key={idx} className="w-9 h-9 flex items-center justify-center text-sm text-black/40 dark:text-white/40">
                    {p}
                  </span>
                )
              )}
              <button
                type="button"
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="p-2 rounded-lg text-sm text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <i className="ri-arrow-right-s-line"></i>
              </button>
            </div>
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={closeModal}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">
                {editingRoom ? 'Ubah Ruangan' : 'Tambah Ruangan'}
              </h2>
              <button
                type="button"
                onClick={closeModal}
                className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <form onSubmit={handleSubmit} className="overflow-y-auto flex-1">
              <div className="px-6 py-5 space-y-4">
                {formError && (
                  <div className="p-3 rounded-lg bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 text-sm">
                    <div className="flex items-start gap-2">
                      <i className="ri-error-warning-line mt-0.5"></i>
                      <span>{formError}</span>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      Kode Ruangan <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={20}
                      value={form.code}
                      onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 uppercase"
                      placeholder="Contoh: A-101"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      Nama Ruangan <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={100}
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                      placeholder="Contoh: Ruang Rapat Melati"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      Gedung <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={form.building_id}
                      onChange={(e) => setForm({ ...form, building_id: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    >
                      <option value="">Pilih Gedung</option>
                      {buildings.map((b) => (
                        <option key={b.id} value={b.id}>
                          {b.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                        Lantai
                      </label>
                      <input
                        type="number"
                        min={1}
                        max={50}
                        value={form.floor}
                        onChange={(e) => setForm({ ...form, floor: Number(e.target.value) || 1 })}
                        className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                        Kapasitas <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="number"
                        required
                        min={1}
                        value={form.capacity}
                        onChange={(e) => setForm({ ...form, capacity: Number(e.target.value) || 1 })}
                        className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      Tipe Ruangan <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={form.room_type}
                      onChange={(e) => setForm({ ...form, room_type: e.target.value as RoomType })}
                      className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                    >
                      {ROOM_TYPE_OPTIONS.map((r) => (
                        <option key={r.value} value={r.value}>
                          {r.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                      Status Aktif
                    </label>
                    <div className="pt-1">
                      <label className="inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          className="sr-only peer"
                          checked={form.is_active}
                          onChange={(e) => setForm({ ...form, is_active: e.target.checked })}
                        />
                        <div className="relative w-11 h-6 bg-black/15 dark:bg-white/15 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-success"></div>
                        <span className={`ml-2 text-sm font-medium ${form.is_active ? 'text-success' : 'text-black/50 dark:text-white/50'}`}>
                          {form.is_active ? 'Aktif' : 'Nonaktif'}
                        </span>
                      </label>
                    </div>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">
                    Deskripsi
                  </label>
                  <textarea
                    rows={2}
                    maxLength={255}
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 resize-none"
                    placeholder="Deskripsi ruangan..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-2">
                    Fasilitas
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {ROOM_FACILITIES.map((f) => (
                      <label
                        key={f}
                        className={`flex items-center gap-2 p-2 rounded-md border cursor-pointer transition-colors ${
                          form.facilities.includes(f)
                            ? 'bg-primary/5 border-primary/20 dark:bg-primary/10'
                            : 'border-black/10 dark:border-white/10 hover:bg-black/[0.02] dark:hover:bg-white/[0.02]'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={form.facilities.includes(f)}
                          onChange={() => toggleFacility(f)}
                          className="w-4 h-4 rounded border-black/20 text-primary focus:ring-primary cursor-pointer"
                        />
                        <span className={`text-sm ${form.facilities.includes(f) ? 'text-primary font-medium' : 'text-black/70 dark:text-white/70'}`}>
                          {f}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
              <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={closeModal}
                  disabled={submitting}
                  className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors disabled:opacity-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submitting && (
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                  )}
                  <span>Simpan Perubahan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setDeleteConfirm(null)}>
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-md overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-5">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-500/10 flex items-center justify-center shrink-0">
                  <i className="ri-delete-bin-line text-2xl text-red-600 dark:text-red-400"></i>
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-black dark:text-white">Hapus Ruangan</h3>
                  <p className="text-sm text-black/60 dark:text-white/60 mt-1">
                    Apakah Anda yakin ingin menghapus ruangan <span className="font-semibold">{deleteConfirm.name}</span>? Semua pemesanan untuk ruangan ini juga akan terdampak.
                  </p>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 bg-black/[0.02] dark:bg-white/[0.02] flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => handleDelete(deleteConfirm)}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors shadow-sm"
              >
                Hapus
              </button>
            </div>
          </div>
        </div>
      )}

      {kioskRoom && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={() => setKioskRoom(null)}
        >
          <div
            className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-lg overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-success/10 flex items-center justify-center">
                  <i className="ri-shield-keyhole-line text-xl text-success"></i>
                </div>
                <div>
                  <h2 className="text-lg font-bold text-black dark:text-white">Kiosk Security</h2>
                  <p className="text-xs text-black/50 dark:text-white/50">
                    {kioskRoom.name} ({kioskRoom.code})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setKioskRoom(null)}
                className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>

            <div className="px-6 py-5 space-y-6">
              {/* ADM-03: Pairing Key */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium text-black/70 dark:text-white/70">
                    Pairing Key Kiosk
                  </label>
                  <span className="text-xs text-black/40 dark:text-white/40">
                    Dipakai untuk mengaktifkan layar pintu ruangan
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 px-4 py-3 font-mono text-xl font-bold tracking-[0.2em] bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg text-primary dark:text-primary text-center">
                    {kioskKey || '—'}
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyKey}
                    title="Salin"
                    className="p-3 rounded-lg bg-black/5 dark:bg-white/5 text-black/60 dark:text-white/60 hover:bg-black/10 dark:hover:bg-white/10 transition-colors"
                  >
                    <i className={kioskCopied ? 'ri-check-line text-success' : 'ri-file-copy-line'}></i>
                  </button>
                  <button
                    type="button"
                    onClick={handleRegenerateKey}
                    disabled={kioskKeyRegenerating}
                    title="Buat kunci baru (kunci lama tidak berlaku)"
                    className="p-3 rounded-lg bg-black/5 dark:bg-white/5 text-black/60 dark:text-white/60 hover:bg-black/10 dark:hover:bg-white/10 disabled:opacity-50 transition-colors"
                  >
                    {kioskKeyRegenerating ? (
                      <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                    ) : (
                      <i className="ri-refresh-line"></i>
                    )}
                  </button>
                </div>
              </div>

              {/* ADM-04: Master PIN */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium text-black/70 dark:text-white/70">
                    Master PIN Kiosk
                  </label>
                  <span
                    className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                      kioskRoom.has_master_pin
                        ? 'bg-success/10 text-success'
                        : 'bg-warning/10 text-warning'
                    }`}
                  >
                    {kioskRoom.has_master_pin ? 'Terpasang' : 'Belum diatur'}
                  </span>
                </div>
                <p className="text-xs text-black/50 dark:text-white/50 mb-3">
                  PIN dipakai petugas untuk membuka ruangan lebih awal (Early Release) langsung dari layar pintu.
                </p>
                <div className="flex items-center gap-2">
                  <input
                    type="password"
                    inputMode="numeric"
                    maxLength={8}
                    value={kioskPin}
                    onChange={(e) => setKioskPin(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder={kioskRoom.has_master_pin ? 'PIN baru (menimpa yang lama)' : '6-8 digit angka'}
                    className="flex-1 px-4 py-3 font-mono tracking-[0.4em] bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80"
                  />
                  <button
                    type="button"
                    onClick={handleSetPin}
                    disabled={kioskSubmitting || !/^[0-9]{4,8}$/.test(kioskPin)}
                    className="px-5 py-3 rounded-lg bg-primary text-white text-sm font-semibold hover:bg-primary/90 disabled:opacity-50 transition-colors inline-flex items-center gap-2"
                  >
                    {kioskSubmitting ? (
                      <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                    ) : (
                      <i className="ri-save-line"></i>
                    )}
                    Simpan
                  </button>
                </div>
              </div>
            </div>

            <div className="px-6 py-4 bg-black/[0.02] dark:bg-white/[0.02] flex items-center justify-end">
              <button
                type="button"
                onClick={() => setKioskRoom(null)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg transition-colors"
              >
                Selesai
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className={`fixed top-4 right-4 z-[60] max-w-sm rounded-lg shadow-lg p-4 flex items-start gap-3 ${
          toast.type === 'success'
            ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20'
            : 'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20'
        }`}>
          <div className="flex-shrink-0">
            <i className={`ri-check-line text-lg ${toast.type === 'success' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}></i>
          </div>
          <p className={`flex-1 text-sm font-medium ${toast.type === 'success' ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>
            {toast.message}
          </p>
          <button
            type="button"
            onClick={() => setToast(null)}
            className={`flex-shrink-0 transition-colors ${toast.type === 'success' ? 'text-green-400 hover:text-green-600' : 'text-red-400 hover:text-red-600'}`}
          >
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}
    </div>
  );
}
