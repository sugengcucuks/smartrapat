import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi } from '../../../shared/api/auth';
import { getErrorMessage } from '../../../shared/api/client';
import { useAuthStore } from '../../store/auth.store';
import type { LicenseStatus } from '@shared/types';

function formatFingerprint(fp: string) {
  if (!fp) return '';
  const chunks = fp.match(/.{1,8}/g) || [];
  const lines: string[] = [];
  for (let i = 0; i < chunks.length; i += 2) {
    lines.push(chunks.slice(i, i + 2).join('-'));
  }
  return lines.join('\n');
}

export function LicenseActivatePage() {
  const navigate = useNavigate();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const [status, setStatus] = useState<LicenseStatus | null>(null);
  const [licenseKey, setLicenseKey] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const loadStatus = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await authApi.getLicenseStatus();
      setStatus(res);
    } catch (err) {
      setError(getErrorMessage(err, 'Gagal membaca status lisensi dari server.'));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStatus();
  }, [loadStatus]);

  const submit = async () => {
    const key = licenseKey.trim();
    if (!key || submitting) return;
    setSubmitting(true);
    setError(null);
    setSuccess(null);
    try {
      const res = await authApi.activateLicense(key);
      setStatus(res.status);
      setSuccess(res.message || 'Lisensi berhasil diaktifkan');
      setLicenseKey('');
      window.setTimeout(() => navigate(isAuthenticated ? '/dashboard' : '/login'), 1500);
    } catch (err: unknown) {
      setError(getErrorMessage(err, 'Lisensi tidak valid. Periksa kembali berkas lisensi Anda.'));
    } finally {
      setSubmitting(false);
    }
  };

  const copyFingerprint = async () => {
    if (!status?.fingerprint) return;
    try {
      await navigator.clipboard.writeText(status.fingerprint);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="min-h-screen w-screen bg-gray flex items-center justify-center p-6">
      <div className="w-full max-w-3xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-primary/20 border-2 border-primary/40 mb-5">
            <i className="ri-shield-keyhole-line text-4xl text-primary"></i>
          </div>
          <h1 className="text-4xl font-black text-white">Aktivasi Lisensi</h1>
          <p className="text-white/60 mt-2 text-lg">
            Aplikasi Smart Meeting Room terkunci sampai lisensi valid dipasang pada perangkat ini.
          </p>
        </div>

        {loading ? (
          <div className="bg-white/5 border border-white/10 rounded-2xl p-12 flex flex-col items-center gap-3 text-white/70">
            <svg className="animate-spin h-9 w-9 text-primary" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
            <span>Memeriksa status lisensi...</span>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="bg-white/5 border border-white/10 rounded-2xl p-7">
              <div className="flex items-center justify-between flex-wrap gap-4 mb-5">
                <div className="flex items-center gap-3">
                  <i className="ri-fingerprint-line text-2xl text-primary"></i>
                  <div>
                    <div className="text-white font-bold text-lg">Fingerprint Perangkat Ini</div>
                    <div className="text-white/50 text-sm">
                      Kirimkan kode ini ke vendor untuk meminta berkas lisensi
                    </div>
                  </div>
                </div>
                {status?.fingerprint && (
                <button
                  type="button"
                  onClick={copyFingerprint}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-white/10 text-white text-sm font-semibold hover:bg-white/15 transition-colors"
                >
                  <i className={copied ? 'ri-check-line' : 'ri-file-copy-line'}></i>
                  {copied ? 'Tersalin' : 'Salin'}
                </button>
                )}
              </div>
              <pre className="font-mono text-primary-200 bg-black/40 rounded-xl p-5 text-lg leading-relaxed overflow-x-auto">
{status?.fingerprint
  ? formatFingerprint(status.fingerprint)
  : status?.activated
    ? 'Disembunyikan (hanya Super Admin yang dapat melihat fingerprint).'
    : '-'}
              </pre>
              <div className="mt-4 flex items-center gap-2 text-sm">
                <span className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full border ${
                  status?.activated
                    ? 'bg-success/10 text-success border-success/30'
                    : 'bg-danger/10 text-danger border-danger/30'
                }`}>
                  <i className={status?.activated ? 'ri-checkbox-circle-fill' : 'ri-lock-fill'}></i>
                  {status?.activated ? 'Lisensi Aktif' : 'Lisensi Belum Aktif'}
                </span>
                {status?.reason && <span className="text-white/50">{status.reason}</span>}
              </div>

              {status?.license && (
                <div className="mt-5 p-5 rounded-xl bg-success/5 border border-success/20 grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <div className="text-white/40">Pelanggan</div>
                    <div className="text-white font-semibold">{status.license.customer}</div>
                  </div>
                  <div>
                    <div className="text-white/40">Edisi</div>
                    <div className="text-white font-semibold capitalize">{status.license.edition}</div>
                  </div>
                  <div>
                    <div className="text-white/40">Berlaku s/d</div>
                    <div className="text-white font-semibold">
                      {status.license.expires_at || 'Permanen'}
                    </div>
                  </div>
                  <div>
                    <div className="text-white/40">Sisa Hari</div>
                    <div className="text-white font-semibold">
                      {status.days_remaining === null || status.days_remaining === undefined
                        ? 'Tidak terbatas'
                        : `${status.days_remaining} hari`}
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-7">
              <div className="flex items-center gap-3 mb-4">
                <i className="ri-key-2-line text-2xl text-primary"></i>
                <div className="text-white font-bold text-lg">Pasang Berkas Lisensi</div>
              </div>
              <textarea
                value={licenseKey}
                onChange={(e) => setLicenseKey(e.target.value)}
                rows={5}
                placeholder="Tempelkan isi berkas lisensi di sini (dimulai dengan SMR1....)"
                className="w-full px-4 py-3 font-mono text-sm rounded-xl bg-black/40 border border-white/10 text-white outline-none focus:border-primary transition-colors resize-none"
              />
              {error && (
                <div className="mt-3 p-3 rounded-lg bg-danger/10 border border-danger/30 text-danger text-sm flex items-start gap-2">
                  <i className="ri-error-warning-line text-lg shrink-0"></i>
                  {error}
                </div>
              )}
              {success && (
                <div className="mt-3 p-3 rounded-lg bg-success/10 border border-success/30 text-success text-sm flex items-center gap-2">
                  <i className="ri-checkbox-circle-fill text-lg"></i>
                  {success}
                </div>
              )}
              <button
                type="button"
                onClick={submit}
                disabled={submitting || !licenseKey.trim()}
                className="mt-5 w-full py-4 rounded-xl bg-primary text-white font-black text-lg hover:bg-primary/90 disabled:opacity-50 transition-colors inline-flex items-center justify-center gap-3"
              >
                {submitting ? (
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                ) : (
                  <i className="ri-shield-check-line text-2xl"></i>
                )}
                Aktifkan Lisensi
              </button>
              <button
                type="button"
                onClick={loadStatus}
                className="mt-3 w-full py-3 rounded-xl bg-white/5 text-white/70 font-semibold hover:bg-white/10 transition-colors"
              >
                Periksa Ulang Status
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
