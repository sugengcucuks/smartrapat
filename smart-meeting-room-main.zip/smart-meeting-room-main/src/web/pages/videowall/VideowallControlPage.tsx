import { useCallback, useEffect, useMemo, useState } from 'react';
import { authApi } from '../../../shared/api/auth';
import type { RoomAvCapabilities, VideowallConfig, VideowallInput } from '@shared/types';
import { RoomControlPanel } from '../../components/av/RoomControlPanel';
import { RoomSelect, useRoomSelection } from '../../components/av/RoomSelect';
import { CommandBadge, CommandDetail } from '../../components/av/CommandFeedback';
import { apiErrorMessage, hasPermission, useAvCommands } from '../../components/av/avUtils';
import { useAuthStore } from '../../store/auth.store';

interface CfgForm {
  config_name: string;
  layout_mode: string;
  inputs: VideowallInput[];
}

export function VideowallControlPage() {
  const user = useAuthStore((s) => s.user);
  const canControl = hasPermission(user, 'videowall.control');
  const canEdit = hasPermission(user, 'videowall.control', 'devices.write');
  const { rooms, roomId, setRoomId, error: roomsError, loading: roomsLoading } = useRoomSelection();

  const [caps, setCaps] = useState<RoomAvCapabilities | null>(null);
  const [configs, setConfigs] = useState<VideowallConfig[]>([]);
  const [listError, setListError] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<VideowallConfig | null>(null);
  const [form, setForm] = useState<CfgForm>({ config_name: '', layout_mode: '', inputs: [] });
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<VideowallConfig | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const { states, run, busy } = useAvCommands();

  const presets = caps?.videowall.presets || [];
  const sources = caps?.videowall.sources || [];
  const presetLabel = (id: string) => presets.find((p) => p.id === id)?.label || id;
  const sourceLabel = (id: string) => sources.find((s) => s.id === id)?.label || id;

  const loadConfigs = useCallback(async () => {
    if (!roomId) return;
    setListError(null);
    try {
      const [c, list] = await Promise.all([
        authApi.getRoomAvCapabilities(roomId),
        authApi.listVideowallConfigs({ room_id: roomId }),
      ]);
      setCaps(c);
      setConfigs(list);
    } catch (err) {
      setCaps(null);
      setConfigs([]);
      setListError(apiErrorMessage(err, 'Gagal memuat konfigurasi videowall'));
    }
  }, [roomId]);

  useEffect(() => {
    loadConfigs();
  }, [loadConfigs]);

  const windowsFor = useCallback(
    (presetId: string) => Math.max(1, presets.find((p) => p.id === presetId)?.windows.length || 1),
    [presets],
  );

  const resizeInputs = (presetId: string, inputs: VideowallInput[]): VideowallInput[] => {
    const n = windowsFor(presetId);
    return Array.from({ length: n }, (_, i) => inputs[i] || { input: '', window: i + 1 }).map((inp, i) => ({ ...inp, window: i + 1 }));
  };

  const openCreate = () => {
    const first = presets[0]?.id || '';
    setEditing(null);
    setForm({ config_name: '', layout_mode: first, inputs: resizeInputs(first, [{ input: sources[0]?.id || '', window: 1 }]) });
    setFormError(null);
    setShowModal(true);
  };

  const openEdit = (c: VideowallConfig) => {
    setEditing(c);
    setForm({ config_name: c.config_name, layout_mode: c.layout_mode, inputs: resizeInputs(c.layout_mode, c.inputs) });
    setFormError(null);
    setShowModal(true);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setFormError(null);
    const inputs = form.inputs.filter((i) => i.input).map((i) => ({ input: i.input, window: i.window }));
    try {
      if (editing) {
        await authApi.updateVideowallConfig(editing.id, { config_name: form.config_name, layout_mode: form.layout_mode, inputs });
      } else {
        await authApi.createVideowallConfig({ room_id: roomId, config_name: form.config_name, layout_mode: form.layout_mode, inputs });
      }
      setShowModal(false);
      loadConfigs();
    } catch (err) {
      setFormError(apiErrorMessage(err, 'Gagal menyimpan konfigurasi'));
    } finally {
      setSaving(false);
    }
  };

  const doDelete = async (c: VideowallConfig) => {
    setDeleteError(null);
    try {
      await authApi.deleteVideowallConfig(c.id);
      setDeleteConfirm(null);
      loadConfigs();
    } catch (err) {
      setDeleteError(apiErrorMessage(err, 'Gagal menghapus konfigurasi'));
    }
  };

  const lastApply = useMemo(() => Object.values(states).sort((a, b) => b.at - a.at)[0], [states]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Kontrol Videowall</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Power, layout & sumber videowall per ruangan. Status diperbarui langsung dari device agent.
          </p>
        </div>
        <RoomSelect rooms={rooms} value={roomId} onChange={setRoomId} />
      </div>

      {roomsError && <p className="text-sm text-red-600">{roomsError}</p>}
      {!roomsLoading && rooms.length === 0 && !roomsError && (
        <p className="text-sm text-black/60 dark:text-white/60">Belum ada ruangan.</p>
      )}

      {roomId && (
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="xl:col-span-2">
            <RoomControlPanel roomId={roomId} />
          </div>

          <div className="bg-white dark:bg-gray rounded-lg shadow-md p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-black dark:text-white">Skenario Tersimpan</h2>
                <p className="text-xs text-black/60 dark:text-white/60">Layout + sumber per jendela, sekali klik.</p>
              </div>
              {canEdit && presets.length > 0 && caps?.videowall.controller && (
                <button type="button" onClick={openCreate} title="Tambah skenario"
                  className="p-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors">
                  <i className="ri-add-line"></i>
                </button>
              )}
            </div>
            {listError && <p className="text-sm text-red-600">{listError}</p>}
            <CommandDetail state={lastApply} />
            {configs.length === 0 ? (
              <div className="py-10 text-center text-black/50 dark:text-white/50">
                <i className="ri-folder-line text-4xl text-black/30 dark:text-white/30"></i>
                <p className="mt-2 text-sm">Belum ada skenario</p>
              </div>
            ) : (
              <ul className="space-y-3">
                {configs.map((c) => (
                  <li key={c.id} className="p-3 border border-black/10 dark:border-white/10 rounded-lg">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h3 className="font-semibold text-sm text-black dark:text-white truncate">{c.config_name}</h3>
                        <p className="text-xs text-black/60 dark:text-white/60 mt-0.5">
                          {presetLabel(c.layout_mode)}
                          {c.inputs.length > 0 && ` · ${c.inputs.map((i) => `${i.window ?? '?'}:${sourceLabel(i.input)}`).join(', ')}`}
                        </p>
                      </div>
                      <CommandBadge state={states[`apply-${c.id}`]} />
                    </div>
                    <div className="flex items-center gap-1 mt-2">
                      {canControl && (
                        <button type="button" disabled={busy} onClick={() => run(`apply-${c.id}`, () => authApi.applyVideowallConfig(c.id))}
                          className="px-2 py-1 text-xs text-primary hover:bg-primary/10 rounded inline-flex items-center gap-1 disabled:opacity-50">
                          <i className="ri-play-circle-line"></i> Terapkan
                        </button>
                      )}
                      {canEdit && (
                        <>
                          <button type="button" onClick={() => openEdit(c)} title="Ubah"
                            className="p-1.5 text-black/60 dark:text-white/60 hover:text-primary hover:bg-primary/10 rounded">
                            <i className="ri-edit-line text-sm"></i>
                          </button>
                          <button type="button" onClick={() => { setDeleteError(null); setDeleteConfirm(c); }} title="Hapus"
                            className="p-1.5 text-black/60 dark:text-white/60 hover:text-red-600 hover:bg-red-500/10 rounded">
                            <i className="ri-delete-bin-line text-sm"></i>
                          </button>
                        </>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setShowModal(false)}>
          <div className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-lg overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="px-6 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold text-black dark:text-white">{editing ? 'Ubah Skenario' : 'Tambah Skenario'}</h2>
              <button type="button" onClick={() => setShowModal(false)} className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/5">
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <form onSubmit={submit}>
              <div className="px-6 py-5 space-y-4">
                {formError && (
                  <div className="p-3 rounded-lg bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 text-sm">
                    <i className="ri-error-warning-line mr-1"></i>{formError}
                  </div>
                )}
                <div>
                  <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Nama <span className="text-red-500">*</span></label>
                  <input type="text" required maxLength={100} value={form.config_name}
                    onChange={(e) => setForm({ ...form, config_name: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary dark:text-white/80" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">Layout</label>
                  <select value={form.layout_mode}
                    onChange={(e) => setForm({ ...form, layout_mode: e.target.value, inputs: resizeInputs(e.target.value, form.inputs) })}
                    className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary dark:text-white/80">
                    {presets.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-black/70 dark:text-white/70">Sumber per jendela</p>
                  {form.inputs.map((inp, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <span className="text-xs text-black/60 dark:text-white/60 w-20">Jendela {i + 1}</span>
                      <select value={inp.input}
                        onChange={(e) => setForm({ ...form, inputs: form.inputs.map((x, j) => (j === i ? { ...x, input: e.target.value } : x)) })}
                        className="flex-1 px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary dark:text-white/80">
                        <option value="">(tidak diubah)</option>
                        {sources.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
                      </select>
                    </div>
                  ))}
                </div>
              </div>
              <div className="px-6 py-4 border-t border-black/10 dark:border-white/10 flex justify-end gap-3">
                <button type="button" onClick={() => setShowModal(false)} disabled={saving}
                  className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 rounded-lg disabled:opacity-50">
                  Batal
                </button>
                <button type="submit" disabled={saving}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg disabled:opacity-50">
                  {saving && <i className="ri-loader-4-line animate-spin"></i>}Simpan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white dark:bg-gray rounded-lg shadow-xl w-full max-w-md p-6 space-y-4" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-black dark:text-white">Hapus Skenario</h3>
            <p className="text-sm text-black/60 dark:text-white/60">
              Hapus <span className="font-semibold">{deleteConfirm.config_name}</span>?
            </p>
            {deleteError && <p className="text-sm text-red-600">{deleteError}</p>}
            <div className="flex justify-end gap-3">
              <button type="button" onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 text-sm font-medium text-black/70 dark:text-white/70 bg-black/5 dark:bg-white/5 rounded-lg">Batal</button>
              <button type="button" onClick={() => doDelete(deleteConfirm)}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg">Hapus</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
