import { useEffect, useMemo, useState } from 'react';
import { authApi } from '../../../shared/api/auth';
import { getErrorMessage } from '../../../shared/api/client';
import { usePermission } from '../../store/auth.store';
import type { SystemSetting, SystemSettingGroup } from '@shared/types';

type Tab = SystemSettingGroup;
type FieldType = 'text' | 'number' | 'email' | 'bool' | 'textarea' | 'secret';

interface FieldDef {
  name: string;
  label: string;
  type: FieldType;
  /**
   * Key system_settings. Key pertama = key utama; sisanya alias (nama lama di seed DB).
   * Nilai dibaca dari key pertama yang ada, dan disimpan ke semua key yang ada.
   */
  keys: string[];
  placeholder?: string;
  hint?: string;
  wide?: boolean;
}

const FIELDS: Record<Tab, FieldDef[]> = {
  authentication: [
    { name: 'session_timeout', label: 'Session Timeout (menit)', type: 'number', keys: ['auth_session_timeout', 'session_timeout_minutes'], placeholder: '60' },
    { name: 'password_min_length', label: 'Panjang Minimal Password', type: 'number', keys: ['auth_password_min_length', 'min_password_length'], placeholder: '8' },
    { name: 'max_failed_login', label: 'Maksimal Gagal Login', type: 'number', keys: ['auth_max_failed_login', 'max_login_attempts'], placeholder: '5' },
    { name: 'require_special', label: 'Password wajib mengandung karakter khusus (!@#$%^&*)', type: 'bool', keys: ['auth_password_require_special', 'require_special_char'] },
  ],
  email: [
    { name: 'smtp_host', label: 'SMTP Host', type: 'text', keys: ['smtp_host', 'email_host'], placeholder: 'smtp.gmail.com' },
    { name: 'smtp_port', label: 'SMTP Port', type: 'number', keys: ['smtp_port', 'email_port'], placeholder: '587' },
    { name: 'smtp_user', label: 'SMTP Username', type: 'text', keys: ['smtp_user', 'email_user'], placeholder: 'user@domain.com' },
    { name: 'smtp_pass', label: 'SMTP Password', type: 'secret', keys: ['smtp_pass', 'email_pass'] },
    { name: 'smtp_from', label: 'Alamat Pengirim', type: 'text', keys: ['smtp_from', 'email_from', 'from_email'], placeholder: 'Smart Meeting Room <no-reply@domain.com>' },
    { name: 'smtp_tls', label: 'Gunakan koneksi TLS/STARTTLS', type: 'bool', keys: ['smtp_tls', 'email_tls'] },
  ],
  company: [
    { name: 'company_name', label: 'Nama Perusahaan', type: 'text', keys: ['company_name'], placeholder: 'PT. Nama Perusahaan', wide: true },
    { name: 'company_logo_url', label: 'Logo URL', type: 'text', keys: ['company_logo_url'], placeholder: 'https://.../logo.png', wide: true },
    { name: 'company_address', label: 'Alamat Perusahaan', type: 'textarea', keys: ['company_address'], wide: true },
    { name: 'company_phone', label: 'Nomor Telepon', type: 'text', keys: ['company_phone'], placeholder: '+62 21 12345678' },
  ],
  booking: [
    { name: 'max_days_ahead', label: 'Batas Pemesanan (hari di muka)', type: 'number', keys: ['booking_max_days_ahead', 'booking_default_advance_days'], placeholder: '30' },
    { name: 'min_minutes', label: 'Durasi Minimal (menit)', type: 'number', keys: ['booking_min_minutes'], placeholder: '15' },
    { name: 'max_hours', label: 'Durasi Maksimal (jam)', type: 'number', keys: ['booking_max_hours'], placeholder: '8' },
    { name: 'extra_time', label: 'Waktu Tambahan yang Diizinkan (menit)', type: 'number', keys: ['booking_allowed_extra_time'], placeholder: '30' },
    { name: 'auto_approve_staff', label: 'Otomatis setujui pemesanan dari staff (non-admin)', type: 'bool', keys: ['booking_auto_approve_staff', 'auto_approve_staff'] },
  ],
  notification: [
    { name: 'email_enabled', label: 'Notifikasi Email', type: 'bool', keys: ['notify_email_enabled', 'email_enabled'], hint: 'Kirim notifikasi melalui email untuk update pemesanan, persetujuan, dll' },
    { name: 'push_enabled', label: 'Notifikasi Push / In-App', type: 'bool', keys: ['notify_push_enabled', 'push_enabled'], hint: 'Tampilkan notifikasi pop-up di aplikasi / browser' },
  ],
  maintenance: [
    { name: 'maintenance_mode', label: 'Mode Pemeliharaan', type: 'bool', keys: ['maintenance_mode'], hint: 'Jika diaktifkan, pengguna non-admin akan melihat banner dan fitur non-kritis akan dibatasi.' },
    { name: 'maintenance_message', label: 'Teks Banner Pemeliharaan', type: 'textarea', keys: ['maintenance_message', 'maintenance_banner'], wide: true },
  ],
};

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: 'authentication', label: 'Otentikasi', icon: 'ri-shield-keyhole-line' },
  { id: 'email', label: 'Email', icon: 'ri-mail-line' },
  { id: 'company', label: 'Perusahaan', icon: 'ri-building-2-line' },
  { id: 'booking', label: 'Pemesanan', icon: 'ri-calendar-line' },
  { id: 'notification', label: 'Notifikasi', icon: 'ri-notification-3-line' },
  { id: 'maintenance', label: 'Pemeliharaan', icon: 'ri-settings-3-line' },
];

const inputCls =
  'w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80 disabled:opacity-60';

const isTrue = (v: string | undefined) => v === 'true' || v === '1';

function Toggle({ checked, onChange, disabled }: { checked: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <label className={`inline-flex items-center ${disabled ? 'cursor-not-allowed opacity-60' : 'cursor-pointer'}`}>
      <input type="checkbox" className="sr-only peer" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <div className="relative w-11 h-6 bg-black/15 dark:bg-white/15 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-success"></div>
      <span className={`ml-2 text-sm font-medium ${checked ? 'text-success' : 'text-black/50 dark:text-white/50'}`}>
        {checked ? 'Aktif' : 'Nonaktif'}
      </span>
    </label>
  );
}

export function SettingsPage() {
  const can = usePermission();
  const canWrite = can('settings.write');
  const [tab, setTab] = useState<Tab>('authentication');
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  /** Pengaturan mentah dari server, per key. */
  const [serverSettings, setServerSettings] = useState<Record<string, SystemSetting>>({});
  /** Nilai form per nama field. */
  const [values, setValues] = useState<Record<string, string>>({});
  /** Field rahasia yang diketik ulang oleh user (hanya ini yang dikirim). */
  const [touchedSecrets, setTouchedSecrets] = useState<Set<string>>(new Set());

  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 4000);
  };

  const existingKeys = (f: FieldDef) => f.keys.filter((k) => k in serverSettings);

  const isSecretField = (f: FieldDef) =>
    f.type === 'secret' || existingKeys(f).some((k) => serverSettings[k]?.is_secret);

  const fetchSettings = async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const data = await authApi.getAllSettings();
      const byKey: Record<string, SystemSetting> = {};
      for (const s of data ?? []) byKey[s.key] = s;
      setServerSettings(byKey);
      const next: Record<string, string> = {};
      for (const fields of Object.values(FIELDS)) {
        for (const f of fields) {
          const key = f.keys.find((k) => k in byKey);
          const secret = f.type === 'secret' || (key ? !!byKey[key]?.is_secret : false);
          next[f.name] = key && !secret ? byKey[key].value ?? '' : '';
        }
      }
      setValues(next);
      setTouchedSecrets(new Set());
    } catch (err) {
      setLoadError(getErrorMessage(err, 'Gagal memuat pengaturan'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const setValue = (f: FieldDef, v: string) => {
    setValues((prev) => ({ ...prev, [f.name]: v }));
    if (isSecretField(f)) setTouchedSecrets((prev) => new Set(prev).add(f.name));
  };

  const handleSave = async (group: Tab) => {
    const settings: Record<string, string> = {};
    for (const f of FIELDS[group]) {
      // Rahasia: kirim hanya bila diketik ulang (backend mengabaikan "" untuk key rahasia).
      if (isSecretField(f) && (!touchedSecrets.has(f.name) || !values[f.name])) continue;
      // Selalu tulis key utama (dibuat backend bila belum ada, mis. smtp_* yang dibaca mailer)
      // dan sinkronkan alias lama yang sudah ada di DB.
      const keys = new Set([f.keys[0], ...existingKeys(f)]);
      for (const k of keys) settings[k] = values[f.name] ?? '';
    }
    if (Object.keys(settings).length === 0) {
      showToast('success', 'Tidak ada perubahan untuk disimpan');
      return;
    }
    setSaving(true);
    try {
      const res = await authApi.batchUpdateSettings({ settings });
      const count = res?.updated_count ?? res?.count ?? res?.updated_keys?.length ?? 0;
      showToast('success', count > 0 ? `Pengaturan berhasil disimpan (${count} diperbarui)` : 'Tidak ada perubahan');
      await fetchSettings();
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal menyimpan pengaturan'));
    } finally {
      setSaving(false);
    }
  };

  const renderField = (f: FieldDef) => {
    const disabled = !canWrite || saving;
    if (f.type === 'bool') {
      return (
        <div key={f.name} className="sm:col-span-2 flex items-center gap-3 p-4 bg-black/[0.02] dark:bg-white/[0.02] rounded-lg">
          <Toggle checked={isTrue(values[f.name])} onChange={(v) => setValue(f, String(v))} disabled={disabled} />
          <div>
            <p className="text-sm font-medium text-black/80 dark:text-white/80">{f.label}</p>
            {f.hint && <p className="text-xs text-black/50 dark:text-white/50 mt-0.5">{f.hint}</p>}
          </div>
        </div>
      );
    }
    const secret = isSecretField(f);
    const secretStored =
      secret && existingKeys(f).some((k) => serverSettings[k]?.has_value ?? true);
    return (
      <div key={f.name} className={f.wide || f.type === 'textarea' ? 'sm:col-span-2' : ''}>
        <label className="block text-sm font-medium text-black/70 dark:text-white/70 mb-1.5">{f.label}</label>
        {f.type === 'textarea' ? (
          <textarea
            rows={3}
            value={values[f.name] ?? ''}
            onChange={(e) => setValue(f, e.target.value)}
            placeholder={f.placeholder}
            disabled={disabled}
            className={`${inputCls} resize-none`}
          />
        ) : (
          <input
            type={secret ? 'password' : f.type}
            value={values[f.name] ?? ''}
            onChange={(e) => setValue(f, e.target.value)}
            placeholder={secret ? (secretStored ? '••••• (tersimpan)' : 'Belum diatur') : f.placeholder}
            autoComplete={secret ? 'new-password' : undefined}
            disabled={disabled}
            className={inputCls}
          />
        )}
        {secret && (
          <p className="mt-1 text-xs text-black/50 dark:text-white/50">Kosongkan bila tidak ingin mengubah password.</p>
        )}
        {f.hint && <p className="mt-1 text-xs text-black/50 dark:text-white/50">{f.hint}</p>}
      </div>
    );
  };

  const currentFields = useMemo(() => {
    const fields = FIELDS[tab];
    // Teks banner hanya relevan bila mode pemeliharaan aktif.
    if (tab === 'maintenance' && !isTrue(values.maintenance_mode)) {
      return fields.filter((f) => f.name !== 'maintenance_message');
    }
    return fields;
  }, [tab, values.maintenance_mode]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-black dark:text-white">Pengaturan Sistem</h1>
        <p className="text-sm text-black/60 dark:text-white/60 mt-1">
          Konfigurasi parameter aplikasi sesuai kebutuhan organisasi
        </p>
      </div>

      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
        <div className="flex gap-1 border-b border-black/10 dark:border-white/10 mb-6 overflow-x-auto">
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`relative flex items-center gap-2 px-4 py-2.5 text-sm font-medium whitespace-nowrap transition-colors ${
                tab === t.id ? 'text-primary' : 'text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white'
              }`}
            >
              <i className={t.icon}></i>
              {t.label}
              {tab === t.id && <span className="absolute left-0 right-0 -bottom-px h-0.5 bg-primary rounded-t"></span>}
            </button>
          ))}
        </div>

        {!canWrite && !loading && !loadError && (
          <div className="mb-5 rounded-lg border border-info/30 bg-info/10 p-3 text-sm text-black/70 dark:text-white/70">
            Anda hanya memiliki akses baca. Perubahan pengaturan memerlukan izin <code>settings.write</code>.
          </div>
        )}

        {loading ? (
          <div className="py-12 text-center text-sm text-black/50 dark:text-white/50">Memuat pengaturan...</div>
        ) : loadError ? (
          <div className="py-12 text-center">
            <p className="text-sm text-red-600 dark:text-red-400">{loadError}</p>
            <button
              type="button"
              onClick={fetchSettings}
              className="mt-3 inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-primary bg-primary/10 hover:bg-primary/15 rounded-lg"
            >
              <i className="ri-refresh-line"></i> Coba Lagi
            </button>
          </div>
        ) : (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSave(tab);
            }}
            className="space-y-5 max-w-2xl"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">{currentFields.map(renderField)}</div>
            {canWrite && (
              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={saving}
                  className="inline-flex items-center gap-2 px-5 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {saving && (
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                  )}
                  <i className="ri-save-line"></i>
                  <span>Simpan Pengaturan</span>
                </button>
              </div>
            )}
          </form>
        )}
      </div>

      {toast && (
        <div className={`fixed top-4 right-4 z-[60] max-w-sm rounded-lg shadow-lg p-4 flex items-start gap-3 ${
          toast.type === 'success'
            ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20'
            : 'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20'
        }`}>
          <div className="flex-shrink-0">
            {toast.type === 'success' ? (
              <i className="ri-check-line text-lg text-green-600 dark:text-green-400"></i>
            ) : (
              <i className="ri-error-warning-line text-lg text-red-600 dark:text-red-400"></i>
            )}
          </div>
          <p className={`flex-1 text-sm font-medium ${toast.type === 'success' ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>
            {toast.message}
          </p>
          <button
            type="button"
            onClick={() => setToast(null)}
            className={`flex-shrink-0 transition-colors ${toast.type === 'success' ? 'text-green-400 hover:text-green-600' : 'text-red-400 hover:text-red-600'}`}
          >
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}
    </div>
  );
}
