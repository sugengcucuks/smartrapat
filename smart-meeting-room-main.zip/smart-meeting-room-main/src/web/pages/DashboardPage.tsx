import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore, usePermission } from '../store/auth.store';
import { authApi } from '../../shared/api/auth';
import { getErrorMessage } from '../../shared/api/client';
import type { DashboardSummary } from '@shared/types';
import type { AxiosError } from 'axios';

export function DashboardPage() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const can = usePermission();
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchSummary = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await authApi.getDashboardSummary();
      setSummary(data);
      setLastUpdated(new Date());
    } catch (err) {
      const status = (err as AxiosError)?.response?.status;
      setError(
        status === 403
          ? 'Ringkasan statistik tidak tersedia untuk akun Anda.'
          : getErrorMessage(err, 'Gagal memuat ringkasan dashboard')
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSummary();
  }, []);

  const STAT_CARDS = summary
    ? [
        { label: 'Total Ruangan', value: summary.total_rooms, icon: 'ri-building-line', color: 'primary' },
        { label: 'Total Pengguna', value: summary.total_users, icon: 'ri-user-line', color: 'info' },
        { label: 'Pemesanan Hari Ini', value: summary.today_bookings, icon: 'ri-calendar-check-line', color: 'success' },
        { label: 'Rapat Berlangsung', value: summary.ongoing_meetings, icon: 'ri-time-line', color: 'warning' },
        { label: 'Perangkat Online', value: summary.online_devices, icon: 'ri-monitor-line', color: 'info' },
        { label: 'Persetujuan Menunggu', value: summary.pending_approvals, icon: 'ri-clock-line', color: 'warning' },
        { label: '% Utilisasi Ruangan', value: `${Number(summary.room_utilization_percent ?? 0).toFixed(1)}%`, icon: 'ri-pie-chart-line', color: 'success' },
        { label: 'Rata-rata Durasi', value: `${Math.round(Number(summary.avg_meeting_duration_minutes ?? 0))} mnt`, icon: 'ri-timer-line', color: 'primary' },
      ]
    : [];

  const quickActions = [
    { show: can(['bookings.create', 'bookings.approve']), path: '/bookings/new', label: 'Booking Cepat', icon: 'ri-add-line', color: 'primary' },
    { show: true, path: '/calendar', label: 'Lihat Jadwal', icon: 'ri-calendar-line', color: 'success' },
    { show: can(['rooms.view', 'rooms.write']), path: '/rooms', label: 'Kelola Ruangan', icon: 'ri-door-open-line', color: 'warning' },
    { show: can('reports.view'), path: '/reports', label: 'Lihat Laporan', icon: 'ri-bar-chart-line', color: 'info' },
  ].filter((a) => a.show);

  const actionHover: Record<string, string> = {
    primary: 'hover:bg-primary/5 hover:border-primary',
    success: 'hover:bg-success/5 hover:border-success',
    warning: 'hover:bg-warning/5 hover:border-warning',
    info: 'hover:bg-info/5 hover:border-info',
  };
  const actionIcon: Record<string, string> = {
    primary: 'bg-primary/10 group-hover:bg-primary text-primary',
    success: 'bg-success/10 group-hover:bg-success text-success',
    warning: 'bg-warning/10 group-hover:bg-warning text-warning',
    info: 'bg-info/10 group-hover:bg-info text-info',
  };

  const colorStyles: Record<string, string> = {
    primary: 'bg-primary/10 text-primary',
    success: 'bg-success/10 text-success',
    info: 'bg-info/10 text-info',
    warning: 'bg-warning/10 text-warning',
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-black dark:text-white">Dashboard</h1>
          <p className="text-sm text-black/60 dark:text-white/60 mt-1">
            Selamat datang, {user?.name || 'Administrator'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={fetchSummary}
            className="p-2 text-black/60 dark:text-white/60 hover:text-primary hover:bg-primary/5 rounded-lg transition-colors"
            title="Refresh"
          >
            <i className={`ri-refresh-line text-lg ${loading ? 'animate-spin' : ''}`}></i>
          </button>
          <span className="text-sm text-black/60 dark:text-white/60">
            Terakhir diperbarui:{' '}
            {lastUpdated
              ? lastUpdated.toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'medium' })
              : loading
                ? 'memuat...'
                : '-'}
          </span>
        </div>
      </div>

      {error && (
        <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6 text-center">
          <p className="text-sm text-black/70 dark:text-white/70">{error}</p>
          <button
            type="button"
            onClick={fetchSummary}
            className="mt-3 inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-primary bg-primary/10 hover:bg-primary/15 rounded-lg"
          >
            <i className="ri-refresh-line"></i> Coba Lagi
          </button>
        </div>
      )}

      {!summary && loading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="bg-white dark:bg-gray rounded-lg shadow-md p-6 h-24 animate-pulse" />
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {STAT_CARDS.map((c) => (
          <div key={c.label} className="bg-white dark:bg-gray rounded-lg shadow-md p-6 flex items-center gap-4">
            <div className={`w-12 h-12 rounded-lg ${colorStyles[c.color] || colorStyles.primary} flex items-center justify-center shrink-0`}>
              <i className={`${c.icon} text-2xl`}></i>
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm text-black/60 dark:text-white/60 truncate">{c.label}</p>
              <h3 className={`text-2xl font-bold text-black dark:text-white ${loading ? 'animate-pulse' : ''}`}>
                {c.value}
              </h3>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
        <h2 className="text-lg font-bold text-black dark:text-white mb-4">Aksi Cepat</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((a) => (
            <button
              key={a.path}
              type="button"
              onClick={() => navigate(a.path)}
              className={`flex flex-col items-center justify-center p-6 border border-black/10 dark:border-white/10 rounded-lg ${actionHover[a.color]} transition-all group`}
            >
              <div className={`w-12 h-12 rounded-lg ${actionIcon[a.color]} flex items-center justify-center mb-3 group-hover:text-white transition-all`}>
                <i className={`${a.icon} text-2xl group-hover:text-white`}></i>
              </div>
              <span className="text-sm font-medium text-black dark:text-white">{a.label}</span>
            </button>
          ))}
        </div>

      </div>
    </div>
  );
}
