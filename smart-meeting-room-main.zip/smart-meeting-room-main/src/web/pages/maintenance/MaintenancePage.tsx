import { useEffect, useRef, useState } from 'react';
import { authApi } from '../../../shared/api/auth';
import { downloadFile, getErrorMessage } from '../../../shared/api/client';
import type { SystemHealth, Migration, BackupResponse } from '@shared/types';

type MaintTab = 'health' | 'backup' | 'migrations' | 'cache' | 'info';

function formatDateTime(dateStr?: string | null) {
  if (!dateStr) return '-';
  return new Date(dateStr).toLocaleString('id-ID', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

function formatUptime(seconds: number) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const parts = [];
  if (d) parts.push(`${d} hari`);
  if (h) parts.push(`${h} jam`);
  parts.push(`${m} menit`);
  return parts.join(', ');
}

function formatBytes(bytes: number) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
  return `${(bytes / 1024 ** i).toFixed(i ? 1 : 0)} ${units[i]}`;
}

// Rute ini dijaga RequirePermission('system.maintenance') di App.tsx.
export function MaintenancePage() {
  const [tab, setTab] = useState<MaintTab>('health');
  const [loading, setLoading] = useState(false);
  const [health, setHealth] = useState<SystemHealth | null>(null);
  const [healthError, setHealthError] = useState<string | null>(null);
  const [migrations, setMigrations] = useState<Migration[]>([]);
  const [migrationsError, setMigrationsError] = useState<string | null>(null);

  const [runningAction, setRunningAction] = useState<string | null>(null);
  const [backups, setBackups] = useState<BackupResponse[]>([]);
  const [backupsError, setBackupsError] = useState<string | null>(null);
  const [restoreFile, setRestoreFile] = useState<File | null>(null);
  const [restoreConfirm, setRestoreConfirm] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [seedConfirm1, setSeedConfirm1] = useState(false);
  const [seedConfirm2, setSeedConfirm2] = useState(false);

  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const safeMigrations = migrations ?? [];

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 4000);
  };

  const pendingMigrationCount = safeMigrations.filter((m) => m.status === 'pending').length;

  const fetchHealth = async () => {
    setLoading(true);
    setHealthError(null);
    try {
      const data = await authApi.getSystemHealth();
      setHealth(data);
    } catch (err) {
      setHealth(null);
      setHealthError(getErrorMessage(err, 'Gagal memuat status sistem'));
    } finally {
      setLoading(false);
    }
  };

  const fetchMigrations = async () => {
    setMigrationsError(null);
    try {
      const data = await authApi.getMigrationsList();
      setMigrations(data?.migrations ?? []);
    } catch (err) {
      setMigrations([]);
      setMigrationsError(getErrorMessage(err, 'Gagal memuat daftar migrasi'));
    }
  };

  const fetchBackups = async () => {
    setBackupsError(null);
    try {
      const data = await authApi.listBackups();
      setBackups(data ?? []);
    } catch (err) {
      setBackups([]);
      setBackupsError(getErrorMessage(err, 'Gagal memuat daftar backup'));
    }
  };

  useEffect(() => {
    fetchHealth();
    fetchMigrations();
    fetchBackups();
  }, []);

  const handleBackup = async () => {
    setRunningAction('backup');
    try {
      const res = await authApi.backupDatabase();
      showToast('success', `Backup dibuat: ${res.filename} (${formatBytes(res.size_bytes)})`);
      fetchHealth();
      fetchBackups();
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal membuat backup'));
    } finally {
      setRunningAction(null);
    }
  };

  const handleDownloadBackup = async (backup: BackupResponse) => {
    const url = backup.download_url;
    if (!url) {
      showToast('error', 'Berkas backup belum tersedia untuk diunduh dari server.');
      return;
    }
    // download_url absolut (/api/v1/...) -> jadikan relatif terhadap base API (butuh header Bearer).
    const path = url.replace(/^\/api\/v1/, '');
    try {
      await downloadFile(path, undefined, backup.filename);
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal mengunduh backup'));
    }
  };

  const handleRestore = async () => {
    if (!restoreFile) return;
    setRunningAction('restore');
    try {
      const fd = new FormData();
      fd.append('file', restoreFile);
      fd.append('confirm', restoreConfirm.trim());
      const res = await authApi.restoreDatabase(fd);
      if (res?.success === false) {
        showToast('error', res.message || 'Gagal memulihkan database');
      } else {
        showToast('success', res?.message || 'Database berhasil dipulihkan');
        setRestoreFile(null);
        setRestoreConfirm('');
        if (fileInputRef.current) fileInputRef.current.value = '';
        fetchHealth();
      }
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal memulihkan database'));
    } finally {
      setRunningAction(null);
    }
  };

  const handleRunMigrations = async () => {
    setRunningAction('migrations');
    try {
      const res = await authApi.runMigrations();
      const errors = res?.errors ?? [];
      if (errors.length > 0) {
        showToast('error', `${res.files_run.length} migrasi dijalankan, ${errors.length} gagal: ${errors.map((e) => e.file).join(', ')}`);
      } else {
        showToast('success', `${res?.files_run?.length ?? 0} migrasi berhasil dijalankan`);
      }
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal menjalankan migrasi'));
    } finally {
      fetchMigrations();
      fetchHealth();
      setRunningAction(null);
    }
  };

  const handleClearCache = async () => {
    setRunningAction('cache');
    try {
      const res = await authApi.clearCache();
      showToast('success', res?.message || 'Cache berhasil dibersihkan');
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal membersihkan cache'));
    } finally {
      setRunningAction(null);
    }
  };

  const handleSeedDemo = async () => {
    setRunningAction('seed');
    try {
      const res = await authApi.seedDemoData();
      showToast('success', res?.message || `Seed demo: ${res?.users_created ?? 0} pengguna, ${res?.bookings_created ?? 0} pemesanan`);
      fetchHealth();
    } catch (err) {
      showToast('error', getErrorMessage(err, 'Gagal membuat data demo'));
    } finally {
      setRunningAction(null);
      setSeedConfirm1(false);
      setSeedConfirm2(false);
    }
  };

  const TabButton = ({ id, label, icon, badge }: { id: MaintTab; label: string; icon: string; badge?: number }) => (
    <button
      type="button"
      onClick={() => setTab(id)}
      className={`relative flex items-center gap-2 px-4 py-2.5 text-sm font-medium whitespace-nowrap transition-colors ${
        tab === id ? 'text-primary' : 'text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white'
      }`}
    >
      <i className={icon}></i>
      {label}
      {badge !== undefined && badge > 0 && (
        <span className="inline-flex items-center justify-center min-w-5 h-5 px-1.5 rounded-full text-[10px] font-bold bg-warning text-black">
          {badge}
        </span>
      )}
      {tab === id && (
        <span className="absolute left-0 right-0 -bottom-px h-0.5 bg-primary rounded-t"></span>
      )}
    </button>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-black dark:text-white">Pemeliharaan Sistem</h1>
        <p className="text-sm text-black/60 dark:text-white/60 mt-1">
          Alat bantu untuk memantau kesehatan, backup, migrasi, dan perawatan sistem
        </p>
      </div>

      <div className="bg-white dark:bg-gray rounded-lg shadow-md p-6">
        <div className="flex gap-1 border-b border-black/10 dark:border-white/10 mb-6 overflow-x-auto">
          <TabButton id="health" label="Kesehatan Sistem" icon="ri-heart-pulse-line" />
          <TabButton id="backup" label="Backup DB" icon="ri-database-2-line" />
          <TabButton id="migrations" label="Migrasi Database" icon="ri-stack-line" badge={pendingMigrationCount} />
          <TabButton id="cache" label="Cache &amp; Reset" icon="ri-refresh-line" />
          <TabButton id="info" label="Info Aplikasi" icon="ri-information-line" />
        </div>

        {tab === 'health' && (
          <div className="space-y-6">
            <div className="flex items-center justify-end">
              <button
                type="button"
                onClick={fetchHealth}
                disabled={loading}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-primary bg-primary/5 hover:bg-primary/10 rounded-lg transition-colors disabled:opacity-50"
              >
                <i className={`ri-refresh-line ${loading ? 'animate-spin' : ''}`}></i>
                <span>Refresh Health</span>
              </button>
            </div>

            {healthError && (
              <div className="py-8 text-center">
                <p className="text-sm text-red-600 dark:text-red-400">{healthError}</p>
              </div>
            )}
            {!health && loading && (
              <div className="py-8 text-center text-sm text-black/50 dark:text-white/50">Memuat status sistem...</div>
            )}
            {health && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="p-5 border border-black/5 dark:border-white/5 rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <p className="text-sm text-black/50 dark:text-white/50">Koneksi Database</p>
                  {health.db_status === 'connected' ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-green-100 dark:bg-green-500/10 text-green-700 dark:text-green-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-600 dark:bg-green-400 animate-pulse"></span>
                      Terhubung
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-red-100 dark:bg-red-500/10 text-red-700 dark:text-red-400">
                      Putus
                    </span>
                  )}
                </div>
                <p className="text-xs text-black/40 dark:text-white/40">
                  {health.pending_backup ? 'Belum ada backup terbaru' : 'Backup terbaru tersedia'}
                </p>
              </div>

              <div className="p-5 border border-black/5 dark:border-white/5 rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <p className="text-sm text-black/50 dark:text-white/50">Uptime</p>
                  <i className="ri-time-line text-primary text-lg"></i>
                </div>
                <p className="text-base font-semibold text-black dark:text-white">{formatUptime(health.uptime_seconds)}</p>
                <p className="text-xs text-black/40 dark:text-white/40 mt-1">Sejak {formatDateTime(health.started_at)}</p>
              </div>

              <div className="p-5 border border-black/5 dark:border-white/5 rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <p className="text-sm text-black/50 dark:text-white/50">Penyimpanan</p>
                  <i className="ri-hard-drive-2-line text-info text-lg"></i>
                </div>
                <div className="w-full h-2 bg-black/5 dark:bg-white/5 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${health.storage_used_pct > 80 ? 'bg-red-500' : health.storage_used_pct > 60 ? 'bg-warning' : 'bg-success'}`}
                    style={{ width: `${Math.min(100, health.storage_used_pct)}%` }}
                  ></div>
                </div>
                <p className="text-xs text-black/40 dark:text-white/40 mt-1">{Number(health.storage_used_pct ?? 0).toFixed(1)}% terpakai</p>
              </div>

              <div className="p-5 border border-black/5 dark:border-white/5 rounded-lg">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm text-black/50 dark:text-white/50">Total Pengguna</p>
                  <i className="ri-user-line text-primary text-lg"></i>
                </div>
                <p className="text-2xl font-bold text-black dark:text-white">{health.total_users}</p>
              </div>

              <div className="p-5 border border-black/5 dark:border-white/5 rounded-lg">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm text-black/50 dark:text-white/50">Total Ruangan</p>
                  <i className="ri-building-line text-success text-lg"></i>
                </div>
                <p className="text-2xl font-bold text-black dark:text-white">{health.total_rooms}</p>
              </div>

              <div className="p-5 border border-black/5 dark:border-white/5 rounded-lg">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm text-black/50 dark:text-white/50">Total Pemesanan</p>
                  <i className="ri-calendar-check-line text-warning text-lg"></i>
                </div>
                <p className="text-2xl font-bold text-black dark:text-white">{health.total_bookings.toLocaleString('id-ID')}</p>
              </div>
            </div>
            )}
          </div>
        )}

        {tab === 'backup' && (
          <div className="space-y-6 max-w-3xl">
            <div className="p-5 border border-black/5 dark:border-white/5 rounded-lg">
              <div className="flex items-start justify-between gap-4 mb-5">
                <div className="flex items-start gap-3">
                  <div className="w-11 h-11 rounded-lg bg-success/10 flex items-center justify-center shrink-0">
                    <i className="ri-save-3-line text-xl text-success"></i>
                  </div>
                  <div>
                    <h3 className="text-base font-semibold text-black dark:text-white">Backup Database</h3>
                    <p className="text-xs text-black/50 dark:text-white/50 mt-0.5">
                      Buat cadangan lengkap database (schema + data) dalam format .sql
                    </p>
                    {health && (
                      <p className="text-xs text-black/40 dark:text-white/40 mt-2">
                        Status: <span className="font-medium text-black/60 dark:text-white/60">{health.pending_backup ? 'Perlu backup' : 'Backup terbaru tersedia'}</span>
                      </p>
                    )}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleBackup}
                  disabled={runningAction === 'backup'}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-success hover:bg-success/90 rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed shrink-0"
                >
                  {runningAction === 'backup' ? (
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                  ) : (
                    <i className="ri-download-cloud-line"></i>
                  )}
                  <span>Cadangkan Sekarang</span>
                </button>
              </div>
              {backupsError && (
                <p className="text-sm text-red-600 dark:text-red-400">
                  {backupsError}{' '}
                  <button type="button" onClick={fetchBackups} className="underline font-medium">Coba lagi</button>
                </p>
              )}
              {!backupsError && backups.length === 0 && (
                <p className="text-sm text-black/50 dark:text-white/50">Belum ada data backup</p>
              )}
              {backups.length > 0 && (
                <ul className="divide-y divide-black/5 dark:divide-white/5 border border-black/5 dark:border-white/5 rounded-lg">
                  {backups.map((b) => (
                    <li key={b.filename} className="flex items-center justify-between gap-3 p-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <i className="ri-file-zip-line text-2xl text-success shrink-0"></i>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-black dark:text-white truncate">{b.filename}</p>
                          <p className="text-xs text-black/50 dark:text-white/50">
                            {formatBytes(b.size_bytes)} · {formatDateTime(b.created_at)}
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleDownloadBackup(b)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-success border border-success/30 hover:bg-success/10 rounded-md transition-colors shrink-0"
                      >
                        <i className="ri-download-line"></i>
                        Download
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="p-5 border border-warning/20 dark:border-warning/20 bg-warning/5 dark:bg-warning/10 rounded-lg">
              <div className="flex items-start gap-3 mb-5">
                <div className="w-11 h-11 rounded-lg bg-warning/10 flex items-center justify-center shrink-0">
                  <i className="ri-restart-line text-xl text-warning"></i>
                </div>
                <div>
                  <h3 className="text-base font-semibold text-black dark:text-white">Pulihkan Database</h3>
                  <p className="text-xs text-black/60 dark:text-white/60 mt-0.5">
                    Pulihkan database dari file cadangan (.sql). Tindakan ini akan menimpa data yang ada.
                  </p>
                </div>
              </div>
              <div className="space-y-3">
                <label className="block">
                  <span className="sr-only">Pilih file backup</span>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".sql,.zip,.gz"
                    onChange={(e) => setRestoreFile(e.target.files?.[0] || null)}
                    className="block w-full text-sm text-black/60 dark:text-white/60 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-primary/10 file:text-primary hover:file:bg-primary/20"
                  />
                </label>
                {restoreFile && (
                  <div className="text-xs text-black/60 dark:text-white/60 bg-black/[0.03] dark:bg-white/[0.03] p-3 rounded-md">
                    File dipilih: <span className="font-semibold text-black dark:text-white">{restoreFile.name}</span> ({(restoreFile.size / 1024 / 1024).toFixed(2)} MB)
                  </div>
                )}
                <label className="block">
                  <span className="block text-xs font-medium text-black/70 dark:text-white/70 mb-1">
                    Ketik <code className="font-bold">RESTORE</code> untuk konfirmasi
                  </span>
                  <input
                    type="text"
                    value={restoreConfirm}
                    onChange={(e) => setRestoreConfirm(e.target.value)}
                    placeholder="RESTORE"
                    className="w-full max-w-xs px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-warning dark:text-white/80"
                  />
                </label>
                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={handleRestore}
                    disabled={!restoreFile || restoreConfirm.trim() !== 'RESTORE' || runningAction === 'restore'}
                    className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-warning hover:bg-warning/90 rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {runningAction === 'restore' ? (
                      <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                    ) : (
                      <i className="ri-upload-cloud-line"></i>
                    )}
                    <span>Pulihkan</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {tab === 'migrations' && (
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <p className="text-sm text-black/60 dark:text-white/60">
                {pendingMigrationCount > 0
                  ? `Ada ${pendingMigrationCount} migrasi tertunda yang perlu dijalankan`
                  : 'Semua migrasi sudah dijalankan'}
              </p>
              <button
                type="button"
                onClick={handleRunMigrations}
                disabled={pendingMigrationCount === 0 || runningAction === 'migrations'}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {runningAction === 'migrations' ? (
                  <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                ) : (
                  <i className="ri-play-circle-line"></i>
                )}
                <span>Jalankan Migrasi Tertunda</span>
              </button>
            </div>
            {migrationsError && (
              <div className="text-sm text-red-600 dark:text-red-400">
                {migrationsError}{' '}
                <button type="button" onClick={fetchMigrations} className="underline font-medium">Coba lagi</button>
              </div>
            )}
            {!migrationsError && safeMigrations.length === 0 && (
              <p className="text-sm text-black/50 dark:text-white/50">Belum ada data</p>
            )}
            <div className="overflow-x-auto -mx-6">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-y border-black/10 dark:border-white/10">
                    {['Nama File', 'Tanggal Apply', 'Status'].map((h) => (
                      <th key={h} className="text-left py-3 px-6 font-semibold text-black/80 dark:text-white/70 whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {safeMigrations.map((m) => (
                    <tr key={m.filename} className="border-b border-black/5 dark:border-white/5">
                      <td className="py-3 px-6 text-black/80 dark:text-white/80 font-mono whitespace-nowrap">{m.filename}</td>
                      <td className="py-3 px-6 text-black/60 dark:text-white/60 whitespace-nowrap">{formatDateTime(m.applied_at)}</td>
                      <td className="py-3 px-6 whitespace-nowrap">
                        {m.status === 'applied' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-success/10 text-success">
                            <i className="ri-checkbox-circle-line"></i> Applied
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-warning/10 text-warning">
                            <i className="ri-time-line"></i> Pending
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {tab === 'cache' && (
          <div className="space-y-6 max-w-3xl">
            <div className="p-5 border border-black/5 dark:border-white/5 rounded-lg">
              <div className="flex items-start justify-between gap-4 mb-3">
                <div className="flex items-start gap-3">
                  <div className="w-11 h-11 rounded-lg bg-info/10 flex items-center justify-center shrink-0">
                    <i className="ri-delete-bin-line text-xl text-info"></i>
                  </div>
                  <div>
                    <h3 className="text-base font-semibold text-black dark:text-white">Bersihkan Cache WS Notifications</h3>
                    <p className="text-xs text-black/50 dark:text-white/50 mt-0.5">
                      Hapus semua cache WebSocket notifikasi real-time. Client akan reconnect otomatis.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleClearCache}
                  disabled={runningAction === 'cache'}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-info bg-info/10 hover:bg-info/15 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed shrink-0"
                >
                  {runningAction === 'cache' ? (
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                  ) : (
                    <i className="ri-broom-line"></i>
                  )}
                  <span>Bersihkan Cache</span>
                </button>
              </div>
            </div>

            <div className="p-5 border border-red-200 dark:border-red-500/20 bg-red-50 dark:bg-red-500/10 rounded-lg">
              <div className="flex items-start gap-3 mb-4">
                <div className="w-11 h-11 rounded-lg bg-red-100 dark:bg-red-500/10 flex items-center justify-center shrink-0">
                  <i className="ri-error-warning-line text-xl text-red-600 dark:text-red-400"></i>
                </div>
                <div>
                  <h3 className="text-base font-semibold text-red-700 dark:text-red-400">Seed Data Demo (BAHAYA)</h3>
                  <p className="text-xs text-red-600/80 dark:text-red-400/80 mt-0.5">
                    Tindakan ini akan MEMBUAT data demo tambahan (pengguna, ruangan, booking). Hanya untuk environment development / staging.
                  </p>
                </div>
              </div>
              <div className="space-y-3">
                <label className="inline-flex items-start gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    className="mt-0.5 rounded border-red-300 text-red-600 focus:ring-red-500"
                    checked={seedConfirm1}
                    onChange={(e) => {
                      setSeedConfirm1(e.target.checked);
                      if (!e.target.checked) setSeedConfirm2(false);
                    }}
                  />
                  <span className="text-sm text-red-700 dark:text-red-400">
                    Saya memahami bahwa ini akan membuat data dummy baru dan mungkin mempengaruhi laporan / statistik
                  </span>
                </label>
                <label className="inline-flex items-start gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    className="mt-0.5 rounded border-red-300 text-red-600 focus:ring-red-500"
                    checked={seedConfirm2}
                    disabled={!seedConfirm1}
                    onChange={(e) => setSeedConfirm2(e.target.checked)}
                  />
                  <span className={`text-sm ${seedConfirm1 ? 'text-red-700 dark:text-red-400' : 'text-black/30 dark:text-white/30'}`}>
                    Saya benar-benar yakin ingin menjalankan Seed Data Demo
                  </span>
                </label>
                <div className="flex justify-end pt-2">
                  <button
                    type="button"
                    onClick={handleSeedDemo}
                    disabled={!seedConfirm1 || !seedConfirm2 || runningAction === 'seed'}
                    className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors shadow-sm disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    {runningAction === 'seed' ? (
                      <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                    ) : (
                      <i className="ri-seedling-line"></i>
                    )}
                    <span>Seed Data Demo</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {tab === 'info' && (
          <div className="max-w-2xl">
            <div className="p-5 border border-black/5 dark:border-white/5 rounded-lg">
              <div className="flex items-center gap-3 mb-6 pb-5 border-b border-black/5 dark:border-white/5">
                <img src="assets/images/favicon.png" alt="" className="w-14 h-14 rounded object-cover" />
                <div>
                  <h3 className="text-xl font-bold text-black dark:text-white">Smart Meeting Room</h3>
                  <p className="text-xs text-black/50 dark:text-white/50 mt-0.5">Sistem Manajemen Ruang Rapat Cerdas</p>
                </div>
              </div>
              <div className="space-y-4">
                {[
                  ['Nama Aplikasi', 'Smart Meeting Room'],
                  ['Versi', import.meta.env.VITE_APP_VERSION || '-'],
                  ['Server Aktif Sejak', formatDateTime(health?.started_at)],

                  ['Framework Backend', 'FastAPI (Python 3.11)'],
                  ['Framework Frontend', 'React 18 + TypeScript + Vite'],
                  ['Database Engine', 'PostgreSQL 16'],
                  ['Styling', 'Tailwind CSS + Remix Icon'],
                  ['State Management', 'Zustand'],
                  ['Realtime', 'WebSocket / Server-Sent Events'],
                ].map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between py-1.5 border-b border-black/[0.03] dark:border-white/[0.03] last:border-b-0">
                    <span className="text-sm text-black/50 dark:text-white/50">{k}</span>
                    <span className="text-sm font-medium text-black/80 dark:text-white/80">{v}</span>
                  </div>
                ))}
              </div>
              <div className="mt-6 pt-5 border-t border-black/5 dark:border-white/5">
                <p className="text-xs text-black/40 dark:text-white/40 mb-2">Credits &amp; Thanks To:</p>
                <p className="text-xs text-black/60 dark:text-white/60">
                  Tim Pengembangan Smart Meeting Room · Open Source Community · FastAPI, React, Tailwind Labs, Remix Icon
                </p>
                <p className="text-xs text-black/40 dark:text-white/40 mt-3 text-center">
                  © 2026 Smart Meeting Room. All rights reserved.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {toast && (
        <div className={`fixed top-4 right-4 z-[60] max-w-sm rounded-lg shadow-lg p-4 flex items-start gap-3 ${
          toast.type === 'success'
            ? 'bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20'
            : 'bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20'
        }`}>
          <div className="flex-shrink-0">
            {toast.type === 'success' ? (
              <i className="ri-check-line text-lg text-green-600 dark:text-green-400"></i>
            ) : (
              <i className="ri-error-warning-line text-lg text-red-600 dark:text-red-400"></i>
            )}
          </div>
          <p className={`flex-1 text-sm font-medium ${toast.type === 'success' ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>
            {toast.message}
          </p>
          <button
            type="button"
            onClick={() => setToast(null)}
            className={`flex-shrink-0 transition-colors ${toast.type === 'success' ? 'text-green-400 hover:text-green-600' : 'text-red-400 hover:text-red-600'}`}
          >
            <i className="ri-close-line"></i>
          </button>
        </div>
      )}
    </div>
  );
}
