/**
 * Panel transkrip live notulensi.
 *
 * - Kontrol rekaman: sumber Multichannel / Mix (recorder PC Monitoring), Browser
 *   (mikrofon perangkat ini, potongan ±10 detik dikirim ke server), atau unggah file.
 * - Daftar segmen transkrip (nama pembicara, kursi, waktu) dengan auto-scroll.
 * - Koreksi teks/pembicara langsung (bila `canEdit` & notulen belum final).
 * - Event live: bila prop `subscribe` diberikan (hook WS ruangan), panel
 *   mendengarkan `transcript_segment` & `recording_status`; bila tidak, polling
 *   `GET /notes/{id}/segments?after=` tiap 3 detik.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { authApi } from '@shared/api/auth';
import type {
  MeetingNote,
  NoteSegment,
  RecordingSource,
  RecordingStatusResponse,
  SttStatus,
} from '@shared/types';
import {
  RECORDING_STATUS_LABEL,
  apiErrorMessage,
  formatMs,
  newUid,
  pickRecorderMime,
  sortSegments,
  speakerColor,
  upsertSegments,
} from '../../pages/notes/noteUtils';

export interface LiveTranscriptPanelProps {
  bookingId: string;
  roomId?: string;
  canEdit: boolean;
  /** Langganan event WS ruangan: kembalikan fungsi untuk berhenti berlangganan. */
  subscribe?: (event: string, cb: (data: any) => void) => () => void;
  /** Peserta rapat untuk pilihan pembicara (mode browser & koreksi). Opsional. */
  participants?: { id: string; name: string }[];
  /** Tinggi maksimum daftar transkrip (CSS). Default 28rem. */
  maxHeight?: string;
  className?: string;
  /** Dipanggil saat notulen dimuat/dibuat (mis. agar halaman tahu note id). */
  onNoteLoaded?: (note: MeetingNote) => void;
  /** Dipanggil saat jumlah segmen berubah. */
  onSegmentCountChange?: (count: number) => void;
}

type SourceChoice = Exclude<RecordingSource, 'upload'> | 'upload';

const SOURCE_OPTIONS: { value: SourceChoice; label: string; hint: string }[] = [
  { value: 'multichannel', label: 'Multichannel (PC Monitoring)', hint: 'Recorder di PC Monitoring merekam tiap mic; pembicara dikenali dari kursi.' },
  { value: 'mix', label: 'Mix 2 kanal (PC Monitoring)', hint: 'Output mix receiver A/B; pembicara hanya per grup mic.' },
  { value: 'browser', label: 'Browser (mic perangkat ini)', hint: 'Merekam dari mikrofon laptop/tablet ini.' },
  { value: 'upload', label: 'Unggah file rekaman', hint: 'Unggah file audio (wav/mp3/m4a/webm/ogg/flac).' },
];

const CHUNK_MS = 10000;
const POLL_MS = 3000;
const ACTIVE = new Set(['recording', 'paused']);

export function LiveTranscriptPanel({
  bookingId,
  canEdit,
  subscribe,
  participants = [],
  maxHeight = '28rem',
  className = '',
  onNoteLoaded,
  onSegmentCountChange,
}: LiveTranscriptPanelProps) {
  const [note, setNote] = useState<MeetingNote | null>(null);
  const [status, setStatus] = useState<RecordingStatusResponse | null>(null);
  const [segments, setSegments] = useState<NoteSegment[]>([]);
  const [stt, setStt] = useState<SttStatus | null>(null);
  const [source, setSource] = useState<SourceChoice>('multichannel');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [browserSpeaker, setBrowserSpeaker] = useState('');
  const [editing, setEditing] = useState<{ id: string; text: string; speaker: string; participantId: string } | null>(null);
  const [autoScroll, setAutoScroll] = useState(true);
  const [micLevel, setMicLevel] = useState(0);
  const [capturing, setCapturing] = useState(false);

  const orderRef = useRef(new Map<string, number>());
  const cursorRef = useRef<string | null>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const pollCount = useRef(0);

  // --- state perekaman browser ---
  const streamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const cycleTimer = useRef<number | null>(null);
  const capturingRef = useRef(false);
  const clockRef = useRef<{ baseMs: number; t0: number }>({ baseMs: 0, t0: 0 });
  const pendingUploads = useRef<Promise<unknown>[]>([]);
  const levelRaf = useRef<number | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const browserSpeakerRef = useRef('');
  browserSpeakerRef.current = browserSpeaker;
  const statusRef = useRef<RecordingStatusResponse | null>(null);
  statusRef.current = status;

  const noteId = note?.id;
  const isFinal = note?.status === 'final';
  const editable = canEdit && !isFinal;
  const recActive = !!status && ACTIVE.has(status.status);

  // ------------------------------------------------------------------ data
  const loadAll = useCallback(async (nid: string) => {
    const res = await authApi.listNoteSegments(nid);
    orderRef.current = new Map();
    setSegments(sortSegments(res.items, orderRef.current));
    cursorRef.current = res.cursor ?? res.server_time;
    setProcessing(res.transcript_processing);
  }, []);

  const refreshStatus = useCallback(async () => {
    try {
      const s = await authApi.getRecordingStatus(bookingId);
      setStatus(s);
      return s;
    } catch {
      return null;
    }
  }, [bookingId]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setError(null);
      try {
        const n = canEdit ? await authApi.ensureNoteForBooking(bookingId) : await authApi.getNoteByBooking(bookingId);
        if (cancelled) return;
        setNote(n);
        if (n) {
          onNoteLoaded?.(n);
          await loadAll(n.id);
        }
        const s = await refreshStatus();
        if (s?.source && s.source !== 'upload' && ACTIVE.has(s.status)) setSource(s.source);
      } catch (err) {
        if (!cancelled) setError(apiErrorMessage(err, 'Gagal memuat notulensi'));
      }
      try {
        const st = await authApi.getSttStatus();
        if (!cancelled) setStt(st);
      } catch {
        /* status STT opsional */
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookingId, canEdit]);

  // --- event live (WS) ---
  useEffect(() => {
    if (!subscribe || !noteId) return;
    const offSeg = subscribe('transcript_segment', (data: NoteSegment) => {
      if (!data || data.note_id !== noteId) return;
      setSegments((prev) => upsertSegments(prev, [data], orderRef.current));
    });
    const offRec = subscribe('recording_status', (data: { booking_id?: string }) => {
      if (data?.booking_id && data.booking_id !== bookingId) return;
      refreshStatus();
    });
    return () => {
      offSeg();
      offRec();
    };
  }, [subscribe, noteId, bookingId, refreshStatus]);

  // --- polling (tanpa WS), juga untuk status saat rekaman/proses berjalan ---
  useEffect(() => {
    if (!noteId) return;
    const needPoll = !subscribe;
    const timer = window.setInterval(async () => {
      pollCount.current += 1;
      if (needPoll) {
        try {
          if (pollCount.current % 10 === 0) {
            await loadAll(noteId); // sesekali muat penuh (menangkap penghapusan)
          } else {
            const after = cursorRef.current ? new Date(new Date(cursorRef.current).getTime() - 5000).toISOString() : null;
            const res = await authApi.listNoteSegments(noteId, after);
            setSegments((prev) => upsertSegments(prev, res.items, orderRef.current));
            if (res.cursor && (!cursorRef.current || res.cursor > cursorRef.current)) cursorRef.current = res.cursor;
            setProcessing(res.transcript_processing);
          }
        } catch {
          /* coba lagi pada interval berikutnya */
        }
      }
      const cur = statusRef.current;
      if (needPoll || (cur && (ACTIVE.has(cur.status) || cur.status === 'processing'))) {
        refreshStatus();
      }
    }, POLL_MS);
    return () => window.clearInterval(timer);
  }, [noteId, subscribe, loadAll, refreshStatus]);

  useEffect(() => {
    onSegmentCountChange?.(segments.length);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [segments.length]);

  // --- auto-scroll ---
  useEffect(() => {
    if (!autoScroll || !listRef.current) return;
    listRef.current.scrollTop = listRef.current.scrollHeight;
  }, [segments, autoScroll]);

  const onScroll = () => {
    const el = listRef.current;
    if (!el) return;
    setAutoScroll(el.scrollHeight - el.scrollTop - el.clientHeight < 60);
  };

  // ------------------------------------------------------- browser capture
  const stopLevelMeter = () => {
    if (levelRaf.current) cancelAnimationFrame(levelRaf.current);
    levelRaf.current = null;
    audioCtxRef.current?.close().catch(() => undefined);
    audioCtxRef.current = null;
    setMicLevel(0);
  };

  const startLevelMeter = (stream: MediaStream) => {
    try {
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new Ctx();
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 1024;
      ctx.createMediaStreamSource(stream).connect(analyser);
      const buf = new Float32Array(analyser.fftSize);
      audioCtxRef.current = ctx;
      const tick = () => {
        analyser.getFloatTimeDomainData(buf);
        let sum = 0;
        for (let i = 0; i < buf.length; i++) sum += buf[i] * buf[i];
        const db = 20 * Math.log10(Math.sqrt(sum / buf.length) + 1e-6);
        setMicLevel(Math.max(0, Math.min(100, ((db + 60) / 55) * 100)));
        levelRaf.current = requestAnimationFrame(tick);
      };
      tick();
    } catch {
      /* meter opsional */
    }
  };

  const elapsedNow = () => clockRef.current.baseMs + (performance.now() - clockRef.current.t0);

  const startCycle = () => {
    const stream = streamRef.current;
    if (!stream || !capturingRef.current) return;
    const picked = pickRecorderMime();
    let rec: MediaRecorder;
    try {
      rec = picked?.mime ? new MediaRecorder(stream, { mimeType: picked.mime }) : new MediaRecorder(stream);
    } catch (err) {
      setError(apiErrorMessage(err, 'Browser tidak mendukung perekaman audio (MediaRecorder)'));
      return;
    }
    const ext = picked?.ext ?? 'webm';
    const parts: Blob[] = [];
    const startMs = elapsedNow();
    const t0 = performance.now();
    rec.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) parts.push(e.data);
    };
    rec.onstop = () => {
      const duration = performance.now() - t0;
      if (parts.length && duration > 500) {
        const blob = new Blob(parts, { type: rec.mimeType || parts[0].type });
        const spk = browserSpeakerRef.current;
        const p = participants.find((x) => x.id === spk);
        const up = authApi
          .uploadRecordingChunk(bookingId, blob, {
            start_ms: startMs,
            duration_ms: duration,
            filename: `chunk.${ext}`,
            chunk_uid: newUid(),
            participant_id: p?.id,
            speaker_name: p?.name,
          })
          .catch((err) => setError(apiErrorMessage(err, 'Gagal mengirim potongan audio')));
        pendingUploads.current.push(up);
        up.finally(() => {
          pendingUploads.current = pendingUploads.current.filter((x) => x !== up);
        });
      }
      if (capturingRef.current) startCycle(); // potongan berikutnya (tiap file berdiri sendiri)
    };
    recorderRef.current = rec;
    rec.start();
    cycleTimer.current = window.setTimeout(() => {
      if (rec.state !== 'inactive') rec.stop();
    }, CHUNK_MS);
  };

  const startBrowserCapture = async (elapsedMs: number) => {
    if (!navigator.mediaDevices?.getUserMedia) {
      throw new Error('Browser tidak mendukung akses mikrofon (butuh HTTPS atau localhost)');
    }
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
    });
    streamRef.current = stream;
    clockRef.current = { baseMs: elapsedMs, t0: performance.now() };
    capturingRef.current = true;
    setCapturing(true);
    startLevelMeter(stream);
    startCycle();
  };

  /** Hentikan capture; menunggu potongan terakhir terkirim. */
  const stopBrowserCapture = async () => {
    capturingRef.current = false;
    setCapturing(false);
    if (cycleTimer.current) window.clearTimeout(cycleTimer.current);
    const rec = recorderRef.current;
    if (rec && rec.state !== 'inactive') {
      await new Promise<void>((resolve) => {
        const prev = rec.onstop;
        rec.onstop = (ev) => {
          prev?.call(rec, ev);
          resolve();
        };
        rec.stop();
      });
    }
    recorderRef.current = null;
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    stopLevelMeter();
    await Promise.allSettled(pendingUploads.current);
  };

  useEffect(() => () => {
    // unmount: hentikan mikrofon (rekaman server tetap aktif; operator dapat melanjutkan)
    capturingRef.current = false;
    if (cycleTimer.current) window.clearTimeout(cycleTimer.current);
    if (recorderRef.current && recorderRef.current.state !== 'inactive') recorderRef.current.stop();
    streamRef.current?.getTracks().forEach((t) => t.stop());
    stopLevelMeter();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // --------------------------------------------------------------- actions
  const run = async (fn: () => Promise<void>, fallback: string) => {
    setBusy(true);
    setError(null);
    setInfo(null);
    try {
      await fn();
    } catch (err) {
      setError(err instanceof Error && !(err as { response?: unknown }).response ? err.message : apiErrorMessage(err, fallback));
    } finally {
      setBusy(false);
    }
  };

  const handleStart = () =>
    run(async () => {
      if (source === 'upload') return;
      const s = await authApi.startRecording({ booking_id: bookingId, source });
      setStatus(s);
      if (source === 'browser') {
        try {
          await startBrowserCapture(s.elapsed_ms ?? 0);
        } catch (err) {
          await authApi.stopRecording(bookingId).catch(() => undefined);
          await refreshStatus();
          throw err;
        }
      } else {
        setInfo('Rekaman dimulai. Recorder di PC Monitoring akan mulai mengirim audio dalam ±2 detik.');
      }
    }, 'Gagal memulai rekaman');

  const handlePause = () =>
    run(async () => {
      if (status?.source === 'browser') await stopBrowserCapture();
      setStatus(await authApi.pauseRecording(bookingId));
    }, 'Gagal menjeda rekaman');

  const handleResume = () =>
    run(async () => {
      const s = await authApi.resumeRecording(bookingId);
      setStatus(s);
      if (s.source === 'browser') await startBrowserCapture(s.elapsed_ms ?? 0);
    }, 'Gagal melanjutkan rekaman');

  const handleStop = () =>
    run(async () => {
      if (status?.source === 'browser') await stopBrowserCapture();
      const s = await authApi.stopRecording(bookingId);
      setStatus(s);
      setInfo(s.message ?? 'Rekaman dihentikan');
    }, 'Gagal menghentikan rekaman');

  const handleUpload = (file: File | null) => {
    if (!file || !noteId) return;
    run(async () => {
      const fd = new FormData();
      fd.append('audio_file', file);
      const res = await authApi.transcribeAudio(noteId, fd);
      setInfo(res.message ?? 'File diterima dan sedang ditranskripsi');
      setProcessing(true);
      await refreshStatus();
      if (fileRef.current) fileRef.current.value = '';
    }, 'Gagal mengunggah file');
  };

  const saveEdit = () => {
    if (!editing || !noteId) return;
    const cur = segments.find((s) => s.id === editing.id);
    run(async () => {
      const body: { text?: string; speaker_name?: string; participant_id?: string } = {};
      if (editing.text.trim() && editing.text.trim() !== cur?.text) body.text = editing.text.trim();
      if (editing.participantId && editing.participantId !== cur?.participant_id) body.participant_id = editing.participantId;
      if (editing.speaker.trim() && editing.speaker.trim() !== cur?.speaker_name) body.speaker_name = editing.speaker.trim();
      if (Object.keys(body).length) {
        const updated = await authApi.updateNoteSegment(noteId, editing.id, body);
        setSegments((prev) => upsertSegments(prev, [updated], orderRef.current));
      }
      setEditing(null);
    }, 'Gagal menyimpan koreksi');
  };

  const deleteSegment = (seg: NoteSegment) => {
    if (!noteId || !window.confirm('Hapus segmen transkrip ini?')) return;
    run(async () => {
      await authApi.deleteNoteSegment(noteId, seg.id);
      setSegments((prev) => prev.filter((s) => s.id !== seg.id));
    }, 'Gagal menghapus segmen');
  };

  // ------------------------------------------------------------------ view
  const st = status?.status ?? 'idle';
  const badge = RECORDING_STATUS_LABEL[st] ?? RECORDING_STATUS_LABEL.idle;
  const hint = SOURCE_OPTIONS.find((o) => o.value === source)?.hint;
  const sttWarning = useMemo(() => {
    if (!stt) return null;
    if (!stt.engine_available) return `Mesin transkripsi belum siap: ${stt.engine_error ?? 'faster-whisper tidak terpasang'}`;
    if (stt.last_error) return `Error transkripsi terakhir: ${stt.last_error}`;
    return null;
  }, [stt]);

  return (
    <div className={`bg-white dark:bg-gray rounded-lg shadow-md flex flex-col ${className}`}>
      <div className="px-4 py-3 border-b border-black/10 dark:border-white/10 flex flex-wrap items-center gap-2">
        <h3 className="font-semibold text-black dark:text-white flex items-center gap-2">
          <i className="ri-mic-line text-primary"></i> Transkrip Rapat
        </h3>
        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${badge.cls}`}>
          {st === 'recording' && <span className="w-2 h-2 rounded-full bg-danger animate-pulse" />}
          {badge.label}
          {status?.source && st !== 'idle' ? ` · ${status.source}` : ''}
        </span>
        {recActive && (
          <span className="text-xs text-black/50 dark:text-white/50 font-mono">{formatMs(status?.elapsed_ms ?? 0)}</span>
        )}
        {(processing || (status?.pending_jobs ?? 0) > 0) && (
          <span className="inline-flex items-center gap-1 text-xs text-info">
            <i className="ri-loader-4-line animate-spin"></i>
            Mentranskrip{status?.progress != null ? ` ${Math.round((status.progress ?? 0) * 100)}%` : '…'}
          </span>
        )}
        {isFinal && (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-success/10 text-success">
            <i className="ri-lock-line"></i> Final
          </span>
        )}
        <span className="ml-auto text-xs text-black/40 dark:text-white/40">{segments.length} segmen</span>
      </div>

      {canEdit && !isFinal && (
        <div className="px-4 py-3 border-b border-black/10 dark:border-white/10 space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={source}
              disabled={recActive || busy}
              onChange={(e) => setSource(e.target.value as SourceChoice)}
              className="px-3 py-1.5 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary dark:text-white/80 disabled:opacity-60"
            >
              {SOURCE_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>

            {source === 'upload' && !recActive ? (
              <label className={`inline-flex items-center gap-2 px-3 py-1.5 text-sm font-medium rounded-lg bg-primary text-white hover:bg-primary/90 cursor-pointer ${busy ? 'opacity-50 pointer-events-none' : ''}`}>
                <i className="ri-upload-2-line"></i> Pilih file…
                <input
                  ref={fileRef}
                  type="file"
                  accept="audio/*,.wav,.mp3,.m4a,.ogg,.oga,.opus,.webm,.flac,.mp4,.aac"
                  className="hidden"
                  onChange={(e) => handleUpload(e.target.files?.[0] ?? null)}
                />
              </label>
            ) : !recActive ? (
              <button type="button" onClick={handleStart} disabled={busy}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium rounded-lg bg-danger text-white hover:bg-danger/90 disabled:opacity-50">
                <i className="ri-record-circle-line"></i> Mulai Rekam
              </button>
            ) : (
              <>
                {st === 'recording' ? (
                  <button type="button" onClick={handlePause} disabled={busy}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium rounded-lg bg-warning/10 text-warning hover:bg-warning/20 disabled:opacity-50">
                    <i className="ri-pause-line"></i> Jeda
                  </button>
                ) : (
                  <button type="button" onClick={handleResume} disabled={busy}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium rounded-lg bg-success/10 text-success hover:bg-success/20 disabled:opacity-50">
                    <i className="ri-play-line"></i> Lanjutkan
                  </button>
                )}
                <button type="button" onClick={handleStop} disabled={busy}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium rounded-lg bg-black/5 dark:bg-white/10 text-black/70 dark:text-white/80 hover:bg-black/10 disabled:opacity-50">
                  <i className="ri-stop-line"></i> Hentikan
                </button>
              </>
            )}

            {(source === 'browser' || status?.source === 'browser') && participants.length > 0 && (
              <select
                value={browserSpeaker}
                onChange={(e) => setBrowserSpeaker(e.target.value)}
                title="Pembicara untuk potongan berikutnya"
                className="px-3 py-1.5 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary dark:text-white/80"
              >
                <option value="">Pembicara: Peserta (umum)</option>
                {participants.map((p) => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
            )}
            {capturing && (
              <div className="flex items-center gap-1.5 text-xs text-black/50 dark:text-white/50" title="Level mikrofon">
                <i className="ri-mic-fill"></i>
                <div className="w-20 h-1.5 rounded bg-black/10 dark:bg-white/10 overflow-hidden">
                  <div className="h-full bg-success transition-[width] duration-75" style={{ width: `${micLevel}%` }} />
                </div>
              </div>
            )}
          </div>
          {hint && !recActive && <p className="text-xs text-black/50 dark:text-white/50">{hint}</p>}
        </div>
      )}

      {(error || info || sttWarning || status?.error) && (
        <div className="px-4 pt-3 space-y-2">
          {error && (
            <div className="p-2.5 rounded-lg bg-danger/10 border border-danger/20 text-danger text-xs flex gap-2">
              <i className="ri-error-warning-line"></i><span className="flex-1">{error}</span>
              <button type="button" onClick={() => setError(null)}><i className="ri-close-line"></i></button>
            </div>
          )}
          {status?.error && (
            <div className="p-2.5 rounded-lg bg-warning/10 border border-warning/20 text-warning text-xs flex gap-2">
              <i className="ri-alert-line"></i><span>{status.error}</span>
            </div>
          )}
          {sttWarning && !status?.error && (
            <div className="p-2.5 rounded-lg bg-warning/10 border border-warning/20 text-warning text-xs flex gap-2">
              <i className="ri-alert-line"></i><span>{sttWarning}</span>
            </div>
          )}
          {info && (
            <div className="p-2.5 rounded-lg bg-info/10 border border-info/20 text-info text-xs flex gap-2">
              <i className="ri-information-line"></i><span className="flex-1">{info}</span>
              <button type="button" onClick={() => setInfo(null)}><i className="ri-close-line"></i></button>
            </div>
          )}
        </div>
      )}

      <div ref={listRef} onScroll={onScroll} className="px-4 py-3 overflow-y-auto space-y-3 flex-1" style={{ maxHeight }}>
        {segments.length === 0 ? (
          <div className="py-10 text-center text-sm text-black/40 dark:text-white/40">
            <i className="ri-chat-voice-line text-3xl block mb-1"></i>
            {recActive ? 'Menunggu ucapan pertama…' : 'Belum ada transkrip.'}
          </div>
        ) : (
          segments.map((seg) => {
            const isEditing = editing?.id === seg.id;
            return (
              <div key={seg.id} className="group flex gap-3">
                <span className="text-[11px] font-mono text-black/40 dark:text-white/40 pt-0.5 w-12 shrink-0 text-right">
                  {formatMs(seg.start_ms)}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5 mb-0.5">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${speakerColor(seg.speaker_name)}`}>
                      {seg.speaker_name || 'Peserta'}
                    </span>
                    {seg.seat_label && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-black/5 dark:bg-white/10 text-black/50 dark:text-white/50">
                        <i className="ri-armchair-line"></i> {seg.seat_label}
                      </span>
                    )}
                    {seg.audio_channel_no != null && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-black/5 dark:bg-white/10 text-black/50 dark:text-white/50">
                        Mic {seg.audio_channel_no}
                      </span>
                    )}
                    {seg.is_edited && <span className="text-[10px] text-black/40 dark:text-white/40 italic">dikoreksi</span>}
                    {editable && !isEditing && (
                      <span className="ml-auto opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity flex gap-1">
                        <button type="button" title="Koreksi"
                          onClick={() => setEditing({ id: seg.id, text: seg.text, speaker: seg.speaker_name ?? '', participantId: seg.participant_id ?? '' })}
                          className="p-1 rounded text-black/50 dark:text-white/50 hover:text-primary hover:bg-primary/10">
                          <i className="ri-edit-line"></i>
                        </button>
                        <button type="button" title="Hapus" onClick={() => deleteSegment(seg)}
                          className="p-1 rounded text-black/50 dark:text-white/50 hover:text-danger hover:bg-danger/10">
                          <i className="ri-delete-bin-line"></i>
                        </button>
                      </span>
                    )}
                  </div>
                  {isEditing ? (
                    <div className="space-y-2 mt-1">
                      <div className="flex flex-wrap gap-2">
                        {participants.length > 0 && (
                          <select value={editing.participantId}
                            onChange={(e) => {
                              const p = participants.find((x) => x.id === e.target.value);
                              setEditing({ ...editing, participantId: e.target.value, speaker: p?.name ?? editing.speaker });
                            }}
                            className="px-2 py-1 text-xs bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded outline-none focus:border-primary dark:text-white/80">
                            <option value="">— pilih peserta —</option>
                            {participants.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                          </select>
                        )}
                        <input value={editing.speaker} placeholder="Nama pembicara"
                          onChange={(e) => setEditing({ ...editing, speaker: e.target.value })}
                          className="px-2 py-1 text-xs bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded outline-none focus:border-primary dark:text-white/80" />
                      </div>
                      <textarea value={editing.text} rows={3}
                        onChange={(e) => setEditing({ ...editing, text: e.target.value })}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) saveEdit();
                          if (e.key === 'Escape') setEditing(null);
                        }}
                        className="w-full px-2 py-1.5 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded outline-none focus:border-primary dark:text-white/80" />
                      <div className="flex gap-2">
                        <button type="button" onClick={saveEdit} disabled={busy}
                          className="px-3 py-1 text-xs font-medium rounded bg-primary text-white hover:bg-primary/90 disabled:opacity-50">Simpan</button>
                        <button type="button" onClick={() => setEditing(null)}
                          className="px-3 py-1 text-xs font-medium rounded bg-black/5 dark:bg-white/10 text-black/70 dark:text-white/70">Batal</button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-black/80 dark:text-white/80 whitespace-pre-wrap break-words">{seg.text}</p>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
      {!autoScroll && segments.length > 0 && (
        <button type="button" onClick={() => setAutoScroll(true)}
          className="mx-4 mb-3 self-end text-xs px-2 py-1 rounded-full bg-primary/10 text-primary hover:bg-primary/20">
          <i className="ri-arrow-down-line"></i> Ke transkrip terbaru
        </button>
      )}
    </div>
  );
}

export default LiveTranscriptPanel;
