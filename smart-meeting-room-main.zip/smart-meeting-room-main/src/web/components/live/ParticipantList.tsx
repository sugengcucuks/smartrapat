// Daftar peserta rapat + status presensi & kursi (diperbarui live oleh halaman induk).
import { useMemo, useState } from 'react';
import type { LiveParticipant } from '@shared/types';
import { formatClock } from './liveUtils';

type Filter = 'all' | 'present' | 'absent';

export interface ParticipantListProps {
  participants: LiveParticipant[];
  /** Klik kursi peserta -> sorot kursi di denah. */
  onSelectSeat?: (seatId: string) => void;
  highlightIds?: Set<string>;
}

export function ParticipantList({ participants, onSelectSeat, highlightIds }: ParticipantListProps) {
  const [filter, setFilter] = useState<Filter>('all');
  const [q, setQ] = useState('');

  const attended = participants.filter((p) => p.attended).length;
  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return participants
      .filter((p) => (filter === 'present' ? p.attended : filter === 'absent' ? !p.attended : true))
      .filter((p) => !needle || p.name.toLowerCase().includes(needle))
      .sort((a, b) => Number(b.attended) - Number(a.attended) || a.name.localeCompare(b.name));
  }, [participants, filter, q]);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2">
        <div className="text-sm font-semibold text-black dark:text-white">
          Kehadiran{' '}
          <span className="text-success">{attended}</span>
          <span className="text-black/50 dark:text-white/50">/{participants.length}</span>
        </div>
        <div className="flex gap-1 p-0.5 rounded-lg bg-black/5 dark:bg-white/5">
          {(
            [
              ['all', 'Semua'],
              ['present', 'Hadir'],
              ['absent', 'Belum'],
            ] as [Filter, string][]
          ).map(([k, label]) => (
            <button
              key={k}
              type="button"
              onClick={() => setFilter(k)}
              className={`px-2.5 py-1 text-xs font-medium rounded-md ${
                filter === k ? 'bg-white dark:bg-gray text-black dark:text-white shadow-sm' : 'text-black/60 dark:text-white/60'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="relative">
        <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40"></i>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Cari peserta..."
          className="w-full pl-9 pr-2 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary dark:text-white/80"
        />
      </div>

      <ul className="divide-y divide-black/5 dark:divide-white/5">
        {rows.length === 0 && (
          <li className="py-6 text-center text-sm text-black/50 dark:text-white/50">
            {participants.length === 0 ? 'Rapat ini belum memiliki daftar peserta' : 'Tidak ada peserta yang cocok'}
          </li>
        )}
        {rows.map((p) => {
          const hot = highlightIds?.has(p.id);
          return (
            <li key={p.id} className="flex items-center gap-3 py-2.5">
              <span
                className={`w-9 h-9 shrink-0 rounded-full flex items-center justify-center text-sm font-bold ${
                  p.attended ? 'bg-success/10 text-success' : 'bg-black/5 dark:bg-white/10 text-black/40 dark:text-white/40'
                }`}
                style={hot ? { boxShadow: '0 0 0 2px #22c55e' } : undefined}
              >
                {p.name.trim().charAt(0).toUpperCase() || '?'}
              </span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 text-sm font-medium text-black dark:text-white">
                  <span className="truncate">{p.name}</span>
                  {p.is_organizer && (
                    <span className="px-1.5 py-0.5 text-[10px] rounded bg-warning/10 text-warning font-semibold">Penyelenggara</span>
                  )}
                  {p.is_guest && (
                    <span className="px-1.5 py-0.5 text-[10px] rounded bg-info/10 text-info font-semibold">Tamu</span>
                  )}
                </div>
                <div className="text-xs text-black/50 dark:text-white/50">
                  {p.attended ? `Hadir ${formatClock(p.checked_in_at)}` : 'Belum presensi'}
                  {p.position ? ` · ${p.position}` : ''}
                </div>
              </div>
              {p.seat ? (
                <button
                  type="button"
                  onClick={() => p.seat?.seat_id && onSelectSeat?.(p.seat.seat_id)}
                  className="shrink-0 px-2 py-1 text-xs font-semibold rounded-lg bg-primary/10 text-primary"
                  title="Lihat di denah"
                >
                  <i className="ri-armchair-line mr-1"></i>
                  {p.seat.label}
                </button>
              ) : (
                <span className="shrink-0 text-xs text-black/40 dark:text-white/40">Tanpa kursi</span>
              )}
            </li>
          );
        })}
      </ul>

      <div className="flex gap-2 p-3 rounded-lg bg-info/10 text-xs text-black/70 dark:text-white/70">
        <i className="ri-qr-scan-2-line text-info text-base leading-none"></i>
        <span>
          Peserta check-in dengan memindai QR tiket (menu <b>Tiket Presensi</b>) di layar pintu ruangan. Kursi kosong
          dipilihkan otomatis dan daftar ini diperbarui langsung.
        </span>
      </div>
    </div>
  );
}

export default ParticipantList;
