// Panel penugasan kursi terpilih: pilih peserta rapat atau ketik nama tamu.
import { useEffect, useMemo, useState } from 'react';
import type { LiveParticipant, LiveSeat, SeatAssignmentInput } from '@shared/types';
import { channelLabel, seatTypeMeta } from './liveUtils';

const ROLE_OPTIONS = ['Pimpinan Rapat', 'Peserta', 'Narasumber', 'Notulis', 'Moderator', 'Operator'];

export interface SeatAssignmentPanelProps {
  seat: LiveSeat;
  participants: LiveParticipant[];
  canEdit: boolean;
  busy?: boolean;
  onSave: (input: SeatAssignmentInput) => void;
  onClear: () => void;
  onClose: () => void;
}

export function SeatAssignmentPanel({ seat, participants, canEdit, busy, onSave, onClear, onClose }: SeatAssignmentPanelProps) {
  const a = seat.assignment;
  const [mode, setMode] = useState<'participant' | 'guest'>(a && !a.participant_id ? 'guest' : 'participant');
  const [participantId, setParticipantId] = useState(a?.participant_id ?? '');
  const [guestName, setGuestName] = useState(a && !a.participant_id ? a.display_name ?? '' : '');
  const [role, setRole] = useState(a?.role_label ?? (seat.seat_type === 'chair' ? 'Pimpinan Rapat' : seat.seat_type === 'secretary' ? 'Notulis' : ''));

  useEffect(() => {
    setMode(a && !a.participant_id ? 'guest' : 'participant');
    setParticipantId(a?.participant_id ?? '');
    setGuestName(a && !a.participant_id ? a.display_name ?? '' : '');
    setRole(a?.role_label ?? (seat.seat_type === 'chair' ? 'Pimpinan Rapat' : seat.seat_type === 'secretary' ? 'Notulis' : ''));
    // Hanya reset saat kursi/penugasannya berubah (bukan setiap polling snapshot).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seat.id, a?.id, a?.participant_id, a?.display_name, a?.role_label, seat.seat_type]);

  const options = useMemo(
    () => [...participants].sort((x, y) => Number(!!x.seat) - Number(!!y.seat) || x.name.localeCompare(y.name)),
    [participants]
  );
  const meta = seatTypeMeta(seat.seat_type);
  const canSubmit = mode === 'participant' ? !!participantId : guestName.trim().length > 0;

  const submit = () => {
    if (!canSubmit) return;
    onSave({
      seat_id: seat.id,
      participant_id: mode === 'participant' ? participantId : null,
      display_name: mode === 'guest' ? guestName.trim() : null,
      role_label: role.trim() || null,
    });
  };

  return (
    <div className="rounded-xl border border-black/10 dark:border-white/10 bg-white dark:bg-gray p-4 space-y-3">
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="text-base font-bold text-black dark:text-white">
            Kursi {seat.label}{' '}
            <span className="ml-1 px-2 py-0.5 text-xs rounded-full font-semibold text-white" style={{ background: meta.color }}>
              {meta.label}
            </span>
          </div>
          <div className="text-xs text-black/50 dark:text-white/50 mt-0.5">
            <i className="ri-mic-line mr-1"></i>
            {channelLabel(seat.channel)}
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="p-1.5 rounded-lg text-black/50 dark:text-white/50 hover:bg-black/5 dark:hover:bg-white/10"
          title="Tutup"
        >
          <i className="ri-close-line text-lg"></i>
        </button>
      </div>

      <div className="text-sm">
        <span className="text-black/50 dark:text-white/50">Ditempati: </span>
        <span className="font-semibold text-black dark:text-white">{a?.name ?? 'Kosong'}</span>
        {a?.role_label && <span className="text-black/50 dark:text-white/50"> · {a.role_label}</span>}
        {a?.assigned_via === 'checkin' && <span className="text-xs text-success ml-1">(otomatis saat presensi)</span>}
      </div>

      {canEdit ? (
        <>
          <div className="flex gap-1 p-0.5 rounded-lg bg-black/5 dark:bg-white/5" style={{ width: 'fit-content' }}>
            {(
              [
                ['participant', 'Peserta rapat'],
                ['guest', 'Nama lain / tamu'],
              ] as ['participant' | 'guest', string][]
            ).map(([k, label]) => (
              <button
                key={k}
                type="button"
                onClick={() => setMode(k)}
                className={`px-3 py-1 text-xs font-medium rounded-md ${
                  mode === k ? 'bg-white dark:bg-gray text-black dark:text-white shadow-sm' : 'text-black/60 dark:text-white/60'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {mode === 'participant' ? (
            <select
              value={participantId}
              onChange={(e) => setParticipantId(e.target.value)}
              aria-label="Pilih peserta"
              className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary dark:text-white/80"
            >
              <option value="">-- Pilih peserta --</option>
              {options.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                  {p.is_guest ? ' (Tamu)' : ''}
                  {p.attended ? ' ✓ hadir' : ''}
                  {p.seat && p.seat.seat_id !== seat.id ? ` — kini di Kursi ${p.seat.label}` : ''}
                </option>
              ))}
            </select>
          ) : (
            <input
              value={guestName}
              onChange={(e) => setGuestName(e.target.value)}
              maxLength={200}
              placeholder="Nama yang ditampilkan"
              aria-label="Nama tamu"
              className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary dark:text-white/80"
            />
          )}

          <div>
            <input
              value={role}
              onChange={(e) => setRole(e.target.value)}
              list="seat-role-options"
              maxLength={50}
              placeholder="Peran (opsional), mis. Narasumber"
              aria-label="Peran"
              className="w-full px-3 py-2 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary dark:text-white/80"
            />
            <datalist id="seat-role-options">
              {ROLE_OPTIONS.map((r) => (
                <option key={r} value={r} />
              ))}
            </datalist>
          </div>

          {mode === 'participant' && participantId && participants.find((p) => p.id === participantId)?.seat && (
            <p className="text-xs text-warning">Peserta akan dipindahkan dari kursi sebelumnya.</p>
          )}

          <div className="flex items-center justify-end gap-2 pt-1">
            {a && (
              <button
                type="button"
                disabled={busy}
                onClick={onClear}
                className="px-3 py-2 text-sm font-medium text-danger bg-danger/10 hover:bg-danger/20 rounded-lg disabled:opacity-50"
              >
                Kosongkan
              </button>
            )}
            <button
              type="button"
              disabled={busy || !canSubmit}
              onClick={submit}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/90 rounded-lg disabled:opacity-50"
            >
              <i className="ri-check-line"></i>
              Simpan
            </button>
          </div>
        </>
      ) : (
        <p className="text-xs text-black/50 dark:text-white/50">
          Hanya penyelenggara rapat atau approver yang dapat mengubah penempatan kursi.
        </p>
      )}
    </div>
  );
}

export default SeatAssignmentPanel;
