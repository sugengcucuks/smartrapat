// Denah kursi ruangan (SVG, koordinat persen pada kanvas 16:10).
// Dipakai halaman editor denah (mode edit: seret kursi) dan konsol live meeting
// (mode view: nama peserta, kehadiran, pembicara aktif, level mic).
import { useRef } from 'react';
import type { KeyboardEvent, PointerEvent as ReactPointerEvent } from 'react';
import type { AudioChannel, SeatAssignment, SeatLayoutShape, SeatLayoutTable, SeatType } from '@shared/types';
import { seatTypeMeta } from './liveUtils';

/** Satuan viewBox: 160 x 100 (x persen * 1.6) agar skala seragam. */
const VB_W = 160;
const VB_H = 100;
const SX = VB_W / 100;

export interface SeatMapSeat {
  id: string;
  seat_no: number;
  label: string;
  seat_type: SeatType;
  pos_x: number;
  pos_y: number;
  rotation: number;
  channel?: AudioChannel | null;
  assignment?: SeatAssignment | null;
}

export interface SeatMapProps {
  seats: SeatMapSeat[];
  layout?: SeatLayoutShape | null;
  /** edit: kursi dapat diseret; view: hanya dipilih. */
  mode?: 'view' | 'edit';
  selectedId?: string | null;
  onSelect?: (seatId: string | null) => void;
  onMove?: (seatId: string, x: number, y: number) => void;
  /** Geser kursi terpilih lewat keyboard (mode edit). */
  onNudge?: (seatId: string, dx: number, dy: number) => void;
  /** seat_id pembicara aktif (cincin berdenyut). */
  activeSeatIds?: Set<string>;
  /** Level mic 0..1 per kursi (null = tidak ada data). */
  levelFor?: (seat: SeatMapSeat) => number | null;
  /** participant_id yang sudah presensi. */
  attendedIds?: Set<string>;
  showNames?: boolean;
  showMic?: boolean;
  /** Tandai kursi yang terisi tetapi pesertanya belum hadir. */
  showAttendance?: boolean;
  className?: string;
  ariaLabel?: string;
}

function truncate(s: string, n: number) {
  return s.length > n ? `${s.slice(0, n - 1)}…` : s;
}

function TableShape({ t }: { t: SeatLayoutTable }) {
  const common = {
    fill: 'rgba(148, 163, 184, 0.18)',
    stroke: 'rgba(100, 116, 139, 0.55)',
    strokeWidth: 0.35,
  };
  if (t.shape === 'ellipse') {
    return <ellipse cx={(t.x + t.w / 2) * SX} cy={t.y + t.h / 2} rx={(t.w / 2) * SX} ry={t.h / 2} {...common} />;
  }
  if (t.shape === 'u') {
    const x = t.x * SX;
    const w = t.w * SX;
    const tx = (t.tx ?? 8) * SX;
    const ty = t.ty ?? 12;
    const d = `M ${x} ${t.y} H ${x + w} V ${t.y + t.h} H ${x + w - tx} V ${t.y + ty} H ${x + tx} V ${t.y + t.h} H ${x} Z`;
    return <path d={d} strokeLinejoin="round" {...common} />;
  }
  return <rect x={t.x * SX} y={t.y} width={t.w * SX} height={t.h} rx={1.5} {...common} />;
}

export function SeatMap({
  seats,
  layout,
  mode = 'view',
  selectedId,
  onSelect,
  onMove,
  onNudge,
  activeSeatIds,
  levelFor,
  attendedIds,
  showNames = true,
  showMic = true,
  showAttendance = false,
  className = '',
  ariaLabel = 'Denah kursi ruangan',
}: SeatMapProps) {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const dragRef = useRef<{ id: string; pointerId: number } | null>(null);
  const editable = mode === 'edit';
  const r = seats.length > 28 ? 2.6 : seats.length > 18 ? 3.0 : 3.4;

  const toPct = (clientX: number, clientY: number) => {
    const rect = svgRef.current?.getBoundingClientRect();
    if (!rect || rect.width === 0 || rect.height === 0) return null;
    const clamp = (v: number) => Math.max(0, Math.min(100, Math.round(v)));
    return {
      x: clamp(((clientX - rect.left) / rect.width) * 100),
      y: clamp(((clientY - rect.top) / rect.height) * 100),
    };
  };

  const onSeatPointerDown = (e: ReactPointerEvent<SVGGElement>, id: string) => {
    e.stopPropagation();
    onSelect?.(id);
    if (!editable || !onMove) return;
    dragRef.current = { id, pointerId: e.pointerId };
    try {
      svgRef.current?.setPointerCapture(e.pointerId);
    } catch {
      /* pointer capture tidak didukung */
    }
  };

  const onPointerMove = (e: ReactPointerEvent<SVGSVGElement>) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== e.pointerId) return;
    const p = toPct(e.clientX, e.clientY);
    if (p) onMove?.(drag.id, p.x, p.y);
  };

  const endDrag = (e: ReactPointerEvent<SVGSVGElement>) => {
    if (dragRef.current && dragRef.current.pointerId === e.pointerId) {
      try {
        svgRef.current?.releasePointerCapture(e.pointerId);
      } catch {
        /* abaikan */
      }
      dragRef.current = null;
    }
  };

  const onKeyDown = (e: KeyboardEvent<SVGSVGElement>) => {
    if (!editable || !selectedId || !onNudge) return;
    const step = e.shiftKey ? 5 : 1;
    const map: Record<string, [number, number]> = {
      ArrowLeft: [-step, 0],
      ArrowRight: [step, 0],
      ArrowUp: [0, -step],
      ArrowDown: [0, step],
    };
    const d = map[e.key];
    if (d) {
      e.preventDefault();
      onNudge(selectedId, d[0], d[1]);
    }
  };

  const sorted = [...seats].sort((a, b) => a.seat_no - b.seat_no);

  return (
    <div
      className={`relative w-full rounded-xl border border-black/10 dark:border-white/10 bg-black/[0.02] dark:bg-white/[0.03] overflow-hidden text-black/70 dark:text-white/70 ${className}`}
      style={{ aspectRatio: '16 / 10' }}
    >
      <svg
        ref={svgRef}
        viewBox={`0 0 ${VB_W} ${VB_H}`}
        className="absolute inset-0 w-full h-full"
        style={{ touchAction: editable ? 'none' : 'manipulation', outline: 'none', userSelect: 'none' }}
        role="img"
        aria-label={ariaLabel}
        tabIndex={editable ? 0 : -1}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        onPointerDown={() => onSelect?.(null)}
        onKeyDown={onKeyDown}
      >
        <defs>
          <pattern id="seatmap-grid" width={SX * 5} height={5} patternUnits="userSpaceOnUse">
            <path d={`M ${SX * 5} 0 L 0 0 0 5`} fill="none" stroke="currentColor" strokeOpacity={0.07} strokeWidth={0.2} />
          </pattern>
        </defs>
        <rect x={0} y={0} width={VB_W} height={VB_H} fill="url(#seatmap-grid)" />

        {(layout?.tables ?? []).map((t, i) => (
          <TableShape key={i} t={t} />
        ))}
        {layout?.type === 'u_shape' && (
          <g>
            <rect x={VB_W / 2 - 22} y={96} width={44} height={1.6} rx={0.8} fill="currentColor" fillOpacity={0.35} />
            <text x={VB_W / 2} y={94.6} fontSize={2} textAnchor="middle" fill="currentColor" fillOpacity={0.55}>
              Layar / Videowall
            </text>
          </g>
        )}

        {sorted.map((s) => {
          const meta = seatTypeMeta(s.seat_type);
          const color = meta.color;
          const cx = s.pos_x * SX;
          const cy = s.pos_y;
          const a = s.assignment;
          const pid = a?.participant_id ?? null;
          const occupied = !!a;
          const attended = pid ? attendedIds?.has(pid) ?? false : occupied;
          const active = activeSeatIds?.has(s.id) ?? false;
          const selected = selectedId === s.id;
          const level = levelFor ? levelFor(s) : null;

          let fill = color;
          let fillOpacity = 1;
          let stroke = color;
          let dash: string | undefined;
          if (!editable) {
            if (!occupied) {
              fill = '#ffffff';
              fillOpacity = 0.85;
              dash = '0.8 0.6';
            } else if (showAttendance && !attended) {
              fillOpacity = 0.35;
            }
          }
          const labelFill = !editable && !occupied ? color : '#ffffff';

          // Arah hadap (menuju meja) & posisi nama (sisi berlawanan).
          const rad = ((s.rotation || 0) * Math.PI) / 180;
          const fx = Math.sin(rad);
          const fy = -Math.cos(rad);
          const off = r + 1.3;
          const nx = -fx * off;
          const ny = -fy * off;
          const horizontal = Math.abs(fx) > 0.7;
          const anchor = horizontal ? (nx < 0 ? 'end' : 'start') : 'middle';
          const nameY = horizontal ? ny + 0.7 : ny > 0 ? ny + 1.6 : ny - 0.4;
          const name = a?.name ?? null;

          return (
            <g
              key={s.id}
              transform={`translate(${cx} ${cy})`}
              onPointerDown={(e) => onSeatPointerDown(e, s.id)}
              style={{ cursor: editable ? 'grab' : onSelect ? 'pointer' : 'default' }}
              data-seat-id={s.id}
              data-seat-no={s.seat_no}
            >
              <title>
                {`Kursi ${s.label} (${meta.label})`}
                {s.channel ? ` · ${s.channel.label}${s.channel.receiver_label ? ` (${s.channel.receiver_label})` : ''}` : ''}
                {name ? ` · ${name}` : ''}
              </title>
              {active && (
                <circle r={r + 1} fill="none" stroke="#22c55e" strokeWidth={0.7}>
                  <animate attributeName="r" values={`${r + 0.6};${r + 3.2}`} dur="1.1s" repeatCount="indefinite" />
                  <animate attributeName="opacity" values="0.95;0" dur="1.1s" repeatCount="indefinite" />
                </circle>
              )}
              {selected && <circle r={r + 1.1} fill="none" stroke="rgb(var(--color-primary, 59 130 246))" strokeWidth={0.6} />}
              <path
                d={`M ${-1.5} ${-r + 0.1} L 0 ${-r - 1.5} L 1.5 ${-r + 0.1} Z`}
                transform={`rotate(${s.rotation || 0})`}
                fill={color}
                fillOpacity={0.9}
              />
              <circle
                r={r}
                fill={fill}
                fillOpacity={fillOpacity}
                stroke={active ? '#22c55e' : stroke}
                strokeWidth={active ? 0.7 : 0.45}
                strokeDasharray={dash}
              />
              <text
                y={showMic && s.channel ? -0.1 : 0.9}
                fontSize={s.label.length > 3 ? 1.8 : 2.5}
                fontWeight={700}
                textAnchor="middle"
                fill={labelFill}
              >
                {truncate(s.label, 6)}
              </text>
              {showMic && s.channel && (
                <text y={2.1} fontSize={1.45} textAnchor="middle" fill={labelFill} fillOpacity={0.9}>
                  M{s.channel.channel_no}
                </text>
              )}
              {level !== null && (
                <g transform={`translate(${-r} ${r + 0.6})`}>
                  <rect width={r * 2} height={0.8} rx={0.4} fill="currentColor" fillOpacity={0.15} />
                  <rect
                    width={Math.max(0, Math.min(1, level)) * r * 2}
                    height={0.8}
                    rx={0.4}
                    fill={level > 0.8 ? '#ef4444' : level > 0.55 ? '#f59e0b' : '#22c55e'}
                  />
                </g>
              )}
              {showNames && name && (
                <text
                  x={nx}
                  y={nameY}
                  fontSize={1.9}
                  fontWeight={600}
                  textAnchor={anchor}
                  fill="currentColor"
                  fillOpacity={showAttendance && !attended ? 0.5 : 0.95}
                >
                  {truncate(name, 18)}
                </text>
              )}
            </g>
          );
        })}
      </svg>
      {seats.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center text-sm text-black/50 dark:text-white/50 pointer-events-none">
          Denah kursi belum dibuat
        </div>
      )}
    </div>
  );
}

export function SeatLegend({ showAttendance = false }: { showAttendance?: boolean }) {
  return (
    <div className="flex flex-wrap items-center gap-x-4 text-xs text-black/60 dark:text-white/60">
      {(['chair', 'delegate', 'secretary', 'guest', 'operator'] as SeatType[]).map((t) => {
        const m = seatTypeMeta(t);
        return (
          <span key={t} className="inline-flex items-center gap-1">
            <span className="inline-block w-3 h-3 rounded-full" style={{ background: m.color }}></span>
            {m.label}
          </span>
        );
      })}
      {showAttendance && (
        <>
          <span className="inline-flex items-center gap-1">
            <span className="inline-block w-3 h-3 rounded-full" style={{ background: '#3b82f6', opacity: 0.35 }}></span>
            Belum hadir
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="inline-block w-3 h-3 rounded-full" style={{ border: '1px dashed #3b82f6' }}></span>
            Kosong
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="inline-block w-3 h-3 rounded-full" style={{ border: '2px solid #22c55e' }}></span>
            Sedang bicara
          </span>
        </>
      )}
    </div>
  );
}

export default SeatMap;
