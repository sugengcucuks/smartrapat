// Utilitas bersama denah kursi & live meeting.
import type { AudioChannel, SeatType } from '@shared/types';

export const SEAT_TYPES: { value: SeatType; label: string; color: string }[] = [
  { value: 'chair', label: 'Pimpinan', color: '#f59e0b' },
  { value: 'delegate', label: 'Peserta', color: '#3b82f6' },
  { value: 'secretary', label: 'Notulis', color: '#8b5cf6' },
  { value: 'guest', label: 'Tamu', color: '#14b8a6' },
  { value: 'operator', label: 'Operator', color: '#64748b' },
];

export function seatTypeMeta(t: SeatType | string) {
  return SEAT_TYPES.find((s) => s.value === t) ?? SEAT_TYPES[1];
}

/** "Mic 3 · M118-A CH3" */
export function channelLabel(ch: AudioChannel | null | undefined): string {
  if (!ch) return 'Tanpa mic';
  return ch.receiver_label ? `${ch.label} · ${ch.receiver_label}` : ch.label;
}

/** dBFS (-60..0) -> 0..1 untuk bar level. */
export function dbToLevel(db: number | null | undefined): number {
  if (db === null || db === undefined || Number.isNaN(db)) return 0;
  return Math.max(0, Math.min(1, (db + 60) / 60));
}

export function formatClock(iso: string | null | undefined): string {
  if (!iso) return '-';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '-';
  return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
}

export function hhmm(t: string | null | undefined): string {
  return t ? t.slice(0, 5) : '-';
}
