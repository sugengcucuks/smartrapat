// Timer rapat berbasis waktu server (sisa waktu terhadap jam selesai efektif).
import { useEffect, useState } from 'react';
import type { LiveBookingInfo } from '@shared/types';

function fmt(totalSec: number) {
  const s = Math.max(0, Math.floor(totalSec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  const pad = (n: number) => n.toString().padStart(2, '0');
  return h > 0 ? `${pad(h)}:${pad(m)}:${pad(ss)}` : `${pad(m)}:${pad(ss)}`;
}

export interface MeetingTimerProps {
  booking: LiveBookingInfo;
  /** server_time - waktu lokal (ms) saat snapshot diambil. */
  serverOffsetMs: number;
  compact?: boolean;
}

export function MeetingTimer({ booking, serverOffsetMs, compact }: MeetingTimerProps) {
  const [now, setNow] = useState(() => Date.now() + serverOffsetMs);
  useEffect(() => {
    setNow(Date.now() + serverOffsetMs);
    const t = window.setInterval(() => setNow(Date.now() + serverOffsetMs), 1000);
    return () => window.clearInterval(t);
  }, [serverOffsetMs]);

  const startAt = Date.parse(booking.start_at);
  const endAt = Date.parse(booking.end_at_effective);
  const status = booking.meeting_status;

  let big = '--:--';
  let caption = '';
  let tone = 'text-primary';
  let progress = 0;

  if (status === 'ended') {
    const a = booking.actual_start_at ? Date.parse(booking.actual_start_at) : startAt;
    const b = booking.actual_end_at ? Date.parse(booking.actual_end_at) : endAt;
    big = fmt((b - a) / 1000);
    caption = 'Durasi rapat';
    tone = 'text-black/70 dark:text-white/70';
    progress = 100;
  } else if (status === 'live' || now >= startAt) {
    const remain = (endAt - now) / 1000;
    const base = booking.actual_start_at ? Date.parse(booking.actual_start_at) : startAt;
    const total = Math.max(1, endAt - base);
    progress = Math.min(100, Math.max(0, ((now - base) / total) * 100));
    if (remain >= 0) {
      big = fmt(remain);
      caption = status === 'live' ? 'Sisa waktu' : 'Sisa waktu (rapat belum dimulai di sistem)';
      tone = remain < 300 ? 'text-danger' : remain < 900 ? 'text-warning' : 'text-primary';
    } else {
      big = `+${fmt(-remain)}`;
      caption = 'Melewati jadwal selesai';
      tone = 'text-danger';
    }
  } else {
    big = fmt((startAt - now) / 1000);
    caption = 'Menuju jadwal mulai';
    tone = 'text-black/70 dark:text-white/70';
  }

  return (
    <div className={compact ? 'text-right' : 'text-center'}>
      <div className={`font-mono font-bold tracking-tight ${compact ? 'text-3xl' : 'text-5xl'} ${tone}`} aria-live="off">
        {big}
      </div>
      <div className="text-xs text-black/50 dark:text-white/50 mt-0.5">{caption}</div>
      {!compact && (
        <div className="w-full h-2 mt-2 bg-black/5 dark:bg-white/10 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full ${tone.includes('danger') ? 'bg-danger' : tone.includes('warning') ? 'bg-warning' : 'bg-primary'}`}
            style={{ width: `${progress}%`, transition: 'width 1s linear' }}
          />
        </div>
      )}
    </div>
  );
}

export default MeetingTimer;
