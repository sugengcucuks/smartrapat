import { passwordStrength } from '@shared/utils/password';

export function PasswordStrengthMeter({ password }: { password: string }) {
  if (!password) return null;
  const s = passwordStrength(password);
  return (
    <div className="mt-2">
      <div className="flex gap-1">
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            className={`h-1.5 flex-1 rounded-full ${i < Math.max(1, s.score) ? s.color : 'bg-black/10 dark:bg-white/10'}`}
          />
        ))}
      </div>
      <p className="mt-1 text-xs text-black/60 dark:text-white/60">
        Kekuatan: <span className="font-semibold">{s.label}</span>
        {s.hints.length > 0 && <span> — {s.hints.join(', ')}</span>}
      </p>
    </div>
  );
}
