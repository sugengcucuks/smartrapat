import { useCallback, useEffect, useState } from 'react';
import { authApi } from '@shared/api/auth';
import type { AudioChannel, RoomAvCapabilities, RoomAvState } from '@shared/types';
import { useAuthStore } from '../../store/auth.store';
import { useRoomLive, type RoomLiveState } from '../../hooks/useRoomLive';
import { apiErrorMessage, avTone, hasPermission, levelPercent, useAvCommands, type AvVariant } from './avUtils';
import { CommandBadge, CommandDetail } from './CommandFeedback';

export interface MicMixerPanelProps {
  roomId: string;
  /** Label kursi/peserta per nomor kanal mic (dari denah & penugasan kursi). */
  seatsByChannel?: Record<number, { label: string; name?: string }>;
  compact?: boolean;
  variant?: AvVariant;
  /** Bagikan koneksi WS dari useRoomLive milik halaman. */
  live?: RoomLiveState;
}

function LevelMeter({ db, active, bg }: { db: number | null | undefined; active: boolean; bg: string }) {
  const pct = levelPercent(db);
  const color = pct > 90 ? 'bg-red-500' : pct > 70 ? 'bg-amber-400' : active ? 'bg-emerald-400' : 'bg-emerald-600/70';
  return (
    <div className={`h-1.5 w-full rounded-full overflow-hidden ${bg}`} title={db != null ? `${db.toFixed(1)} dBFS` : 'tidak ada data level'}>
      <div className={`h-full ${color} transition-[width] duration-150`} style={{ width: `${pct}%` }} />
    </div>
  );
}

/**
 * Panel mic ruangan: level meter per kanal + sorotan pembicara aktif (WS),
 * mute/unmute per mic, mute semua, fader utama. Mode tanpa mixer ("none"):
 * hanya level (dari recorder) + pesan "Mixer tidak terpasang; atur manual di receiver".
 */
export function MicMixerPanel({ roomId, seatsByChannel, compact = false, variant = 'default', live: liveProp }: MicMixerPanelProps) {
  const t = avTone(variant);
  const dark = variant === 'dark';
  const user = useAuthStore((s) => s.user);
  const canControl = hasPermission(user, 'audio.control');
  const ownLive = useRoomLive(liveProp ? null : roomId);
  const live = liveProp || ownLive;

  const [caps, setCaps] = useState<RoomAvCapabilities | null>(null);
  const [initial, setInitial] = useState<RoomAvState | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [mainDraft, setMainDraft] = useState<number | null>(null);
  const { states, run, busy } = useAvCommands();

  const load = useCallback(async () => {
    if (!roomId) return;
    setLoading(true);
    setLoadError(null);
    try {
      const [c, s] = await Promise.all([
        authApi.getRoomAvCapabilities(roomId),
        authApi.getRoomAvState(roomId).catch(() => null),
      ]);
      setCaps(c);
      setInitial(s);
    } catch (err) {
      setCaps(null);
      setLoadError(apiErrorMessage(err, 'Gagal memuat data audio ruangan'));
    } finally {
      setLoading(false);
    }
  }, [roomId]);

  useEffect(() => {
    setMainDraft(null);
    load();
  }, [load]);

  const audio = caps?.audio;
  const mixer = live.mixer || initial?.mixer || null;
  const hasLiveLevels = Object.keys(live.levels).length > 0;
  const levels: Record<number, number> = hasLiveLevels
    ? live.levels
    : Object.fromEntries(Object.entries(initial?.levels || {}).map(([k, v]) => [Number(k), v]));
  const activeSet = new Set<number>(live.connected ? live.activeChannels : initial?.active_speakers.channels || []);
  const channels: AudioChannel[] = (audio?.channels || []).filter((c) => c.enabled);
  const controllable = !!audio?.can_control && canControl;
  const mqttDown = !!caps && !caps.mqtt.configured && !caps.mqtt.simulate;
  const disabled = !controllable || busy || mqttDown;
  const mainFader = mainDraft ?? (mixer?.main?.fader ?? null);
  const lastState = Object.values(states).sort((a, b) => b.at - a.at)[0];

  const toggleMute = (ch: AudioChannel, muted: boolean | null | undefined) =>
    run(`mic-${ch.channel_no}`, () => authApi.avMicMute(roomId, ch.channel_no, !muted));

  const commitMain = (v: number) => {
    run('fader-main', () => authApi.avFader(roomId, 'main', v)).then(() => setMainDraft(null));
  };

  return (
    <section className={`${t.card} ${compact ? 'p-4' : 'p-5'} space-y-4`}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h2 className={`${compact ? 'text-sm uppercase tracking-wide' : 'text-lg'} font-bold ${compact ? t.muted : t.title}`}>
            Mikrofon
          </h2>
          {audio && (
            <p className={`text-xs ${t.muted} mt-0.5`}>
              {channels.length} kanal · {audio.mode === 'none' ? 'tanpa mixer' : `mixer ${audio.mixer?.name || audio.mode}`}
              {activeSet.size > 0 && <> · <span className="text-emerald-500 font-medium">{activeSet.size} bicara</span></>}
            </p>
          )}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className={`inline-flex items-center gap-1 text-xs ${live.connected ? 'text-emerald-500' : t.faint}`}>
            <span className={`h-1.5 w-1.5 rounded-full ${live.connected ? 'bg-emerald-500' : 'bg-gray-400'}`} />
            {live.connected ? 'Live' : 'Offline'}
          </span>
          <button type="button" onClick={load} disabled={loading} title="Muat ulang"
            className={`h-8 w-8 rounded-lg ${t.btn} flex items-center justify-center disabled:opacity-50`}>
            <i className={`ri-refresh-line ${loading ? 'animate-spin' : ''}`}></i>
          </button>
        </div>
      </div>

      {loadError && <p className="text-sm text-red-500">{loadError}</p>}

      {audio && !audio.can_control && (
        <div className={`p-3 rounded-lg text-xs border ${dark ? 'bg-slate-800 border-slate-700 text-slate-300' : 'bg-black/[0.03] dark:bg-white/[0.03] border-black/10 dark:border-white/10 text-black/70 dark:text-white/70'}`}>
          <i className="ri-information-line mr-1"></i>
          {audio.message || 'Mixer tidak terpasang; atur manual di receiver'}.
          {' '}Level mic tampil bila recorder multikanal aktif.
        </div>
      )}
      {audio?.can_control && mqttDown && (
        <p className="text-xs text-amber-500">Broker MQTT belum dikonfigurasi — kontrol mixer nonaktif.</p>
      )}
      {audio?.can_control && !canControl && (
        <p className={`text-xs ${t.muted}`}>Anda hanya dapat melihat (butuh izin kontrol audio).</p>
      )}

      {audio && channels.length === 0 && (
        <p className={`text-sm ${t.muted}`}>Belum ada kanal mic untuk ruangan ini. Atur di menu Audio → Kanal Mic.</p>
      )}

      {audio?.can_control && channels.length > 0 && (
        <div className={`flex flex-wrap items-center gap-3 ${t.sub} p-3`}>
          <button type="button" disabled={disabled} onClick={() => run('mute-all', () => authApi.avMuteAll(roomId, true))}
            className={`h-9 px-3 rounded-lg text-xs font-semibold disabled:opacity-50 ${dark ? 'bg-red-500/15 border border-red-500/30 text-red-400' : 'bg-red-600 text-white hover:bg-red-700'}`}>
            <i className="ri-mic-off-line mr-1"></i>Mute semua
          </button>
          <button type="button" disabled={disabled} onClick={() => run('unmute-all', () => authApi.avMuteAll(roomId, false))}
            className={`h-9 px-3 rounded-lg text-xs font-semibold disabled:opacity-50 ${t.btn}`}>
            <i className="ri-mic-line mr-1"></i>Aktifkan semua
          </button>
          <CommandBadge state={states['mute-all'] || states['unmute-all']} dark={dark} />
          <div className="flex items-center gap-2 flex-1 min-w-[200px]">
            <span className={`text-xs ${t.muted} shrink-0`}>Master</span>
            <input type="range" min={0} max={100} disabled={disabled || mainFader == null}
              value={Math.round((mainFader ?? 0) * 100)}
              onChange={(e) => setMainDraft(Number(e.target.value) / 100)}
              onPointerUp={(e) => commitMain(Number((e.target as HTMLInputElement).value) / 100)}
              onKeyUp={(e) => commitMain(Number((e.target as HTMLInputElement).value) / 100)}
              className="flex-1 accent-emerald-500 h-2 disabled:opacity-50" />
            <span className={`text-xs ${t.muted} w-10 text-right`}>{mainFader == null ? '-' : `${Math.round(mainFader * 100)}%`}</span>
            <CommandBadge state={states['fader-main']} dark={dark} />
          </div>
          {mixer?.main?.muted && <span className="text-xs font-semibold text-red-500">MASTER MUTE</span>}
        </div>
      )}

      {channels.length > 0 && (
        <div className={`grid gap-2 ${compact ? 'grid-cols-2' : 'grid-cols-2 sm:grid-cols-4 xl:grid-cols-8'}`}>
          {channels.map((ch) => {
            const ms = mixer?.channels?.[String(ch.channel_no)];
            const muted = ms?.muted;
            const active = activeSet.has(ch.channel_no);
            const seat = seatsByChannel?.[ch.channel_no];
            const st = states[`mic-${ch.channel_no}`];
            return (
              <div key={ch.id}
                className={`rounded-lg p-2.5 border transition-colors ${
                  active
                    ? 'border-emerald-500 ring-2 ring-emerald-500/40 bg-emerald-500/10'
                    : muted
                      ? `${dark ? 'border-red-500/30 bg-red-500/5' : 'border-red-300 dark:border-red-500/30 bg-red-50/50 dark:bg-red-500/5'}`
                      : `${dark ? 'border-slate-700 bg-slate-800/60' : 'border-black/10 dark:border-white/10'}`
                }`}>
                <div className="flex items-start justify-between gap-1">
                  <div className="min-w-0">
                    <p className={`text-sm font-semibold truncate ${t.text}`}>{seat?.label || ch.label}</p>
                    <p className={`text-[11px] truncate ${t.faint}`}>
                      {seat?.name || (seat ? ch.label : ch.receiver_label || `Kanal ${ch.channel_no}`)}
                    </p>
                  </div>
                  {active && <i className="ri-volume-up-fill text-emerald-500 animate-pulse" title="Sedang bicara"></i>}
                </div>
                <div className="mt-2">
                  <LevelMeter db={levels[ch.channel_no]} active={active} bg={t.meterBg} />
                </div>
                {audio?.can_control && (
                  <div className="mt-2 flex items-center justify-between gap-1">
                    <button type="button" disabled={disabled || ch.mixer_channel == null} onClick={() => toggleMute(ch, muted)}
                      title={ch.mixer_channel == null ? 'Kanal belum dipetakan ke mixer' : undefined}
                      className={`h-7 px-2 rounded-md text-[11px] font-semibold disabled:opacity-50 ${
                        muted
                          ? 'bg-red-600 text-white'
                          : dark ? 'bg-slate-700 text-slate-200' : 'bg-black/5 dark:bg-white/10 text-black/70 dark:text-white/70'
                      }`}>
                      {muted ? <><i className="ri-mic-off-line"></i> MUTE</> : <><i className="ri-mic-line"></i> ON</>}
                    </button>
                    {st ? <CommandBadge state={st} dark={dark} /> : ms?.gain != null && !compact ? (
                      <span className={`text-[10px] ${t.faint}`}>{ms.gain.toFixed(0)} dB</span>
                    ) : null}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <CommandDetail state={lastState} dark={dark} />
    </section>
  );
}

export default MicMixerPanel;
