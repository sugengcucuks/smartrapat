import { useCallback, useEffect, useState } from 'react';
import { authApi } from '@shared/api/auth';
import type { AudioChannelInput } from '@shared/types';
import { useAuthStore } from '../../store/auth.store';
import { apiErrorMessage, hasPermission } from './avUtils';

interface Row extends AudioChannelInput {
  key: string;
}

let rowSeq = 0;
const newKey = () => `r${++rowSeq}`;

function defaultChannels(count = 16): Row[] {
  return Array.from({ length: count }, (_, i) => {
    const n = i + 1;
    return {
      key: newKey(),
      channel_no: n,
      label: `Mic ${n}`,
      receiver_label: `M118-${n <= 8 ? 'A' : 'B'} CH${((n - 1) % 8) + 1}`,
      mixer_channel: n,
      capture_channel: n,
      enabled: true,
    };
  });
}

function numOrNull(v: string): number | null {
  if (v.trim() === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

/** Editor kanal mic ruangan (GET/PUT /rooms/{id}/audio-channels). */
export function AudioChannelEditor({ roomId, onSaved }: { roomId: string; onSaved?: () => void }) {
  const user = useAuthStore((s) => s.user);
  const canWrite = hasPermission(user, 'rooms.write');
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [dirty, setDirty] = useState(false);

  const load = useCallback(async () => {
    if (!roomId) return;
    setLoading(true);
    setError(null);
    setInfo(null);
    try {
      const list = await authApi.listAudioChannels(roomId);
      setRows(list.map((c) => ({
        key: newKey(), channel_no: c.channel_no, label: c.label, receiver_label: c.receiver_label,
        mixer_channel: c.mixer_channel, capture_channel: c.capture_channel, device_id: c.device_id, enabled: c.enabled,
      })));
      setDirty(false);
    } catch (err) {
      setError(apiErrorMessage(err, 'Gagal memuat kanal mic'));
    } finally {
      setLoading(false);
    }
  }, [roomId]);

  useEffect(() => {
    load();
  }, [load]);

  const update = (key: string, patch: Partial<Row>) => {
    setRows((prev) => prev.map((r) => (r.key === key ? { ...r, ...patch } : r)));
    setDirty(true);
  };

  const addRow = () => {
    const next = rows.reduce((m, r) => Math.max(m, r.channel_no), 0) + 1;
    setRows((prev) => [...prev, { key: newKey(), channel_no: next, label: `Mic ${next}`, receiver_label: '',
      mixer_channel: null, capture_channel: null, enabled: true }]);
    setDirty(true);
  };

  const generate = () => {
    if (rows.length > 0 && !window.confirm('Ganti daftar kanal saat ini dengan 16 kanal default?')) return;
    setRows(defaultChannels(16));
    setDirty(true);
  };

  const validate = (): string | null => {
    const seen = new Set<number>();
    for (const r of rows) {
      if (!r.channel_no || r.channel_no < 1 || r.channel_no > 64) return `Nomor kanal harus 1-64 (baris "${r.label}")`;
      if (seen.has(r.channel_no)) return `Nomor kanal ${r.channel_no} dipakai lebih dari sekali`;
      seen.add(r.channel_no);
      if (!r.label.trim()) return `Label kanal ${r.channel_no} wajib diisi`;
    }
    const dup = (vals: (number | null | undefined)[]) => {
      const v = vals.filter((x): x is number => x != null);
      return v.length !== new Set(v).size;
    };
    if (dup(rows.map((r) => r.mixer_channel))) return 'Kanal mixer tidak boleh dipakai dua kali';
    if (dup(rows.map((r) => r.capture_channel))) return 'Kanal rekam tidak boleh dipakai dua kali';
    return null;
  };

  const save = async () => {
    const v = validate();
    if (v) {
      setError(v);
      return;
    }
    setSaving(true);
    setError(null);
    setInfo(null);
    try {
      const payload: AudioChannelInput[] = [...rows]
        .sort((a, b) => a.channel_no - b.channel_no)
        .map(({ key: _k, ...r }) => ({ ...r, receiver_label: r.receiver_label || null }));
      const saved = await authApi.saveAudioChannels(roomId, payload);
      setRows(saved.map((c) => ({
        key: newKey(), channel_no: c.channel_no, label: c.label, receiver_label: c.receiver_label,
        mixer_channel: c.mixer_channel, capture_channel: c.capture_channel, device_id: c.device_id, enabled: c.enabled,
      })));
      setDirty(false);
      setInfo(`${saved.length} kanal tersimpan`);
      onSaved?.();
    } catch (err) {
      setError(apiErrorMessage(err, 'Gagal menyimpan kanal mic'));
    } finally {
      setSaving(false);
    }
  };

  const inputCls = 'w-full px-2 py-1.5 text-sm bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-md outline-none focus:border-primary dark:text-white/80 disabled:opacity-60';

  return (
    <section className="bg-white dark:bg-gray rounded-lg shadow-md p-5 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-black dark:text-white">Kanal Mic</h2>
          <p className="text-xs text-black/60 dark:text-white/60 mt-0.5">
            Pemetaan mic fisik (receiver Ashley M118) ke kanal mixer & kanal rekam. Kursi di denah merujuk ke kanal ini.
          </p>
        </div>
        {canWrite && (
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={generate} disabled={saving}
              className="px-3 py-2 text-sm font-medium rounded-lg bg-black/5 dark:bg-white/10 text-black/70 dark:text-white/80 hover:bg-black/10 dark:hover:bg-white/20 disabled:opacity-50">
              <i className="ri-magic-line mr-1"></i>Generate 16 kanal default
            </button>
            <button type="button" onClick={addRow} disabled={saving}
              className="px-3 py-2 text-sm font-medium rounded-lg bg-black/5 dark:bg-white/10 text-black/70 dark:text-white/80 hover:bg-black/10 dark:hover:bg-white/20 disabled:opacity-50">
              <i className="ri-add-line mr-1"></i>Tambah
            </button>
            <button type="button" onClick={save} disabled={saving || !dirty}
              className="px-4 py-2 text-sm font-medium rounded-lg bg-primary text-white hover:bg-primary/90 disabled:opacity-50 inline-flex items-center gap-2">
              {saving && <i className="ri-loader-4-line animate-spin"></i>}Simpan
            </button>
          </div>
        )}
      </div>

      {error && (
        <div className="p-3 rounded-lg bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400 text-sm">
          <i className="ri-error-warning-line mr-1"></i>{error}
        </div>
      )}
      {info && !dirty && <p className="text-sm text-green-600 dark:text-green-400"><i className="ri-check-line mr-1"></i>{info}</p>}
      {!canWrite && <p className="text-xs text-black/50 dark:text-white/50">Hanya baca (butuh izin kelola ruangan).</p>}

      <div className="overflow-x-auto -mx-5">
        <table className="w-full text-sm min-w-[720px]">
          <thead>
            <tr className="border-y border-black/10 dark:border-white/10 text-left text-black/70 dark:text-white/70">
              <th className="py-2 px-3 w-20">No</th>
              <th className="py-2 px-3">Label</th>
              <th className="py-2 px-3">Receiver</th>
              <th className="py-2 px-3 w-28">Kanal Mixer</th>
              <th className="py-2 px-3 w-28">Kanal Rekam</th>
              <th className="py-2 px-3 w-20 text-center">Aktif</th>
              <th className="py-2 px-3 w-12"></th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="py-8 text-center text-black/50 dark:text-white/50">Memuat...</td></tr>
            ) : rows.length === 0 ? (
              <tr><td colSpan={7} className="py-8 text-center text-black/50 dark:text-white/50">
                Belum ada kanal. Klik “Generate 16 kanal default”.
              </td></tr>
            ) : rows.map((r) => (
              <tr key={r.key} className="border-b border-black/5 dark:border-white/5">
                <td className="py-1.5 px-3">
                  <input type="number" min={1} max={64} value={r.channel_no} disabled={!canWrite}
                    onChange={(e) => update(r.key, { channel_no: Number(e.target.value) })} className={inputCls} />
                </td>
                <td className="py-1.5 px-3">
                  <input type="text" value={r.label} maxLength={100} disabled={!canWrite}
                    onChange={(e) => update(r.key, { label: e.target.value })} className={inputCls} />
                </td>
                <td className="py-1.5 px-3">
                  <input type="text" value={r.receiver_label || ''} maxLength={100} disabled={!canWrite} placeholder="M118-A CH1"
                    onChange={(e) => update(r.key, { receiver_label: e.target.value })} className={inputCls} />
                </td>
                <td className="py-1.5 px-3">
                  <input type="number" min={1} max={64} value={r.mixer_channel ?? ''} disabled={!canWrite} placeholder="-"
                    onChange={(e) => update(r.key, { mixer_channel: numOrNull(e.target.value) })} className={inputCls} />
                </td>
                <td className="py-1.5 px-3">
                  <input type="number" min={1} max={64} value={r.capture_channel ?? ''} disabled={!canWrite} placeholder="-"
                    onChange={(e) => update(r.key, { capture_channel: numOrNull(e.target.value) })} className={inputCls} />
                </td>
                <td className="py-1.5 px-3 text-center">
                  <input type="checkbox" checked={r.enabled} disabled={!canWrite}
                    onChange={(e) => update(r.key, { enabled: e.target.checked })} className="h-4 w-4 accent-primary" />
                </td>
                <td className="py-1.5 px-3 text-right">
                  {canWrite && (
                    <button type="button" title="Hapus" onClick={() => { setRows((p) => p.filter((x) => x.key !== r.key)); setDirty(true); }}
                      className="p-1.5 text-black/50 dark:text-white/50 hover:text-red-600 rounded">
                      <i className="ri-delete-bin-line"></i>
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

export default AudioChannelEditor;
