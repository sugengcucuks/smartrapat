import type { CommandUiState } from './avUtils';
import { COMMAND_STATUS_LABEL } from './avUtils';

/** Badge status perintah (pending / berhasil / gagal / tanpa respons). */
export function CommandBadge({ state, dark = false }: { state?: CommandUiState; dark?: boolean }) {
  if (!state) return null;
  const cls: Record<string, string> = {
    pending: dark ? 'text-slate-300' : 'text-black/60 dark:text-white/60',
    acked: dark ? 'text-emerald-400' : 'text-green-600 dark:text-green-400',
    sent: dark ? 'text-slate-300' : 'text-black/60 dark:text-white/60',
    failed: dark ? 'text-red-400' : 'text-red-600 dark:text-red-400',
    error: dark ? 'text-red-400' : 'text-red-600 dark:text-red-400',
    timeout: dark ? 'text-amber-400' : 'text-amber-600 dark:text-amber-400',
  };
  const icon: Record<string, string> = {
    pending: 'ri-loader-4-line animate-spin',
    sent: 'ri-send-plane-line',
    acked: 'ri-checkbox-circle-line',
    failed: 'ri-close-circle-line',
    error: 'ri-close-circle-line',
    timeout: 'ri-time-line',
  };
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-medium ${cls[state.status] || ''}`} title={state.message}>
      <i className={icon[state.status] || ''}></i>
      {COMMAND_STATUS_LABEL[state.status]}
    </span>
  );
}

/** Rincian hasil perintah terakhir (per perangkat) — hanya tampil bila tidak sukses. */
export function CommandDetail({ state, dark = false }: { state?: CommandUiState; dark?: boolean }) {
  if (!state || state.status === 'pending' || state.status === 'acked') return null;
  const box = dark
    ? 'bg-red-500/10 border-red-500/30 text-red-300'
    : 'bg-red-50 dark:bg-red-500/10 border-red-200 dark:border-red-500/20 text-red-700 dark:text-red-400';
  const warn = dark
    ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
    : 'bg-amber-50 dark:bg-amber-500/10 border-amber-200 dark:border-amber-500/20 text-amber-700 dark:text-amber-400';
  const failed = state.result?.results.filter((r) => r.status !== 'acked') || [];
  return (
    <div className={`mt-2 p-2.5 rounded-lg border text-xs ${state.status === 'timeout' ? warn : box}`}>
      <p className="font-medium">{state.message}</p>
      {failed.length > 1 && (
        <ul className="mt-1 space-y-0.5">
          {failed.map((r) => (
            <li key={r.cmd_id}>
              <span className="font-mono">{r.device_code}</span>: {r.error || COMMAND_STATUS_LABEL[r.status]}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
