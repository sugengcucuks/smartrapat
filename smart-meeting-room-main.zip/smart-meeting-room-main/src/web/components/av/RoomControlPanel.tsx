import { useCallback, useEffect, useMemo, useState } from 'react';
import { authApi } from '@shared/api/auth';
import type { AvDeviceBrief, DeviceLiveState, RoomAvCapabilities, VideowallPreset } from '@shared/types';
import { useAuthStore } from '../../store/auth.store';
import { useRoomLive, type RoomLiveState } from '../../hooks/useRoomLive';
import { apiErrorMessage, avTone, hasPermission, useAvCommands, type AvVariant } from './avUtils';
import { CommandBadge, CommandDetail } from './CommandFeedback';

export interface RoomControlPanelProps {
  roomId: string;
  /** Tampilan ringkas (mobile / panel samping live meeting). */
  compact?: boolean;
  /** 'dark' untuk halaman bertema gelap tetap (mis. /m mobile). Default ikut tema app. */
  variant?: AvVariant;
  /** Bagikan koneksi WS dari useRoomLive milik halaman agar tidak membuka koneksi kedua. */
  live?: RoomLiveState;
}

function mergedState(dev: AvDeviceBrief, live: Record<string, DeviceLiveState>): DeviceLiveState & { isOnline: boolean } {
  const st = { ...(dev.live || {}), ...(live[dev.id] || {}) };
  const isOnline = st.online === true || (st.online == null && dev.status === 'online');
  return { ...st, isOnline };
}

function PresetPreview({ preset, grid, active, dark }: {
  preset: VideowallPreset; grid: { cols: number; rows: number }; active: boolean; dark: boolean;
}) {
  return (
    <div className={`relative w-full rounded ${dark ? 'bg-black/60' : 'bg-black/80'}`} style={{ aspectRatio: `${grid.cols * 16} / ${grid.rows * 9}` }}>
      {/* garis bezel panel */}
      <div className="absolute inset-0 grid" style={{ gridTemplateColumns: `repeat(${grid.cols}, 1fr)`, gridTemplateRows: `repeat(${grid.rows}, 1fr)` }}>
        {Array.from({ length: grid.cols * grid.rows }).map((_, i) => (
          <div key={i} className="border border-white/10" />
        ))}
      </div>
      {preset.windows.map((w) => (
        <div
          key={w.id}
          className={`absolute flex items-center justify-center text-[10px] font-semibold rounded-sm ${
            active ? 'bg-emerald-500/50 text-white' : 'bg-sky-500/40 text-white/90'
          }`}
          style={{ left: `${w.x * 100 + 1}%`, top: `${w.y * 100 + 2}%`, width: `${w.w * 100 - 2}%`, height: `${w.h * 100 - 4}%` }}
        >
          {w.id}
        </div>
      ))}
    </div>
  );
}

/**
 * Kontrol videowall satu ruangan: power (WoL/IP control panel + processor),
 * preset layout & sumber (dari GET /rooms/{id}/av/capabilities), status online
 * perangkat (live dari WS), dan umpan balik per perintah (mengirim/berhasil/gagal).
 */
export function RoomControlPanel({ roomId, compact = false, variant = 'default', live: liveProp }: RoomControlPanelProps) {
  const t = avTone(variant);
  const dark = variant === 'dark';
  const user = useAuthStore((s) => s.user);
  const canControl = hasPermission(user, 'videowall.control');
  const ownLive = useRoomLive(liveProp ? null : roomId);
  const live = liveProp || ownLive;

  const [caps, setCaps] = useState<RoomAvCapabilities | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [lastPreset, setLastPreset] = useState<string | null>(null);
  const [lastSource, setLastSource] = useState<Record<number, string>>({});
  const [windowNo, setWindowNo] = useState(1);
  const { states, run, busy } = useAvCommands();

  const load = useCallback(async () => {
    if (!roomId) return;
    setLoading(true);
    setLoadError(null);
    try {
      setCaps(await authApi.getRoomAvCapabilities(roomId));
    } catch (err) {
      setCaps(null);
      setLoadError(apiErrorMessage(err, 'Gagal memuat kapabilitas AV ruangan'));
    } finally {
      setLoading(false);
    }
  }, [roomId]);

  useEffect(() => {
    setLastPreset(null);
    setLastSource({});
    setWindowNo(1);
    load();
  }, [load]);

  const vw = caps?.videowall;
  const controllerState = vw?.controller ? mergedState(vw.controller, live.devices) : null;
  const activePresetId = lastPreset || (controllerState?.layout as string | undefined) || null;
  const activePreset = useMemo(
    () => vw?.presets.find((p) => p.id === activePresetId) || null,
    [vw, activePresetId],
  );
  const windowCount = activePreset ? Math.max(1, activePreset.windows.length) : 1;
  useEffect(() => {
    if (windowNo > windowCount) setWindowNo(1);
  }, [windowCount, windowNo]);

  const panelStates = (vw?.panels || []).map((p) => ({ dev: p, st: mergedState(p, live.devices) }));
  const onlinePanels = panelStates.filter((p) => p.st.isOnline).length;
  const poweredOn = panelStates.filter((p) => p.st.power === 'on').length;

  const doPower = (on: boolean) =>
    run(on ? 'power-on' : 'power-off', () => authApi.avVideowallPower(roomId, on));
  const doPreset = async (p: VideowallPreset) => {
    const res = await run(`preset-${p.id}`, () => authApi.avVideowallLayout(roomId, p.id));
    if (res?.status === 'acked') setLastPreset(p.id);
  };
  const doSource = async (sourceId: string) => {
    const w = windowNo;
    const res = await run(`source-${sourceId}`, () => authApi.avVideowallSource(roomId, sourceId, w));
    if (res?.status === 'acked') setLastSource((prev) => ({ ...prev, [w]: sourceId }));
  };

  const mqttDown = caps && !caps.mqtt.configured && !caps.mqtt.simulate;
  const mqttDisconnected = caps && caps.mqtt.configured && !caps.mqtt.connected;
  const disabled = !canControl || busy || !!mqttDown;
  const lastState = Object.values(states).sort((a, b) => b.at - a.at)[0];

  const pad = compact ? 'p-4' : 'p-5';

  return (
    <section className={`${t.card} ${pad} space-y-4`}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h2 className={`${compact ? 'text-sm uppercase tracking-wide' : 'text-lg'} font-bold ${compact ? t.muted : t.title}`}>
            Videowall
          </h2>
          {vw && (
            <p className={`text-xs ${t.muted} mt-0.5`}>
              {vw.panels.length} panel · {onlinePanels} online · {poweredOn} menyala
              {vw.controller && (
                <>
                  {' '}· processor{' '}
                  <span className={controllerState?.isOnline ? 'text-emerald-500' : t.faint}>
                    {controllerState?.isOnline ? 'online' : 'offline'}
                  </span>
                </>
              )}
            </p>
          )}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className={`inline-flex items-center gap-1 text-xs ${live.connected ? 'text-emerald-500' : t.faint}`} title="Koneksi realtime">
            <span className={`h-1.5 w-1.5 rounded-full ${live.connected ? 'bg-emerald-500' : 'bg-gray-400'}`} />
            {live.connected ? 'Live' : 'Offline'}
          </span>
          <button type="button" onClick={load} disabled={loading} title="Muat ulang"
            className={`h-8 w-8 rounded-lg ${t.btn} flex items-center justify-center disabled:opacity-50`}>
            <i className={`ri-refresh-line ${loading ? 'animate-spin' : ''}`}></i>
          </button>
        </div>
      </div>

      {loadError && <p className="text-sm text-red-500">{loadError}</p>}
      {mqttDown && (
        <div className={`p-3 rounded-lg text-xs border ${dark ? 'bg-amber-500/10 border-amber-500/30 text-amber-300' : 'bg-amber-50 dark:bg-amber-500/10 border-amber-200 dark:border-amber-500/20 text-amber-700 dark:text-amber-400'}`}>
          Broker MQTT belum dikonfigurasi di server — kontrol perangkat nonaktif.
        </div>
      )}
      {mqttDisconnected && (
        <div className={`p-3 rounded-lg text-xs border ${dark ? 'bg-amber-500/10 border-amber-500/30 text-amber-300' : 'bg-amber-50 dark:bg-amber-500/10 border-amber-200 dark:border-amber-500/20 text-amber-700 dark:text-amber-400'}`}>
          Server belum terhubung ke broker MQTT{caps?.mqtt.last_error ? ` (${caps.mqtt.last_error})` : ''}.
        </div>
      )}
      {!canControl && caps && (
        <p className={`text-xs ${t.muted}`}>Anda hanya dapat melihat status (butuh izin kontrol videowall).</p>
      )}

      {caps && !vw?.available && (
        <p className={`text-sm ${t.muted}`}>
          Ruangan ini belum punya perangkat videowall. Tambahkan perangkat bertipe
          “Videowall Controller” dan “TV / Panel Videowall” di menu Perangkat IoT.
        </p>
      )}

      {vw?.available && (
        <>
          {/* Power */}
          <div className="grid grid-cols-2 gap-3">
            <button type="button" disabled={disabled} onClick={() => doPower(true)}
              className={`${compact ? 'h-12' : 'h-11'} rounded-xl font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-50 ${
                dark ? 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-400' : 'bg-green-600 text-white hover:bg-green-700'
              }`}>
              <i className="ri-power-line"></i> Hidupkan
            </button>
            <button type="button" disabled={disabled} onClick={() => doPower(false)}
              className={`${compact ? 'h-12' : 'h-11'} rounded-xl font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-50 ${
                dark ? 'bg-red-500/15 border border-red-500/30 text-red-400' : 'bg-red-600 text-white hover:bg-red-700'
              }`}>
              <i className="ri-shut-down-line"></i> Matikan
            </button>
          </div>
          <div className="flex items-center gap-3 min-h-[1rem]">
            <CommandBadge state={states['power-on']} dark={dark} />
            <CommandBadge state={states['power-off']} dark={dark} />
          </div>

          {/* Preset */}
          {vw.controller && (
            <div>
              <p className={`text-xs font-medium ${t.muted} mb-2`}>Layout</p>
              <div className={`grid gap-2 ${compact ? 'grid-cols-2' : 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-5'}`}>
                {vw.presets.map((p) => {
                  const active = p.id === activePresetId;
                  const st = states[`preset-${p.id}`];
                  return (
                    <button key={p.id} type="button" disabled={disabled} onClick={() => doPreset(p)}
                      className={`p-2 rounded-lg text-left transition-colors disabled:opacity-50 ${active ? t.btnActive : t.btn}`}>
                      {!compact && <PresetPreview preset={p} grid={vw.grid} active={active} dark={dark} />}
                      <div className="mt-1.5 flex items-center justify-between gap-1">
                        <span className="text-xs font-medium leading-tight">{p.label}</span>
                        {st && <CommandBadge state={st} dark={dark || active} />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Sumber */}
          {vw.controller && (
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <p className={`text-xs font-medium ${t.muted}`}>Sumber</p>
                {windowCount > 1 && (
                  <label className={`text-xs ${t.muted} flex items-center gap-1.5`}>
                    Jendela
                    <select value={windowNo} onChange={(e) => setWindowNo(Number(e.target.value))}
                      className={`px-2 py-1 rounded-md text-xs outline-none ${t.input}`}>
                      {Array.from({ length: windowCount }).map((_, i) => (
                        <option key={i + 1} value={i + 1}>{i + 1}</option>
                      ))}
                    </select>
                  </label>
                )}
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {vw.sources.map((s) => {
                  const active = lastSource[windowNo] === s.id ||
                    (!lastSource[windowNo] && windowNo === 1 && controllerState?.source === s.id);
                  return (
                    <button key={s.id} type="button" disabled={disabled} onClick={() => doSource(s.id)}
                      className={`h-11 rounded-lg text-sm font-medium flex items-center justify-center gap-1.5 disabled:opacity-50 ${active ? t.btnActive : t.btn}`}>
                      <i className="ri-hd-line"></i>{s.label}
                      {states[`source-${s.id}`]?.status === 'pending' && <i className="ri-loader-4-line animate-spin"></i>}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <CommandDetail state={lastState} dark={dark} />

          {/* Perangkat */}
          {!compact && (
            <div>
              <p className={`text-xs font-medium ${t.muted} mb-2`}>Perangkat</p>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {[...(vw.controller ? [vw.controller] : []), ...vw.panels].map((d) => {
                  const st = mergedState(d, live.devices);
                  return (
                    <li key={d.id} className={`${t.sub} px-3 py-2 flex items-center justify-between gap-2`}>
                      <div className="min-w-0">
                        <p className={`text-sm font-medium truncate ${t.text}`}>{d.name}</p>
                        <p className={`text-xs ${t.faint} font-mono`}>{d.code}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <span className={`inline-flex items-center gap-1 text-xs font-medium ${st.isOnline ? 'text-emerald-500' : t.faint}`}>
                          <span className={`h-1.5 w-1.5 rounded-full ${st.isOnline ? 'bg-emerald-500' : 'bg-gray-400'}`} />
                          {st.isOnline ? 'Online' : 'Offline'}
                        </span>
                        {st.power && <p className={`text-[11px] ${t.faint}`}>Daya: {st.power === 'on' ? 'nyala' : 'mati'}</p>}
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
        </>
      )}
    </section>
  );
}

export default RoomControlPanel;
