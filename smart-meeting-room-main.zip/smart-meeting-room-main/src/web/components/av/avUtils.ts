import { useCallback, useEffect, useRef, useState } from 'react';
import type { AvCommandResult, AvCommandStatus, User } from '@shared/types';

/** Ambil pesan error asli dari FastAPI (`detail` string / {code,message} / array validasi). */
export function apiErrorMessage(err: unknown, fallback = 'Permintaan gagal'): string {
  const e = err as {
    response?: { status?: number; data?: { detail?: unknown; message?: string } };
    message?: string;
  };
  const status = e?.response?.status;
  const detail = e?.response?.data?.detail;
  if (typeof detail === 'string') return detail;
  if (detail && typeof detail === 'object' && !Array.isArray(detail)) {
    const d = detail as { message?: string; code?: string };
    if (d.message) return d.message;
    if (d.code) return d.code;
  }
  if (Array.isArray(detail) && detail.length > 0) {
    const first = detail[0] as { msg?: string; loc?: unknown[] };
    const field = Array.isArray(first.loc) ? first.loc[first.loc.length - 1] : '';
    return `${field ? `${String(field)}: ` : ''}${first.msg || 'data tidak valid'}`;
  }
  if (status === 403) return 'Anda tidak memiliki izin untuk aksi ini';
  if (status === 503) return 'Layanan kontrol perangkat tidak tersedia (broker MQTT)';
  if (!e?.response) return 'Tidak dapat terhubung ke server';
  return e?.response?.data?.message || fallback;
}

export function hasPermission(user: User | null | undefined, ...codes: string[]): boolean {
  const perms = user?.permissions || [];
  if (perms.includes('*')) return true;
  return codes.some((c) => perms.includes(c));
}

export const COMMAND_STATUS_LABEL: Record<AvCommandStatus | 'pending' | 'error', string> = {
  sent: 'Terkirim',
  pending: 'Mengirim...',
  acked: 'Berhasil',
  failed: 'Gagal',
  timeout: 'Tidak ada respons',
  error: 'Gagal',
};

export function commandSummary(result: AvCommandResult): string {
  if (result.status === 'acked') {
    const n = result.results.length;
    return n > 1 ? `Berhasil (${n} perangkat)` : 'Berhasil';
  }
  if (result.status === 'timeout') {
    return result.error || 'Agent tidak merespons dalam 3 detik';
  }
  return result.error || 'Perintah gagal di perangkat';
}

export type CommandUiStatus = 'pending' | AvCommandStatus | 'error';

export interface CommandUiState {
  status: CommandUiStatus;
  message?: string;
  result?: AvCommandResult;
  at: number;
}

/**
 * Menjalankan perintah AV dan menyimpan status per tombol (key):
 * pending -> acked | failed | timeout | error (HTTP gagal).
 * Status sukses hilang otomatis setelah 4 detik, gagal setelah 10 detik.
 */
export function useAvCommands() {
  const [states, setStates] = useState<Record<string, CommandUiState>>({});
  const timers = useRef<Record<string, ReturnType<typeof setTimeout>>>({});

  useEffect(() => {
    const t = timers.current;
    return () => Object.values(t).forEach(clearTimeout);
  }, []);

  const set = useCallback((key: string, st: CommandUiState | null) => {
    setStates((prev) => {
      const next = { ...prev };
      if (st) next[key] = st;
      else delete next[key];
      return next;
    });
  }, []);

  const run = useCallback(
    async (key: string, fn: () => Promise<AvCommandResult>): Promise<AvCommandResult | null> => {
      if (timers.current[key]) clearTimeout(timers.current[key]);
      set(key, { status: 'pending', at: Date.now() });
      let final: CommandUiState;
      let result: AvCommandResult | null = null;
      try {
        result = await fn();
        final = { status: result.status, message: commandSummary(result), result, at: Date.now() };
      } catch (err) {
        final = { status: 'error', message: apiErrorMessage(err), at: Date.now() };
      }
      set(key, final);
      timers.current[key] = setTimeout(() => set(key, null), final.status === 'acked' ? 4000 : 10000);
      return result;
    },
    [set],
  );

  const busy = Object.values(states).some((s) => s.status === 'pending');
  return { states, run, busy };
}

/** dBFS -> persen tinggi meter (-60 dB = 0%, 0 dB = 100%). */
export function levelPercent(db: number | null | undefined): number {
  if (db === null || db === undefined || Number.isNaN(db)) return 0;
  return Math.max(0, Math.min(100, ((db + 60) / 60) * 100));
}

/** Kelas warna per varian: 'default' (ikut tema app) atau 'dark' (halaman mobile). */
export type AvVariant = 'default' | 'dark';

export function avTone(variant: AvVariant) {
  if (variant === 'dark') {
    return {
      card: 'rounded-2xl bg-slate-900 border border-slate-800',
      sub: 'rounded-xl bg-slate-800/60 border border-slate-700/60',
      title: 'text-slate-100',
      text: 'text-slate-200',
      muted: 'text-slate-400',
      faint: 'text-slate-500',
      btn: 'bg-slate-800 border border-slate-700 text-slate-200 hover:bg-slate-700 active:bg-slate-700',
      btnActive: 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-300',
      input: 'bg-slate-800 border border-slate-700 text-slate-200',
      meterBg: 'bg-slate-700/60',
    };
  }
  return {
    card: 'bg-white dark:bg-gray rounded-lg shadow-md',
    sub: 'rounded-lg bg-black/[0.03] dark:bg-white/[0.03] border border-black/10 dark:border-white/10',
    title: 'text-black dark:text-white',
    text: 'text-black/80 dark:text-white/80',
    muted: 'text-black/60 dark:text-white/60',
    faint: 'text-black/40 dark:text-white/40',
    btn: 'bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 text-black/70 dark:text-white/70 hover:bg-black/10 dark:hover:bg-white/10',
    btnActive: 'bg-primary text-white border border-primary shadow-sm',
    input: 'bg-black/5 dark:bg-black/40 border border-black/10 dark:border-white/10 dark:text-white/80',
    meterBg: 'bg-black/10 dark:bg-white/10',
  };
}
