import { useEffect, useState } from 'react';
import { authApi } from '@shared/api/auth';
import type { Room } from '@shared/types';
import { apiErrorMessage } from './avUtils';

const STORAGE_KEY = 'smr-av-room';

/** Daftar ruangan + ruangan terpilih (diingat per browser). */
export function useRoomSelection() {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [roomId, setRoomIdState] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const res = await authApi.listRooms({ per_page: 100 });
        if (!alive) return;
        setRooms(res.items);
        let saved = '';
        try {
          saved = localStorage.getItem(STORAGE_KEY) || '';
        } catch {
          saved = '';
        }
        const pick = res.items.find((r) => r.id === saved) || res.items[0];
        if (pick) setRoomIdState(pick.id);
      } catch (err) {
        if (alive) setError(apiErrorMessage(err, 'Gagal memuat daftar ruangan'));
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  const setRoomId = (id: string) => {
    setRoomIdState(id);
    try {
      localStorage.setItem(STORAGE_KEY, id);
    } catch {
      /* abaikan */
    }
  };

  return { rooms, roomId, setRoomId, error, loading, room: rooms.find((r) => r.id === roomId) || null };
}

export function RoomSelect({ rooms, value, onChange }: { rooms: Room[]; value: string; onChange: (id: string) => void }) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)}
      className="w-full sm:w-72 px-3 py-2 text-sm bg-white dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg outline-none focus:border-primary transition-colors dark:text-white/80">
      {rooms.length === 0 && <option value="">Tidak ada ruangan</option>}
      {rooms.map((r) => (
        <option key={r.id} value={r.id}>{r.name} ({r.code})</option>
      ))}
    </select>
  );
}
