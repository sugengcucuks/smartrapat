import { useCallback, useEffect, useRef, useState } from 'react';
import apiClient, { buildWsUrl } from '@shared/api/client';
import { useAuthStore } from '../store/auth.store';
import type { DeviceLiveState, MixerState } from '@shared/types';

/** Pesan dari server: {"event", "room_id", "data", "ts"} (docs/architecture/LIVE_MEETING.md §5). */
export interface RoomLiveEvent<T = unknown> {
  event: string;
  room_id?: string;
  data: T;
  ts?: string;
}

export type RoomLiveListener = (data: any, msg: RoomLiveEvent) => void;

/**
 * Bentuk nilai kembali `useRoomLive(roomId)`:
 *
 * - connected           : WebSocket terhubung & terautentikasi
 * - levels              : { [channel_no]: dBFS } dari event `audio_levels` (maks 5 Hz)
 * - activeChannels      : kanal mic yang sedang bicara (event `active_speakers`)
 * - activeSeats         : id kursi (room_seats.id) yang sedang bicara
 * - activeParticipants  : id peserta (booking_participants.id) yang sedang bicara
 * - mixer               : state mixer terakhir (event `mixer_state`), null bila belum ada
 * - devices             : { [device_id]: state } dari event `device_state`
 * - lastEvent           : pesan terakhir apa pun (termasuk event live meeting/notulensi)
 * - subscribe(ev, cb)   : dengarkan event apa pun (mis. 'transcript_segment',
 *                         'attendance_changed', 'seats_changed', 'meeting_status', '*' = semua);
 *                         mengembalikan fungsi unsubscribe.
 *
 * Koneksi: /api/v1/ws/rooms/{roomId}/live?token=<access token>, ws/wss mengikuti
 * window.location, reconnect otomatis (backoff 1..30 dtk), berhenti saat unmount
 * atau roomId kosong.
 */
export interface RoomLiveState {
  connected: boolean;
  levels: Record<number, number>;
  activeChannels: number[];
  activeSeats: string[];
  activeParticipants: string[];
  mixer: MixerState | null;
  devices: Record<string, DeviceLiveState>;
  lastEvent: RoomLiveEvent | null;
  subscribe: (event: string, cb: RoomLiveListener) => () => void;
}

function currentToken(storeToken: string | null): string | null {
  // Token tunggal ada di auth store (diperbarui interceptor saat refresh).
  return useAuthStore.getState().accessToken || storeToken;
}

export function useRoomLive(roomId: string | null | undefined): RoomLiveState {
  const storeToken = useAuthStore((s) => s.accessToken);
  const tokenRef = useRef(storeToken);
  tokenRef.current = storeToken;

  const [connected, setConnected] = useState(false);
  const [levels, setLevels] = useState<Record<number, number>>({});
  const [activeChannels, setActiveChannels] = useState<number[]>([]);
  const [activeSeats, setActiveSeats] = useState<string[]>([]);
  const [activeParticipants, setActiveParticipants] = useState<string[]>([]);
  const [mixer, setMixer] = useState<MixerState | null>(null);
  const [devices, setDevices] = useState<Record<string, DeviceLiveState>>({});
  const [lastEvent, setLastEvent] = useState<RoomLiveEvent | null>(null);
  const listeners = useRef<Map<string, Set<RoomLiveListener>>>(new Map());

  const subscribe = useCallback((event: string, cb: RoomLiveListener) => {
    const map = listeners.current;
    if (!map.has(event)) map.set(event, new Set());
    map.get(event)!.add(cb);
    return () => {
      map.get(event)?.delete(cb);
    };
  }, []);

  useEffect(() => {
    // reset saat ganti ruangan
    setLevels({});
    setActiveChannels([]);
    setActiveSeats([]);
    setActiveParticipants([]);
    setMixer(null);
    setDevices({});
    setLastEvent(null);
    setConnected(false);
    if (!roomId) return;

    let ws: WebSocket | null = null;
    let stopped = false;
    let attempt = 0;
    let authFailed = false;
    let retryTimer: ReturnType<typeof setTimeout> | null = null;
    let pingTimer: ReturnType<typeof setInterval> | null = null;

    const dispatch = (msg: RoomLiveEvent) => {
      const call = (set?: Set<RoomLiveListener>) =>
        set?.forEach((cb) => {
          try {
            cb(msg.data, msg);
          } catch (e) {
            console.error('useRoomLive listener error', e);
          }
        });
      call(listeners.current.get(msg.event));
      call(listeners.current.get('*'));
    };

    const handle = (msg: RoomLiveEvent) => {
      const d = (msg.data || {}) as Record<string, any>;
      switch (msg.event) {
        case 'connected':
          attempt = 0;
          authFailed = false;
          setConnected(true);
          break;
        case 'error':
          authFailed = true;
          break;
        case 'audio_levels': {
          const next: Record<number, number> = {};
          Object.entries((d.levels || {}) as Record<string, number>).forEach(([k, v]) => {
            next[Number(k)] = Number(v);
          });
          setLevels(next);
          break;
        }
        case 'active_speakers':
          setActiveChannels(Array.isArray(d.channels) ? d.channels.map(Number) : []);
          setActiveSeats(Array.isArray(d.seats) ? d.seats : []);
          setActiveParticipants(Array.isArray(d.participants) ? d.participants : []);
          break;
        case 'mixer_state':
          setMixer(d as MixerState);
          break;
        case 'device_state':
          if (d.device_id) {
            setDevices((prev) => ({ ...prev, [String(d.device_id)]: (d.state || {}) as DeviceLiveState }));
          }
          break;
        default:
          break;
      }
      if (msg.event !== 'pong') setLastEvent(msg);
      dispatch(msg);
    };

    const connect = () => {
      if (stopped) return;
      const token = currentToken(tokenRef.current);
      if (!token) {
        schedule();
        return;
      }
      const url = buildWsUrl(`/api/v1/ws/rooms/${encodeURIComponent(roomId)}/live`, { token });
      try {
        ws = new WebSocket(url);
      } catch {
        schedule();
        return;
      }
      ws.onmessage = (ev) => {
        try {
          handle(JSON.parse(ev.data as string) as RoomLiveEvent);
        } catch {
          /* abaikan pesan non-JSON */
        }
      };
      ws.onopen = () => {
        if (pingTimer) clearInterval(pingTimer);
        pingTimer = setInterval(() => {
          if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'ping' }));
        }, 25000);
      };
      ws.onclose = () => {
        setConnected(false);
        if (pingTimer) clearInterval(pingTimer);
        pingTimer = null;
        ws = null;
        if (stopped) return;
        if (authFailed) {
          // Token kedaluwarsa: panggil API ringan agar interceptor me-refresh token.
          apiClient.get('/auth/session').catch(() => undefined);
        }
        schedule();
      };
      ws.onerror = () => {
        /* onclose menyusul */
      };
    };

    const schedule = () => {
      if (stopped) return;
      const delay = Math.min(30000, 1000 * 2 ** Math.min(attempt, 5)) + Math.random() * 500;
      attempt += 1;
      retryTimer = setTimeout(connect, delay);
    };

    connect();

    return () => {
      stopped = true;
      if (retryTimer) clearTimeout(retryTimer);
      if (pingTimer) clearInterval(pingTimer);
      if (ws) {
        ws.onclose = null;
        ws.close();
      }
      setConnected(false);
    };
  }, [roomId]);

  return { connected, levels, activeChannels, activeSeats, activeParticipants, mixer, devices, lastEvent, subscribe };
}

export default useRoomLive;
