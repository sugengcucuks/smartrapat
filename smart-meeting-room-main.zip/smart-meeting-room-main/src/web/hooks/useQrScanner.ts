import { useCallback, useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';

export type ScannerStatus = 'idle' | 'starting' | 'scanning' | 'error';

interface BarcodeDetectorLike {
  detect: (source: HTMLVideoElement) => Promise<Array<{ rawValue: string }>>;
}

interface BarcodeDetectorCtor {
  new (options?: { formats?: string[] }): BarcodeDetectorLike;
}

interface UseQrScannerOptions {
  videoRef: React.RefObject<HTMLVideoElement>;
  active: boolean;
  onDetected: (code: string) => void;
  /** Jeda minimum sebelum kode yang sama boleh terdeteksi lagi (ms). */
  cooldownMs?: number;
}

/**
 * Scanner QR dari kamera.
 * Pakai BarcodeDetector bawaan browser bila tersedia, kalau tidak fallback ke jsQR.
 */
export function useQrScanner({
  videoRef,
  active,
  onDetected,
  cooldownMs = 2500,
}: UseQrScannerOptions) {
  const [status, setStatus] = useState<ScannerStatus>('idle');
  const [error, setError] = useState<string | null>(null);

  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);
  const detectorRef = useRef<BarcodeDetectorLike | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const lastHitRef = useRef<{ code: string; at: number } | null>(null);
  const detectedRef = useRef(onDetected);
  detectedRef.current = onDetected;

  const stop = useCallback(() => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    const video = videoRef.current;
    if (video) video.srcObject = null;
    setStatus('idle');
  }, [videoRef]);

  const handleHit = useCallback(
    (raw: string) => {
      const code = raw.trim();
      if (!code) return;
      const now = Date.now();
      const last = lastHitRef.current;
      if (last && last.code === code && now - last.at < cooldownMs) return;
      lastHitRef.current = { code, at: now };
      detectedRef.current(code);
    },
    [cooldownMs]
  );

  const scanFrame = useCallback(() => {
    const video = videoRef.current;
    if (!video || video.readyState !== video.HAVE_ENOUGH_DATA) {
      rafRef.current = requestAnimationFrame(scanFrame);
      return;
    }

    if (detectorRef.current) {
      detectorRef.current
        .detect(video)
        .then((codes) => {
          if (codes.length > 0) handleHit(codes[0].rawValue);
        })
        .catch(() => {});
    } else {
      if (!canvasRef.current) canvasRef.current = document.createElement('canvas');
      const canvas = canvasRef.current;
      const w = video.videoWidth;
      const h = video.videoHeight;
      if (w > 0 && h > 0) {
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (ctx) {
          ctx.drawImage(video, 0, 0, w, h);
          const image = ctx.getImageData(0, 0, w, h);
          const result = jsQR(image.data, w, h, { inversionAttempts: 'dontInvert' });
          if (result?.data) handleHit(result.data);
        }
      }
    }

    rafRef.current = requestAnimationFrame(scanFrame);
  }, [handleHit, videoRef]);

  useEffect(() => {
    if (!active) {
      stop();
      return;
    }

    let cancelled = false;

    const start = async () => {
      setStatus('starting');
      setError(null);

      const Ctor = (window as unknown as { BarcodeDetector?: BarcodeDetectorCtor })
        .BarcodeDetector;
      if (Ctor) {
        try {
          detectorRef.current = new Ctor({ formats: ['qr_code'] });
        } catch {
          detectorRef.current = null;
        }
      }

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 } },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        const video = videoRef.current;
        if (!video) return;
        video.srcObject = stream;
        video.setAttribute('playsinline', 'true');
        await video.play().catch(() => {});
        setStatus('scanning');
        rafRef.current = requestAnimationFrame(scanFrame);
      } catch (err) {
        if (cancelled) return;
        console.error('Kamera gagal dibuka', err);
        setError('Kamera tidak dapat diakses. Periksa izin kamera pada perangkat ini.');
        setStatus('error');
      }
    };

    start();

    return () => {
      cancelled = true;
      stop();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active]);

  return { status, error };
}
