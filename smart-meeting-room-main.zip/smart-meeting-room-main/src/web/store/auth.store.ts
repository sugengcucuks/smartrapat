import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, MenuItem } from '@shared/types';

/**
 * Satu-satunya sumber kebenaran untuk sesi (user + access/refresh token).
 * `src/shared/api/client.ts` membaca & memperbarui token langsung dari store ini,
 * jadi JANGAN menyimpan token di key localStorage lain.
 */

interface AuthState {
  user: User | null;
  accessToken: string | null;
  refreshToken: string | null;
  menu: MenuItem[];
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;

  // Actions
  setAuth: (user: User, accessToken: string, refreshToken: string) => void;
  setTokens: (accessToken: string, refreshToken: string) => void;
  setMenu: (menu: MenuItem[]) => void;
  setLoading: (isLoading: boolean) => void;
  setError: (error: string | null) => void;
  updateUser: (patch: Partial<User>) => void;
  /** Bersihkan sesi lokal. Untuk logout lengkap (cabut token di server) pakai `signOut()` dari client.ts. */
  logout: () => void;
  clearError: () => void;
  /** True bila user memiliki SALAH SATU izin pada `codes` (["*"] = semua izin). */
  hasPermission: (codes: string | string[]) => boolean;
}

const EMPTY_SESSION = {
  user: null,
  accessToken: null,
  refreshToken: null,
  menu: [] as MenuItem[],
  isAuthenticated: false,
  isLoading: false,
  error: null,
};

/** Cek izin murni (dipakai store dan komponen yang sudah memegang `user`). */
export function userHasPermission(user: User | null | undefined, codes: string | string[]): boolean {
  const perms = user?.permissions ?? [];
  if (perms.includes('*')) return true;
  const list = Array.isArray(codes) ? codes : [codes];
  return list.some((c) => perms.includes(c));
}

// Bersihkan key token lama (versi sebelumnya menyimpan token terpisah di localStorage).
try {
  localStorage.removeItem('access_token');
  localStorage.removeItem('refresh_token');
} catch {
  /* storage tidak tersedia */
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      ...EMPTY_SESSION,

      setAuth: (user, accessToken, refreshToken) => {
        set({
          user: { ...user, permissions: user.permissions ?? [] },
          accessToken,
          refreshToken,
          isAuthenticated: true,
          error: null,
        });
      },

      setTokens: (accessToken, refreshToken) => set({ accessToken, refreshToken }),

      setMenu: (menu) => set({ menu: Array.isArray(menu) ? menu : [] }),

      setLoading: (isLoading) => set({ isLoading }),

      setError: (error) => set({ error, isLoading: false }),

      updateUser: (patch) =>
        set((state) => ({
          user: state.user ? { ...state.user, ...patch } : state.user,
        })),

      logout: () => set({ ...EMPTY_SESSION }),

      clearError: () => set({ error: null }),

      hasPermission: (codes) => userHasPermission(get().user, codes),
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({
        user: state.user,
        accessToken: state.accessToken,
        refreshToken: state.refreshToken,
        isAuthenticated: state.isAuthenticated,
        menu: state.menu,
      }),
    }
  )
);

/** Hook ringkas: `const can = usePermission(); can('users.create')`. */
export function usePermission() {
  const user = useAuthStore((s) => s.user);
  return (codes: string | string[]) => userHasPermission(user, codes);
}
