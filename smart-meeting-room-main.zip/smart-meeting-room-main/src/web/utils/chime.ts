/**
 * Nada notifikasi kiosk memakai Web Audio API (tanpa file audio eksternal).
 * success = nada naik (presensi berhasil), error = nada turun (tiket ditolak).
 */
let ctxRef: AudioContext | null = null;

function getContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const Ctor =
    window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctor) return null;
  if (!ctxRef) ctxRef = new Ctor();
  if (ctxRef.state === 'suspended') void ctxRef.resume();
  return ctxRef;
}

function playTone(freq: number, startAt: number, duration: number, gainValue: number) {
  const ctx = getContext();
  if (!ctx) return;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = 'sine';
  osc.frequency.setValueAtTime(freq, ctx.currentTime + startAt);
  gain.gain.setValueAtTime(0.0001, ctx.currentTime + startAt);
  gain.gain.exponentialRampToValueAtTime(gainValue, ctx.currentTime + startAt + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + startAt + duration);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(ctx.currentTime + startAt);
  osc.stop(ctx.currentTime + startAt + duration + 0.02);
}

/** Bunyi saat presensi berhasil (nada naik). */
export function playSuccessChime() {
  playTone(880, 0, 0.14, 0.25);
  playTone(1174.66, 0.13, 0.18, 0.25);
}

/** Bunyi saat tiket duplikat / tidak dikenal (nada turun). */
export function playErrorChime() {
  playTone(392, 0, 0.18, 0.22);
  playTone(261.63, 0.16, 0.24, 0.22);
}

/** Bunyi saat kode sudah pernah dipakai (peringatan netral). */
export function playDuplicateChime() {
  playTone(659.25, 0, 0.12, 0.2);
  playTone(659.25, 0.16, 0.14, 0.2);
}
