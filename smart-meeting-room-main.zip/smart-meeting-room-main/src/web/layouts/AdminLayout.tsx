import { useState, useEffect, useRef } from 'react';
import { Outlet, NavLink, useNavigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '../store/auth.store';
import { authApi } from '@shared/api/auth';
import { buildWsUrl, signOut } from '@shared/api/client';
import type { Notification } from '@shared/types';

interface MenuItem {
  id: string;
  name: string;
  icon: string;
  path: string;
}

export function AdminLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, menu, accessToken, setMenu, updateUser } = useAuthStore();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isDark, setIsDark] = useState(false);
  const [avatarOpen, setAvatarOpen] = useState(false);
  const [bellOpen, setBellOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [latestNotifs, setLatestNotifs] = useState<Notification[]>([]);
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({
    users: false,
    rooms: false,
    bookings: false,
    devices: false,
    system: false,
  });
  const avatarRef = useRef<HTMLLIElement>(null);
  const bellRef = useRef<HTMLLIElement>(null);
  const wsRef = useRef<WebSocket | null>(null);

  const SIDEBAR_GROUPS = [
    { groupId: 'users', parentIcon: 'ri-user-line', childrenIds: ['users', 'departments', 'roles'] },
    { groupId: 'rooms', parentIcon: 'ri-door-open-line', childrenIds: ['rooms', 'buildings'] },
    { groupId: 'bookings', parentIcon: 'ri-file-list-3-line', childrenIds: ['bookings', 'presensi_tickets', 'presensi_scanner', 'calendar', 'notes', 'search', 'followups', 'live_meeting'] },
    { groupId: 'devices', parentIcon: 'ri-monitor-line', childrenIds: ['equipment', 'devices', 'videowall', 'audio'] },
    { groupId: 'system', parentIcon: 'ri-settings-3-line', childrenIds: ['notifications', 'reports', 'settings', 'audit', 'maintenance'] },
  ];
  const GROUPED_IDS = new Set(['dashboard', ...SIDEBAR_GROUPS.flatMap((g) => g.childrenIds)]);
  // Item menu dari /auth/menu yang tidak termasuk grup mana pun tetap ditampilkan.
  const ungroupedItems = menu.filter((m: MenuItem) => !GROUPED_IDS.has(m.id));

  const toggleGroup = (groupId: string) => {
    setOpenGroups((prev) => ({ ...prev, [groupId]: !(prev[groupId] ?? false) }));
  };

  const findMenuItem = (id: string): MenuItem | undefined => {
    if (id === 'live_meeting') {
      // Live Meeting hanya relevan bila user punya akses pemesanan.
      if (!menu.some((m: MenuItem) => m.id === 'bookings')) return undefined;
      return {
        id: 'live_meeting',
        name: 'Live Meeting',
        icon: 'video',
        path: '/bookings/meeting',
      } as MenuItem;
    }
    return menu.find((m: MenuItem) => m.id === id);
  };

  const isGroupChildActive = (childrenIds: string[]): boolean => {
    return childrenIds.some((cid) => {
      const item = findMenuItem(cid);
      if (!item) return false;
      if (cid === 'live_meeting') {
        return location.pathname.startsWith('/bookings/') && location.pathname.includes('/meeting');
      }
      const loc = location.pathname.replace(/\/+$/, '');
      const it = item.path.replace(/\/+$/, '');
      return loc === it || loc.startsWith(it + '/');
    });
  };

  useEffect(() => {
    const autoExpand: Record<string, boolean> = {};
    for (const g of SIDEBAR_GROUPS) {
      if (isGroupChildActive(g.childrenIds)) {
        autoExpand[g.groupId] = true;
      }
    }
    if (Object.keys(autoExpand).length > 0) {
      setOpenGroups((prev) => ({ ...prev, ...autoExpand }));
    }
  }, [location.pathname]);

  // Segarkan profil sesi (izin, wajib ganti password) & menu dari server.
  useEffect(() => {
    let cancelled = false;
    authApi
      .getSession()
      .then((session) => {
        if (!cancelled && session) {
          updateUser({
            ...session,
            permissions: session.permissions ?? [],
            must_change_password: !!session.must_change_password,
          });
          if (session.must_change_password) navigate('/change-password', { replace: true });
        }
      })
      .catch(() => {
        /* 401/403 ditangani interceptor */
      });
    authApi
      .getMenu()
      .then((m) => {
        if (!cancelled) setMenu(m);
      })
      .catch(() => {
        /* biarkan menu tersimpan */
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const savedTheme = localStorage.getItem('turbine-theme');
    const html = document.documentElement;

    if (savedTheme === 'dark') {
      html.classList.add('dark');
      html.classList.remove('light');
      setIsDark(true);
    } else {
      html.classList.add('light');
      html.classList.remove('dark');
      setIsDark(false);
    }
  }, []);

  const toggleDarkMode = () => {
    const html = document.documentElement;
    if (html.classList.contains('dark')) {
      html.classList.remove('dark');
      html.classList.add('light');
      localStorage.setItem('turbine-theme', 'light');
      setIsDark(false);
    } else {
      html.classList.remove('light');
      html.classList.add('dark');
      localStorage.setItem('turbine-theme', 'dark');
      setIsDark(true);
    }
  };

  const handleLogout = async () => {
    closeWsRef.current?.();
    await signOut();
    navigate('/login', { replace: true });
  };

  useEffect(() => {
    function handleDocClick(e: MouseEvent) {
      if (avatarRef.current && !avatarRef.current.contains(e.target as Node)) setAvatarOpen(false);
      if (bellRef.current && !bellRef.current.contains(e.target as Node)) setBellOpen(false);
    }
    document.addEventListener('mousedown', handleDocClick);
    return () => document.removeEventListener('mousedown', handleDocClick);
  }, []);

  const loadLatestNotifs = async () => {
    try {
      const res = await authApi.listNotifications({ limit: 5, is_read: false });
      const list = Array.isArray(res) ? res : (res?.items ?? []);
      setLatestNotifs(list.slice(0, 5));
      const unread = Array.isArray(res) ? res.filter((n: Notification) => !n.is_read).length : (res?.unread_count ?? 0);
      setUnreadCount(unread as number);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadLatestNotifs();
  }, []);

  // WebSocket notifikasi realtime. Token selalu dibaca segar dari store saat
  // (re)connect; effect di-restart ketika token berganti (refresh / ganti password).
  const closeWsRef = useRef<(() => void) | null>(null);
  useEffect(() => {
    if (!accessToken) return;
    let retryMs = 1000;
    let closedByUs = false;
    let retryTimer: ReturnType<typeof setTimeout> | null = null;

    const scheduleReconnect = () => {
      if (closedByUs) return;
      retryTimer = setTimeout(() => { openWs(); }, retryMs);
      retryMs = Math.min(retryMs * 2, 15000);
    };

    const openWs = () => {
      if (closedByUs) return;
      const token = useAuthStore.getState().accessToken;
      if (!token) return;
      try {
        const ws = new WebSocket(buildWsUrl('/api/v1/ws/notifications', { token }));
        wsRef.current = ws;
        ws.onopen = () => { retryMs = 1000; };
        ws.onmessage = (evt) => {
          try {
            const msg = JSON.parse(evt.data);
            if (msg?.event === 'new_notification' || msg?.type === 'new_notification') {
              const payload: Notification = (msg.data || msg.payload || msg);
              setLatestNotifs((prev) => [payload, ...prev].slice(0, 5));
              setUnreadCount((u) => (u ?? 0) + 1);
            } else if (msg?.event === 'mark_all_read' || msg?.type === 'mark_all_read') {
              setUnreadCount(0);
              setLatestNotifs((prev) => prev.map((n) => ({ ...n, is_read: true })));
            } else if (msg?.type === 'auth_error') {
              // Token ditolak: jangan reconnect terus-menerus; tunggu token baru.
              closedByUs = true;
            }
          } catch { /* pesan non-JSON diabaikan */ }
        };
        ws.onclose = () => {
          if (wsRef.current === ws) wsRef.current = null;
          scheduleReconnect();
        };
        ws.onerror = () => { try { ws.close(); } catch { /* ignore */ } };
      } catch {
        scheduleReconnect();
      }
    };

    const closeWs = () => {
      closedByUs = true;
      if (retryTimer) clearTimeout(retryTimer);
      try { wsRef.current?.close(1000, 'client closed'); } catch { /* ignore */ }
      wsRef.current = null;
    };
    closeWsRef.current = closeWs;
    openWs();
    return closeWs;
  }, [accessToken]);

  const handleMarkAllRead = async () => {
    try {
      await authApi.markAllRead();
      setUnreadCount(0);
      setLatestNotifs((prev) => prev.map((n) => ({ ...n, is_read: true })));
    } catch {
      loadLatestNotifs();
    }
  };

  const handleOpenNotifPage = () => { setBellOpen(false); navigate('/notifications'); };

  const handleGoProfile = () => { setAvatarOpen(false); navigate('/profile'); };
  const handleOpenChangePass = () => { setAvatarOpen(false); navigate('/change-password'); };

  const getIcon = (iconName: string) => {
    const iconMap: Record<string, string> = {
      home: 'ri-home-2-line',
      users: 'ri-user-line',
      shield: 'ri-shield-user-line',
      'door-open': 'ri-door-open-line',
      tool: 'ri-tools-line',
      monitor: 'ri-monitor-line',
      calendar: 'ri-calendar-line',
      'volume-2': 'ri-volume-up-line',
      'file-text': 'ri-file-text-line',
      'bar-chart': 'ri-bar-chart-line',
      settings: 'ri-settings-3-line',
      'folder-3': 'ri-folder-3-line',
      'qr-code': 'ri-qr-code-line',
      scan: 'ri-qr-scan-2-line',
      bell: 'ri-notification-3-line',
      'file-list': 'ri-file-list-3-line',
      'settings-2': 'ri-restart-line',
      video: 'ri-video-chat-line',
      search: 'ri-search-line',
      'list-check': 'ri-list-check-2',
      magic: 'ri-magic-line',
    };
    return iconMap[iconName] || 'ri-circle-line';
  };

  return (
    <div className="flex min-h-screen bg-[#f5f7fa] dark:bg-dark">
      {/* Sidebar */}
      <aside
        className="bg-white dark:bg-gray fixed top-0 left-0 h-full w-64 shadow-md z-50 flex flex-col overflow-hidden transition-transform duration-200"
        style={{ transform: sidebarOpen ? 'translateX(0)' : 'translateX(-100%)' }}
      >
        {/* Logo Header */}
        <div className="h-[4.55rem] py-2 px-4 shrink-0 border-b border-b-black/10 dark:border-b-white/10 flex items-center relative z-10">
          <a href="#" className="flex items-center">
            <img src="assets/images/favicon.png" alt="" className="w-8 h-8 rounded object-cover" />
            <span className="text-lg font-bold text-dark dark:text-white/80 ml-3">Smart Meeting</span>
          </a>
        </div>

        {/* Scrollable Menu */}
        <div className="flex-1 p-4 relative z-10 overflow-y-auto" style={{ maxHeight: 'calc(100vh - 64px)' }}>
          {/* Sidebar User Profile */}
          <div className="flex items-center gap-2 pb-3 border-b border-black/10 dark:border-white/10">
            <div className="relative inline-block">
              <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center mb-2 border-2 border-primary p-0.5">
                <span className="text-white text-xl font-bold">
                  {user?.name?.charAt(0) || 'U'}
                </span>
              </div>
              <span className="absolute bottom-2 right-0 w-3 h-3 bg-success border-2 border-white dark:border-gray rounded-full"></span>
            </div>
            <div>
              <h6 className="text-sm font-semibold text-black dark:text-white">
                {user?.name || 'User'}
              </h6>
              <p className="text-xs text-black/50 dark:text-white/50">{user?.role || 'Role'}</p>
            </div>
          </div>

          <ul className="mt-2">
            <span className="text-sm text-black/80 font-semibold dark:text-white/50 my-5 block">Menu</span>
            {(() => {
              const dashboardItem = findMenuItem('dashboard');
              return dashboardItem ? (
                <li key="dashboard" className="mb-1">
                  <NavLink
                    to={dashboardItem.path}
                    className={({ isActive }) =>
                      `flex items-center py-2 px-4 rounded-md transition-all ${
                        isActive
                          ? 'bg-primary text-white shadow-sm shadow-primary/30'
                          : 'text-black dark:text-white hover:bg-black/5 dark:hover:bg-white/5'
                      }`
                    }
                  >
                    <i className="ri-home-2-line mr-3 text-lg"></i>
                    <span className="text-sm">{dashboardItem.name}</span>
                  </NavLink>
                </li>
              ) : null;
            })()}

            {SIDEBAR_GROUPS.map((group) => {
              const firstChild = group.childrenIds.map(findMenuItem).find(Boolean);
              if (!firstChild) return null;
              const groupOpen = !!openGroups[group.groupId];
              const hasActiveChild = isGroupChildActive(group.childrenIds);

              const parentName = (() => {
                switch (group.groupId) {
                  case 'users': return 'Pengguna';
                  case 'rooms': return 'Ruangan & Gedung';
                  case 'bookings': return 'Pemesanan';
                  case 'devices': return 'Perangkat';
                  case 'system': return 'Sistem';
                  default: return firstChild.name;
                }
              })();

              return (
                <li key={group.groupId} className={`mb-1 group ${groupOpen ? 'selected' : ''}`}>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      toggleGroup(group.groupId);
                    }}
                    className={`w-full flex items-center py-2 px-4 rounded-md transition-all duration-150 cursor-pointer select-none sidebar-dropdown-toggle ${
                      hasActiveChild
                        ? 'bg-primary/5 text-primary border-l-[6px] border-primary font-semibold hover:bg-primary/10'
                        : 'text-black dark:text-white hover:bg-black/5 dark:hover:bg-white/5'
                    }`}
                  >
                    <i className={`${group.parentIcon} mr-3 rtl:ml-3 rtl:mr-0 text-lg shrink-0`}></i>
                    <span className="text-sm flex-1 text-left">{parentName}</span>
                    <i
                      className={`ri-arrow-right-s-line ml-auto rtl:mr-auto rtl:ml-0 text-xl shrink-0 transition-transform duration-200 ${
                        groupOpen ? 'rotate-90' : ''
                      }`}
                      style={{ transitionProperty: 'transform' }}
                    ></i>
                  </button>
                  <div
                    className="overflow-hidden transition-[max-height,opacity] duration-300 ease-in-out"
                    style={{
                      maxHeight: groupOpen ? '2000px' : '0px',
                      opacity: groupOpen ? 1 : 0.8,
                    }}
                  >
                    <ul className="ml-3 mt-1 mb-1 space-y-0.5 border-l border-black/10 dark:border-white/10 pl-2.5 py-0.5">
                      {group.childrenIds.map((cid) => {
                        const childItem = findMenuItem(cid);
                        if (!childItem) return null;
                        const isLiveMeeting = cid === 'live_meeting';
                        return (
                          <li key={cid} className="mb-0.5">
                            <NavLink
                              to={childItem.path}
                              end={!isLiveMeeting}
                              onClick={() => {
                                if (!groupOpen) {
                                  setOpenGroups((prev) => ({ ...prev, [group.groupId]: true }));
                                }
                              }}
                              className={({ isActive }) => {
                                let finalActive = isActive;
                                if (isLiveMeeting) {
                                  finalActive = location.pathname.startsWith('/bookings/') && location.pathname.includes('/meeting');
                                }
                                return `flex items-center py-2 px-3 rounded-md text-sm transition-all ${
                                  finalActive
                                    ? 'bg-primary text-white shadow-sm shadow-primary/30 font-medium'
                                    : 'text-black/70 dark:text-white/70 hover:bg-black/5 dark:hover:bg-white/5 hover:text-black dark:hover:text-white'
                                }`;
                              }}
                            >
                              <i className={`${getIcon(childItem.icon)} mr-2 text-[14px] shrink-0`}></i>
                              <span className="flex-1">{childItem.name}</span>
                              {isLiveMeeting && (
                                <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded bg-danger/15 text-danger font-bold shrink-0">
                                  LIVE
                                </span>
                              )}
                            </NavLink>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                </li>
              );
            })}

            {ungroupedItems.map((item: MenuItem) => (
              <li key={item.id} className="mb-1">
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `flex items-center py-2 px-4 rounded-md transition-all ${
                      isActive
                        ? 'bg-primary text-white shadow-sm shadow-primary/30'
                        : 'text-black dark:text-white hover:bg-black/5 dark:hover:bg-white/5'
                    }`
                  }
                >
                  <i className={`${getIcon(item.icon)} mr-3 text-lg`}></i>
                  <span className="text-sm">{item.name}</span>
                </NavLink>
              </li>
            ))}
          </ul>
        </div>
      </aside>

      {/* Main Content */}
      <div
        className="flex flex-col flex-1 min-w-0 transition-all duration-200"
        style={{ marginLeft: sidebarOpen ? '16rem' : '0' }}
      >
        {/* Navbar */}
        <nav className="py-4 px-6 bg-white dark:bg-gray flex items-center shadow-md shadow-black/5 sticky top-0 z-30">
          <button
            type="button"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-lg text-black-600"
          >
            <i className="ri-menu-line dark:text-white/80"></i>
          </button>

          <form className="search-bar mx-3 sm:flex hidden">
            <div className="relative w-full">
              <input
                type="text"
                className="py-2 pr-4 pl-10 bg-black/5 dark:text-white/70 dark:bg-black/40 w-full outline-none border border-black/10 dark:border-white/10 rounded-md text-sm focus:border-primary transition-all"
                placeholder="Cari..."
              />
              <i className="ri-search-line absolute top-1/2 left-4 -translate-y-1/2 dark:text-white/30 text-black/30"></i>
            </div>
          </form>

          <ul className="ml-auto flex items-center gap-2">
            <li className="relative" ref={bellRef}>
              <button
                type="button"
                onClick={() => setBellOpen((p) => !p)}
                className="relative w-9 h-9 rounded-full flex items-center justify-center dark:text-white/80 text-black/70 hover:bg-black/10 dark:hover:bg-dark/60 hover:text-primary transition-colors"
                title="Pemberitahuan"
              >
                <i className="ri-notification-3-line text-xl"></i>
                {unreadCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-danger text-white text-[10px] font-bold flex items-center justify-center border-2 border-white dark:border-gray">
                    {unreadCount > 99 ? '99+' : unreadCount}
                  </span>
                )}
              </button>
              {bellOpen && (
                <>
                  <div
                    className="fixed inset-0 z-[99998] bg-transparent"
                    onClick={() => setBellOpen(false)}
                  />
                  <div
                    className="fixed bg-white dark:bg-gray rounded-2xl shadow-2xl shadow-black/40 border border-black/10 dark:border-white/10"
                    style={{
                      zIndex: 99999,
                      top: '84px',
                      right: '24px',
                      width: '440px',
                      minWidth: '400px',
                      maxWidth: 'calc(100vw - 48px)',
                    }}
                  >
                  <div className="px-5 py-4 border-b border-black/10 dark:border-white/10 flex items-center justify-between bg-black/[0.02] dark:bg-white/[0.02]">
                    <div>
                      <h3 className="font-bold text-black dark:text-white">Pemberitahuan</h3>
                      <p className="text-xs text-black/50 dark:text-white/50 mt-0.5">{unreadCount} belum dibaca</p>
                    </div>
                    {unreadCount > 0 && (
                      <button
                        type="button"
                        onClick={handleMarkAllRead}
                        className="text-xs font-semibold text-primary hover:text-primary/80 shrink-0"
                      >
                        Tandai semua dibaca
                      </button>
                    )}
                  </div>
                  <div className="overflow-y-auto" style={{ maxHeight: '480px' }}>
                    {latestNotifs.length === 0 ? (
                      <div className="py-20 text-center">
                        <i className="ri-notification-off-line text-5xl text-black/15 dark:text-white/15"></i>
                        <p className="mt-4 text-base font-medium text-black/50 dark:text-white/50">Tidak ada pemberitahuan</p>
                        <p className="mt-1 text-xs text-black/40 dark:text-white/40">Semua notifikasi akan muncul di sini</p>
                      </div>
                    ) : (
                      <ul className="divide-y divide-black/5 dark:divide-white/5">
                        {latestNotifs.map((n) => (
                          <li
                            key={n.id}
                            onClick={async () => {
                              try { if (!n.is_read) await authApi.markRead(n.id); } catch { /* tetap buka halaman */ }
                              setBellOpen(false);

                              navigate('/notifications');
                            }}
                            className="px-4 py-3 cursor-pointer hover:bg-black/[0.02] dark:hover:bg-white/[0.02] transition-colors"
                          >
                            <div className="flex items-start gap-3">
                              <div className={`w-8 h-8 rounded-full shrink-0 flex items-center justify-center ${
                                n.type === 'error' ? 'bg-danger/10 text-danger' :
                                n.type === 'warning' ? 'bg-warning/10 text-warning' :
                                'bg-info/10 text-info'
                              }`}>
                                <i className="ri-notification-3-line"></i>
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-0.5">
                                  <p className="text-sm font-semibold text-black/80 dark:text-white/80 truncate">{n.title}</p>
                                  {!n.is_read && <span className="w-2 h-2 rounded-full bg-primary shrink-0"></span>}
                                </div>
                                <p className="text-xs text-black/50 dark:text-white/50 line-clamp-2">{n.message}</p>
                                <p className="text-[11px] text-black/40 dark:text-white/40 mt-1">
                                  {n.created_at ? new Date(n.created_at).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' }) : '-'}
                                </p>
                              </div>
                            </div>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                  <div className="px-5 py-3.5 border-t border-black/10 dark:border-white/10 bg-black/[0.02] dark:bg-white/[0.02]">
                    <button
                      type="button"
                      onClick={handleOpenNotifPage}
                      className="w-full text-center text-sm font-semibold text-primary hover:text-primary/80 transition-colors"
                    >
                      Lihat semua pemberitahuan →
                    </button>
                  </div>
                </div>
                </>
              )}
            </li>

            <li>
              <button
                type="button"
                id="dark-mode-toggle"
                onClick={toggleDarkMode}
                className="w-9 h-9 rounded-full flex items-center justify-center dark:text-white/80 text-black/70 hover:bg-black/10 dark:hover:bg-dark/60 transition-colors"
                title={isDark ? 'Mode Terang' : 'Mode Gelap'}
              >
                <i className={`ri-moon-fill text-lg ${isDark ? 'hidden' : 'flex'}`}></i>
                <i className={`ri-sun-fill text-lg ${isDark ? 'flex' : 'hidden'}`}></i>
              </button>
            </li>

            <li className="relative" ref={avatarRef}>
              <div className="flex items-center gap-3">
                <div className="text-right hidden sm:block">
                  <p className="text-sm font-semibold text-black dark:text-white/80 truncate max-w-[140px]">{user?.name}</p>
                  <p className="text-xs text-black/50 dark:text-white/50">{user?.role}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setAvatarOpen((p) => !p)}
                  className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white font-bold shadow-sm hover:ring-2 hover:ring-primary/50 transition-all"
                  title="Menu Pengguna"
                >
                  {user?.name?.charAt(0) || 'U'}
                </button>
              </div>
              {avatarOpen && (
                <div className="absolute right-0 top-full mt-2 w-64 bg-white dark:bg-gray rounded-xl shadow-xl shadow-black/20 border border-black/10 dark:border-white/10 z-[60] overflow-hidden">
                  <div className="px-4 py-3 border-b border-black/10 dark:border-white/10 bg-gradient-to-r from-primary/10 to-primary/5 dark:from-primary/20 dark:to-primary/10">
                    <p className="font-semibold text-black dark:text-white truncate">{user?.name || 'Pengguna'}</p>
                    <p className="text-xs text-black/60 dark:text-white/60 truncate">{user?.email || ''}</p>
                    <p className="text-xs text-primary/80 mt-0.5">{user?.role || ''}</p>
                  </div>
                  <ul className="py-1.5">
                    <li>
                      <button
                        type="button"
                        onClick={handleGoProfile}
                        className="w-full px-4 py-2.5 text-left flex items-center gap-3 text-sm text-black/70 dark:text-white/70 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                      >
                        <i className="ri-user-line text-lg"></i>
                        <span>Profil Saya</span>
                      </button>
                    </li>
                    <li>
                      <button
                        type="button"
                        onClick={handleOpenChangePass}
                        className="w-full px-4 py-2.5 text-left flex items-center gap-3 text-sm text-black/70 dark:text-white/70 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                      >
                        <i className="ri-lock-password-line text-lg"></i>
                        <span>Ganti Password</span>
                      </button>
                    </li>
                    <li className="my-1 border-t border-black/10 dark:border-white/10"></li>
                    <li>
                      <button
                        type="button"
                        onClick={handleLogout}
                        className="w-full px-4 py-2.5 text-left flex items-center gap-3 text-sm text-danger hover:bg-danger/10 transition-colors"
                      >
                        <i className="ri-logout-box-r-line text-lg"></i>
                        <span>Keluar</span>
                      </button>
                    </li>
                  </ul>
                </div>
              )}
            </li>
          </ul>
        </nav>

        {/* Page Content */}
        <div className="flex-1 p-6 w-full min-w-0 box-border">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
