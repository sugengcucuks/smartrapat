export const PASSWORD_MIN_LENGTH = 8;

export interface PasswordStrength {
  score: 0 | 1 | 2 | 3 | 4;
  label: string;
  color: string;
  hints: string[];
}

/** Estimasi kekuatan password sederhana untuk petunjuk di UI (bukan validasi server). */
export function passwordStrength(pw: string): PasswordStrength {
  const hints: string[] = [];
  if (pw.length < PASSWORD_MIN_LENGTH) hints.push(`Minimal ${PASSWORD_MIN_LENGTH} karakter`);
  if (!/[a-z]/.test(pw) || !/[A-Z]/.test(pw)) hints.push('Gunakan huruf besar dan kecil');
  if (!/\d/.test(pw)) hints.push('Tambahkan angka');
  if (!/[^A-Za-z0-9]/.test(pw)) hints.push('Tambahkan simbol');

  let score = 0;
  if (pw.length >= PASSWORD_MIN_LENGTH) score++;
  if (pw.length >= 12) score++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) score++;
  if (/\d/.test(pw) && /[^A-Za-z0-9]/.test(pw)) score++;
  if (pw.length < PASSWORD_MIN_LENGTH) score = Math.min(score, 1);

  const s = Math.min(4, score) as PasswordStrength['score'];
  const table: Record<number, { label: string; color: string }> = {
    0: { label: 'Sangat lemah', color: 'bg-danger' },
    1: { label: 'Lemah', color: 'bg-danger' },
    2: { label: 'Cukup', color: 'bg-warning' },
    3: { label: 'Kuat', color: 'bg-success' },
    4: { label: 'Sangat kuat', color: 'bg-success' },
  };
  return { score: s, ...table[s], hints };
}
