/**
 * Utilitas tanggal berbasis zona waktu LOKAL browser.
 *
 * Jangan pakai `new Date().toISOString().split('T')[0]` untuk "hari ini":
 * itu tanggal UTC, sehingga di WIB (UTC+7) antara 00:00-07:00 hasilnya kemarin.
 */

const pad = (n: number) => String(n).padStart(2, '0');

/** Format `Date` menjadi `YYYY-MM-DD` menurut zona waktu lokal. */
export function toLocalDateString(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/** Tanggal hari ini (lokal) dalam format `YYYY-MM-DD`. */
export function todayLocal(): string {
  return toLocalDateString(new Date());
}

/** Tambah `days` hari ke tanggal `YYYY-MM-DD` (lokal) dan kembalikan `YYYY-MM-DD`. */
export function addDaysLocal(dateStr: string, days: number): string {
  const d = parseLocalDate(dateStr);
  d.setDate(d.getDate() + days);
  return toLocalDateString(d);
}

/** Parse `YYYY-MM-DD` sebagai tanggal lokal (bukan UTC seperti `new Date('YYYY-MM-DD')`). */
export function parseLocalDate(dateStr: string): Date {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

/** Format waktu `HH:MM` lokal dari `Date`. */
export function toLocalTimeString(d: Date): string {
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
