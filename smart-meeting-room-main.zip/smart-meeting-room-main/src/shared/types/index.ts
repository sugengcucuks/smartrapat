// API Response Types
export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: Record<string, unknown>;
  };
  meta?: {
    page: number;
    limit: number;
    total: number;
  };
}

// Auth Types
export interface User {
  id: string;
  username: string;
  name: string;
  email: string;
  /** Nama role dari backend (mis. "Super Admin"). */
  role: UserRole | string;
  /** Kode izin efektif; ["*"] = semua izin (super admin). */
  permissions: string[];
  /** True bila user wajib mengganti password sebelum memakai aplikasi. */
  must_change_password?: boolean;
  avatar_url?: string;
  department?: string;
  rank?: string;
  position?: string;
  phone?: string | null;
  nik?: string | null;
  created_at?: string;
}

export type UserRole = 'super_admin' | 'admin' | 'operator' | 'user';

export interface AuthTokens {
  access_token: string;
  refresh_token: string;
  token_type: 'Bearer';
  expires_in: number;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  access_token: string;
  refresh_token: string;
  token_type: 'Bearer';
  expires_in: number;
  user: User;
}

export interface MenuItem {
  id: string;
  name: string;
  icon: string;
  path: string;
  children?: MenuItem[];
}

// Building Types
export interface Building {
  id: string;
  code: string;
  name: string;
  floors: number;
  address?: string;
  created_at?: string;
  updated_at?: string;
}

export interface BuildingCreate {
  code: string;
  name: string;
  floors: number;
  address?: string;
}

export interface BuildingUpdate {
  code?: string;
  name?: string;
  floors?: number;
  address?: string;
}

// Room Types
export type RoomType = 'meeting' | 'training' | 'aula' | 'office';

export const ROOM_TYPE_OPTIONS: { value: RoomType; label: string }[] = [
  { value: 'meeting', label: 'Rapat' },
  { value: 'training', label: 'Pelatihan' },
  { value: 'aula', label: 'Aula' },
  { value: 'office', label: 'Kantor' },
];

export const ROOM_FACILITIES: string[] = [
  'Proyektor',
  'Whiteboard',
  'TV',
  'Mic',
  'Speaker',
  'AC',
  'WiFi',
  'Kamera',
  'Videocall',
];

export interface Room {
  id: string;
  code: string;
  name: string;
  building_id?: string;
  building_name?: string;
  floor?: number;
  capacity: number;
  room_type: RoomType;
  description?: string;
  /** Alias UI untuk `amenities` backend (diisi normalizeRoom). */
  facilities: string[];
  amenities?: string[];
  /**
   * Catatan: backend mengirim huruf kecil (available/maintenance/disabled — lihat RoomAdminStatus);
   * tipe lama dipertahankan agar halaman mobile/display tetap kompilasi. Bandingkan case-insensitive.
   */
  status: RoomStatus;
  /** Turunan: status !== 'disabled' (backend tidak punya kolom is_active). */
  is_active: boolean;
  pairing_key?: string | null;
  has_master_pin?: boolean;
  created_at?: string;
  updated_at?: string;
}

// === Kiosk Security (ADM-03/04, DSP-07/09) ===
export interface PairingKeyResponse {
  room_id: string;
  room_code: string;
  pairing_key: string;
}

export interface MasterPinResponse {
  room_id: string;
  room_code: string;
  has_master_pin: boolean;
  message: string;
}

export interface KioskPairResult {
  room_id: string;
  room_code: string;
  room_name: string;
  paired: boolean;
  has_master_pin: boolean;
  /** Token kiosk (header X-Kiosk-Token / ?kiosk_token= untuk WebSocket). */
  kiosk_token?: string;
  expires_at?: string;
}

export interface EarlyReleaseResult {
  booking_id: string;
  title: string;
  room_code: string;
  status: string;
  message: string;
}

/** Status tampilan (format lama, dipakai halaman mobile/display). */
export type RoomStatus = 'AVAILABLE' | 'OCCUPIED' | 'MAINTENANCE' | 'RESERVED';

/** Status ruangan yang disimpan backend (schemas/room.py). */
export type RoomAdminStatus = 'available' | 'maintenance' | 'disabled';

export interface RoomCreate {
  code: string;
  name: string;
  building_id?: string;
  floor?: number;
  capacity: number;
  room_type: RoomType;
  description?: string;
  facilities: string[];
  status?: RoomAdminStatus;
  /** Dipetakan ke status 'available' / 'disabled' oleh API layer. */
  is_active?: boolean;
}

export interface RoomUpdate {
  code?: string;
  name?: string;
  building_id?: string;
  floor?: number;
  capacity?: number;
  room_type?: RoomType;
  description?: string;
  facilities?: string[];
  status?: RoomAdminStatus;
  /** Dipetakan ke status 'available' / 'disabled' oleh API layer. */
  is_active?: boolean;
}

// Booking Types
export type BookingStatus =
  | 'pending'
  | 'approved'
  | 'rejected'
  | 'cancelled'
  | 'completed'
  | 'draft';

export const BOOKING_STATUS_OPTIONS: { value: BookingStatus; label: string }[] = [
  { value: 'pending', label: 'Menunggu' },
  { value: 'approved', label: 'Disetujui' },
  { value: 'rejected', label: 'Ditolak' },
  { value: 'cancelled', label: 'Dibatalkan' },
  { value: 'completed', label: 'Selesai' },
  { value: 'draft', label: 'Draf' },
];

/**
 * Peserta rapat (bentuk ternormalisasi untuk UI).
 * Backend mengirim `user_name` / `guest_name` / `guest_email` / `is_guest`;
 * gunakan `normalizeParticipant()` (src/shared/api/auth.ts) untuk mengisi `name` & `email`.
 */
export interface BookingParticipant {
  id?: string;
  /** Nama tampilan: user_name (internal) atau guest_name (tamu). */
  name: string;
  email: string;
  user_id?: string | null;
  /** Tamu / eksternal (alias `is_guest` dari backend). */
  is_external?: boolean;
  is_guest?: boolean;
  user_name?: string | null;
  guest_name?: string | null;
  guest_email?: string | null;
  ticket_code?: string | null;
  attended?: boolean;
  checked_in_at?: string | null;
}

/** Payload peserta untuk POST/PUT /bookings (schema BookingParticipantCreate). */
export interface BookingParticipantPayload {
  user_id?: string | null;
  guest_name?: string | null;
  guest_email?: string | null;
  is_guest: boolean;
}

export interface Booking {
  id: string;
  title: string;
  room_id: string;
  room_name?: string;
  building_name?: string;
  date: string;
  start_time: string;
  end_time: string;
  organizer_id: string;
  organizer_name?: string;
  /** Pemilik booking (sama dengan organizer_id). */
  user_id?: string;
  user_name?: string;
  approval_notes?: string | null;
  approved_by_name?: string | null;
  participant_count: number;
  participants: BookingParticipant[];
  description?: string;
  status: BookingStatus;
  notes?: string;
  created_at?: string;
  updated_at?: string;
}

export interface BookingCreate {
  title: string;
  room_id: string;
  date: string;
  start_time: string;
  end_time: string;
  participant_count: number;
  participants?: BookingParticipant[];
  description?: string;
  status?: BookingStatus;
}

export interface BookingUpdate {
  title?: string;
  room_id?: string;
  date?: string;
  start_time?: string;
  end_time?: string;
  participant_count?: number;
  participants?: BookingParticipant[];
  description?: string;
  status?: BookingStatus;
  notes?: string;
}

// Calendar Types
export interface CalendarEvent {
  id: string;
  title: string;
  start: string;
  end: string;
  date: string;
  room_id: string;
  room_name?: string;
  building_name?: string;
  status: BookingStatus;
  organizer_name?: string;
  participant_count?: number;
  description?: string;
  backgroundColor?: string;
  borderColor?: string;
}

export interface DayAgendaItem {
  id: string;
  title: string;
  room_id: string;
  room_name: string;
  building_name?: string;
  start?: string;
  end?: string;
  start_time: string;
  end_time: string;
  status: BookingStatus;
  organizer_name?: string;
  participant_count?: number;
}

// Meeting Types
export interface Meeting {
  id: string;
  booking_id?: string;
  room_id: string;
  title: string;
  start_time: string;
  end_time?: string;
  status: MeetingStatus;
  summary?: string;
  action_items: ActionItem[];
  decisions: string[];
  recording_url?: string;
}

export type MeetingStatus = 'SCHEDULED' | 'ONGOING' | 'COMPLETED' | 'CANCELLED';

// Department Types
export interface Department {
  id: string;
  name: string;
  code: string;
  head_id?: string | null;
  head_name?: string | null;
  created_at: string;
  updated_at: string;
}

export interface DepartmentCreate {
  name: string;
  code: string;
  head_id?: string | null;
}

export interface DepartmentUpdate {
  name?: string;
  code?: string;
  head_id?: string | null;
}

// Role & Permission Types
export interface Permission {
  id: string;
  name: string;
  code: string;
  group: PermissionGroup;
  description?: string;
}

export type PermissionGroup =
  | 'users'
  | 'rooms'
  | 'bookings'
  | 'notes'
  | 'devices'
  | 'reports'
  | 'settings'
  | 'audit';

export const PERMISSION_GROUPS: { key: PermissionGroup; label: string }[] = [
  { key: 'users', label: 'Pengguna & Peran' },
  { key: 'rooms', label: 'Ruangan, Gedung & Display' },
  { key: 'bookings', label: 'Pemesanan Ruangan' },
  { key: 'notes', label: 'Notulensi Rapat' },
  { key: 'devices', label: 'Perangkat, Audio & Videowall' },
  { key: 'reports', label: 'Laporan & Statistik' },
  { key: 'settings', label: 'Pengaturan, Notifikasi & Pemeliharaan' },
  { key: 'audit', label: 'Log Audit' },
];

export interface Role {
  id: string;
  name: string;
  description?: string;
  /** Kode izin (mis. "users.view"); ["*"] = akses penuh. */
  permissions?: string[];
  /** Id katalog izin (perm_*), padanan `permissions`. */
  permission_ids?: string[];
  permission_count?: number;
  /** Peran bawaan sistem (mis. Super Admin): tidak boleh diubah/dihapus. */
  is_system?: boolean;
  is_active?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface RoleCreate {
  name: string;
  description?: string;
}

export interface RoleUpdate {
  name?: string;
  description?: string;
}

export interface SyncRolePermissionsRequest {
  /** Kode izin (mis. "users.view"). */
  permissions: string[];
}

// Extended User Response from API
export interface UserResponse {
  id: string;
  username: string;
  name: string;
  email: string;
  nik?: string | null;
  rank?: string | null;
  position?: string | null;
  role_id?: string | null;
  role_name?: string | null;
  department_id?: string | null;
  department_name?: string | null;
  avatar_url?: string | null;
  phone?: string | null;
  status: string;
  last_login?: string | null;
  login_attempts: number;
  created_at: string;
  updated_at: string;
}

export interface UserCreate {
  username: string;
  name: string;
  email: string;
  password: string;
  nik?: string | null;
  rank?: string | null;
  position?: string | null;
  role_id?: string | null;
  department_id?: string | null;
  avatar_url?: string | null;
  phone?: string | null;
  status?: string;
}

export interface UserUpdate {
  username?: string;
  name?: string;
  email?: string;
  nik?: string | null;
  rank?: string | null;
  position?: string | null;
  role_id?: string | null;
  department_id?: string | null;
  avatar_url?: string | null;
  phone?: string | null;
  status?: string | null;
}

export interface PaginatedUsersResponse {
  items: UserResponse[];
  total: number;
  page: number;
  per_page: number;
  total_pages: number;
}

// === Equipment Types (Perangkat AV) ===
/** Nilai sesuai schema backend (schemas/equipment.py). */
export type EquipmentCategory = 'display' | 'audio' | 'input' | 'network' | 'camera' | 'other';
export type EquipmentStatus = 'active' | 'maintenance' | 'broken' | 'disposed';

export const EQUIPMENT_CATEGORY_OPTIONS: { value: EquipmentCategory; label: string }[] = [
  { value: 'display', label: 'Display' },
  { value: 'audio', label: 'Audio' },
  { value: 'input', label: 'Input' },
  { value: 'network', label: 'Jaringan' },
  { value: 'camera', label: 'Kamera' },
  { value: 'other', label: 'Lainnya' },
];

export const EQUIPMENT_STATUS_OPTIONS: { value: EquipmentStatus; label: string }[] = [
  { value: 'active', label: 'Aktif' },
  { value: 'maintenance', label: 'Perawatan' },
  { value: 'broken', label: 'Rusak' },
  { value: 'disposed', label: 'Dibuang' },
];

export interface Equipment {
  id: string;
  code: string;
  name: string;
  category: EquipmentCategory;
  brand?: string;
  model?: string;
  serial_number?: string;
  purchase_date?: string;
  warranty_until?: string;
  status: EquipmentStatus;
  /** Alias UI untuk `location_id` backend (diisi oleh API layer). */
  room_id?: string | null;
  location_id?: string | null;
  room_name?: string | null;
  notes?: string;
  created_at?: string;
  updated_at?: string;
}

export interface EquipmentCreate {
  code: string;
  name: string;
  category: EquipmentCategory;
  brand?: string;
  model?: string;
  serial_number?: string;
  purchase_date?: string;
  warranty_until?: string;
  status?: EquipmentStatus;
  room_id?: string | null;
  notes?: string;
}

export interface EquipmentUpdate {
  code?: string;
  name?: string;
  category?: EquipmentCategory;
  brand?: string;
  model?: string;
  serial_number?: string;
  purchase_date?: string;
  warranty_until?: string;
  status?: EquipmentStatus;
  room_id?: string | null;
  notes?: string;
}

export interface PaginatedEquipmentResponse {
  items: Equipment[];
  total: number;
  page: number;
  per_page: number;
  total_pages: number;
}

// === Device Types (IoT Devices) — sama persis dengan backend (src/api/schemas/device.py) ===
export type DeviceStatus = 'online' | 'offline' | 'error' | 'maintenance';

export type DeviceType =
  | 'tv'
  | 'display'
  | 'projector'
  | 'ac'
  | 'cctv'
  | 'lights'
  | 'curtain'
  | 'sensor_temp'
  | 'sensor_humidity'
  | 'door_lock'
  | 'videowall_controller'
  | 'audio_mixer'
  | 'audio_processor'
  | 'tablet';

export const DEVICE_TYPE_OPTIONS: { value: DeviceType; label: string }[] = [
  { value: 'tv', label: 'TV / Panel Videowall' },
  { value: 'display', label: 'Display' },
  { value: 'videowall_controller', label: 'Videowall Controller' },
  { value: 'audio_mixer', label: 'Digital Mixer Audio' },
  { value: 'audio_processor', label: 'Audio Processor' },
  { value: 'projector', label: 'Proyektor' },
  { value: 'ac', label: 'AC' },
  { value: 'cctv', label: 'CCTV' },
  { value: 'lights', label: 'Lampu' },
  { value: 'curtain', label: 'Tirai' },
  { value: 'sensor_temp', label: 'Sensor Suhu' },
  { value: 'sensor_humidity', label: 'Sensor Kelembaban' },
  { value: 'door_lock', label: 'Kunci Pintu' },
  { value: 'tablet', label: 'Tablet' },
];

export function deviceTypeLabel(type: string): string {
  return DEVICE_TYPE_OPTIONS.find((o) => o.value === type)?.label || type;
}

export const DEVICE_STATUS_OPTIONS: { value: DeviceStatus; label: string }[] = [
  { value: 'online', label: 'Online' },
  { value: 'offline', label: 'Offline' },
  { value: 'error', label: 'Error' },
  { value: 'maintenance', label: 'Maintenance' },
];

/** State terakhir yang dilaporkan device agent (MQTT topic state). */
export interface DeviceLiveState {
  online?: boolean | null;
  power?: 'on' | 'off' | null;
  source?: string | null;
  layout?: string | null;
  reason?: string;
  ts?: string;
  last_ack?: { cmd_id?: string; ok?: boolean; error?: string | null; ts?: string };
}

export interface Device {
  id: string;
  code: string;
  name: string;
  device_type: DeviceType | string;
  location_id?: string | null;
  room_name?: string | null;
  ip_address?: string | null;
  mac_address?: string | null;
  firmware_version?: string | null;
  status: DeviceStatus;
  last_seen?: string | null;
  config: Record<string, unknown>;
  last_action?: string | null;
  live?: DeviceLiveState | null;
  created_at: string;
  updated_at: string;
}

export interface DeviceCreate {
  code: string;
  name: string;
  device_type: DeviceType;
  location_id?: string | null;
  ip_address?: string | null;
  mac_address?: string | null;
  firmware_version?: string | null;
  config?: Record<string, unknown>;
}

export interface DeviceUpdate {
  code?: string;
  name?: string;
  device_type?: DeviceType;
  location_id?: string | null;
  ip_address?: string | null;
  mac_address?: string | null;
  firmware_version?: string | null;
  /** Hanya untuk menandai maintenance; online/offline otomatis dari agent. */
  status?: DeviceStatus;
  config?: Record<string, unknown>;
}

export interface DeviceHealthRoom {
  room_id: string | null;
  room_name: string;
  room_code: string;
  online: number;
  offline: number;
  error: number;
  maintenance: number;
  total: number;
}

export interface DeviceHealthSummary {
  count_total: number;
  count_online: number;
  count_offline: number;
  count_error: number;
  count_maintenance: number;
  list_per_room: DeviceHealthRoom[];
}

export interface PaginatedDevicesResponse {
  items: Device[];
  total: number;
  page: number;
  per_page: number;
  total_pages: number;
}

// === Kontrol AV (perintah MQTT + ack) — src/api/services/av_service.py ===
export type AvCommandStatus = 'sent' | 'acked' | 'failed' | 'timeout';

export interface AvCommandDeviceResult {
  device_id: string;
  device_code: string;
  device_name: string;
  action: string;
  cmd_id: string;
  status: AvCommandStatus;
  error: string | null;
  response: string | null;
}

/** Respons setiap perintah AV/perangkat (HTTP 200; cek `status`). */
export interface AvCommandResult {
  cmd_id: string | null;
  status: AvCommandStatus;
  error: string | null;
  results: AvCommandDeviceResult[];
}

export type DeviceCommandAction = 'power-on' | 'power-off' | 'lock' | 'unlock' | 'restart';

export interface MqttStatus {
  configured: boolean;
  connected: boolean;
  simulate: boolean;
  broker: string | null;
  tls: boolean;
  last_error: string | null;
}

export interface AvDeviceBrief {
  id: string;
  code: string;
  name: string;
  device_type: string;
  status: DeviceStatus;
  last_seen: string | null;
  last_action: string | null;
  live: DeviceLiveState | null;
}

export interface VideowallWindowRect {
  id: number;
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface VideowallPreset {
  id: string;
  label: string;
  scene: number;
  windows: VideowallWindowRect[];
}

export interface VideowallSourceOption {
  id: string;
  label: string;
  code: number;
}

export type AudioMode = 'xair' | 'none' | string;

export interface RoomAvCapabilities {
  room_id: string;
  room_code: string;
  room_name: string;
  mqtt: MqttStatus;
  videowall: {
    available: boolean;
    controller: AvDeviceBrief | null;
    panels: AvDeviceBrief[];
    grid: { cols: number; rows: number };
    presets: VideowallPreset[];
    sources: VideowallSourceOption[];
  };
  audio: {
    mode: AudioMode;
    can_control: boolean;
    has_meters: boolean;
    message: string | null;
    mixer: AvDeviceBrief | null;
    max_channels: number;
    channels: AudioChannel[];
  };
  devices: AvDeviceBrief[];
}

export interface MixerChannelState {
  muted?: boolean | null;
  fader?: number | null;
  gain?: number | null;
}

/** Payload smr/audio/{room}/mixer, kunci = channel_no. */
export interface MixerState {
  channels: Record<string, MixerChannelState>;
  main?: { muted?: boolean | null; fader?: number | null };
  online?: boolean;
  ts?: string;
}

export interface ActiveSpeakers {
  channels: number[];
  seats: string[];
  participants: string[];
  booking_id?: string | null;
}

export interface RoomAvState {
  room_id: string;
  room_code: string;
  mqtt: MqttStatus;
  devices: AvDeviceBrief[];
  audio_mode: AudioMode;
  mixer: MixerState | null;
  levels: Record<string, number>;
  active_speakers: ActiveSpeakers;
}

// === Videowall (konfigurasi tersimpan) ===
export interface VideowallInput {
  /** id sumber dari capabilities, mis. "hdmi1" */
  input: string;
  label?: string | null;
  window?: number | null;
}

export interface VideowallConfig {
  id: string;
  room_id: string;
  room_name?: string | null;
  device_id?: string | null;
  device_name?: string | null;
  config_name: string;
  /** id preset dari capabilities, mis. "fullscreen" */
  layout_mode: string;
  inputs: VideowallInput[];
  last_action?: string | null;
  created_at: string;
  updated_at: string;
}

export interface VideowallConfigCreate {
  room_id: string;
  device_id?: string | null;
  config_name: string;
  layout_mode: string;
  inputs?: VideowallInput[];
}

export interface VideowallConfigUpdate {
  room_id?: string;
  device_id?: string | null;
  config_name?: string;
  layout_mode?: string;
  inputs?: VideowallInput[];
}

// === Audio ===
export type AudioZoneSource = 'mic1' | 'mic2' | 'line1' | 'bluetooth' | 'hdmi' | 'usb';

export const AUDIO_ZONE_SOURCE_OPTIONS: { value: AudioZoneSource; label: string }[] = [
  { value: 'mic1', label: 'Mic 1' },
  { value: 'mic2', label: 'Mic 2' },
  { value: 'line1', label: 'Line In' },
  { value: 'bluetooth', label: 'Bluetooth' },
  { value: 'hdmi', label: 'HDMI' },
  { value: 'usb', label: 'USB' },
];

export interface AudioZone {
  id: string;
  room_id: string;
  room_name?: string | null;
  device_id?: string | null;
  device_name?: string | null;
  zone_name: string;
  volume: number;
  is_muted: boolean;
  input_source: AudioZoneSource;
  created_at: string;
  updated_at: string;
}

export interface AudioZoneCreate {
  room_id: string;
  device_id?: string | null;
  zone_name: string;
  volume?: number;
  is_muted?: boolean;
  input_source?: AudioZoneSource;
}

export interface AudioZoneUpdate {
  room_id?: string;
  device_id?: string | null;
  zone_name?: string;
  volume?: number;
  is_muted?: boolean;
  input_source?: AudioZoneSource;
}

/** Respons perintah zona = hasil perintah + state zona terbaru. */
export type AudioZoneCommandResult = AvCommandResult & {
  zone_id: string;
  volume?: number;
  is_muted?: boolean;
  input_source?: AudioZoneSource;
};

/** Kanal mic fisik ruangan (tabel audio_channels). */
export interface AudioChannel {
  id: string;
  room_id: string;
  channel_no: number;
  label: string;
  receiver_label: string | null;
  mixer_channel: number | null;
  capture_channel: number | null;
  device_id: string | null;
  enabled: boolean;
}

export interface AudioChannelInput {
  channel_no: number;
  label: string;
  receiver_label?: string | null;
  mixer_channel?: number | null;
  capture_channel?: number | null;
  device_id?: string | null;
  enabled: boolean;
}

/** GET /audio/microphones?room_id= : kanal + state mixer/level live. */
export interface Microphone extends AudioChannel {
  muted: boolean | null;
  fader: number | null;
  gain: number | null;
  level_db: number | null;
  active: boolean;
}

export interface MicrophonesResponse {
  audio_mode: AudioMode;
  can_control: boolean;
  message: string | null;
  items: Microphone[];
}

// === Notes / Notulensi Types ===
export type ActionItemStatus = 'open' | 'in_progress' | 'done' | 'cancelled';

export interface ActionItem {
  id?: string;
  note_id?: string;
  task: string;
  /** Penanggung jawab (PIC). */
  owner?: string | null;
  /** @deprecated alias lama untuk `owner`. */
  assignee?: string | null;
  due_date?: string | null;
  /** 'pending'/'completed' = nilai lama; backend memetakan ke 'open'/'done'. */
  status: ActionItemStatus | 'pending' | 'completed';
  source?: 'manual' | 'ai';
  created_at?: string;
  updated_at?: string;
}

export const ACTION_ITEM_STATUS_OPTIONS: { value: ActionItemStatus; label: string }[] = [
  { value: 'open', label: 'Terbuka' },
  { value: 'in_progress', label: 'Berjalan' },
  { value: 'done', label: 'Selesai' },
  { value: 'cancelled', label: 'Dibatalkan' },
];

export interface TranscriptLine {
  id?: string;
  speaker: string;
  time?: string;
  timestamp?: string;
  text: string;
}

export interface NoteSummaryTopic {
  judul: string;
  uraian: string;
}

export interface NoteSummaryFollowUp {
  tugas: string;
  pic?: string | null;
  tenggat?: string | null;
}

/** Ringkasan terstruktur hasil LLM (meeting_notes.summary_json). */
export interface NoteSummaryJson {
  ringkasan?: string;
  pokok_bahasan?: NoteSummaryTopic[];
  keputusan?: string[];
  tindak_lanjut?: NoteSummaryFollowUp[];
  peserta_aktif?: string[];
  model?: string;
  generated_at?: string;
  chunks?: number;
  edited?: boolean;
}

export type NoteStatus = 'draft' | 'final';

export interface MeetingNote {
  id: string;
  booking_id?: string | null;
  booking_title?: string | null;
  title: string;
  room_id: string;
  room_name?: string;
  date: string;
  start_time: string;
  end_time: string;
  participants: string[];
  summary?: string;
  decisions?: string[];
  action_items: ActionItem[];
  transcript?: TranscriptLine[];
  transcript_processing?: boolean;
  ai_model?: string | null;
  generated_at?: string | null;
  status?: NoteStatus;
  summary_json?: NoteSummaryJson | null;
  finalized_at?: string | null;
  finalized_by?: string | null;
  finalized_by_name?: string | null;
  segment_count?: number;
  created_by?: string | null;
  created_by_name?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface MeetingNoteCreate {
  title: string;
  room_id: string;
  booking_id?: string;
  date: string;
  start_time: string;
  end_time: string;
  participants: string[];
  summary?: string;
  decisions?: string[];
  action_items?: ActionItem[];
}

export interface MeetingNoteUpdate {
  title?: string;
  room_id?: string;
  date?: string;
  start_time?: string;
  end_time?: string;
  participants?: string[];
  summary?: string;
  decisions?: string[];
  action_items?: ActionItem[];
  /** @deprecated transkrip kini disimpan per segmen; field ini diabaikan backend. */
  transcript?: TranscriptLine[];
  summary_json?: NoteSummaryJson;
}

/** Satu segmen transkrip (GET /notes/{id}/segments & event WS `transcript_segment`). */
export interface NoteSegment {
  id: string;
  note_id: string;
  booking_id?: string | null;
  recording_id?: string | null;
  start_ms: number;
  end_ms: number;
  audio_channel_no?: number | null;
  seat_id?: string | null;
  seat_label?: string | null;
  participant_id?: string | null;
  speaker_name?: string | null;
  text: string;
  confidence?: number | null;
  language?: string | null;
  is_edited: boolean;
  created_at?: string | null;
  updated_at?: string | null;
  /** true pada event WS saat segmen dihapus. */
  deleted?: boolean;
}

export interface NoteSegmentsResponse {
  items: NoteSegment[];
  total: number;
  cursor: string | null;
  server_time: string;
  transcript_processing: boolean;
}

export interface NoteSegmentUpdate {
  text?: string;
  speaker_name?: string;
  participant_id?: string;
  clear_participant?: boolean;
}

export interface SttStatus {
  engine: string;
  engine_available: boolean;
  engine_error?: string | null;
  model: string;
  model_loaded: boolean;
  device: string;
  compute_type: string;
  language: string;
  ffmpeg_available: boolean;
  worker_running: boolean;
  queue_size: number;
  current_job?: string | null;
  processed: number;
  last_error?: string | null;
  last_error_at?: string | null;
}

export interface LlmStatus {
  reachable: boolean;
  base_url: string;
  model: string;
  model_available: boolean;
  error?: string | null;
  models: string[];
}

export interface PaginatedNotesResponse {
  items: MeetingNote[];
  total: number;
  page: number;
  per_page: number;
  total_pages: number;
}

// === Module 13: Notifications ===
export type NotificationType =
  | 'info'
  | 'success'
  | 'warning'
  | 'error'
  | 'booking_request'
  | 'booking_approved'
  | 'booking_rejected'
  | 'booking_cancelled'
  | 'room_available'
  | 'system';

export const NOTIFICATION_TYPE_OPTIONS: { value: NotificationType; label: string }[] = [
  { value: 'info', label: 'Informasi' },
  { value: 'success', label: 'Sukses' },
  { value: 'warning', label: 'Peringatan' },
  { value: 'error', label: 'Error' },
  { value: 'booking_request', label: 'Permintaan Pemesanan' },
  { value: 'booking_approved', label: 'Pemesanan Disetujui' },
  { value: 'booking_rejected', label: 'Pemesanan Ditolak' },
  { value: 'booking_cancelled', label: 'Pemesanan Dibatalkan' },
  { value: 'room_available', label: 'Ruangan Tersedia' },
  { value: 'system', label: 'Sistem' },
];

export interface Notification {
  id: string;
  user_id?: string;
  type: NotificationType;
  title: string;
  message: string;
  data?: Record<string, unknown>;
  is_read: boolean;
  read_at?: string;
  created_at: string;
  updated_at: string;
}

export interface NotificationCreate {
  user_ids?: string[];
  broadcast?: boolean;
  type: NotificationType;
  title: string;
  message: string;
  data?: Record<string, unknown>;
}

export interface PaginatedNotificationsResponse {
  items: Notification[];
  total: number;
  page: number;
  per_page: number;
  total_pages: number;
  unread_count: number;
}

// === Module 14: Reports & Dashboard ===
export interface DashboardSummary {
  total_rooms: number;
  total_users: number;
  today_bookings: number;
  ongoing_meetings: number;
  online_devices: number;
  pending_approvals: number;
  room_utilization_percent: number;
  avg_meeting_duration_minutes: number;
}

/** GET /reports/bookings (format=json) */
export interface BookingsReport {
  total_bookings: number;
  per_status: { status: string; count: number }[];
  per_room: { room_id: string; room_name: string; count: number }[];
  per_day: { date: string; count: number }[];
  from_date?: string | null;
  to_date?: string | null;
}

/** GET /reports/rooms-utilization */
export interface RoomUtilizationItem {
  room_id: string;
  room_name: string;
  total_hours_available: number;
  total_hours_booked: number;
  utilization_percent: number;
  booking_count: number;
}

export interface AttendanceReportItem {
  meeting_id: string;
  meeting_title: string;
  date: string;
  room_name: string;
  organizer_name: string;
  total_participants: number;
  present_count: number;
  absent_count: number;
  attendance_percent: number;
}

export interface EquipmentInventoryItem {
  category: string;
  total: number;
  active: number;
  maintenance: number;
  broken: number;
  disposed: number;
}

/** GET /reports/equipment-inventory */
export interface EquipmentInventoryReport {
  items: EquipmentInventoryItem[];
  grand_total: number;
}

// === Module 15: System Settings ===
export type SystemSettingGroup =
  | 'authentication'
  | 'email'
  | 'company'
  | 'booking'
  | 'notification'
  | 'maintenance';

export const SYSTEM_SETTING_GROUP_OPTIONS: { key: SystemSettingGroup; label: string }[] = [
  { key: 'authentication', label: 'Otentikasi' },
  { key: 'email', label: 'Email' },
  { key: 'company', label: 'Perusahaan' },
  { key: 'booking', label: 'Pemesanan' },
  { key: 'notification', label: 'Notifikasi' },
  { key: 'maintenance', label: 'Pemeliharaan' },
];

export interface SystemSetting {
  id: string;
  key: string;
  value: string;
  group_name: SystemSettingGroup;
  description?: string;
  data_type: 'string' | 'integer' | 'boolean' | 'json';
  is_public: boolean;
  /** Nilai rahasia (mis. smtp_pass) dikirim kosong/ter-mask oleh backend. */
  is_secret?: boolean;
  /** Untuk nilai rahasia: apakah nilai sudah tersimpan di server. */
  has_value?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface SystemSettingUpdate {
  value: string;
}

export interface BatchSettingsUpdate {
  /** Map key -> value. */
  settings: Record<string, string>;
}

// === Module 17: Audit Logs ===
export type AuditModule =
  | 'auth'
  | 'users'
  | 'roles'
  | 'rooms'
  | 'buildings'
  | 'bookings'
  | 'equipment'
  | 'devices'
  | 'settings'
  | 'notes'
  | 'system';

export const AUDIT_MODULE_OPTIONS: { value: AuditModule; label: string }[] = [
  { value: 'auth', label: 'Otentikasi' },
  { value: 'users', label: 'Pengguna' },
  { value: 'roles', label: 'Peran & Izin' },
  { value: 'rooms', label: 'Ruangan' },
  { value: 'buildings', label: 'Gedung' },
  { value: 'bookings', label: 'Pemesanan' },
  { value: 'equipment', label: 'Perangkat AV' },
  { value: 'devices', label: 'Perangkat IoT' },
  { value: 'settings', label: 'Pengaturan' },
  { value: 'notes', label: 'Notulensi' },
  { value: 'system', label: 'Sistem' },
];

export type AuditAction =
  | 'create'
  | 'update'
  | 'delete'
  | 'login'
  | 'logout'
  | 'approve'
  | 'reject'
  | 'export'
  | 'import'
  | 'other';

export const AUDIT_ACTION_OPTIONS: { value: AuditAction; label: string }[] = [
  { value: 'create', label: 'Buat' },
  { value: 'update', label: 'Ubah' },
  { value: 'delete', label: 'Hapus' },
  { value: 'login', label: 'Login' },
  { value: 'logout', label: 'Logout' },
  { value: 'approve', label: 'Setujui' },
  { value: 'reject', label: 'Tolak' },
  { value: 'export', label: 'Ekspor' },
  { value: 'import', label: 'Impor' },
  { value: 'other', label: 'Lainnya' },
];

export interface AuditLog {
  id: string;
  timestamp: string;
  user_id?: string;
  user_name?: string;
  module: AuditModule;
  action: AuditAction;
  target_type?: string;
  target_id?: string;
  description?: string;
  old_value?: Record<string, unknown> | string;
  new_value?: Record<string, unknown> | string;
  ip_address?: string;
  user_agent?: string;
  browser?: string;
  os?: string;
}

/** GET /audit/stats/summary */
export interface AuditStatsSummary {
  total_logs_30d: number;
  per_module: { module: AuditModule; count: number }[];
  per_action: { action: string; count: number }[];
  top_users: { user_id: string; user_name: string; count: number }[];
}

export interface PaginatedAuditLogsResponse {
  items: AuditLog[];
  total: number;
  page: number;
  per_page: number;
  total_pages: number;
}

// === Module 18: Maintenance & System ===
/** GET /maintenance/health */
export interface SystemHealth {
  db_status: 'connected' | 'disconnected' | string;
  total_users: number;
  total_rooms: number;
  total_bookings: number;
  pending_backup: boolean;
  storage_used_pct: number;
  uptime_seconds: number;
  started_at: string;
}

export interface Migration {
  filename: string;
  status: 'applied' | 'pending' | string;
  applied_at?: string | null;
}

/** GET /maintenance/migrations */
export interface MigrationsList {
  migrations: Migration[];
  total_applied: number;
  total_pending: number;
}

/** POST /maintenance/migrations/run */
export interface MigrationsRunResult {
  files_run: string[];
  errors: { file: string; error: string }[];
}

/** POST /maintenance/backup */
export interface BackupResponse {
  filename: string;
  size_bytes: number;
  created_at: string;
  download_url: string;
}

/** POST /maintenance/restore */
export interface RestoreResponse {
  success: boolean;
  filename: string;
  message: string;
  restored_at: string;
}

export interface CacheClearResult {
  success: boolean;
  cleared_caches: string[];
  message: string;
}

export interface SeedDemoResult {
  success: boolean;
  users_created: number;
  bookings_created: number;
  message: string;
}

// === Public Door Display Types ===
export interface DoorDisplayCurrentMeeting {
  booking_id: string;
  title: string;
  participants_count: number;
  start_time: string;
  end_time: string;
  minutes_remaining: number;
  host_name: string;
  status: string;
}

export interface DoorDisplayUpcomingMeeting {
  booking_id: string;
  title: string;
  start_time: string;
  end_time: string;
  host_name: string;
}

export interface DoorDisplayRoomStatus {
  room_id: string;
  room_name: string;
  room_code: string;
  capacity: number;
  room_status: 'available' | 'occupied' | 'soon';
  current_meeting?: DoorDisplayCurrentMeeting | null;
  next_upcoming: DoorDisplayUpcomingMeeting[];
}

// === Module 11: Notulensi - Recording / Transcript / Summary ===
/** idle = belum ada rekaman; completed/error = nilai lama (kompatibilitas). */
export type RecordingStatus =
  | 'idle' | 'recording' | 'paused' | 'stopped' | 'processing' | 'done' | 'failed' | 'completed' | 'error';

export type RecordingSource = 'multichannel' | 'mix' | 'browser' | 'upload';

export interface RecordingStatusResponse {
  booking_id: string;
  status: RecordingStatus;
  recording_id?: string | null;
  note_id?: string | null;
  source?: RecordingSource;
  channel_count?: number;
  started_at?: string | null;
  paused_at?: string | null;
  ended_at?: string | null;
  duration_seconds: number;
  /** Waktu rekam efektif (ms, tanpa jeda) — acuan start_ms segmen. */
  elapsed_ms?: number;
  pending_jobs?: number;
  progress?: number | null;
  error?: string | null;
  message?: string;
  audio_level?: number;
  audio_peak?: number;
  current_speaker?: string | null;
  segment_count?: number;
}

export interface TranscriptSegment {
  id: string;
  speaker: string;
  speaker_id?: string;
  text: string;
  start_time: number;
  end_time?: number;
  confidence?: number;
  timestamp?: string;
}

export interface SummaryDecision {
  id?: string;
  topic: string;
  decision: string;
  decided_by?: string;
  notes?: string;
}

export interface SummaryResponse {
  note_id: string;
  booking_id?: string;
  title?: string;
  summary_text: string;
  key_points: string[];
  decisions: SummaryDecision[];
  action_items: ActionItem[];
  participants_mentioned?: string[];
  generated_at?: string;
  processing?: boolean;
  processing_percent?: number;
}

export interface SummarizeTriggerResponse {
  success: boolean;
  message: string;
  booking_id?: string;
  note_id?: string;
  job_id?: string;
  status: 'queued' | 'processing' | 'completed';
  estimated_seconds?: number;
}

// === Module 16: Door Display Interactive ===
export interface TimeSlot {
  start: string;
  end: string;
  available: boolean;
  booking_id?: string | null;
  title?: string;
  booked_by?: string;
}

export interface DoorAvailableSlotsResponse {
  room_code: string;
  room_name?: string;
  date: string;
  interval_minutes: number;
  day_start: string;
  day_end: string;
  slots: TimeSlot[];
  total_available: number;
  total_booked: number;
}

export interface QuickBookingRequest {
  title: string;
  start_time: string;
  duration_minutes: number;
  booked_by: string;
  participant_count?: number;
  notes?: string;
}

export interface QuickBookingResponse {
  success: boolean;
  message: string;
  booking_id?: string;
  room_code?: string;
  room_id?: string;
  title?: string;
  date?: string;
  start_time?: string;
  end_time?: string;
  duration_minutes?: number;
  status?: 'approved' | 'pending' | 'cancelled';
  conflict_booking?: {
    booking_id: string;
    title: string;
    start_time: string;
    end_time: string;
  };
}

export interface DoorCancelBookingResponse {
  success: boolean;
  message: string;
  booking_id: string;
  status?: 'cancelled';
}

export interface WelcomeMessageResponse {
  room_code: string;
  room_name?: string;
  title: string;
  subtitle: string;
  custom_message?: string;
  show_custom_message: boolean;
  footer_text?: string;
  last_updated?: string;
}

// === Presensi QR (Tiket Peserta + Scanner Kiosk) ===
export interface TicketItem {
  participant_id: string;
  booking_id: string;
  ticket_code: string;
  booking_title: string;
  room_name?: string;
  room_code?: string;
  date: string;
  start_time: string;
  end_time: string;
  booking_status: string;
  attended: boolean;
  checked_in_at?: string | null;
  attended_count: number;
  total_participants: number;
}

export interface MyTicketsResponse {
  items: TicketItem[];
  total: number;
}

export interface PresensiScanRequest {
  code: string;
  room_code?: string;
}

export interface PresensiScanResponse {
  success: boolean;
  message: string;
  participant_id: string;
  participant_name: string;
  booking_id: string;
  booking_title: string;
  room_name?: string;
  attended: boolean;
  already_checked_in: boolean;
  checked_in_at?: string | null;
  attended_count: number;
  total_participants: number;
  /** Kursi peserta (denah ruangan), diisi otomatis saat presensi. */
  seat?: PresensiSeatInfo | null;
}

export interface AttendanceParticipantItem {
  participant_id: string;
  name: string;
  is_guest: boolean;
  attended: boolean;
  checked_in_at?: string | null;
}

export interface BookingAttendanceResponse {
  booking_id: string;
  booking_title: string;
  room_name?: string;
  attended_count: number;
  total_participants: number;
  participants: AttendanceParticipantItem[];
}

// === Lisensi (Gating Aplikasi) ===
export interface LicenseInfo {
  license_id: string;
  customer: string;
  fingerprint: string;
  edition: string;
  issued_at: string;
  expires_at?: string | null;
  max_rooms: number;
  max_users: number;
  features: string[];
  notes: string;
}

export interface LicenseStatus {
  enforced: boolean;
  activated: boolean;
  reason: string;
  fingerprint: string;
  license_file: string;
  days_remaining?: number | null;
  license?: LicenseInfo | null;
}

export interface LicenseActivateRequest {
  license_key: string;
}

// ============================================================
// Live meeting & denah kursi
// (docs/architecture/LIVE_MEETING.md, src/api/routers/live_meeting.py)
// ============================================================

export type SeatType = 'chair' | 'delegate' | 'secretary' | 'guest' | 'operator';
export type SeatLayoutType = 'u_shape' | 'boardroom' | 'classroom' | 'circle';
export type MeetingLiveStatus = 'scheduled' | 'live' | 'ended';

// AudioChannel: lihat definisi kanal mic di bagian audio (dipakai bersama modul AV).

/** Bentuk meja pada denah; koordinat persen (0-100) kanvas 16:10. */
export interface SeatLayoutTable {
  shape: 'rect' | 'ellipse' | 'u';
  x: number;
  y: number;
  w: number;
  h: number;
  /** Tebal lengan meja U (sumbu x). */
  tx?: number | null;
  /** Tebal alas meja U (sumbu y). */
  ty?: number | null;
  label?: string | null;
}

export interface SeatLayoutShape {
  type: SeatLayoutType | 'custom';
  tables: SeatLayoutTable[];
}

export interface RoomSeat {
  id: string;
  room_id: string;
  seat_no: number;
  label: string;
  seat_type: SeatType;
  pos_x: number;
  pos_y: number;
  /** Arah hadap kursi (derajat, 0 = atas, searah jarum jam). */
  rotation: number;
  audio_channel_id: string | null;
  channel: AudioChannel | null;
}

export interface RoomSeatInput {
  id?: string;
  seat_no: number;
  label: string;
  seat_type: SeatType;
  pos_x: number;
  pos_y: number;
  rotation: number;
  audio_channel_id?: string | null;
}

export interface RoomSeatMap {
  room_id: string;
  room_name: string;
  room_code: string;
  capacity: number;
  layout: SeatLayoutShape | null;
  seats: RoomSeat[];
  audio_channels: AudioChannel[];
  channels_created?: number;
}

export interface SeatGenerateRequest {
  layout: SeatLayoutType;
  count: number;
  chair_count?: number;
  link_channels?: boolean;
}

export interface SeatAssignment {
  id: string;
  booking_id: string;
  seat_id: string;
  seat_no: number | null;
  seat_label: string | null;
  participant_id: string | null;
  display_name: string | null;
  /** Nama tampilan ternormalisasi (nama peserta atau display_name). */
  name: string | null;
  role_label: string | null;
  assigned_via: 'manual' | 'checkin' | 'auto';
}

/** Item tanpa participant_id & display_name = kosongkan kursi. */
export interface SeatAssignmentInput {
  seat_id: string;
  participant_id?: string | null;
  display_name?: string | null;
  role_label?: string | null;
}

export interface SeatAssignmentsResponse {
  booking_id: string;
  items: SeatAssignment[];
  assigned?: number;
}

export interface PresensiSeatInfo {
  seat_id?: string | null;
  seat_no: number;
  label: string;
}

export interface LiveParticipant {
  id: string;
  user_id: string | null;
  name: string;
  is_guest: boolean;
  is_organizer: boolean;
  position?: string | null;
  attended: boolean;
  checked_in_at: string | null;
  seat: PresensiSeatInfo | null;
}

export interface LiveSeat extends RoomSeat {
  assignment: SeatAssignment | null;
}

export interface LiveBookingInfo {
  id: string;
  title: string;
  description?: string | null;
  room_id: string;
  room_name: string | null;
  room_code: string | null;
  date: string;
  start_time: string;
  /** Jam selesai efektif (sudah termasuk perpanjangan). */
  end_time: string;
  original_end_time: string;
  start_at: string;
  end_at_effective: string;
  status: string;
  meeting_status: MeetingLiveStatus;
  actual_start_at: string | null;
  actual_end_at: string | null;
  extended_minutes: number;
  organizer_id: string;
  organizer_name: string | null;
}

export interface LiveRecordingInfo {
  id: string;
  status: string;
  source: string;
  channel_count: number;
  started_at: string | null;
}

export interface LiveMeetingSnapshot {
  server_time: string;
  booking: LiveBookingInfo;
  permissions: { can_control: boolean; can_edit_notes: boolean; can_edit_layout: boolean };
  attendance: { attended: number; total: number };
  participants: LiveParticipant[];
  seats: LiveSeat[];
  layout: SeatLayoutShape | null;
  audio_channels: AudioChannel[];
  recording: LiveRecordingInfo | null;
  note_id: string | null;
}
