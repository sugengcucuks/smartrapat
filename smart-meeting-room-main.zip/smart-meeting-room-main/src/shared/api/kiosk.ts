import axios, { AxiosError } from 'axios';

/**
 * Client HTTP khusus kiosk / display depan pintu.
 *
 * - Mengirim header `X-Kiosk-Token` (didapat dari POST /door-display/pair).
 * - TIDAK memakai token login user & TIDAK redirect ke /login saat 401:
 *   sebagai gantinya memancarkan event `kiosk-unpaired` agar halaman kiosk
 *   kembali ke layar pairing.
 */
const API_BASE_URL = import.meta.env.VITE_API_URL || '/api/v1';

export const KIOSK_UNPAIRED_EVENT = 'kiosk-unpaired';

const tokenKey = (roomCode: string) => `kiosk_token_${roomCode}`;
const pinKey = (roomCode: string) => `kiosk_has_pin_${roomCode}`;

function safeGet(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

export const kioskSession = {
  getToken(roomCode: string): string | null {
    const t = safeGet(tokenKey(roomCode));
    return t && t !== 'null' && t !== 'undefined' ? t : null;
  },
  setToken(roomCode: string, token: string, hasMasterPin: boolean) {
    try {
      localStorage.setItem(tokenKey(roomCode), token);
      localStorage.setItem(pinKey(roomCode), hasMasterPin ? '1' : '0');
      localStorage.removeItem(`kiosk_paired_${roomCode}`); // flag lama (tanpa token)
    } catch {
      /* storage tidak tersedia */
    }
  },
  clear(roomCode: string) {
    try {
      localStorage.removeItem(tokenKey(roomCode));
      localStorage.removeItem(pinKey(roomCode));
      localStorage.removeItem(`kiosk_paired_${roomCode}`);
    } catch {
      /* abaikan */
    }
  },
  hasMasterPin(roomCode: string): boolean {
    return safeGet(pinKey(roomCode)) === '1';
  },
};

export const kioskClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

kioskClient.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      const roomCode = (error.config?.headers as Record<string, unknown> | undefined)?.['X-Kiosk-Room'];
      window.dispatchEvent(
        new CustomEvent(KIOSK_UNPAIRED_EVENT, { detail: { roomCode: typeof roomCode === 'string' ? roomCode : null } })
      );
    }
    return Promise.reject(error);
  }
);

/** Header untuk request kiosk ruangan tertentu. */
export function kioskHeaders(roomCode: string): Record<string, string> {
  const token = kioskSession.getToken(roomCode);
  const headers: Record<string, string> = { 'X-Kiosk-Room': roomCode };
  if (token) headers['X-Kiosk-Token'] = token;
  return headers;
}

/** Ambil pesan error dari respons FastAPI (`detail` string / {message}). */
export function apiErrorMessage(err: unknown, fallback: string): string {
  const data = (err as { response?: { data?: any } })?.response?.data;
  const detail = data?.detail;
  if (typeof detail === 'string' && detail) return detail;
  if (detail && typeof detail === 'object') {
    if (typeof detail.message === 'string' && detail.message) return detail.message;
    if (Array.isArray(detail) && detail[0]?.msg) return String(detail[0].msg);
  }
  if (typeof data?.message === 'string' && data.message) return data.message;
  return fallback;
}
