import axios from 'axios';
import apiClient, { API_BASE_URL, downloadFile } from './client';
import { kioskClient, kioskHeaders, kioskSession } from './kiosk';
// Live meeting & denah kursi
import type {
  LiveMeetingSnapshot,
  RoomSeatInput,
  RoomSeatMap,
  SeatAssignmentInput,
  SeatAssignmentsResponse,
  SeatGenerateRequest,
  SeatLayoutShape,
} from '@shared/types';
import {
  LoginRequest,
  LoginResponse,
  MenuItem,
  UserResponse,
  UserCreate,
  UserUpdate,
  PaginatedUsersResponse,
  Department,
  DepartmentCreate,
  DepartmentUpdate,
  Role,
  RoleCreate,
  RoleUpdate,
  SyncRolePermissionsRequest,
  Permission,
  Building,
  BuildingCreate,
  BuildingUpdate,
  Room,
  RoomCreate,
  RoomUpdate,
  Booking,
  BookingCreate,
  BookingUpdate,
  BookingParticipant,
  BookingParticipantPayload,
  DoorDisplayRoomStatus,
  CalendarEvent,
  DayAgendaItem,
  Equipment,
  EquipmentCreate,
  EquipmentUpdate,
  PaginatedEquipmentResponse,
  Device,
  DeviceCreate,
  DeviceUpdate,
  DeviceHealthSummary,
  PaginatedDevicesResponse,
  VideowallConfig,
  VideowallConfigCreate,
  VideowallConfigUpdate,
  AudioZone,
  AudioZoneCreate,
  AudioZoneUpdate,
  AudioZoneCommandResult,
  AudioZoneSource,
  AudioChannel,
  AudioChannelInput,
  MicrophonesResponse,
  AvCommandResult,
  DeviceCommandAction,
  RoomAvCapabilities,
  RoomAvState,
  MeetingNote,
  MeetingNoteCreate,
  MeetingNoteUpdate,
  PaginatedNotesResponse,
  Notification,
  NotificationCreate,
  PaginatedNotificationsResponse,
  DashboardSummary,
  BookingsReport,
  RoomUtilizationItem,
  EquipmentInventoryReport,
  SystemSetting,
  BatchSettingsUpdate,
  AuditLog,
  AuditStatsSummary,
  PaginatedAuditLogsResponse,
  SystemHealth,
  MigrationsList,
  MigrationsRunResult,
  BackupResponse,
  RestoreResponse,
  CacheClearResult,
  SeedDemoResult,
  ActionItem,
  RecordingStatusResponse,
  SummaryResponse,
  SummarizeTriggerResponse,
  DoorAvailableSlotsResponse,
  QuickBookingRequest,
  QuickBookingResponse,
  DoorCancelBookingResponse,
  WelcomeMessageResponse,
  TicketItem,
  MyTicketsResponse,
  PresensiScanRequest,
  PresensiScanResponse,
  BookingAttendanceResponse,
  LicenseStatus,
  PairingKeyResponse,
  MasterPinResponse,
  KioskPairResult,
  EarlyReleaseResult,
} from '@shared/types';

interface ApiWrapper<T> {
  success: boolean;
  data: T;
}

// --- Notulensi: tipe tambahan & helper unduhan terautentikasi ---
import type {
  NoteSegment,
  NoteSegmentsResponse,
  NoteSegmentUpdate,
  SttStatus,
  LlmStatus,
  RecordingSource,
} from '@shared/types';

export type NoteExportFormat = 'pdf' | 'docx' | 'txt' | 'html';

export interface TranscribeUploadResponse {
  queued: boolean;
  job_id: string;
  recording_id?: string | null;
  size_bytes?: number;
  queue_size?: number;
  message?: string;
}

export interface ChunkUploadResponse {
  queued?: boolean;
  duplicate?: boolean;
  job_id?: string;
  recording_id?: string;
  queue_size?: number;
}

/** Ringkasan AI di CPU bisa beberapa menit. */
const NOTES_SUMMARY_TIMEOUT_MS = 15 * 60 * 1000;

/** Unduh file dari endpoint API ber-JWT (window.open tidak membawa header Authorization). */
export async function downloadNoteFile(path: string, fallbackName: string, params?: Record<string, unknown>): Promise<void> {
  await downloadFile(path, params, fallbackName);
}

type RawParticipant = Partial<BookingParticipant> & Record<string, unknown>;

/**
 * Normalisasi peserta dari backend (`user_name`/`guest_name`/`guest_email`/`is_guest`)
 * ke bentuk UI (`name`/`email`/`is_external`). Aman dipanggil berulang.
 */
export function normalizeParticipant(p: RawParticipant): BookingParticipant {
  const isGuest = Boolean(p.is_guest ?? p.is_external ?? (!p.user_id && (p.guest_name || p.guest_email)));
  const name =
    (typeof p.name === 'string' && p.name) ||
    (p.user_name as string | undefined) ||
    (p.guest_name as string | undefined) ||
    (typeof p.email === 'string' && p.email) ||
    (p.guest_email as string | undefined) ||
    'Peserta';
  const email = (typeof p.email === 'string' && p.email) || (p.guest_email as string | undefined) || '';
  return {
    ...p,
    id: p.id as string | undefined,
    user_id: (p.user_id as string | null | undefined) ?? null,
    name,
    email,
    is_guest: isGuest,
    is_external: isGuest,
  };
}

/** Normalisasi booking: pastikan `participants` berbentuk ternormalisasi. */
export function normalizeBooking<T extends Partial<Booking>>(b: T): T {
  if (!b || !Array.isArray(b.participants)) return b;
  return { ...b, participants: b.participants.map((p) => normalizeParticipant(p as RawParticipant)) };
}

/** Ubah peserta UI ke payload backend (BookingParticipantCreate). */
export function toParticipantPayload(p: Partial<BookingParticipant>): BookingParticipantPayload {
  const isGuest = Boolean(p.is_guest ?? p.is_external ?? !p.user_id);
  if (!isGuest && p.user_id) {
    return { user_id: p.user_id, is_guest: false };
  }
  return {
    user_id: null,
    guest_name: (p.guest_name ?? p.name ?? '').trim() || null,
    guest_email: (p.guest_email ?? p.email ?? '').trim() || null,
    is_guest: true,
  };
}

/** Backend tidak mengirim `date`; turunkan dari `start` (YYYY-MM-DDTHH:MM:SS, waktu lokal server). */
function normalizeCalendarEvent(e: CalendarEvent): CalendarEvent {
  return { ...e, date: e.date ?? String(e.start ?? '').slice(0, 10) };
}

/** Backend: `amenities` & `status` (available/maintenance/disabled); UI: `facilities` & `is_active`. */
export function normalizeRoom(r: Room): Room {
  if (!r) return r;
  const amenities = r.facilities ?? r.amenities ?? [];
  const status = (r.status ?? 'available') as Room['status'];
  return {
    ...r,
    facilities: amenities,
    amenities,
    status,
    is_active: r.is_active ?? String(status).toLowerCase() !== 'disabled',
  };
}

function toRoomPayload(data: RoomCreate | RoomUpdate): Record<string, unknown> {
  const { facilities, is_active, ...rest } = data;
  const body: Record<string, unknown> = { ...rest };
  if (facilities !== undefined) body.amenities = facilities;
  if (body.status === undefined && is_active !== undefined) body.status = is_active ? 'available' : 'disabled';
  if (body.building_id === '') body.building_id = null;
  return body;
}

/** Backend memakai `location_id` untuk ruangan perangkat; UI memakai `room_id`. */
function normalizeEquipment(e: Equipment): Equipment {
  if (!e) return e;
  return { ...e, room_id: e.room_id ?? e.location_id ?? null };
}

function toEquipmentPayload(data: EquipmentCreate | EquipmentUpdate): Record<string, unknown> {
  const { room_id, ...rest } = data;
  const body: Record<string, unknown> = { ...rest };
  if (room_id !== undefined) body.location_id = room_id || null;
  return body;
}

/** Bentuk body booking sesuai schema backend (attendees + participants). */
function toBookingPayload(data: BookingCreate | BookingUpdate): Record<string, unknown> {
  const { participant_count, participants, ...rest } = data;
  const body: Record<string, unknown> = { ...rest };
  if (participant_count !== undefined) body.attendees = Math.max(1, Number(participant_count) || 1);
  if (participants !== undefined) {
    body.participants = (participants ?? []).map((p) => toParticipantPayload(p));
  }
  return body;
}

export const authApi = {
  async login(credentials: LoginRequest): Promise<LoginResponse> {
    const response = await apiClient.post<LoginResponse>('/auth/login', credentials);
    return response.data;
  },

  async logout(): Promise<void> {
    await apiClient.post('/auth/logout');
  },

  async refreshToken(refreshToken: string): Promise<{ access_token: string; refresh_token: string }> {
    const response = await apiClient.post<{ access_token: string; refresh_token: string }>(
      '/auth/refresh',
      { refresh_token: refreshToken }
    );
    return response.data;
  },

  async getSession(): Promise<LoginResponse['user']> {
    const response = await apiClient.get<LoginResponse['user']>('/auth/session');
    return response.data;
  },

  async getMenu(): Promise<MenuItem[]> {
    const response = await apiClient.get<{ menu: MenuItem[] }>('/auth/menu');
    return response.data.menu;
  },

  /** Ganti password; backend mencabut token lama dan mengembalikan token baru. */
  async changePassword(
    oldPassword: string,
    newPassword: string
  ): Promise<{ access_token: string; refresh_token: string }> {
    const response = await apiClient.post<
      ApiWrapper<{ access_token: string; refresh_token: string }> & { message?: string }
    >('/auth/change-password', {
      old_password: oldPassword,
      new_password: newPassword,
    });
    return response.data.data;
  },

  async forgotPassword(email: string): Promise<{ message: string }> {
    const response = await apiClient.post<{ message: string }>('/auth/forgot-password', { email });
    return response.data;
  },

  /** Reset password memakai token dari link email (publik). */
  async resetPasswordWithToken(token: string, newPassword: string): Promise<{ message: string }> {
    const response = await apiClient.post<{ message: string }>('/auth/reset-password', {
      token,
      new_password: newPassword,
    });
    return response.data;
  },

  async listUsers(params?: {
    search?: string;
    role_id?: string;
    department_id?: string;
    is_active?: boolean;
    page?: number;
    per_page?: number;
  }): Promise<PaginatedUsersResponse> {
    const response = await apiClient.get<ApiWrapper<PaginatedUsersResponse>>('/users', { params });
    return response.data.data;
  },

  /** Profil user yang sedang login (GET /users/me). */
  async getMe(): Promise<UserResponse> {
    const response = await apiClient.get<ApiWrapper<UserResponse>>('/users/me');
    return response.data.data;
  },

  /** Ubah profil sendiri (PUT /users/me) — tidak butuh izin users.edit. */
  async updateMe(data: {
    name?: string;
    email?: string;
    phone?: string | null;
    avatar_url?: string | null;
  }): Promise<UserResponse> {
    const response = await apiClient.put<ApiWrapper<UserResponse>>('/users/me', data);
    return response.data.data;
  },

  async createUser(data: UserCreate): Promise<UserResponse> {
    const response = await apiClient.post<ApiWrapper<UserResponse>>('/users', data);
    return response.data.data;
  },

  async updateUser(userId: string, data: UserUpdate): Promise<UserResponse> {
    const response = await apiClient.put<ApiWrapper<UserResponse>>(`/users/${userId}`, data);
    return response.data.data;
  },

  async deleteUser(userId: string): Promise<{ message: string }> {
    const response = await apiClient.delete<ApiWrapper<{ message: string }>>(`/users/${userId}`);
    return response.data.data;
  },

  async resetPassword(userId: string, newPassword: string): Promise<{ message: string }> {
    const response = await apiClient.put<ApiWrapper<{ message: string }>>(
      `/users/${userId}/password`,
      { new_password: newPassword }
    );
    return response.data.data;
  },

  async listDepartments(): Promise<Department[]> {
    const response = await apiClient.get<ApiWrapper<Department[]>>('/users/departments');
    return response.data.data;
  },

  async createDepartment(data: DepartmentCreate): Promise<Department> {
    const response = await apiClient.post<ApiWrapper<Department>>('/users/departments', data);
    return response.data.data;
  },

  async updateDepartment(deptId: string, data: DepartmentUpdate): Promise<Department> {
    const response = await apiClient.put<ApiWrapper<Department>>(
      `/users/departments/${deptId}`,
      data
    );
    return response.data.data;
  },

  async deleteDepartment(deptId: string): Promise<{ message: string }> {
    const response = await apiClient.delete<ApiWrapper<{ message: string }>>(
      `/users/departments/${deptId}`
    );
    return response.data.data;
  },

  // === Roles & Permissions ===
  async listRoles(params?: { page?: number; per_page?: number }): Promise<{
    items: Role[];
    total: number;
    page: number;
    per_page: number;
    total_pages: number;
  }> {
    const response = await apiClient.get<
      ApiWrapper<{ items: Role[]; total: number; page: number; per_page: number; total_pages: number }>
    >('/roles', { params });
    return response.data.data;
  },

  async createRole(data: RoleCreate): Promise<Role> {
    const response = await apiClient.post<ApiWrapper<Role>>('/roles', data);
    return response.data.data;
  },

  async updateRole(roleId: string, data: RoleUpdate): Promise<Role> {
    const response = await apiClient.put<ApiWrapper<Role>>(`/roles/${roleId}`, data);
    return response.data.data;
  },

  async deleteRole(roleId: string): Promise<{ message: string }> {
    const response = await apiClient.delete<ApiWrapper<{ message: string }>>(`/roles/${roleId}`);
    return response.data.data;
  },

  async syncRolePermissions(roleId: string, data: SyncRolePermissionsRequest): Promise<Role> {
    const response = await apiClient.post<ApiWrapper<Role>>(
      `/roles/${roleId}/permissions`,
      data
    );
    return response.data.data;
  },

  async listPermissions(): Promise<Permission[]> {
    const response = await apiClient.get<ApiWrapper<Permission[]>>('/roles/permissions');
    return response.data.data;
  },

  // === Buildings ===
  async listBuildings(params?: { search?: string }): Promise<Building[]> {
    const response = await apiClient.get<ApiWrapper<Building[]>>('/buildings', { params });
    return response.data.data;
  },

  async createBuilding(data: BuildingCreate): Promise<Building> {
    const response = await apiClient.post<ApiWrapper<Building>>('/buildings', data);
    return response.data.data;
  },

  async updateBuilding(buildingId: string, data: BuildingUpdate): Promise<Building> {
    const response = await apiClient.put<ApiWrapper<Building>>(
      `/buildings/${buildingId}`,
      data
    );
    return response.data.data;
  },

  async deleteBuilding(buildingId: string): Promise<{ message: string }> {
    const response = await apiClient.delete<ApiWrapper<{ message: string }>>(
      `/buildings/${buildingId}`
    );
    return response.data.data;
  },

  // === Rooms ===
  async listRooms(params?: {
    search?: string;
    building_id?: string;
    room_type?: string;
    status?: string;
    capacity_min?: number;
    page?: number;
    per_page?: number;
  }): Promise<{
    items: Room[];
    total: number;
    page: number;
    per_page: number;
    total_pages: number;
  }> {
    const response = await apiClient.get<
      ApiWrapper<{ items: Room[]; total: number; page: number; per_page: number; total_pages: number }>
    >('/rooms', { params });
    const data = response.data.data;
    return { ...data, items: (data?.items ?? []).map(normalizeRoom) };
  },

  async getRoom(roomId: string): Promise<Room> {
    const response = await apiClient.get<ApiWrapper<Room>>(`/rooms/${encodeURIComponent(roomId)}`);
    return normalizeRoom(response.data.data);
  },

  /** Cari ruangan berdasarkan kode (GET /rooms/by-code/{code}); null bila tidak ada. */
  async findRoomByCode(code: string): Promise<Room | null> {
    try {
      const response = await apiClient.get<ApiWrapper<Room>>(
        `/rooms/by-code/${encodeURIComponent(code.trim())}`
      );
      return normalizeRoom(response.data.data);
    } catch (err) {
      if (axios.isAxiosError(err) && err.response?.status === 404) return null;
      throw err;
    }
  },

  /** Pairing key kiosk (GET /rooms/{id}/pairing-key; butuh rooms.write / door_display.manage). */
  async getRoomPairingKey(roomId: string): Promise<PairingKeyResponse> {
    const response = await apiClient.get<ApiWrapper<PairingKeyResponse>>(
      `/rooms/${encodeURIComponent(roomId)}/pairing-key`
    );
    return response.data.data;
  },

  async createRoom(data: RoomCreate): Promise<Room> {
    const response = await apiClient.post<ApiWrapper<Room>>('/rooms', toRoomPayload(data));
    return normalizeRoom(response.data.data);
  },

  async updateRoom(roomId: string, data: RoomUpdate): Promise<Room> {
    const response = await apiClient.put<ApiWrapper<Room>>(`/rooms/${roomId}`, toRoomPayload(data));
    return normalizeRoom(response.data.data);
  },

  async deleteRoom(roomId: string): Promise<{ message: string }> {
    const response = await apiClient.delete<ApiWrapper<{ message: string }>>(`/rooms/${roomId}`);
    return response.data.data;
  },

  // === Bookings ===
  async listBookings(params?: {
    room_id?: string;
    user_id?: string;
    status?: string;
    date_from?: string;
    date_to?: string;
    page?: number;
    per_page?: number;
  }): Promise<{
    items: Booking[];
    total: number;
    page: number;
    per_page: number;
    total_pages: number;
  }> {
    const response = await apiClient.get<
      ApiWrapper<{ items: Booking[]; total: number; page: number; per_page: number; total_pages: number }>
    >('/bookings', { params });
    const data = response.data.data;
    return { ...data, items: (data?.items ?? []).map(normalizeBooking) };
  },

  async getBooking(bookingId: string): Promise<Booking> {
    const response = await apiClient.get<ApiWrapper<Booking>>(`/bookings/${encodeURIComponent(bookingId)}`);
    return normalizeBooking(response.data.data);
  },

  async upcomingBookings(params?: { limit?: number }): Promise<Booking[]> {
    const response = await apiClient.get<ApiWrapper<Booking[]>>('/bookings/upcoming', {
      params,
    });
    return (response.data.data ?? []).map(normalizeBooking);
  },

  async createBooking(data: BookingCreate): Promise<Booking> {
    const response = await apiClient.post<ApiWrapper<Booking>>('/bookings', toBookingPayload(data));
    return normalizeBooking(response.data.data);
  },

  async updateBooking(bookingId: string, data: BookingUpdate): Promise<Booking> {
    const response = await apiClient.put<ApiWrapper<Booking>>(`/bookings/${bookingId}`, toBookingPayload(data));
    return normalizeBooking(response.data.data);
  },

  async deleteBooking(bookingId: string): Promise<{ message: string }> {
    const response = await apiClient.delete<ApiWrapper<{ message: string }>>(
      `/bookings/${bookingId}`
    );
    return response.data.data;
  },

  async approveBooking(bookingId: string): Promise<Booking> {
    const response = await apiClient.put<ApiWrapper<Booking>>(`/bookings/${bookingId}/approve`);
    return response.data.data;
  },

  async rejectBooking(bookingId: string): Promise<Booking> {
    const response = await apiClient.put<ApiWrapper<Booking>>(`/bookings/${bookingId}/reject`);
    return response.data.data;
  },

  async cancelBooking(bookingId: string): Promise<Booking> {
    const response = await apiClient.put<ApiWrapper<Booking>>(`/bookings/${bookingId}/cancel`);
    return response.data.data;
  },

  // === Calendar ===
  async getCalendarEvents(params?: {
    start_date?: string;
    end_date?: string;
    room_id?: string;
  }): Promise<CalendarEvent[]> {
    const response = await apiClient.get<ApiWrapper<CalendarEvent[]>>('/calendar', {
      params: { start: params?.start_date, end: params?.end_date, room_id: params?.room_id },
    });
    return (response.data.data ?? []).map(normalizeCalendarEvent);
  },

  async getRoomCalendar(roomId: string, params?: { date?: string }): Promise<CalendarEvent[]> {
    const month = (params?.date ?? '').slice(0, 7);
    const response = await apiClient.get<ApiWrapper<{ events: CalendarEvent[] }>>(
      `/calendar/rooms/${roomId}`,
      { params: { month } }
    );
    return (response.data.data?.events ?? []).map(normalizeCalendarEvent);
  },

  async getDayAgenda(date: string): Promise<DayAgendaItem[]> {
    const response = await apiClient.get<
      ApiWrapper<{ rooms: Array<{ room_id: string; room_name: string; bookings: DayAgendaItem[] }> }>
    >('/calendar/day', { params: { date } });
    const agenda = response.data.data;
    return (agenda?.rooms ?? []).flatMap((room) =>
      (room.bookings ?? []).map((b) => ({ ...b, room_id: room.room_id, room_name: room.room_name }))
    );
  },

  // === Equipment (Perangkat AV) ===
  async listEquipment(params?: {
    search?: string;
    category?: string;
    status?: string;
    room_id?: string;
    page?: number;
    per_page?: number;
  }): Promise<PaginatedEquipmentResponse> {
    const response = await apiClient.get<ApiWrapper<PaginatedEquipmentResponse>>('/equipment', { params });
    const data = response.data.data;
    return { ...data, items: (data?.items ?? []).map(normalizeEquipment) };
  },

  async createEquipment(data: EquipmentCreate): Promise<Equipment> {
    const response = await apiClient.post<ApiWrapper<Equipment>>('/equipment', toEquipmentPayload(data));
    return normalizeEquipment(response.data.data);
  },

  async updateEquipment(equipmentId: string, data: EquipmentUpdate): Promise<Equipment> {
    const response = await apiClient.put<ApiWrapper<Equipment>>(`/equipment/${equipmentId}`, toEquipmentPayload(data));
    return normalizeEquipment(response.data.data);
  },

  async deleteEquipment(equipmentId: string): Promise<{ message: string }> {
    const response = await apiClient.delete<ApiWrapper<{ message: string }>>(`/equipment/${equipmentId}`);
    return response.data.data;
  },

  async assignEquipmentRoom(equipmentId: string, roomId: string | null): Promise<Equipment> {
    const response = await apiClient.put<ApiWrapper<Equipment>>(`/equipment/${equipmentId}/assign`, { location_id: roomId });
    return normalizeEquipment(response.data.data);
  },

  // === Devices (IoT Devices) ===
  async listDevices(params?: {
    search?: string;
    device_type?: string;
    status?: string;
    room_id?: string;
    page?: number;
    per_page?: number;
  }): Promise<PaginatedDevicesResponse> {
    const response = await apiClient.get<ApiWrapper<PaginatedDevicesResponse>>('/devices', { params });
    return response.data.data;
  },

  async getDevice(deviceId: string): Promise<Device> {
    const response = await apiClient.get<ApiWrapper<Device>>(`/devices/${deviceId}`);
    return response.data.data;
  },

  async createDevice(data: DeviceCreate): Promise<Device> {
    const response = await apiClient.post<ApiWrapper<Device>>('/devices', data);
    return response.data.data;
  },

  async updateDevice(deviceId: string, data: DeviceUpdate): Promise<Device> {
    const response = await apiClient.put<ApiWrapper<Device>>(`/devices/${deviceId}`, data);
    return response.data.data;
  },

  async deleteDevice(deviceId: string): Promise<{ message: string }> {
    const response = await apiClient.delete<ApiWrapper<{ message: string }>>(`/devices/${deviceId}`);
    return response.data.data;
  },

  async getDeviceHealth(): Promise<DeviceHealthSummary> {
    const response = await apiClient.get<ApiWrapper<DeviceHealthSummary>>('/devices/health/summary');
    return response.data.data;
  },

  /** Perintah ke perangkat lewat agent; cek `status` (acked/failed/timeout). */
  async deviceCommand(deviceId: string, action: DeviceCommandAction): Promise<AvCommandResult> {
    const response = await apiClient.post<ApiWrapper<AvCommandResult>>(`/devices/${deviceId}/${action}`);
    return response.data.data;
  },

  // === Kontrol AV per ruangan (/rooms/{id}/av/*) ===
  async getRoomAvCapabilities(roomId: string): Promise<RoomAvCapabilities> {
    const response = await apiClient.get<ApiWrapper<RoomAvCapabilities>>(`/rooms/${roomId}/av/capabilities`);
    return response.data.data;
  },

  async getRoomAvState(roomId: string): Promise<RoomAvState> {
    const response = await apiClient.get<ApiWrapper<RoomAvState>>(`/rooms/${roomId}/av/state`);
    return response.data.data;
  },

  async avVideowallPower(roomId: string, on: boolean): Promise<AvCommandResult> {
    const response = await apiClient.post<ApiWrapper<AvCommandResult>>(
      `/rooms/${roomId}/av/videowall/${on ? 'power-on' : 'power-off'}`,
    );
    return response.data.data;
  },

  async avVideowallLayout(roomId: string, preset: string): Promise<AvCommandResult> {
    const response = await apiClient.post<ApiWrapper<AvCommandResult>>(`/rooms/${roomId}/av/videowall/layout`, { preset });
    return response.data.data;
  },

  async avVideowallSource(roomId: string, source: string, window = 1): Promise<AvCommandResult> {
    const response = await apiClient.post<ApiWrapper<AvCommandResult>>(`/rooms/${roomId}/av/videowall/source`, { source, window });
    return response.data.data;
  },

  async avMicMute(roomId: string, channelNo: number, mute: boolean): Promise<AvCommandResult> {
    const response = await apiClient.post<ApiWrapper<AvCommandResult>>(
      `/rooms/${roomId}/av/audio/mic/${channelNo}/${mute ? 'mute' : 'unmute'}`,
    );
    return response.data.data;
  },

  async avMuteAll(roomId: string, mute: boolean): Promise<AvCommandResult> {
    const response = await apiClient.post<ApiWrapper<AvCommandResult>>(
      `/rooms/${roomId}/av/audio/${mute ? 'mute-all' : 'unmute-all'}`,
    );
    return response.data.data;
  },

  /** target: nomor kanal (channel_no) atau 'main'; value 0..1 */
  async avFader(roomId: string, target: number | 'main', value: number): Promise<AvCommandResult> {
    const response = await apiClient.post<ApiWrapper<AvCommandResult>>(`/rooms/${roomId}/av/audio/fader`, { target, value });
    return response.data.data;
  },

  async avGain(roomId: string, channelNo: number, db: number): Promise<AvCommandResult> {
    const response = await apiClient.post<ApiWrapper<AvCommandResult>>(`/rooms/${roomId}/av/audio/gain`, { channel_no: channelNo, db });
    return response.data.data;
  },

  async listAudioChannels(roomId: string): Promise<AudioChannel[]> {
    const response = await apiClient.get<ApiWrapper<AudioChannel[]>>(`/rooms/${roomId}/audio-channels`);
    return response.data.data;
  },

  /** Ganti seluruh kanal mic ruangan (batch). */
  async saveAudioChannels(roomId: string, channels: AudioChannelInput[]): Promise<AudioChannel[]> {
    const response = await apiClient.put<ApiWrapper<AudioChannel[]>>(`/rooms/${roomId}/audio-channels`, { channels });
    return response.data.data;
  },

  // === Videowall (konfigurasi tersimpan) ===
  async listVideowallConfigs(params?: { room_id?: string }): Promise<VideowallConfig[]> {
    const response = await apiClient.get<ApiWrapper<VideowallConfig[]>>('/videowall', { params });
    return response.data.data;
  },

  async createVideowallConfig(data: VideowallConfigCreate): Promise<VideowallConfig> {
    const response = await apiClient.post<ApiWrapper<VideowallConfig>>('/videowall', data);
    return response.data.data;
  },

  async updateVideowallConfig(configId: string, data: VideowallConfigUpdate): Promise<VideowallConfig> {
    const response = await apiClient.put<ApiWrapper<VideowallConfig>>(`/videowall/${configId}`, data);
    return response.data.data;
  },

  async deleteVideowallConfig(configId: string): Promise<{ message: string }> {
    const response = await apiClient.delete<ApiWrapper<{ message: string }>>(`/videowall/${configId}`);
    return response.data.data;
  },

  /** Terapkan preset + sumber per jendela dari konfigurasi tersimpan. */
  async applyVideowallConfig(configId: string): Promise<AvCommandResult> {
    const response = await apiClient.post<ApiWrapper<AvCommandResult>>(`/videowall/${configId}/apply`);
    return response.data.data;
  },

  // === Audio (zona speaker & daftar mic) ===
  async listAudioZones(params?: { room_id?: string }): Promise<AudioZone[]> {
    const response = await apiClient.get<ApiWrapper<AudioZone[]>>('/audio/zones', { params });
    return response.data.data;
  },

  async createAudioZone(data: AudioZoneCreate): Promise<AudioZone> {
    const response = await apiClient.post<ApiWrapper<AudioZone>>('/audio/zones', data);
    return response.data.data;
  },

  async updateAudioZone(zoneId: string, data: AudioZoneUpdate): Promise<AudioZone> {
    const response = await apiClient.put<ApiWrapper<AudioZone>>(`/audio/zones/${zoneId}`, data);
    return response.data.data;
  },

  async deleteAudioZone(zoneId: string): Promise<{ message: string }> {
    const response = await apiClient.delete<ApiWrapper<{ message: string }>>(`/audio/zones/${zoneId}`);
    return response.data.data;
  },

  async setZoneVolume(zoneId: string, volume: number): Promise<AudioZoneCommandResult> {
    const response = await apiClient.put<ApiWrapper<AudioZoneCommandResult>>(
      `/audio/zones/${zoneId}/volume`, {}, { params: { value: volume } },
    );
    return response.data.data;
  },

  async setZoneMute(zoneId: string, mute: boolean): Promise<AudioZoneCommandResult> {
    const response = await apiClient.put<ApiWrapper<AudioZoneCommandResult>>(
      `/audio/zones/${zoneId}/${mute ? 'mute' : 'unmute'}`,
    );
    return response.data.data;
  },

  async setZoneSource(zoneId: string, source: AudioZoneSource): Promise<AudioZoneCommandResult> {
    const response = await apiClient.put<ApiWrapper<AudioZoneCommandResult>>(
      `/audio/zones/${zoneId}/source`, {}, { params: { input: source } },
    );
    return response.data.data;
  },

  async listMicrophones(roomId: string): Promise<MicrophonesResponse> {
    const response = await apiClient.get<ApiWrapper<MicrophonesResponse>>('/audio/microphones', { params: { room_id: roomId } });
    return response.data.data;
  },

  // === Notes (Notulensi) ===
  async listNotes(params?: {
    search?: string;
    room_id?: string;
    booking_id?: string;
    status?: 'draft' | 'final';
    date_from?: string;
    date_to?: string;
    page?: number;
    per_page?: number;
  }): Promise<PaginatedNotesResponse> {
    const response = await apiClient.get<ApiWrapper<PaginatedNotesResponse>>('/notes', { params });
    return response.data.data;
  },

  async createNote(data: MeetingNoteCreate): Promise<MeetingNote> {
    const response = await apiClient.post<ApiWrapper<MeetingNote>>('/notes', data);
    return response.data.data;
  },

  async updateNote(noteId: string, data: MeetingNoteUpdate): Promise<MeetingNote> {
    const response = await apiClient.put<ApiWrapper<MeetingNote>>(`/notes/${encodeURIComponent(noteId)}`, data);
    return response.data.data;
  },

  async deleteNote(noteId: string): Promise<{ message: string }> {
    const response = await apiClient.delete<ApiWrapper<{ message: string }>>(`/notes/${encodeURIComponent(noteId)}`);
    return response.data.data;
  },

  async getNoteDetail(noteId: string): Promise<MeetingNote> {
    const response = await apiClient.get<ApiWrapper<MeetingNote>>(`/notes/${encodeURIComponent(noteId)}`);
    return response.data.data;
  },

  /** Ringkas transkrip dengan LLM lokal (Ollama). Sinkron; bisa beberapa menit. */
  async summarizeNote(noteId: string): Promise<MeetingNote> {
    const response = await apiClient.post<ApiWrapper<MeetingNote>>(
      `/notes/${encodeURIComponent(noteId)}/summarize`, undefined, { timeout: NOTES_SUMMARY_TIMEOUT_MS },
    );
    return response.data.data;
  },

  /** @deprecated pakai summarizeNote. */
  async regenerateSummary(noteId: string): Promise<MeetingNote> {
    return this.summarizeNote(noteId);
  },

  async finalizeNote(noteId: string): Promise<MeetingNote> {
    const response = await apiClient.post<ApiWrapper<MeetingNote>>(`/notes/${encodeURIComponent(noteId)}/finalize`);
    return response.data.data;
  },

  async reopenNote(noteId: string): Promise<MeetingNote> {
    const response = await apiClient.post<ApiWrapper<MeetingNote>>(`/notes/${encodeURIComponent(noteId)}/reopen`);
    return response.data.data;
  },

  /** Unggah rekaman penuh (field `audio_file`); diproses di latar belakang. */
  async transcribeAudio(noteId: string, formData: FormData): Promise<TranscribeUploadResponse> {
    const response = await apiClient.post<ApiWrapper<TranscribeUploadResponse>>(
      `/notes/${encodeURIComponent(noteId)}/transcribe-audio`, formData,
      { headers: { 'Content-Type': 'multipart/form-data' }, timeout: 30 * 60 * 1000 },
    );
    return response.data.data;
  },

  async listNoteSegments(noteId: string, after?: string | null): Promise<NoteSegmentsResponse> {
    const response = await apiClient.get<ApiWrapper<NoteSegmentsResponse>>(
      `/notes/${encodeURIComponent(noteId)}/segments`, { params: after ? { after } : undefined },
    );
    return response.data.data;
  },

  async addNoteSegment(
    noteId: string,
    data: { text: string; speaker_name?: string; participant_id?: string; start_ms?: number },
  ): Promise<NoteSegment> {
    const response = await apiClient.post<ApiWrapper<NoteSegment>>(`/notes/${encodeURIComponent(noteId)}/segments`, data);
    return response.data.data;
  },

  async updateNoteSegment(noteId: string, segmentId: string, data: NoteSegmentUpdate): Promise<NoteSegment> {
    const response = await apiClient.patch<ApiWrapper<NoteSegment>>(
      `/notes/${encodeURIComponent(noteId)}/segments/${encodeURIComponent(segmentId)}`, data,
    );
    return response.data.data;
  },

  async deleteNoteSegment(noteId: string, segmentId: string): Promise<void> {
    await apiClient.delete(`/notes/${encodeURIComponent(noteId)}/segments/${encodeURIComponent(segmentId)}`);
  },

  async getSttStatus(): Promise<SttStatus> {
    const response = await apiClient.get<ApiWrapper<SttStatus>>('/notes/stt/status');
    return response.data.data;
  },

  async getLlmStatus(): Promise<LlmStatus> {
    const response = await apiClient.get<ApiWrapper<LlmStatus>>('/notes/llm/status');
    return response.data.data;
  },

  // === Module 13: Notifications ===
  async listNotifications(params?: {
    is_read?: boolean;
    page?: number;
    limit?: number;
  }): Promise<PaginatedNotificationsResponse> {
    const response = await apiClient.get<ApiWrapper<PaginatedNotificationsResponse>>('/notifications', { params });
    return response.data.data;
  },

  async getNotification(notificationId: string): Promise<Notification> {
    const response = await apiClient.get<ApiWrapper<Notification>>(`/notifications/${notificationId}`);
    return response.data.data;
  },

  async markRead(notificationId: string): Promise<Notification> {
    const response = await apiClient.put<ApiWrapper<Notification>>(`/notifications/${notificationId}/read`);
    return response.data.data;
  },

  async markAllRead(): Promise<{ marked_read: number }> {
    const response = await apiClient.put<ApiWrapper<{ marked_read: number }>>('/notifications/read-all');
    return response.data.data;
  },

  async deleteNotification(notificationId: string): Promise<{ message: string }> {
    const response = await apiClient.delete<ApiWrapper<{ message: string }>>(`/notifications/${notificationId}`);
    return response.data.data;
  },

  async deleteReadNotifications(): Promise<{ deleted: number }> {
    const response = await apiClient.delete<ApiWrapper<{ deleted: number }>>('/notifications/read');
    return response.data.data;
  },


  /** Kirim ke user tertentu: POST /notifications/send {user_ids, type, title, message, data}. */
  async sendNotificationMany(
    data: Omit<NotificationCreate, 'broadcast'> & { user_ids: string[] }
  ): Promise<{ sent_count: number }> {
    const response = await apiClient.post<ApiWrapper<{ sent_count: number }>>('/notifications/send', data);
    return response.data.data;
  },

  /** Broadcast ke semua user: POST /notifications/broadcast {type, title, message, data}. */
  async broadcastNotification(
    data: Omit<NotificationCreate, 'user_ids' | 'broadcast'>
  ): Promise<{ broadcast_count: number; title: string }> {
    const response = await apiClient.post<ApiWrapper<{ broadcast_count: number; title: string }>>(
      '/notifications/broadcast',
      data
    );
    return response.data.data;
  },

  // === Module 14: Reports & Dashboard ===
  async getDashboardSummary(): Promise<DashboardSummary> {
    const response = await apiClient.get<ApiWrapper<DashboardSummary>>('/reports/dashboard-summary');
    return response.data.data;
  },

  /** GET /reports/bookings — parameter tanggal bernama `from` / `to`. */
  async getBookingsReport(params?: { from?: string; to?: string }): Promise<BookingsReport> {
    const response = await apiClient.get<ApiWrapper<BookingsReport>>('/reports/bookings', {
      params: { ...params, format: 'json' },
    });
    return response.data.data;
  },

  async getRoomsUtilization(params?: {
    from_date?: string;
    to_date?: string;
    room_id?: string;
  }): Promise<RoomUtilizationItem[]> {
    const response = await apiClient.get<ApiWrapper<RoomUtilizationItem[]>>('/reports/rooms-utilization', { params });
    return response.data.data;
  },

  async getEquipmentInventory(): Promise<EquipmentInventoryReport> {
    const response = await apiClient.get<ApiWrapper<EquipmentInventoryReport>>('/reports/equipment-inventory');
    const data = response.data.data as EquipmentInventoryReport | EquipmentInventoryReport['items'];
    // Toleran terhadap bentuk lama (array langsung).
    if (Array.isArray(data)) {
      return { items: data, grand_total: data.reduce((s, e) => s + (e.total || 0), 0) };
    }
    return { items: data?.items ?? [], grand_total: data?.grand_total ?? 0 };
  },

  // === Module 15: System Settings ===
  async getPublicSettings(): Promise<SystemSetting[]> {
    const response = await apiClient.get<ApiWrapper<SystemSetting[]>>('/settings/public');
    return response.data.data;
  },

  async getAllSettings(params?: { group_name?: string }): Promise<SystemSetting[]> {
    const response = await apiClient.get<ApiWrapper<SystemSetting[]>>('/settings', { params });
    return response.data.data;
  },

  async updateSetting(key: string, value: string): Promise<SystemSetting> {
    const response = await apiClient.put<ApiWrapper<SystemSetting>>(`/settings/${key}`, { value });
    return response.data.data;
  },

  /** PUT /settings {settings: {key: value}} */
  async batchUpdateSettings(
    data: BatchSettingsUpdate
  ): Promise<{ updated_keys: string[]; count?: number; updated_count?: number; message?: string }> {
    const response = await apiClient.put<
      ApiWrapper<{ updated_keys: string[]; count?: number; updated_count?: number; message?: string }>
    >('/settings', data);
    return response.data.data;
  },

  async getSettingByKey(key: string): Promise<SystemSetting> {
    const response = await apiClient.get<ApiWrapper<SystemSetting>>(`/settings/${key}`);
    return response.data.data;
  },

  // === Module 17: Audit Logs ===
  async listAuditLogs(params?: {
    user_id?: string;
    module?: string;
    action?: string;
    target_type?: string;
    target_id?: string;
    from_date?: string;
    to_date?: string;
    page?: number;
    per_page?: number;
  }): Promise<PaginatedAuditLogsResponse> {
    const response = await apiClient.get<ApiWrapper<PaginatedAuditLogsResponse>>('/audit/logs', { params });
    return response.data.data;
  },

  async getAuditLogDetail(auditId: string): Promise<AuditLog> {
    const response = await apiClient.get<ApiWrapper<AuditLog>>(`/audit/logs/${auditId}`);
    return response.data.data;
  },

  async createAuditLog(data: Partial<AuditLog>): Promise<AuditLog> {
    const response = await apiClient.post<ApiWrapper<AuditLog>>('/audit/logs', data);
    return response.data.data;
  },

  async getAuditStatsSummary(): Promise<AuditStatsSummary> {
    const response = await apiClient.get<ApiWrapper<AuditStatsSummary>>('/audit/stats/summary');
    return response.data.data;
  },

  // === Module 18: Maintenance & System ===
  async getSystemHealth(): Promise<SystemHealth> {
    const response = await apiClient.get<ApiWrapper<SystemHealth>>('/maintenance/health');
    return response.data.data;
  },

  async runMigrations(): Promise<MigrationsRunResult> {
    const response = await apiClient.post<ApiWrapper<MigrationsRunResult>>('/maintenance/migrations/run');
    return response.data.data;
  },

  async getMigrationsList(): Promise<MigrationsList> {
    const response = await apiClient.get<ApiWrapper<MigrationsList>>('/maintenance/migrations');
    return response.data.data;
  },

  async backupDatabase(): Promise<BackupResponse> {
    const response = await apiClient.post<ApiWrapper<BackupResponse>>('/maintenance/backup');
    return response.data.data;
  },

  async listBackups(): Promise<BackupResponse[]> {
    const response = await apiClient.get<ApiWrapper<BackupResponse[]>>('/maintenance/backups');
    return response.data.data;
  },

  /** FormData wajib berisi `file` dan `confirm` = "RESTORE". */
  async restoreDatabase(formData: FormData): Promise<RestoreResponse> {
    const response = await apiClient.post<ApiWrapper<RestoreResponse>>('/maintenance/restore', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return response.data.data;
  },

  async clearCache(): Promise<CacheClearResult> {
    const response = await apiClient.post<ApiWrapper<CacheClearResult>>('/maintenance/clear-cache');
    return response.data.data;
  },

  async seedDemoData(): Promise<SeedDemoResult> {
    const response = await apiClient.post<ApiWrapper<SeedDemoResult>>('/maintenance/seed-demo');
    return response.data.data;
  },

  // === Door Display (wajib token kiosk hasil pairing) ===
  async getDoorDisplayStatus(roomCode: string): Promise<DoorDisplayRoomStatus> {
    const response = await kioskClient.get<ApiWrapper<DoorDisplayRoomStatus>>(
      `/door-display/status/${encodeURIComponent(roomCode)}`,
      { headers: kioskHeaders(roomCode) }
    );
    return response.data.data;
  },

  // === Module 11: Notulensi - Recording Controls ===
  /** Mulai rekaman (satu rekaman aktif per booking). `source` default multichannel (recorder PC Monitoring). */
  async startRecording(data: {
    booking_id: string;
    source?: Exclude<RecordingSource, 'upload'>;
    room_id?: string;
    title?: string;
    record_audio?: boolean;
    transcribe_live?: boolean;
  }): Promise<RecordingStatusResponse> {
    const response = await apiClient.post<ApiWrapper<RecordingStatusResponse>>(
      `/notes/recording/${encodeURIComponent(data.booking_id)}/start`,
      { source: data.source ?? 'multichannel' },
    );
    return response.data.data;
  },

  async pauseRecording(bookingId: string): Promise<RecordingStatusResponse> {
    const response = await apiClient.post<ApiWrapper<RecordingStatusResponse>>(
      `/notes/recording/${encodeURIComponent(bookingId)}/pause`
    );
    return response.data.data;
  },

  async resumeRecording(bookingId: string): Promise<RecordingStatusResponse> {
    const response = await apiClient.post<ApiWrapper<RecordingStatusResponse>>(
      `/notes/recording/${encodeURIComponent(bookingId)}/resume`
    );
    return response.data.data;
  },

  async stopRecording(bookingId: string): Promise<RecordingStatusResponse> {
    const response = await apiClient.post<ApiWrapper<RecordingStatusResponse>>(
      `/notes/recording/${encodeURIComponent(bookingId)}/stop`
    );
    return response.data.data;
  },

  async getRecordingStatus(bookingId: string): Promise<RecordingStatusResponse> {
    const response = await apiClient.get<ApiWrapper<RecordingStatusResponse>>(
      `/notes/recording/${encodeURIComponent(bookingId)}/status`
    );
    return response.data.data;
  },

  /** Mode browser: kirim potongan audio (webm/ogg) ke antrean STT. */
  async uploadRecordingChunk(bookingId: string, audio: Blob, opts: {
    start_ms?: number;
    duration_ms?: number;
    speaker_name?: string;
    participant_id?: string;
    chunk_uid?: string;
    filename?: string;
  } = {}): Promise<ChunkUploadResponse> {
    const fd = new FormData();
    fd.append('audio', audio, opts.filename ?? 'chunk.webm');
    if (opts.start_ms != null) fd.append('start_ms', String(Math.max(0, Math.round(opts.start_ms))));
    if (opts.duration_ms != null) fd.append('duration_ms', String(Math.max(0, Math.round(opts.duration_ms))));
    if (opts.speaker_name) fd.append('speaker_name', opts.speaker_name);
    if (opts.participant_id) fd.append('participant_id', opts.participant_id);
    if (opts.chunk_uid) fd.append('chunk_uid', opts.chunk_uid);
    const response = await apiClient.post<ApiWrapper<ChunkUploadResponse>>(
      `/notes/recording/${encodeURIComponent(bookingId)}/chunks`, fd,
      { headers: { 'Content-Type': 'multipart/form-data' }, timeout: 60000 },
    );
    return response.data.data;
  },

  // === Module 11: Notulensi - Action Items (per Note ID & per Booking shortcut) ===
  async listNoteActionItems(noteId: string): Promise<ActionItem[]> {
    const response = await apiClient.get<ApiWrapper<ActionItem[]>>(`/notes/${encodeURIComponent(noteId)}/action-items`);
    return response.data.data;
  },

  async addNoteActionItem(noteId: string, item: Partial<ActionItem>): Promise<ActionItem> {
    const response = await apiClient.post<ApiWrapper<ActionItem>>(
      `/notes/${encodeURIComponent(noteId)}/action-items`,
      item
    );
    return response.data.data;
  },

  async updateNoteActionItem(noteId: string, itemId: string, item: Partial<ActionItem>): Promise<ActionItem> {
    const response = await apiClient.patch<ApiWrapper<ActionItem>>(
      `/notes/${encodeURIComponent(noteId)}/action-items/${encodeURIComponent(itemId)}`,
      item
    );
    return response.data.data;
  },

  async deleteNoteActionItem(noteId: string, itemId: string): Promise<void> {
    await apiClient.delete(`/notes/${encodeURIComponent(noteId)}/action-items/${encodeURIComponent(itemId)}`);
  },

  async listBookingActionItems(bookingId: string): Promise<ActionItem[]> {
    const response = await apiClient.get<ApiWrapper<ActionItem[]>>(
      `/notes/meetings/${encodeURIComponent(bookingId)}/action-items`
    );
    return response.data.data;
  },

  async addBookingActionItem(bookingId: string, item: Partial<ActionItem>): Promise<ActionItem> {
    const response = await apiClient.post<ApiWrapper<ActionItem>>(
      `/notes/meetings/${encodeURIComponent(bookingId)}/action-items`,
      item
    );
    return response.data.data;
  },

  // === Module 11: Notulensi - Meeting Note shortcut per Booking ===
  /** Notulen milik booking, atau null bila belum ada. */
  async getNoteByBooking(bookingId: string): Promise<MeetingNote | null> {
    const response = await apiClient.get<ApiWrapper<MeetingNote | null>>(
      `/notes/by-booking/${encodeURIComponent(bookingId)}`
    );
    return response.data.data;
  },

  /** Ambil atau buat notulen untuk booking (judul/waktu/peserta diambil server dari booking). */
  async ensureNoteForBooking(bookingId: string, _data?: Partial<MeetingNoteCreate>): Promise<MeetingNote> {
    const response = await apiClient.post<ApiWrapper<MeetingNote>>(
      `/notes/by-booking/${encodeURIComponent(bookingId)}`
    );
    return response.data.data;
  },

  // === Module 11: Notulensi - AI Summary (alias per booking) ===
  async triggerAISummary(bookingId: string): Promise<SummarizeTriggerResponse> {
    const response = await apiClient.post<ApiWrapper<SummarizeTriggerResponse>>(
      `/notes/meetings/${encodeURIComponent(bookingId)}/summarize`, undefined, { timeout: NOTES_SUMMARY_TIMEOUT_MS },
    );
    return response.data.data;
  },

  async getAISummary(bookingId: string): Promise<SummaryResponse> {
    const response = await apiClient.get<ApiWrapper<SummaryResponse>>(
      `/notes/meetings/${encodeURIComponent(bookingId)}/summary`
    );
    return response.data.data;
  },

  // === Module 11: Notulensi - Export Formats ===
  getExportNoteUrl(noteId: string, format: NoteExportFormat = 'pdf'): string {
    return `${API_BASE_URL}/notes/${encodeURIComponent(noteId)}/export/${encodeURIComponent(format)}`;
  },

  /** Unduh notulen (PDF/DOCX/TXT/HTML) lewat request ber-JWT. */
  async exportNote(noteId: string, format: NoteExportFormat = 'pdf', includeTranscript = false): Promise<void> {
    await downloadNoteFile(
      `/notes/${encodeURIComponent(noteId)}/export/${encodeURIComponent(format)}`,
      `notulensi.${format}`,
      includeTranscript ? { include_transcript: 1 } : undefined,
    );
  },

  // === Module 16: Door Display Interactive (Public) ===
  async getAvailableSlots(
    roomCode: string,
    opts?: { interval_minutes?: number; day_start?: string; day_end?: string }
  ): Promise<DoorAvailableSlotsResponse> {
    const response = await kioskClient.get<ApiWrapper<DoorAvailableSlotsResponse>>(
      `/door-display/${encodeURIComponent(roomCode)}/available-slots`,
      { params: opts || {}, headers: kioskHeaders(roomCode) }
    );
    return response.data.data;
  },

  async quickBookRoom(roomCode: string, req: QuickBookingRequest): Promise<QuickBookingResponse> {
    const response = await kioskClient.post<ApiWrapper<QuickBookingResponse>>(
      `/door-display/${encodeURIComponent(roomCode)}/book`,
      req,
      { headers: kioskHeaders(roomCode) }
    );
    return response.data.data;
  },

  async cancelDoorBooking(roomCode: string, bookingId: string, pin?: string): Promise<DoorCancelBookingResponse> {
    const response = await kioskClient.post<ApiWrapper<DoorCancelBookingResponse>>(
      `/door-display/${encodeURIComponent(roomCode)}/cancel/${encodeURIComponent(bookingId)}`,
      { pin: pin || null },
      { headers: kioskHeaders(roomCode) }
    );
    return response.data.data;
  },

  async getWelcomeMessage(roomCode: string): Promise<WelcomeMessageResponse> {
    const response = await kioskClient.get<ApiWrapper<WelcomeMessageResponse>>(
      `/door-display/${encodeURIComponent(roomCode)}/welcome-message`,
      { headers: kioskHeaders(roomCode) }
    );
    return response.data.data;
  },

  async updateWelcomeMessage(
    roomCode: string,
    data: Partial<WelcomeMessageResponse>
  ): Promise<WelcomeMessageResponse> {
    const response = await apiClient.put<ApiWrapper<WelcomeMessageResponse>>(
      `/door-display/${encodeURIComponent(roomCode)}/welcome-message`,
      data
    );
    return response.data.data;
  },

  async extendDoorBooking(
    bookingId: string,
    minutes: number = 15,
    roomCode?: string,
    pin?: string
  ): Promise<{ success: boolean; message: string; new_end_time?: string; booking_id?: string }> {
    const response = await kioskClient.post<ApiWrapper<{ success: boolean; message: string; new_end_time?: string; booking_id?: string }>>(
      `/door-display/extend/${encodeURIComponent(bookingId)}?minutes=${minutes}`,
      { pin: pin || null },
      { headers: roomCode ? kioskHeaders(roomCode) : {} }
    );
    return response.data.data;
  },

  // === Presensi QR (Tiket Peserta + Scanner Kiosk) ===
  async getMyTickets(params?: { include_past?: boolean }): Promise<MyTicketsResponse> {
    const response = await apiClient.get<ApiWrapper<MyTicketsResponse>>('/presensi/tickets/my', {
      params,
    });
    return response.data.data;
  },

  async getTicketDetail(participantId: string): Promise<TicketItem> {
    const response = await apiClient.get<ApiWrapper<TicketItem>>(
      `/presensi/tickets/${encodeURIComponent(participantId)}`
    );
    return response.data.data;
  },

  /** `kioskRoomCode` diisi bila dipanggil dari kiosk (pakai token kiosk, bukan login). */
  async scanTicket(payload: PresensiScanRequest, kioskRoomCode?: string): Promise<PresensiScanResponse> {
    const response = kioskRoomCode
      ? await kioskClient.post<ApiWrapper<PresensiScanResponse>>('/presensi/scan', payload, {
          headers: kioskHeaders(kioskRoomCode),
        })
      : await apiClient.post<ApiWrapper<PresensiScanResponse>>('/presensi/scan', payload);
    return response.data.data;
  },

  async getBookingAttendance(bookingId: string, kioskRoomCode?: string): Promise<BookingAttendanceResponse> {
    const url = `/presensi/bookings/${encodeURIComponent(bookingId)}/attendance`;
    const response = kioskRoomCode
      ? await kioskClient.get<ApiWrapper<BookingAttendanceResponse>>(url, { headers: kioskHeaders(kioskRoomCode) })
      : await apiClient.get<ApiWrapper<BookingAttendanceResponse>>(url);
    return response.data.data;
  },

  // === Lisensi (Gating Aplikasi) ===
  async getLicenseStatus(): Promise<LicenseStatus> {
    const response = await apiClient.get<LicenseStatus>('/license/status');
    return response.data;
  },

  async getLicenseFingerprint(): Promise<{ fingerprint: string; license_file: string }> {
    const response = await apiClient.get<
      ApiWrapper<{ fingerprint: string; license_file: string }>
    >('/license/fingerprint');
    return response.data.data;
  },

  async activateLicense(licenseKey: string): Promise<{ message: string; status: LicenseStatus }> {
    const response = await apiClient.post<
      ApiWrapper<{ message: string; status: LicenseStatus }>
    >('/license/activate', { license_key: licenseKey });
    return response.data.data;
  },

  // === Kiosk Security (ADM-03/04, DSP-07/09) ===
  async regeneratePairingKey(roomId: string): Promise<PairingKeyResponse> {
    const response = await apiClient.post<ApiWrapper<PairingKeyResponse>>(
      `/rooms/${encodeURIComponent(roomId)}/pairing-key/regenerate`
    );
    return response.data.data;
  },

  async setMasterPin(roomId: string, pin: string): Promise<MasterPinResponse> {
    const response = await apiClient.put<ApiWrapper<MasterPinResponse>>(
      `/rooms/${encodeURIComponent(roomId)}/master-pin`,
      { pin }
    );
    return response.data.data;
  },

  /** Pairing kiosk: simpan token kiosk (localStorage `kiosk_token_<room>`). */
  async pairKiosk(roomCode: string, pairingKey: string): Promise<KioskPairResult> {
    const response = await kioskClient.post<ApiWrapper<KioskPairResult>>('/door-display/pair', {
      room_code: roomCode,
      pairing_key: pairingKey,
    });
    const result = response.data.data;
    if (result.paired && result.kiosk_token) {
      kioskSession.setToken(roomCode, result.kiosk_token, !!result.has_master_pin);
    }
    return result;
  },

  async earlyReleaseBooking(bookingId: string, pin: string, roomCode?: string): Promise<EarlyReleaseResult> {
    const response = await kioskClient.post<ApiWrapper<EarlyReleaseResult>>(
      `/door-display/early-release/${encodeURIComponent(bookingId)}`,
      { pin },
      { headers: roomCode ? kioskHeaders(roomCode) : {} }
    );
    return response.data.data;
  },
};

// ============================================================
// Live meeting & denah kursi
// (src/api/routers/live_meeting.py)
// ============================================================

export const liveMeetingApi = {
  async getRoomSeats(roomId: string): Promise<RoomSeatMap> {
    const r = await apiClient.get<ApiWrapper<RoomSeatMap>>(`/rooms/${encodeURIComponent(roomId)}/seats`);
    return r.data.data;
  },

  /** Simpan denah batch: upsert per id, kursi yang tidak dikirim dihapus. */
  async saveRoomSeats(roomId: string, items: RoomSeatInput[], layout?: SeatLayoutShape | null): Promise<RoomSeatMap> {
    const body: { items: RoomSeatInput[]; layout?: SeatLayoutShape } = { items };
    if (layout) body.layout = layout;
    const r = await apiClient.put<ApiWrapper<RoomSeatMap>>(`/rooms/${encodeURIComponent(roomId)}/seats`, body);
    return r.data.data;
  },

  async generateRoomSeats(roomId: string, payload: SeatGenerateRequest): Promise<RoomSeatMap> {
    const r = await apiClient.post<ApiWrapper<RoomSeatMap>>(
      `/rooms/${encodeURIComponent(roomId)}/seats/generate`,
      payload
    );
    return r.data.data;
  },

  async getLive(bookingId: string): Promise<LiveMeetingSnapshot> {
    const r = await apiClient.get<ApiWrapper<LiveMeetingSnapshot>>(`/bookings/${encodeURIComponent(bookingId)}/live`);
    return r.data.data;
  },

  async startMeeting(bookingId: string): Promise<LiveMeetingSnapshot> {
    const r = await apiClient.post<ApiWrapper<LiveMeetingSnapshot>>(
      `/bookings/${encodeURIComponent(bookingId)}/meeting/start`
    );
    return r.data.data;
  },

  async extendMeeting(bookingId: string, minutes: number): Promise<LiveMeetingSnapshot> {
    const r = await apiClient.post<ApiWrapper<LiveMeetingSnapshot>>(
      `/bookings/${encodeURIComponent(bookingId)}/meeting/extend`,
      { minutes }
    );
    return r.data.data;
  },

  async endMeeting(bookingId: string): Promise<LiveMeetingSnapshot> {
    const r = await apiClient.post<ApiWrapper<LiveMeetingSnapshot>>(
      `/bookings/${encodeURIComponent(bookingId)}/meeting/end`
    );
    return r.data.data;
  },

  async getSeatAssignments(bookingId: string): Promise<SeatAssignmentsResponse> {
    const r = await apiClient.get<ApiWrapper<SeatAssignmentsResponse>>(
      `/bookings/${encodeURIComponent(bookingId)}/seat-assignments`
    );
    return r.data.data;
  },

  /** Upsert penugasan per kursi; `replace` = kursi yang tidak dikirim dikosongkan. */
  async saveSeatAssignments(
    bookingId: string,
    items: SeatAssignmentInput[],
    replace = false
  ): Promise<SeatAssignmentsResponse> {
    const r = await apiClient.put<ApiWrapper<SeatAssignmentsResponse>>(
      `/bookings/${encodeURIComponent(bookingId)}/seat-assignments`,
      { items, replace }
    );
    return r.data.data;
  },

  async autoSeatAssignments(
    bookingId: string,
    strategy: 'attended_first' | 'all' = 'attended_first'
  ): Promise<SeatAssignmentsResponse> {
    const r = await apiClient.post<ApiWrapper<SeatAssignmentsResponse>>(
      `/bookings/${encodeURIComponent(bookingId)}/seat-assignments/auto`,
      { strategy }
    );
    return r.data.data;
  },
};

// ============================================================
// Pencarian lintas rapat (FTS)
// (src/api/routers/search.py)
// ============================================================

export interface SearchCounts {
  total: number;
  notes: number;
  transcripts: number;
  actions: number;
}

export interface SearchNoteItem {
  id: string;
  note_id: string;
  booking_id: string | null;
  title: string;
  date: string;
  start_time?: string | null;
  end_time?: string | null;
  booking_title?: string | null;
  snippet: string;
  rank: number;
}

export interface SearchTranscriptItem {
  id: string;
  note_id: string;
  booking_id: string | null;
  speaker_name?: string | null;
  start_ms?: number | null;
  note_title?: string | null;
  date?: string | null;
  booking_title?: string | null;
  snippet: string;
  rank: number;
}

export interface SearchActionItem {
  id: string;
  note_id: string;
  task: string;
  owner?: string | null;
  due_date?: string | null;
  status: string;
  source?: string | null;
  note_title?: string | null;
  date?: string | null;
  booking_id?: string | null;
  booking_title?: string | null;
}

export interface SearchResultNotes {
  notes: SearchNoteItem[];
  transcripts: SearchTranscriptItem[];
  actions: SearchActionItem[];
}

export interface SearchResponse {
  query: string;
  counts: SearchCounts;
  results: SearchResultNotes;
}

export type SearchType = 'all' | 'notes' | 'transcripts' | 'actions';

export const searchApi = {
  async search(params: { q: string; type?: SearchType; limit?: number; offset?: number }): Promise<SearchResponse> {
    const r = await apiClient.get<ApiWrapper<SearchResponse>>('/search', { params });
    return r.data.data;
  },
};

// ============================================================
// Dashboard tindak lanjut lintas rapat
// (src/api/routers/followups.py)
// ============================================================

export interface FollowupItem {
  id: string;
  note_id: string;
  task: string;
  owner?: string | null;
  assignee?: string | null;
  due_date?: string | null;
  status: string;
  source?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  note_title?: string | null;
  booking_title?: string | null;
  booking_id?: string | null;
  meeting_date?: string | null;
  room_name?: string | null;
}

export interface FollowupOwnerStat {
  owner: string;
  total: number;
}

export interface FollowupSummary {
  total: number;
  open: number;
  in_progress: number;
  done: number;
  cancelled: number;
  overdue: number;
  due_today: number;
  due_this_week: number;
  by_owner: FollowupOwnerStat[];
}

export interface FollowupItemsResponse {
  items: FollowupItem[];
  total: number;
  page: number;
  per_page: number;
  total_pages: number;
}

export interface FollowupUpdateInput {
  task?: string;
  owner?: string | null;
  due_date?: string | null;
  status?: string;
}

export type FollowupStatusFilter = 'all' | 'open' | 'in_progress' | 'done' | 'cancelled' | 'overdue' | 'due_this_week';

export const followupsApi = {
  async summary(): Promise<FollowupSummary> {
    const r = await apiClient.get<ApiWrapper<FollowupSummary>>('/followups/summary');
    return r.data.data;
  },

  async items(
    params?: {
      status?: FollowupStatusFilter;
      owner?: string;
      q?: string;
      booking_id?: string;
      page?: number;
      per_page?: number;
    }
  ): Promise<FollowupItemsResponse> {
    const r = await apiClient.get<ApiWrapper<FollowupItemsResponse>>('/followups/items', { params });
    return r.data.data;
  },

  async updateItem(itemId: string, data: FollowupUpdateInput): Promise<FollowupItem> {
    const r = await apiClient.patch<ApiWrapper<FollowupItem>>(
      `/followups/items/${encodeURIComponent(itemId)}`,
      data
    );
    return r.data.data;
  },
};

// ============================================================
// Setup wizard ala WordPress
// (src/api/routers/setup.py)
// ============================================================

export interface SetupStep {
  key: string;
  label: string;
  done: boolean;
  detail: string;
}

export interface SetupStatus {
  completed: boolean;
  steps: SetupStep[];
}

export interface SetupProfileInput {
  org_name: string;
  org_address?: string;
  org_phone?: string;
  org_email?: string;
}

export const setupApi = {
  async status(): Promise<SetupStatus> {
    const r = await apiClient.get<ApiWrapper<SetupStatus>>('/setup/status');
    return r.data.data;
  },

  async saveProfile(data: SetupProfileInput): Promise<SetupStatus> {
    const r = await apiClient.post<ApiWrapper<SetupStatus>>('/setup/profile', data);
    return r.data.data;
  },

  async complete(): Promise<{ completed: boolean; message: string }> {
    const r = await apiClient.post<ApiWrapper<{ completed: boolean; message: string }>>('/setup/complete');
    return r.data.data;
  },
};
