import axios, { AxiosError, type InternalAxiosRequestConfig } from 'axios';
import { useAuthStore } from '@/web/store/auth.store';

declare module 'axios' {
  interface AxiosRequestConfig {
    /** Jangan refresh/redirect otomatis saat 401 (dipakai untuk logout). */
    skipAuthRedirect?: boolean;
    /** Internal: request ini sudah dicoba ulang setelah refresh token. */
    _retry?: boolean;
  }
}

/**
 * Base URL API. Default relatif (`/api/v1`) sehingga proxy Vite / reverse proxy
 * produksi yang meneruskan ke backend. Override via `VITE_API_URL`.
 */
export const API_BASE_URL: string = import.meta.env.VITE_API_URL || '/api/v1';

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// ---------------------------------------------------------------------------
// Helpers sesi
// ---------------------------------------------------------------------------

function redirectTo(path: string) {
  if (typeof window === 'undefined') return;
  if (window.location.pathname !== path) {
    window.location.href = path;
  }
}

/** Hapus sesi lokal sepenuhnya lalu arahkan ke /login. */
export function forceLogout() {
  useAuthStore.getState().logout();
  redirectTo('/login');
}

/**
 * Logout lengkap: cabut semua token di server (error diabaikan), lalu
 * bersihkan store. Pemanggil bertanggung jawab melakukan navigasi.
 */
export async function signOut(): Promise<void> {
  const { accessToken } = useAuthStore.getState();
  if (accessToken) {
    try {
      await apiClient.post('/auth/logout', undefined, { skipAuthRedirect: true });
    } catch {
      /* abaikan: token mungkin sudah kedaluwarsa */
    }
  }
  useAuthStore.getState().logout();
}

function errorCode(data: unknown): string | undefined {
  const detail = (data as { detail?: unknown } | undefined)?.detail;
  if (detail && typeof detail === 'object' && !Array.isArray(detail)) {
    return (detail as { code?: string }).code;
  }
  return undefined;
}

/**
 * Ambil pesan error yang ramah dari error axios/FastAPI:
 * - `detail` berupa string
 * - `detail.message` (format {code, message})
 * - `detail` berupa array validasi Pydantic (422)
 */
export function getErrorMessage(err: unknown, fallback = 'Terjadi kesalahan. Silakan coba lagi.'): string {
  const e = err as AxiosError<{ detail?: unknown; message?: string; error?: { message?: string } }>;
  const data = e?.response?.data;
  const detail = data?.detail;
  if (typeof detail === 'string' && detail.trim()) return detail;
  if (Array.isArray(detail) && detail.length > 0) {
    return detail
      .map((d: { loc?: unknown[]; msg?: string }) => {
        const field = Array.isArray(d?.loc) ? d.loc.filter((x) => x !== 'body').join('.') : '';
        return field ? `${field}: ${d?.msg ?? ''}` : d?.msg ?? '';
      })
      .filter(Boolean)
      .join('; ');
  }
  if (detail && typeof detail === 'object') {
    const msg = (detail as { message?: string }).message;
    if (msg) return msg;
  }
  if (data?.error?.message) return data.error.message;
  if (typeof data?.message === 'string' && data.message) return data.message;
  if (e?.code === 'ECONNABORTED') return 'Permintaan melebihi batas waktu.';
  if (e?.message === 'Network Error') return 'Tidak dapat terhubung ke server.';
  return fallback;
}

// ---------------------------------------------------------------------------
// Interceptors
// ---------------------------------------------------------------------------

apiClient.interceptors.request.use(
  (config) => {
    const token = useAuthStore.getState().accessToken;
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Satu permintaan refresh untuk semua request yang gagal bersamaan.
let refreshPromise: Promise<string> | null = null;

async function refreshAccessToken(): Promise<string> {
  const { refreshToken } = useAuthStore.getState();
  if (!refreshToken) throw new Error('no refresh token');
  const res = await axios.post(`${API_BASE_URL}/auth/refresh`, { refresh_token: refreshToken });
  const payload = res.data?.data ?? res.data;
  const access = payload?.access_token as string | undefined;
  const refresh = (payload?.refresh_token as string | undefined) ?? refreshToken;
  if (!access) throw new Error('invalid refresh response');
  useAuthStore.getState().setTokens(access, refresh);
  return access;
}

const AUTH_ENDPOINTS_NO_REFRESH = ['/auth/login', '/auth/refresh', '/auth/logout', '/auth/forgot-password', '/auth/reset-password'];

apiClient.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const status = error.response?.status;
    const config = error.config as InternalAxiosRequestConfig | undefined;
    const url = config?.url ?? '';
    const code = errorCode(error.response?.data);

    // Lisensi belum aktif -> arahkan ke halaman aktivasi.
    if (status === 402) {
      if (!window.location.pathname.startsWith('/license')) {
        useAuthStore.getState().logout();
        window.location.href = '/license';
      }
      return Promise.reject(error);
    }

    // Wajib ganti password sebelum boleh memakai API lain.
    if (status === 403 && code === 'PASSWORD_CHANGE_REQUIRED') {
      const { user, updateUser } = useAuthStore.getState();
      if (user && !user.must_change_password) updateUser({ must_change_password: true });
      redirectTo('/change-password');
      return Promise.reject(error);
    }

    if (status === 401 && !config?.skipAuthRedirect) {
      const isAuthEndpoint = AUTH_ENDPOINTS_NO_REFRESH.some((p) => url.includes(p));
      if (isAuthEndpoint) {
        return Promise.reject(error);
      }
      // Token dicabut (logout di perangkat lain / ganti password) -> sesi berakhir.
      if (code === 'AUTH_REVOKED' || config?._retry || !useAuthStore.getState().refreshToken) {
        forceLogout();
        return Promise.reject(error);
      }
      try {
        if (!refreshPromise) {
          refreshPromise = refreshAccessToken().finally(() => {
            refreshPromise = null;
          });
        }
        const newToken = await refreshPromise;
        if (config) {
          config._retry = true;
          config.headers.Authorization = `Bearer ${newToken}`;
          return apiClient(config);
        }
      } catch {
        forceLogout();
      }
    }
    return Promise.reject(error);
  }
);

// ---------------------------------------------------------------------------
// Download berkas (kirim header Authorization, tidak bisa lewat window.open)
// ---------------------------------------------------------------------------

function filenameFromDisposition(header: string | undefined | null): string | null {
  if (!header) return null;
  const star = /filename\*\s*=\s*(?:UTF-8'')?([^;]+)/i.exec(header);
  if (star?.[1]) {
    try {
      return decodeURIComponent(star[1].trim().replace(/^"|"$/g, ''));
    } catch {
      /* lanjut ke filename biasa */
    }
  }
  const plain = /filename\s*=\s*"?([^";]+)"?/i.exec(header);
  return plain?.[1]?.trim() || null;
}

/**
 * Unduh berkas dari API sebagai blob (dengan token) lalu simpan di browser.
 * Nama berkas diambil dari header Content-Disposition bila tersedia.
 * Melempar error bila server mengembalikan status gagal.
 */
export async function downloadFile(
  url: string,
  params?: Record<string, unknown>,
  fallbackName = 'download'
): Promise<string> {
  let response;
  try {
    response = await apiClient.get<Blob>(url, { params, responseType: 'blob', timeout: 120000 });
  } catch (err) {
    // Body error berupa Blob -> ubah ke JSON supaya getErrorMessage bisa membacanya.
    const e = err as AxiosError;
    const data = e.response?.data;
    if (data instanceof Blob) {
      try {
        const text = await data.text();
        (e.response as { data: unknown }).data = JSON.parse(text);
      } catch {
        /* biarkan apa adanya */
      }
    }
    throw err;
  }

  const contentType = String(response.headers['content-type'] ?? '');
  if (contentType.includes('application/json')) {
    // Endpoint mengembalikan JSON, bukan berkas (mis. belum didukung).
    const text = await response.data.text();
    let message = 'Server tidak mengembalikan berkas.';
    try {
      const json = JSON.parse(text);
      message = json?.detail?.message || json?.detail || json?.message || message;
    } catch {
      /* ignore */
    }
    throw new Error(typeof message === 'string' ? message : 'Server tidak mengembalikan berkas.');
  }

  const name = filenameFromDisposition(response.headers['content-disposition'] as string | undefined) || fallbackName;
  const blobUrl = URL.createObjectURL(response.data);
  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
  return name;
}

// ---------------------------------------------------------------------------
// WebSocket URL
// ---------------------------------------------------------------------------

/**
 * Bangun URL WebSocket untuk `path` (mis. `/api/v1/ws/notifications`).
 * Default: host halaman saat ini (ws/wss mengikuti http/https) sehingga lewat
 * proxy Vite / reverse proxy. Override dengan `VITE_WS_URL` (mis. `wss://api.contoh.id`).
 */
export function buildWsUrl(path: string, query?: Record<string, string>): string {
  const override = (import.meta.env.VITE_WS_URL as string | undefined)?.replace(/\/+$/, '');
  const base = override || `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.host}`;
  const qs = query ? `?${new URLSearchParams(query).toString()}` : '';
  return `${base}${path.startsWith('/') ? path : `/${path}`}${qs}`;
}

export default apiClient;
