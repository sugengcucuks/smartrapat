"""Inti lisensi: pembuatan kunci, penandatanganan, dan verifikasi (Ed25519).

Format berkas lisensi (satu baris teks, mudah disalin):
    SMR1.<base64url(payload_json)>.<base64url(signature)>
"""
import base64
import json
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

LICENSE_PREFIX = "SMR1"
LICENSE_FILE_NAME = "license.key"


# ============================================================
# Utilitas kunci
# ============================================================

def generate_keypair() -> tuple[bytes, bytes]:
    """Buat pasangan kunci Ed25519 (private_pem, public_pem)."""
    private_key = Ed25519PrivateKey.generate()
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_pem = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return private_pem, public_pem


def load_private_key(pem: bytes) -> Ed25519PrivateKey:
    key = serialization.load_pem_private_key(pem, password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise ValueError("Kunci privat bukan Ed25519")
    return key


def load_public_key(pem: bytes) -> Ed25519PublicKey:
    key = serialization.load_pem_public_key(pem)
    if not isinstance(key, Ed25519PublicKey):
        raise ValueError("Kunci publik bukan Ed25519")
    return key


def _b64e(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _b64d(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


# ============================================================
# Struktur lisensi
# ============================================================

@dataclass
class LicensePayload:
    license_id: str
    customer: str
    fingerprint: str
    edition: str = "standard"
    issued_at: str = ""
    expires_at: Optional[str] = None   # None / "" = lisensi permanen
    max_rooms: int = 0                 # 0 = tidak dibatasi
    max_users: int = 0                 # 0 = tidak dibatasi
    features: List[str] = field(default_factory=list)
    notes: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "license_id": self.license_id,
            "customer": self.customer,
            "fingerprint": self.fingerprint,
            "edition": self.edition,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
            "max_rooms": self.max_rooms,
            "max_users": self.max_users,
            "features": self.features,
            "notes": self.notes,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "LicensePayload":
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in data.items() if k in known})


@dataclass
class LicenseCheck:
    valid: bool
    reason: str = ""
    payload: Optional[LicensePayload] = None

    @property
    def days_remaining(self) -> Optional[int]:
        if not self.payload or not self.payload.expires_at:
            return None
        try:
            exp = _parse_date(self.payload.expires_at)
        except ValueError:
            return None
        return (exp - date.today()).days


def _parse_date(value: str) -> date:
    """Terima format ISO date (2027-01-01) atau ISO datetime."""
    text = str(value).strip()
    if not text:
        raise ValueError("tanggal kosong")
    try:
        return date.fromisoformat(text[:10])
    except ValueError:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).date()


def sign_payload(payload: LicensePayload, private_pem: bytes) -> str:
    """Tanda tangani payload, hasilkan string lisensi siap disimpan."""
    raw = json.dumps(payload.to_dict(), separators=(",", ":"), sort_keys=True).encode("utf-8")
    signature = load_private_key(private_pem).sign(raw)
    return f"{LICENSE_PREFIX}.{_b64e(raw)}.{_b64e(signature)}"


def verify_license_text(license_text: str, public_pem: bytes) -> LicenseCheck:
    """Verifikasi tanda tangan lisensi terhadap kunci publik bawaan aplikasi."""
    text = (license_text or "").strip()
    if not text:
        return LicenseCheck(False, "Berkas lisensi kosong")

    parts = text.split(".")
    if len(parts) != 3 or parts[0] != LICENSE_PREFIX:
        return LicenseCheck(False, "Format lisensi tidak dikenali")

    try:
        raw = _b64d(parts[1])
        signature = _b64d(parts[2])
    except Exception:
        return LicenseCheck(False, "Isi lisensi rusak / tidak dapat dibaca")

    try:
        load_public_key(public_pem).verify(signature, raw)
    except InvalidSignature:
        return LicenseCheck(False, "Tanda tangan lisensi tidak valid")
    except Exception:
        return LicenseCheck(False, "Gagal memverifikasi tanda tangan lisensi")

    try:
        payload = LicensePayload.from_dict(json.loads(raw.decode("utf-8")))
    except Exception:
        return LicenseCheck(False, "Data lisensi tidak dapat dibaca")

    return LicenseCheck(True, "", payload)


def validate_payload(
    payload: LicensePayload,
    machine_fingerprint: str,
    today: Optional[date] = None,
) -> LicenseCheck:
    """Validasi isi lisensi: fingerprint mesin dan masa berlaku."""
    today = today or date.today()

    if not (payload.fingerprint or "").strip():
        # Lisensi tanpa fingerprint bisa dipakai di mesin mana pun -> tolak.
        return LicenseCheck(False, "Lisensi tidak terikat ke perangkat (fingerprint kosong)", payload)

    if payload.fingerprint != machine_fingerprint:
        return LicenseCheck(
            False,
            "Lisensi tidak untuk perangkat ini (fingerprint tidak cocok)",
            payload,
        )

    if payload.expires_at:
        try:
            exp = _parse_date(payload.expires_at)
        except ValueError:
            return LicenseCheck(False, "Tanggal kedaluwarsa lisensi tidak valid", payload)
        if today > exp:
            return LicenseCheck(
                False,
                f"Lisensi sudah kedaluwarsa sejak {exp.isoformat()}",
                payload,
            )

    return LicenseCheck(True, "", payload)


def validate_license_text(
    license_text: str,
    public_pem: bytes,
    machine_fingerprint: str,
    today: Optional[date] = None,
) -> LicenseCheck:
    """Verifikasi tanda tangan lalu validasi fingerprint + masa berlaku."""
    check = verify_license_text(license_text, public_pem)
    if not check.valid or not check.payload:
        return check
    return validate_payload(check.payload, machine_fingerprint, today)


def read_license_file(path: str | Path) -> str:
    return Path(path).read_text(encoding="utf-8").strip()


def write_license_file(path: str | Path, license_text: str) -> None:
    """Tulis berkas lisensi secara atomik (temp file + os.replace)."""
    import os
    import tempfile

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".license-", suffix=".tmp", dir=str(target.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(license_text.strip() + "\n")
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, target)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
