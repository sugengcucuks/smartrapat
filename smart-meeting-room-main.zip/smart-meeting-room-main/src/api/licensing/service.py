"""Layanan lisensi runtime: memuat, memverifikasi, dan menyimpan status lisensi."""
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Optional

from src.api.config import settings
from src.api.licensing.core import (
    LicenseCheck,
    LicensePayload,
    read_license_file,
    validate_license_text,
    write_license_file,
)
from src.api.licensing.fingerprint import get_machine_fingerprint

PUBLIC_KEY_PATH = Path(__file__).resolve().parent / "public_key.pem"


@dataclass
class LicenseStatus:
    enforced: bool
    activated: bool
    reason: str
    fingerprint: str
    license_file: str
    payload: Optional[LicensePayload] = None
    days_remaining: Optional[int] = None

    def to_dict(self) -> dict:
        return {
            "enforced": self.enforced,
            "activated": self.activated,
            "reason": self.reason,
            "fingerprint": self.fingerprint,
            "license_file": self.license_file,
            "days_remaining": self.days_remaining,
            "license": self.payload.to_dict() if self.payload else None,
        }


def _public_key_bytes() -> bytes:
    try:
        return PUBLIC_KEY_PATH.read_bytes()
    except OSError:
        return b""


def license_file_path() -> Path:
    configured = (settings.LICENSE_FILE or "").strip()
    if configured:
        return Path(configured)
    return Path(settings.LICENSE_DIR or ".") / "license.key"


def evaluate() -> LicenseStatus:
    """Hitung status lisensi terkini dari berkas di disk."""
    fingerprint = get_machine_fingerprint()
    path = license_file_path()
    enforced = bool(settings.LICENSE_ENFORCED)

    base = LicenseStatus(
        enforced=enforced,
        activated=False,
        reason="",
        fingerprint=fingerprint,
        license_file=str(path),
    )

    if not path.exists():
        base.reason = "Berkas lisensi belum ada. Silakan lakukan aktivasi."
        base.activated = not enforced
        return base

    public_pem = _public_key_bytes()
    if not public_pem:
        base.reason = "Kunci publik lisensi tidak ditemukan pada aplikasi."
        return base

    try:
        text = read_license_file(path)
    except OSError:
        base.reason = "Berkas lisensi tidak dapat dibaca."
        return base

    check: LicenseCheck = validate_license_text(text, public_pem, fingerprint)
    if not check.valid or not check.payload:
        base.reason = check.reason or "Lisensi tidak valid."
        return base

    base.activated = True
    base.payload = check.payload
    base.reason = "Lisensi aktif."

    if check.payload.expires_at:
        try:
            exp = date.fromisoformat(str(check.payload.expires_at)[:10])
            base.days_remaining = (exp - date.today()).days
        except ValueError:
            base.days_remaining = None

    return base


def is_enforced() -> bool:
    return bool(settings.LICENSE_ENFORCED)


def check_license_text(license_text: str) -> LicenseCheck:
    """Validasi teks lisensi (tanda tangan, fingerprint, masa berlaku) TANPA menyimpan."""
    public_pem = _public_key_bytes()
    if not public_pem:
        return LicenseCheck(False, "Kunci publik lisensi tidak ditemukan pada aplikasi.")
    return validate_license_text(license_text, public_pem, get_machine_fingerprint())


def install_license_text(license_text: str) -> LicenseStatus:
    """Validasi dulu; hanya bila valid berkas lisensi ditulis (atomik) lalu dievaluasi ulang.

    Lisensi tidak valid TIDAK pernah menimpa lisensi yang sedang aktif.
    """
    check = check_license_text(license_text)
    if not check.valid:
        failed = evaluate()
        failed.activated = False
        failed.reason = check.reason or "Lisensi tidak valid."
        failed.payload = None
        return failed
    write_license_file(license_file_path(), license_text)
    return evaluate()
