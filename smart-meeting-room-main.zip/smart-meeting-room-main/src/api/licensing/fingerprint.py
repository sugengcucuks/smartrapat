"""Fingerprint mesin: identitas unik perangkat untuk mengikat lisensi."""
import hashlib
import platform
import uuid
from pathlib import Path


def _machine_id() -> str:
    """Ambil machine-id bawaan OS (Windows MachineGuid / Linux machine-id)."""
    try:
        if platform.system() == "Windows":
            import winreg

            with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Microsoft\Cryptography",
                0,
                winreg.KEY_READ | winreg.KEY_WOW64_64KEY,
            ) as key:
                value, _ = winreg.QueryValueEx(key, "MachineGuid")
                if value:
                    return str(value)
        else:
            for candidate in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
                path = Path(candidate)
                if path.exists():
                    content = path.read_text(encoding="utf-8").strip()
                    if content:
                        return content
    except Exception:
        pass
    return ""


def raw_machine_identity() -> str:
    """Gabungan beberapa penanda perangkat menjadi satu string identitas."""
    parts = [
        _machine_id(),
        platform.node(),
        f"{uuid.getnode():012x}",
        platform.machine(),
        platform.system(),
    ]
    return "|".join(p.strip().lower() for p in parts if p)


def get_machine_fingerprint() -> str:
    """Sidik jari mesin (sha256 heksadesimal)."""
    return hashlib.sha256(raw_machine_identity().encode("utf-8")).hexdigest()


def format_fingerprint(fingerprint: str, group: int = 8, per_line: int = 2) -> str:
    """Format sidik jari agar mudah dibaca dan dikirim ke vendor."""
    chunks = [fingerprint[i : i + group] for i in range(0, len(fingerprint), group)]
    lines = ["-".join(chunks[i : i + per_line]) for i in range(0, len(chunks), per_line)]
    return "\n".join(lines)
