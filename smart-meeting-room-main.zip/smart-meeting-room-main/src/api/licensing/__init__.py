"""Modul lisensi offline (Ed25519) untuk Smart Meeting Room."""
