"""Kontrol AV per ruangan + konfigurasi kanal mic.

Kontrak: docs/architecture/LIVE_MEETING.md §4 "Kontrol AV per ruangan".
Respons perintah: {"cmd_id", "status": "acked"|"failed"|"timeout", "error", "results": [...]}
(HTTP 200; 503 bila broker MQTT tidak dikonfigurasi/terhubung, 409 bila mixer tidak
terpasang, 404 bila perangkat/kanal tidak ada).
"""
from typing import List, Optional, Union
from uuid import UUID

from fastapi import APIRouter, Depends, status
from pydantic import BaseModel, Field
from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.database import get_db
from src.api.models.device import Device
from src.api.models.live import AudioChannel, RoomSeat
from src.api.models.user import User
from src.api.services import av_service as av
from src.api.services.live_hub import live_hub
from src.api.utils.permissions import require_permission

router = APIRouter(prefix="/rooms", tags=["Kontrol AV Ruangan"])

_view = require_permission("rooms.view", "devices.view", "videowall.control", "audio.control")
_vw = require_permission("videowall.control")
_audio = require_permission("audio.control")


class LayoutRequest(BaseModel):
    preset: str = Field(..., min_length=1, max_length=50)


class SourceRequest(BaseModel):
    source: str = Field(..., min_length=1, max_length=50)
    window: int = Field(1, ge=1, le=16)


class FaderRequest(BaseModel):
    target: Union[int, str] = Field(..., description="nomor kanal (channel_no) atau 'main'")
    value: float = Field(..., ge=0.0, le=1.0)


class GainRequest(BaseModel):
    channel_no: int = Field(..., ge=1, le=64)
    db: float = Field(..., ge=-12.0, le=60.0)


class AudioChannelIn(BaseModel):
    channel_no: int = Field(..., ge=1, le=64)
    label: str = Field(..., min_length=1, max_length=100)
    receiver_label: Optional[str] = Field(None, max_length=100)
    mixer_channel: Optional[int] = Field(None, ge=1, le=64)
    capture_channel: Optional[int] = Field(None, ge=1, le=64)
    device_id: Optional[UUID] = None
    enabled: bool = True


class AudioChannelsPut(BaseModel):
    channels: List[AudioChannelIn]


def _ok(data):
    return {"success": True, "data": data}


# ---------------------------------------------------------------------------
# Kapabilitas & state
# ---------------------------------------------------------------------------

@router.get("/{room_id}/av/capabilities")
async def get_capabilities(room_id: UUID, _u: User = Depends(_view), db: AsyncSession = Depends(get_db)):
    return _ok(await av.capabilities(db, room_id))


@router.get("/{room_id}/av/state")
async def get_av_state(room_id: UUID, _u: User = Depends(_view), db: AsyncSession = Depends(get_db)):
    rd = await av.load_room_devices(db, room_id)
    live_hub.remember_room(str(rd.room.id), rd.room.code)
    audio_state = await live_hub.room_av_state(str(rd.room.id), rd.room.code)
    return _ok({
        "room_id": str(rd.room.id),
        "room_code": rd.room.code,
        "mqtt": av.mqtt_manager.status(),
        "devices": [av.device_brief(d) for d in rd.all],
        "audio_mode": rd.audio_mode,
        **audio_state,
    })


# ---------------------------------------------------------------------------
# Videowall
# ---------------------------------------------------------------------------

@router.post("/{room_id}/av/videowall/power-on")
async def videowall_power_on(room_id: UUID, user: User = Depends(_vw), db: AsyncSession = Depends(get_db)):
    return _ok(await av.videowall_power(db, room_id, True, user))


@router.post("/{room_id}/av/videowall/power-off")
async def videowall_power_off(room_id: UUID, user: User = Depends(_vw), db: AsyncSession = Depends(get_db)):
    return _ok(await av.videowall_power(db, room_id, False, user))


@router.post("/{room_id}/av/videowall/layout")
async def videowall_layout(room_id: UUID, body: LayoutRequest, user: User = Depends(_vw),
                           db: AsyncSession = Depends(get_db)):
    return _ok(await av.videowall_layout(db, room_id, body.preset, user))


@router.post("/{room_id}/av/videowall/source")
async def videowall_source(room_id: UUID, body: SourceRequest, user: User = Depends(_vw),
                           db: AsyncSession = Depends(get_db)):
    return _ok(await av.videowall_source(db, room_id, body.source, body.window, user))


# ---------------------------------------------------------------------------
# Audio
# ---------------------------------------------------------------------------

@router.post("/{room_id}/av/audio/mic/{channel_no}/mute")
async def mic_mute(room_id: UUID, channel_no: int, user: User = Depends(_audio), db: AsyncSession = Depends(get_db)):
    return _ok(await av.mic_mute(db, room_id, channel_no, True, user))


@router.post("/{room_id}/av/audio/mic/{channel_no}/unmute")
async def mic_unmute(room_id: UUID, channel_no: int, user: User = Depends(_audio), db: AsyncSession = Depends(get_db)):
    return _ok(await av.mic_mute(db, room_id, channel_no, False, user))


@router.post("/{room_id}/av/audio/mute-all")
async def audio_mute_all(room_id: UUID, user: User = Depends(_audio), db: AsyncSession = Depends(get_db)):
    return _ok(await av.mute_all(db, room_id, True, user))


@router.post("/{room_id}/av/audio/unmute-all")
async def audio_unmute_all(room_id: UUID, user: User = Depends(_audio), db: AsyncSession = Depends(get_db)):
    return _ok(await av.mute_all(db, room_id, False, user))


@router.post("/{room_id}/av/audio/fader")
async def audio_fader(room_id: UUID, body: FaderRequest, user: User = Depends(_audio),
                      db: AsyncSession = Depends(get_db)):
    return _ok(await av.set_fader(db, room_id, body.target, body.value, user))


@router.post("/{room_id}/av/audio/gain")
async def audio_gain(room_id: UUID, body: GainRequest, user: User = Depends(_audio),
                     db: AsyncSession = Depends(get_db)):
    return _ok(await av.set_gain(db, room_id, body.channel_no, body.db, user))


# ---------------------------------------------------------------------------
# Kanal mic ruangan
# ---------------------------------------------------------------------------

@router.get("/{room_id}/audio-channels")
async def list_audio_channels(room_id: UUID, _u: User = Depends(require_permission("rooms.view")),
                              db: AsyncSession = Depends(get_db)):
    await av.get_room(db, room_id)
    return _ok([av.channel_dict(c) for c in await av.audio_channels(db, room_id)])


@router.put("/{room_id}/audio-channels")
async def replace_audio_channels(
    room_id: UUID,
    body: AudioChannelsPut,
    _u: User = Depends(require_permission("rooms.write")),
    db: AsyncSession = Depends(get_db),
):
    """Ganti seluruh daftar kanal mic ruangan (batch). Kanal yang sama (channel_no)
    diperbarui di tempat sehingga kaitan kursi (room_seats.audio_channel_id) tetap."""
    await av.get_room(db, room_id)
    nos = [c.channel_no for c in body.channels]
    if not av.unique_ints(nos):
        raise av.http_error(status.HTTP_400_BAD_REQUEST, "DUPLICATE_CHANNEL", "Nomor kanal (channel_no) harus unik")
    mixers = [c.mixer_channel for c in body.channels if c.mixer_channel is not None]
    if not av.unique_ints(mixers):
        raise av.http_error(status.HTTP_400_BAD_REQUEST, "DUPLICATE_MIXER_CHANNEL",
                            "Kanal mixer (mixer_channel) tidak boleh dipakai dua kali")
    captures = [c.capture_channel for c in body.channels if c.capture_channel is not None]
    if not av.unique_ints(captures):
        raise av.http_error(status.HTTP_400_BAD_REQUEST, "DUPLICATE_CAPTURE_CHANNEL",
                            "Kanal rekam (capture_channel) tidak boleh dipakai dua kali")
    dev_ids = {c.device_id for c in body.channels if c.device_id}
    if dev_ids:
        found = set((await db.execute(select(Device.id).where(Device.id.in_(dev_ids)))).scalars().all())
        missing = dev_ids - found
        if missing:
            raise av.http_error(status.HTTP_400_BAD_REQUEST, "INVALID_DEVICE",
                                f"device_id tidak ditemukan: {', '.join(str(m) for m in missing)}")

    existing = {c.channel_no: c for c in await av.audio_channels(db, room_id)}
    keep = set(nos)
    removed = [c.id for no, c in existing.items() if no not in keep]
    if removed:
        # Lepas dulu kaitan kursi (FK juga SET NULL, ini agar eksplisit)
        seats = (await db.execute(select(RoomSeat).where(RoomSeat.audio_channel_id.in_(removed)))).scalars().all()
        for s in seats:
            s.audio_channel_id = None
        await db.execute(delete(AudioChannel).where(AudioChannel.id.in_(removed)))
    for item in body.channels:
        ch = existing.get(item.channel_no)
        if ch is None:
            ch = AudioChannel(room_id=room_id, channel_no=item.channel_no)
            db.add(ch)
        ch.label = item.label
        ch.receiver_label = item.receiver_label
        ch.mixer_channel = item.mixer_channel
        ch.capture_channel = item.capture_channel
        ch.device_id = item.device_id
        ch.is_enabled = item.enabled
    await db.commit()
    live_hub.invalidate_room(room_id)
    return _ok([av.channel_dict(c) for c in await av.audio_channels(db, room_id)])
