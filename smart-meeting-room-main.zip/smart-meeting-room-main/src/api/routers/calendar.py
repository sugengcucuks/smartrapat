from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from typing import Optional, Dict, List, Any
from uuid import UUID
from datetime import date, datetime, timedelta
from calendar import monthrange

from src.api.database import get_db
from src.api.models.user import User
from src.api.models.room import Room
from src.api.models.booking import Booking
from src.api.schemas.user import SuccessResponse
from src.api.utils.auth import get_current_user

router = APIRouter(prefix="/calendar", tags=["Calendar"])

STATUS_COLORS = {
    "draft": "#9CA3AF",
    "pending": "#F59E0B",
    "approved": "#10B981",
    "rejected": "#EF4444",
    "cancelled": "#6B7280",
    "completed": "#3B82F6",
}


def _combine_date_time(d: date, t) -> str:
    combined = datetime.combine(d, t)
    return combined.isoformat()


@router.get("", response_model=SuccessResponse)
async def get_calendar_range(
    start: date = Query(..., description="Start date YYYY-MM-DD"),
    end: date = Query(..., description="End date YYYY-MM-DD"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    stmt = (
        select(Booking, Room)
        .join(Room, Booking.room_id == Room.id)
        .where(
            and_(
                Booking.date >= start,
                Booking.date <= end,
                Booking.status.in_(["draft", "pending", "approved", "completed"]),
            )
        )
        .order_by(Booking.date.asc(), Booking.start_time.asc())
    )
    result = await db.execute(stmt)
    rows = result.all()

    events = []
    for booking, room in rows:
        events.append({
            "id": str(booking.id),
            "title": booking.title,
            "date": booking.date.isoformat(),
            "organizer_id": str(booking.user_id) if booking.user_id else None,
            "meeting_status": getattr(booking, "meeting_status", None),
            "start": _combine_date_time(booking.date, booking.start_time),
            "end": _combine_date_time(booking.date, booking.end_time),
            "room_id": str(booking.room_id),
            "room_name": room.name,
            "status": booking.status,
            "backgroundColor": STATUS_COLORS.get(booking.status, "#6B7280"),
            "borderColor": STATUS_COLORS.get(booking.status, "#6B7280"),
        })

    return SuccessResponse(data=events)


@router.get("/rooms/{room_id}", response_model=SuccessResponse)
async def get_room_month_calendar(
    room_id: UUID,
    month: str = Query(..., description="Month in YYYY-MM format"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    try:
        year_num, month_num = month.split("-")
        year_num = int(year_num)
        month_num = int(month_num)
        if month_num < 1 or month_num > 12:
            raise ValueError
    except (ValueError, AttributeError):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Format month harus YYYY-MM",
        )

    room_check = await db.execute(select(Room).where(Room.id == room_id))
    if not room_check.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ruangan tidak ditemukan",
        )

    num_days = monthrange(year_num, month_num)[1]
    start_date = date(year_num, month_num, 1)
    end_date = date(year_num, month_num, num_days)

    stmt = (
        select(Booking, Room)
        .join(Room, Booking.room_id == Room.id)
        .where(
            and_(
                Booking.room_id == room_id,
                Booking.date >= start_date,
                Booking.date <= end_date,
                Booking.status.in_(["draft", "pending", "approved", "completed"]),
            )
        )
        .order_by(Booking.date.asc(), Booking.start_time.asc())
    )
    result = await db.execute(stmt)
    rows = result.all()

    events = []
    for booking, room in rows:
        events.append({
            "id": str(booking.id),
            "title": booking.title,
            "date": booking.date.isoformat(),
            "organizer_id": str(booking.user_id) if booking.user_id else None,
            "meeting_status": getattr(booking, "meeting_status", None),
            "start": _combine_date_time(booking.date, booking.start_time),
            "end": _combine_date_time(booking.date, booking.end_time),
            "room_id": str(booking.room_id),
            "room_name": room.name,
            "status": booking.status,
            "backgroundColor": STATUS_COLORS.get(booking.status, "#6B7280"),
            "borderColor": STATUS_COLORS.get(booking.status, "#6B7280"),
        })

    return SuccessResponse(data={
        "room_id": str(room_id),
        "month": month,
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat(),
        "events": events,
    })


@router.get("/day", response_model=SuccessResponse)
async def get_day_agenda(
    date_val: date = Query(..., alias="date", description="Date in YYYY-MM-DD format"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    stmt_rooms = select(Room).order_by(Room.name.asc())
    rooms_result = await db.execute(stmt_rooms)
    all_rooms = rooms_result.scalars().all()

    stmt = (
        select(Booking, Room)
        .join(Room, Booking.room_id == Room.id)
        .where(
            and_(
                Booking.date == date_val,
                Booking.status.in_(["draft", "pending", "approved", "completed"]),
            )
        )
        .order_by(Room.name.asc(), Booking.start_time.asc())
    )
    result = await db.execute(stmt)
    rows = result.all()

    bookings_by_room: Dict[str, List[Any]] = {}
    for booking, room in rows:
        key = str(room.id)
        if key not in bookings_by_room:
            bookings_by_room[key] = []
        bookings_by_room[key].append({
            "id": str(booking.id),
            "title": booking.title,
            "date": booking.date.isoformat(),
            "organizer_id": str(booking.user_id) if booking.user_id else None,
            "meeting_status": getattr(booking, "meeting_status", None),
            "start": _combine_date_time(booking.date, booking.start_time),
            "end": _combine_date_time(booking.date, booking.end_time),
            "start_time": booking.start_time.isoformat(),
            "end_time": booking.end_time.isoformat(),
            "status": booking.status,
            "backgroundColor": STATUS_COLORS.get(booking.status, "#6B7280"),
        })

    agenda = []
    for room in all_rooms:
        agenda.append({
            "room_id": str(room.id),
            "room_name": room.name,
            "room_code": room.code,
            "floor": room.floor,
            "capacity": room.capacity,
            "bookings": bookings_by_room.get(str(room.id), []),
        })

    return SuccessResponse(data={
        "date": date_val.isoformat(),
        "rooms": agenda,
    })
