from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.database import get_db
from src.api.licensing.service import LicenseStatus, evaluate, install_license_text
from src.api.models.user import User
from src.api.schemas.license import (
    SuccessResponse,
    LicenseActivateRequest,
    LicenseStatusResponse,
)
from src.api.utils.audit import client_ip, record_audit
from src.api.utils.kiosk import optional_user
from src.api.utils.permissions import is_super_admin
from src.api.utils.rate_limit import rate_limiter

router = APIRouter(prefix="/license", tags=["Lisensi"])


def _public_view(st: LicenseStatus, user: Optional[User]) -> dict:
    """Fingerprint mesin & path berkas hanya ditampilkan saat lisensi belum aktif
    (dibutuhkan untuk meminta lisensi) atau kepada Super Admin."""
    data = st.to_dict()
    if st.activated and not (user is not None and is_super_admin(user)):
        data["fingerprint"] = ""
        data["license_file"] = ""
        if isinstance(data.get("license"), dict):
            data["license"] = {**data["license"], "fingerprint": ""}
    return data


@router.get("/status", response_model=LicenseStatusResponse)
async def get_license_status(user: Optional[User] = Depends(optional_user)):
    """Status lisensi perangkat ini (dipakai halaman aktivasi & banner admin)."""
    return LicenseStatusResponse(**_public_view(evaluate(), user))


@router.get("/fingerprint", response_model=SuccessResponse)
async def get_fingerprint(user: Optional[User] = Depends(optional_user)):
    """Fingerprint mesin ini, untuk dikirim ke vendor saat meminta lisensi."""
    data = _public_view(evaluate(), user)
    return SuccessResponse(
        data={
            "fingerprint": data["fingerprint"],
            "license_file": data["license_file"],
        }
    )


@router.post("/activate", response_model=SuccessResponse)
async def activate_license(
    request: LicenseActivateRequest,
    http_request: Request,
    user: Optional[User] = Depends(optional_user),
    db: AsyncSession = Depends(get_db),
):
    """Verifikasi lisensi LALU simpan (hanya bila valid).

    Bila lisensi sudah aktif, penggantian hanya boleh dilakukan Super Admin.
    """
    rate_limiter.hit(f"license-activate:{client_ip(http_request) or 'unknown'}", limit=10, window_seconds=600)
    license_text = request.license_key.strip()

    current = evaluate()
    if current.activated and current.payload is not None and not (user is not None and is_super_admin(user)):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "FORBIDDEN", "message": "Lisensi sudah aktif. Penggantian hanya oleh Super Admin."},
        )

    installed = install_license_text(license_text)
    if not installed.activated:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=installed.reason or "Lisensi tidak valid",
        )

    await record_audit(
        db, user, "update", "system", "license", None,
        {"action": "activate", "replaced": bool(current.activated and current.payload)},
        http_request, commit=True,
    )
    return SuccessResponse(
        data={
            "message": "Lisensi berhasil diaktifkan",
            "status": _public_view(installed, user),
            "previous": _public_view(current, user),
        }
    )
