"""WebSocket live per ruangan: /api/v1/ws/rooms/{room_id}/live?token=<access_token>

Event server -> klien (lihat docs/architecture/LIVE_MEETING.md §5):
  {"event": "audio_levels"|"active_speakers"|"mixer_state"|"device_state"|..., "room_id", "data", "ts"}
Saat terhubung server mengirim "connected" lalu state AV terakhir
(device_state per perangkat, mixer_state, audio_levels, active_speakers).
Klien boleh mengirim {"type": "ping"} -> {"event": "pong"}.
"""
import json
from datetime import datetime, timezone
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect

from src.api.database import async_session
from src.api.services.live_hub import live_hub
from src.api.utils.auth import decode_token, get_user_from_payload
from src.api.utils.permissions import has_permission

router = APIRouter(tags=["Live WebSocket"])


async def _reject(ws: WebSocket, reason: str, code: int = 1008) -> None:
    await ws.accept()
    await ws.send_json({"event": "error", "data": {"message": reason}})
    try:
        await ws.close(code=code, reason=reason[:120])
    except Exception:
        pass


@router.websocket("/ws/rooms/{room_id}/live")
async def ws_room_live(websocket: WebSocket, room_id: str, token: Optional[str] = Query(None)):
    try:
        rid = str(UUID(room_id))
    except ValueError:
        await _reject(websocket, "room_id tidak valid")
        return
    if not token:
        await _reject(websocket, "Token tidak ada")
        return
    try:
        payload = decode_token(token, expected_type="access")
        async with async_session() as db:
            user = await get_user_from_payload(payload, db)
    except Exception:
        await _reject(websocket, "Token tidak valid atau kedaluwarsa")
        return
    if not has_permission(user, "rooms.view", "bookings.view"):
        await _reject(websocket, "Tidak memiliki izin")
        return

    await websocket.accept()
    live_hub.connect(rid, websocket)
    try:
        await websocket.send_json({
            "event": "connected", "room_id": rid,
            "data": {"user_id": str(user.id)},
            "ts": datetime.now(timezone.utc).isoformat(),
        })
        await live_hub.send_initial(rid, websocket)
        while True:
            text = await websocket.receive_text()
            try:
                msg = json.loads(text)
            except ValueError:
                continue
            if isinstance(msg, dict) and msg.get("type") == "ping":
                await websocket.send_json({"event": "pong", "room_id": rid, "data": {},
                                           "ts": datetime.now(timezone.utc).isoformat()})
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        live_hub.disconnect(rid, websocket)
