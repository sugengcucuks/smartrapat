"""Audio: zona speaker (metadata + kontrol bila terhubung perangkat) dan daftar mic.

Kontrol mic per kanal ada di /rooms/{room_id}/av/audio/* (src/api/routers/av_control.py).
Hardware saat ini (Ashley M118 + FC-A5400) analog: tanpa mixer digital, perintah
audio mengembalikan 409 "Mixer tidak terpasang; atur manual di receiver".

Zona hanya dikontrol bila `device_id` terisi:
  - device mixer X-Air  -> volume = fader main L/R, mute/unmute = main L/R
  - device lain         -> aksi generik set_volume/mute/unmute/set_source ke agent
State zona (volume/is_muted/input_source) di DB hanya diubah setelah perintah di-ack.
"""
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.database import get_db
from src.api.models.audio import AudioZone
from src.api.models.device import Device
from src.api.models.room import Room
from src.api.models.user import User
from src.api.schemas.audio import (
    AudioZoneCreate,
    AudioZoneResponse,
    AudioZoneUpdate,
    SuccessResponse,
)
from src.api.services import av_service as av
from src.api.services.live_hub import live_hub
from src.api.utils.permissions import require_permission

router = APIRouter(prefix="/audio", tags=["Audio Control"])

_view = require_permission("devices.view", "audio.control", "rooms.view")
_write = require_permission("devices.write", "audio.control")
_control = require_permission("audio.control")

ZONE_DEVICE_TYPES = ["audio_processor", "audio_mixer"]


def _zone_response(az: AudioZone, room: Optional[Room], device: Optional[Device]) -> AudioZoneResponse:
    return AudioZoneResponse(
        id=az.id,
        room_id=az.room_id,
        room_name=room.name if room else None,
        device_id=az.device_id,
        device_name=device.name if device else None,
        zone_name=az.zone_name,
        volume=az.volume,
        is_muted=az.is_muted,
        input_source=az.input_source,
        created_at=az.created_at,
        updated_at=az.updated_at,
    )


async def _zone_with_relations(db: AsyncSession, az_id: UUID) -> Optional[AudioZoneResponse]:
    row = (await db.execute(
        select(AudioZone, Room, Device)
        .outerjoin(Room, AudioZone.room_id == Room.id)
        .outerjoin(Device, AudioZone.device_id == Device.id)
        .where(AudioZone.id == az_id)
    )).first()
    return _zone_response(*row) if row else None


async def _get_zone(db: AsyncSession, zone_id: UUID) -> AudioZone:
    az = (await db.execute(select(AudioZone).where(AudioZone.id == zone_id))).scalar_one_or_none()
    if not az:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Audio zone tidak ditemukan")
    return az


async def _check_device(db: AsyncSession, device_id: Optional[UUID]) -> None:
    if not device_id:
        return
    ok = (await db.execute(select(Device).where(
        Device.id == device_id, Device.device_type.in_(ZONE_DEVICE_TYPES)
    ))).scalar_one_or_none()
    if not ok:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Device ID tidak valid atau bukan audio_processor/audio_mixer")


async def _zone_device(db: AsyncSession, az: AudioZone) -> Device:
    dev = None
    if az.device_id:
        dev = (await db.execute(select(Device).where(Device.id == az.device_id))).scalar_one_or_none()
    if dev is None:
        raise av.http_error(status.HTTP_409_CONFLICT, "ZONE_NOT_CONTROLLABLE",
                            "Zona ini tidak terhubung ke perangkat yang bisa dikontrol "
                            "(amplifier analog: atur manual di perangkat)")
    return dev


async def _zone_command(db: AsyncSession, az: AudioZone, kind: str, value, user: User):
    dev = await _zone_device(db, az)
    if av.is_mixer(dev):
        if kind == "volume":
            return await av.run_commands(db, [(dev, "set_fader", {"target": "main", "value": value / 100})],
                                         user, f"Volume {az.zone_name} {value}%")
        if kind in ("mute", "unmute"):
            return await av.run_commands(db, [(dev, kind, {"target": "main"})], user, f"{kind} {az.zone_name}")
        raise av.http_error(status.HTTP_409_CONFLICT, "NOT_SUPPORTED",
                            "Pemilihan sumber tidak didukung mixer; atur routing di mixer")
    action = {"volume": "set_volume", "mute": "mute", "unmute": "unmute", "source": "set_source"}[kind]
    params = {"volume": value} if kind == "volume" else {"input_source": value} if kind == "source" else {}
    params["zone"] = az.zone_name
    return await av.run_commands(db, [(dev, action, params)], user, f"{action} {az.zone_name}")


# ---------------------------------------------------------------------------
# Zona
# ---------------------------------------------------------------------------

@router.get("/zones", response_model=SuccessResponse)
async def list_audio_zones(
    room_id: Optional[UUID] = Query(None, description="Filter by room ID"),
    current_user: User = Depends(_view),
    db: AsyncSession = Depends(get_db),
):
    where = and_(AudioZone.room_id == room_id) if room_id else True
    rows = (await db.execute(
        select(AudioZone, Room, Device)
        .outerjoin(Room, AudioZone.room_id == Room.id)
        .outerjoin(Device, AudioZone.device_id == Device.id)
        .where(where)
        .order_by(AudioZone.zone_name.asc())
    )).all()
    return SuccessResponse(data=[_zone_response(*r) for r in rows])


@router.post("/zones", response_model=SuccessResponse)
async def create_audio_zone(request: AudioZoneCreate, current_user: User = Depends(_write),
                            db: AsyncSession = Depends(get_db)):
    if not (await db.execute(select(Room).where(Room.id == request.room_id))).scalar_one_or_none():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Room ID tidak valid")
    await _check_device(db, request.device_id)
    az = AudioZone(
        room_id=request.room_id, device_id=request.device_id, zone_name=request.zone_name,
        volume=request.volume, is_muted=request.is_muted, input_source=request.input_source,
    )
    db.add(az)
    await db.commit()
    await db.refresh(az)
    return SuccessResponse(data=await _zone_with_relations(db, az.id))


@router.get("/zones/{zone_id}", response_model=SuccessResponse)
async def get_audio_zone(zone_id: UUID, current_user: User = Depends(_view), db: AsyncSession = Depends(get_db)):
    data = await _zone_with_relations(db, zone_id)
    if not data:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Audio zone tidak ditemukan")
    return SuccessResponse(data=data)


@router.put("/zones/{zone_id}", response_model=SuccessResponse)
async def update_audio_zone(zone_id: UUID, request: AudioZoneUpdate, current_user: User = Depends(_write),
                            db: AsyncSession = Depends(get_db)):
    """Ubah metadata zona (tanpa mengirim perintah ke perangkat)."""
    az = await _get_zone(db, zone_id)
    if request.room_id is not None:
        if not (await db.execute(select(Room).where(Room.id == request.room_id))).scalar_one_or_none():
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Room ID tidak valid")
        az.room_id = request.room_id
    if request.device_id is not None:
        await _check_device(db, request.device_id)
        az.device_id = request.device_id
    if request.zone_name is not None:
        az.zone_name = request.zone_name
    if request.volume is not None:
        az.volume = request.volume
    if request.is_muted is not None:
        az.is_muted = request.is_muted
    if request.input_source is not None:
        az.input_source = request.input_source
    await db.commit()
    return SuccessResponse(data=await _zone_with_relations(db, zone_id))


@router.delete("/zones/{zone_id}", response_model=SuccessResponse)
async def delete_audio_zone(zone_id: UUID, current_user: User = Depends(_write), db: AsyncSession = Depends(get_db)):
    az = await _get_zone(db, zone_id)
    await db.delete(az)
    await db.commit()
    return SuccessResponse(data={"message": "Audio zone berhasil dihapus"})


@router.put("/zones/{zone_id}/volume", response_model=SuccessResponse)
async def set_zone_volume(
    zone_id: UUID,
    value: int = Query(..., ge=0, le=100, description="Volume 0-100"),
    current_user: User = Depends(_control),
    db: AsyncSession = Depends(get_db),
):
    az = await _get_zone(db, zone_id)
    result = await _zone_command(db, az, "volume", value, current_user)
    if result["status"] == "acked":
        az.volume = value
        await db.commit()
    return SuccessResponse(data={**result, "zone_id": str(zone_id), "volume": az.volume, "is_muted": az.is_muted})


@router.put("/zones/{zone_id}/mute", response_model=SuccessResponse)
async def mute_zone(zone_id: UUID, current_user: User = Depends(_control), db: AsyncSession = Depends(get_db)):
    az = await _get_zone(db, zone_id)
    result = await _zone_command(db, az, "mute", None, current_user)
    if result["status"] == "acked":
        az.is_muted = True
        await db.commit()
    return SuccessResponse(data={**result, "zone_id": str(zone_id), "is_muted": az.is_muted, "volume": az.volume})


@router.put("/zones/{zone_id}/unmute", response_model=SuccessResponse)
async def unmute_zone(zone_id: UUID, current_user: User = Depends(_control), db: AsyncSession = Depends(get_db)):
    az = await _get_zone(db, zone_id)
    result = await _zone_command(db, az, "unmute", None, current_user)
    if result["status"] == "acked":
        az.is_muted = False
        await db.commit()
    return SuccessResponse(data={**result, "zone_id": str(zone_id), "is_muted": az.is_muted, "volume": az.volume})


@router.put("/zones/{zone_id}/source", response_model=SuccessResponse)
async def set_zone_source(
    zone_id: UUID,
    input: str = Query(..., pattern="^(mic1|mic2|line1|bluetooth|hdmi|usb)$", description="Input source"),
    current_user: User = Depends(_control),
    db: AsyncSession = Depends(get_db),
):
    az = await _get_zone(db, zone_id)
    result = await _zone_command(db, az, "source", input, current_user)
    if result["status"] == "acked":
        az.input_source = input
        await db.commit()
    return SuccessResponse(data={**result, "zone_id": str(zone_id), "input_source": az.input_source})


# ---------------------------------------------------------------------------
# Mic = kanal audio ruangan (audio_channels) + state mixer live
# ---------------------------------------------------------------------------

@router.get("/microphones", response_model=SuccessResponse)
async def list_microphones(
    room_id: UUID = Query(..., description="ID ruangan"),
    current_user: User = Depends(_view),
    db: AsyncSession = Depends(get_db),
):
    """Kanal mic ruangan + state mixer/level terakhir (bila mixer terpasang)."""
    rd = await av.load_room_devices(db, room_id)
    state = await live_hub.room_av_state(str(rd.room.id), rd.room.code)
    mixer_chans = ((state.get("mixer") or {}).get("channels") or {})
    levels = state.get("levels") or {}
    active = set((state.get("active_speakers") or {}).get("channels") or [])
    items = []
    for ch in await av.audio_channels(db, room_id):
        ms = mixer_chans.get(str(ch.channel_no)) or {}
        items.append({
            **av.channel_dict(ch),
            "muted": ms.get("muted"),
            "fader": ms.get("fader"),
            "gain": ms.get("gain"),
            "level_db": levels.get(str(ch.channel_no)),
            "active": ch.channel_no in active,
        })
    return SuccessResponse(data={"audio_mode": rd.audio_mode, "can_control": rd.mixer is not None,
                                 "message": None if rd.mixer else av.MIXER_ABSENT_MESSAGE,
                                 "items": items})
