from fastapi import APIRouter, Depends, HTTPException, status, Query, Request, WebSocket
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, delete, update
from typing import Optional, List, Dict
from uuid import UUID
from datetime import datetime
import math
from collections import defaultdict

from src.api.database import get_db
from src.api.models.user import User
from src.api.models.notification import Notification
from src.api.schemas.notification import (
    SuccessResponse,
    NotificationSendMany,
    NotificationBroadcast,
    NotificationResponse,
    PaginatedNotificationsResponse,
)
from src.api.utils.auth import get_current_user
from src.api.utils.audit import record_audit
from src.api.utils.permissions import require_permission

router = APIRouter(prefix="/notifications", tags=["Notifications"])


class NotificationWebSocketManager:
    def __init__(self):
        self.active_connections: Dict[UUID, List[WebSocket]] = defaultdict(list)

    async def connect(self, user_id: UUID, websocket: WebSocket):
        await websocket.accept()
        self.active_connections[user_id].append(websocket)

    def disconnect(self, user_id: UUID, websocket: WebSocket):
        if websocket in self.active_connections[user_id]:
            self.active_connections[user_id].remove(websocket)
        if not self.active_connections[user_id]:
            del self.active_connections[user_id]

    async def send_to_user(self, user_id: UUID, message: dict):
        if user_id in self.active_connections:
            for connection in self.active_connections[user_id]:
                try:
                    await connection.send_json(message)
                except Exception:
                    pass

    async def broadcast(self, message: dict, user_ids: Optional[List[UUID]] = None):
        if user_ids:
            for uid in user_ids:
                await self.send_to_user(uid, message)
        else:
            for uid in list(self.active_connections.keys()):
                await self.send_to_user(uid, message)

    def clear_all(self):
        self.active_connections.clear()


ws_manager = NotificationWebSocketManager()


async def _build_notification_response(notification: Notification) -> NotificationResponse:
    return NotificationResponse(
        id=notification.id,
        user_id=notification.user_id,
        type=notification.type,
        title=notification.title,
        message=notification.message,
        data=notification.data,
        is_read=notification.is_read,
        read_at=notification.read_at,
        created_at=notification.created_at,
    )


async def _create_notification(
    db: AsyncSession,
    user_id: UUID,
    type: str,
    title: str,
    message: Optional[str] = None,
    data: Optional[dict] = None,
) -> Notification:
    notification = Notification(
        user_id=user_id,
        type=type,
        title=title,
        message=message,
        data=data or {},
    )
    db.add(notification)
    await db.flush()

    notif_response = await _build_notification_response(notification)
    payload = notif_response.model_dump(mode="json")
    await ws_manager.send_to_user(
        user_id,
        {
            "event": "new_notification",
            "type": "new_notification",
            "data": payload,
            "payload": payload,
        },
    )

    return notification


@router.get("", response_model=SuccessResponse)
async def list_my_notifications(
    is_read: Optional[bool] = Query(None, description="Filter by read status"),
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(20, ge=1, le=100, description="Items per page"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    conditions = [Notification.user_id == current_user.id]
    if is_read is not None:
        conditions.append(Notification.is_read == is_read)

    where_clause = and_(*conditions)

    count_stmt = select(func.count(Notification.id)).where(where_clause)
    total_result = await db.execute(count_stmt)
    total = total_result.scalar() or 0

    unread_stmt = select(func.count(Notification.id)).where(
        and_(Notification.user_id == current_user.id, Notification.is_read == False)
    )
    unread_result = await db.execute(unread_stmt)
    unread_count = unread_result.scalar() or 0

    offset = (page - 1) * limit
    stmt = (
        select(Notification)
        .where(where_clause)
        .order_by(Notification.created_at.desc())
        .offset(offset)
        .limit(limit)
    )
    result = await db.execute(stmt)
    notifications = result.scalars().all()

    items = []
    for n in notifications:
        items.append(await _build_notification_response(n))

    total_pages = math.ceil(total / limit) if limit > 0 else 0

    return SuccessResponse(
        data=PaginatedNotificationsResponse(
            items=items,
            total=total,
            page=page,
            per_page=limit,
            total_pages=total_pages,
            unread_count=unread_count,
        )
    )


@router.get("/{notification_id}", response_model=SuccessResponse)
async def get_notification(
    notification_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Notification).where(
            and_(Notification.id == notification_id, Notification.user_id == current_user.id)
        )
    )
    notification = result.scalar_one_or_none()

    if not notification:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Notification tidak ditemukan",
        )

    data = await _build_notification_response(notification)
    return SuccessResponse(data=data)


@router.put("/{notification_id}/read", response_model=SuccessResponse)
async def mark_notification_read(
    notification_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Notification).where(
            and_(Notification.id == notification_id, Notification.user_id == current_user.id)
        )
    )
    notification = result.scalar_one_or_none()

    if not notification:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Notification tidak ditemukan",
        )

    notification.is_read = True
    notification.read_at = datetime.now()
    await db.commit()
    await db.refresh(notification)

    data = await _build_notification_response(notification)
    try:
        await ws_manager.send_to_user(
            current_user.id,
            {
                "event": "mark_read",
                "type": "mark_read",
                "notification_id": str(notification_id),
                "data": data.model_dump(mode="json"),
            },
        )
    except Exception:
        pass
    return SuccessResponse(data=data)


@router.put("/read-all", response_model=SuccessResponse)
async def mark_all_notifications_read(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    stmt = (
        update(Notification)
        .where(
            and_(
                Notification.user_id == current_user.id,
                Notification.is_read == False,
            )
        )
        .values(is_read=True, read_at=datetime.now())
    )
    result = await db.execute(stmt)
    await db.commit()
    updated_count = result.rowcount or 0

    try:
        await ws_manager.send_to_user(
            current_user.id,
            {
                "event": "mark_all_read",
                "type": "mark_all_read",
                "marked_read": updated_count,
            },
        )
    except Exception:
        pass

    return SuccessResponse(data={"marked_read": updated_count})


# Rute statis HARUS dideklarasikan sebelum /{notification_id}.
@router.delete("/read", response_model=SuccessResponse)
async def delete_read_notifications(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    stmt = delete(Notification).where(
        and_(
            Notification.user_id == current_user.id,
            Notification.is_read == True,
        )
    )
    result = await db.execute(stmt)
    await db.commit()
    deleted_count = result.rowcount or 0

    return SuccessResponse(data={"deleted": deleted_count})


@router.delete("/{notification_id}", response_model=SuccessResponse)
async def delete_notification(
    notification_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Notification).where(
            and_(Notification.id == notification_id, Notification.user_id == current_user.id)
        )
    )
    notification = result.scalar_one_or_none()

    if not notification:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Notification tidak ditemukan",
        )

    await db.delete(notification)
    await db.commit()

    return SuccessResponse(data={"message": "Notification berhasil dihapus"})


@router.post("/send", response_model=SuccessResponse)
@router.post("/send-many", response_model=SuccessResponse)
async def send_notifications(
    request: NotificationSendMany,
    http_request: Request,
    current_user: User = Depends(require_permission("notifications.send")),
    db: AsyncSession = Depends(get_db),
):
    user_ids = list(dict.fromkeys(request.user_ids))
    if len(user_ids) > 1000:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Maksimal 1000 penerima per kiriman")
    existing = await db.execute(select(User.id).where(User.id.in_(user_ids)))
    user_ids = [row[0] for row in existing.all()]
    created_notifications = []
    for uid in user_ids:
        notif = await _create_notification(
            db=db,
            user_id=uid,
            type=request.type,
            title=request.title,
            message=request.message,
            data=request.data,
        )
        created_notifications.append(notif)

    await record_audit(
        db, current_user, "create", "system", "notification", None,
        {"action": "send", "recipients": len(user_ids), "title": request.title}, http_request,
    )
    await db.commit()

    responses = []
    for n in created_notifications:
        responses.append(await _build_notification_response(n))

    return SuccessResponse(data={"sent_count": len(responses), "notifications": responses})


@router.post("/broadcast", response_model=SuccessResponse)
async def broadcast_notification(
    request: NotificationBroadcast,
    http_request: Request,
    current_user: User = Depends(require_permission("notifications.send")),
    db: AsyncSession = Depends(get_db),
):
    users_stmt = select(User.id).where(User.status == "ACTIVE")
    users_result = await db.execute(users_stmt)
    all_user_ids = [row[0] for row in users_result.all()]

    created_notifications = []
    for uid in all_user_ids:
        notif = await _create_notification(
            db=db,
            user_id=uid,
            type=request.type,
            title=request.title,
            message=request.message,
            data=request.data,
        )
        created_notifications.append(notif)

    await record_audit(
        db, current_user, "create", "system", "notification", None,
        {"action": "broadcast", "recipients": len(created_notifications), "title": request.title}, http_request,
    )
    await db.commit()

    return SuccessResponse(
        data={"sent_count": len(created_notifications), "broadcast_count": len(created_notifications), "title": request.title}
    )



