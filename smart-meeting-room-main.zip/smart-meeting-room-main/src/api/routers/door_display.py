from fastapi import APIRouter, Body, Depends, HTTPException, Request, status, Query, WebSocket
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, func
from typing import Optional, List, Dict, Any
from collections import defaultdict
from uuid import UUID, uuid4
from datetime import datetime, date, time, timedelta
import hmac
import logging
import secrets

from src.api.database import get_db, async_session
from src.api.models.user import User
from src.api.models.room import Room
from src.api.models.booking import Booking, BookingParticipant
from src.api.schemas.door_display import (
    SuccessResponse,
    DoorDisplayRoomStatus,
    DoorDisplayCurrentMeeting,
    DoorDisplayUpcomingMeeting,
    DoorDisplayBookingItem,
    DoorDisplayTodayBookingsResponse,
    DoorDisplayCheckInResponse,
    DoorDisplayExtendResponse,
)
from src.api.schemas.note import (
    QuickBookingRequest,
    QuickBookingResponse,
    TimeSlot,
    DoorAvailableSlotsResponse,
    DoorCancelBookingResponse,
    WelcomeMessageResponse,
)
from src.api.schemas.room import KioskPairRequest, EarlyReleaseRequest
from src.api.utils.audit import client_ip, record_audit
from src.api.utils.auth import verify_password
from src.api.utils.kiosk import (
    create_kiosk_token,
    kiosk_token_from_request,
    optional_user,
    pin_lockout,
    verify_kiosk_token,
)
from src.api.utils.permissions import has_permission, require_permission
from src.api.utils.rate_limit import rate_limiter

router = APIRouter(prefix="/door-display", tags=["Door Display"])
logger = logging.getLogger("smr.door_display")


class DoorDisplayWSManager:
    def __init__(self):
        self.active_connections: Dict[str, List[WebSocket]] = defaultdict(list)

    async def connect(self, room_code: str, websocket: WebSocket):
        await websocket.accept()
        self.active_connections[room_code].append(websocket)

    def disconnect(self, room_code: str, websocket: WebSocket):
        if websocket in self.active_connections[room_code]:
            self.active_connections[room_code].remove(websocket)
        if not self.active_connections[room_code]:
            del self.active_connections[room_code]

    async def broadcast_room(self, room_code: str, message: dict):
        if room_code in self.active_connections:
            for conn in list(self.active_connections[room_code]):
                try:
                    await conn.send_json(message)
                except Exception:
                    self.disconnect(room_code, conn)


door_ws_manager = DoorDisplayWSManager()


def _minutes_remaining(end_time: time) -> int:
    now = datetime.now()
    end_dt = datetime.combine(date.today(), end_time)
    remaining = (end_dt - now).total_seconds() / 60
    return max(0, int(remaining))


async def _get_status_payload(db: AsyncSession, room: Room) -> Optional[Dict[str, Any]]:
    """Recompute status payload same as GET /status/{room_code}."""
    today = date.today()
    now_time = datetime.now().time()

    current_stmt = (
        select(Booking, User)
        .join(User, Booking.user_id == User.id)
        .where(
            and_(
                Booking.room_id == room.id,
                Booking.date == today,
                Booking.status == "approved",
                Booking.start_time <= now_time,
                Booking.end_time >= now_time,
            )
        )
        .limit(1)
    )
    current_res = await db.execute(current_stmt)
    cur = current_res.one_or_none()
    current_meeting = None
    if cur:
        b, host = cur
        pc_stmt = select(func.count(BookingParticipant.id)).where(BookingParticipant.booking_id == b.id)
        pc_res = await db.execute(pc_stmt)
        pc = pc_res.scalar() or 0
        current_meeting = {
            "booking_id": str(b.id),
            "title": b.title,
            "participants_count": pc,
            "start_time": b.start_time.strftime("%H:%M"),
            "end_time": b.end_time.strftime("%H:%M"),
            "minutes_remaining": _minutes_remaining(b.end_time),
            "host_name": host.name,
            "status": b.status,
        }

    upcoming_stmt = (
        select(Booking, User)
        .join(User, Booking.user_id == User.id)
        .where(
            and_(
                Booking.room_id == room.id,
                Booking.date == today,
                Booking.status == "approved",
                Booking.start_time > now_time,
            )
        )
        .order_by(Booking.start_time.asc())
        .limit(3)
    )
    upcoming_res = await db.execute(upcoming_stmt)
    ups = upcoming_res.all()
    next_upcoming = []
    for b, host in ups:
        next_upcoming.append({
            "booking_id": str(b.id),
            "title": b.title,
            "start_time": b.start_time.strftime("%H:%M"),
            "end_time": b.end_time.strftime("%H:%M"),
            "host_name": host.name,
        })

    if current_meeting:
        room_status = "occupied"
    elif next_upcoming:
        first_start = next_upcoming[0]["start_time"]
        try:
            now_dt = datetime.combine(today, now_time)
            fh, fm = first_start.split(":")
            first_dt = datetime.combine(today, time(int(fh), int(fm)))
            if (first_dt - now_dt).total_seconds() <= 600:
                room_status = "soon"
            else:
                room_status = "available"
        except Exception:
            room_status = "available"
    else:
        room_status = "available"

    return {
        "room_id": str(room.id),
        "room_name": room.name,
        "room_code": room.code,
        "capacity": room.capacity,
        "room_status": room_status,
        "current_meeting": current_meeting,
        "next_upcoming": next_upcoming,
    }


# ============================================================
# Autentikasi kiosk
# ============================================================
KIOSK_USERNAME = "kiosk"
WALK_IN_GRACE_MINUTES = 15


class KioskPinBody(BaseModel):
    pin: Optional[str] = Field(None, max_length=8)


async def _room_by_code(db: AsyncSession, room_code: str) -> Room:
    room = (await db.execute(select(Room).where(Room.code == room_code))).scalar_one_or_none()
    if not room:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Room tidak ditemukan")
    return room


async def _kiosk_or_user_room(
    db: AsyncSession, request: Request, room_code: str, user: Optional[User], *codes: str
) -> Room:
    """Izinkan kiosk yang dipasangkan ke ruangan ini, atau user login (dengan izin `codes` bila diberikan)."""
    token = kiosk_token_from_request(request)
    if token:
        return await verify_kiosk_token(db, token, room_code)
    if user is not None and (not codes or has_permission(user, *codes)):
        return await _room_by_code(db, room_code)
    await verify_kiosk_token(db, None)  # -> 401 KIOSK_UNPAIRED
    raise AssertionError("unreachable")


async def _kiosk_room_for_booking(db: AsyncSession, request: Request, booking: Booking) -> Room:
    room = await verify_kiosk_token(db, kiosk_token_from_request(request))
    if booking.room_id != room.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "KIOSK_ROOM_MISMATCH", "message": "Booking bukan milik ruangan kiosk ini"},
        )
    return room


def _check_pin(request: Request, room: Room, pin: Optional[str], required: bool) -> None:
    """Verifikasi Master PIN ruangan dengan rate limit per IP + lockout per ruangan."""
    if not room.master_pin_hash:
        if required:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Master PIN kiosk belum diatur untuk ruangan ini",
            )
        return
    key = f"room:{room.id}"
    pin_lockout.check(key)
    ip = client_ip(request) or "unknown"
    rate_limiter.hit(f"kiosk-pin:{ip}", limit=10, window_seconds=60)
    if not pin or not verify_password(pin, room.master_pin_hash):
        left = pin_lockout.fail(key)
        msg = "Master PIN diperlukan" if not pin else "Master PIN salah"
        if left:
            msg += f" (sisa {left} percobaan)"
        else:
            msg += ". Kiosk dikunci 15 menit."
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail={"code": "PIN_INVALID", "message": msg})
    pin_lockout.success(key)


async def _kiosk_user_id(db: AsyncSession) -> UUID:
    """Akun sistem 'kiosk' sebagai pemilik booking walk-in (dibuat migrasi 012)."""
    uid = (await db.execute(select(User.id).where(User.username == KIOSK_USERNAME))).scalar_one_or_none()
    if uid:
        return uid
    kiosk = User(
        username=KIOSK_USERNAME,
        password_hash="!" + secrets.token_hex(16),  # bukan hash bcrypt -> tidak bisa login
        name="Kiosk Display",
        email="kiosk@system.local",
        position="Akun sistem (booking walk-in)",
        status="ACTIVE",
    )
    db.add(kiosk)
    await db.flush()
    return kiosk.id


async def _broadcast_status(db: AsyncSession, room: Room, extra: Optional[dict] = None) -> None:
    try:
        payload_raw = await _get_status_payload(db, room)
        if payload_raw:
            await door_ws_manager.broadcast_room(
                room.code,
                {"event": "status_changed", "data": payload_raw, "timestamp": datetime.now().isoformat()},
            )
        if extra:
            await door_ws_manager.broadcast_room(room.code, {**extra, "timestamp": datetime.now().isoformat()})
    except Exception:  # noqa: BLE001 - broadcast best effort
        logger.debug("Broadcast door display gagal", exc_info=True)


# ============================================================
# STATUS & KONTEN
# ============================================================

@router.get("/status/{room_code}", response_model=SuccessResponse)
async def get_room_status(
    room_code: str,
    request: Request,
    user: Optional[User] = Depends(optional_user),
    db: AsyncSession = Depends(get_db),
):
    room = await _kiosk_or_user_room(db, request, room_code, user)
    status_payload = await _get_status_payload(db, room)
    return SuccessResponse(data=status_payload)


# Konten welcome message per ruangan (in-memory).
WELCOME_STORE: Dict[str, WelcomeMessageResponse] = {}


@router.get("/{room_code}/welcome-message", response_model=SuccessResponse)
async def get_welcome_message(
    room_code: str,
    request: Request,
    user: Optional[User] = Depends(optional_user),
    db: AsyncSession = Depends(get_db),
):
    room = await _kiosk_or_user_room(db, request, room_code, user)
    if room_code in WELCOME_STORE:
        return SuccessResponse(data=WELCOME_STORE[room_code])
    return SuccessResponse(data=WelcomeMessageResponse(
        room_id=room.id,
        title=f"Selamat Datang di {room.name}",
        subtitle="Silakan masuk untuk menggunakan ruangan",
        custom_message="Untuk booking cepat, gunakan tombol Booking di layar.",
        show_weather=False,
        show_clock=True,
    ))


@router.put("/{room_code}/welcome-message", response_model=SuccessResponse)
async def update_welcome_message(
    room_code: str,
    msg: WelcomeMessageResponse,
    current_user: User = Depends(require_permission("door_display.manage")),
    db: AsyncSession = Depends(get_db),
):
    room = await _room_by_code(db, room_code)
    msg.room_id = room.id
    WELCOME_STORE[room_code] = msg
    return SuccessResponse(data=msg)


@router.get("/{room_code}/bookings/today", response_model=SuccessResponse)
async def get_today_bookings(
    room_code: str,
    request: Request,
    user: Optional[User] = Depends(optional_user),
    db: AsyncSession = Depends(get_db),
):
    room = await _kiosk_or_user_room(db, request, room_code, user, "bookings.view")
    today = date.today()

    bookings_stmt = (
        select(Booking, User)
        .join(User, Booking.user_id == User.id)
        .where(
            and_(
                Booking.room_id == room.id,
                Booking.date == today,
                Booking.status.in_(["approved", "pending", "completed"]),
            )
        )
        .order_by(Booking.start_time.asc())
    )
    rows = (await db.execute(bookings_stmt)).all()

    booking_items = []
    for booking, host in rows:
        participants_count = (await db.execute(
            select(func.count(BookingParticipant.id)).where(BookingParticipant.booking_id == booking.id)
        )).scalar() or 0
        booking_items.append(
            DoorDisplayBookingItem(
                booking_id=booking.id,
                title=booking.title,
                start_time=booking.start_time,
                end_time=booking.end_time,
                host_name=host.name,
                status=booking.status,
                participants_count=participants_count,
            )
        )

    return SuccessResponse(
        data=DoorDisplayTodayBookingsResponse(
            room_id=room.id,
            room_name=room.name,
            date=today,
            bookings=booking_items,
        )
    )


@router.post("/checkin/{booking_id}", response_model=SuccessResponse)
async def participant_checkin(
    booking_id: UUID,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """(Lama) check-in peserta pertama. Presensi per tiket: gunakan /presensi/scan."""
    booking = (await db.execute(select(Booking).where(Booking.id == booking_id))).scalar_one_or_none()
    if not booking:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Booking tidak ditemukan")
    await _kiosk_room_for_booking(db, request, booking)
    if booking.status != "approved" or booking.date != date.today():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Check-in hanya untuk rapat disetujui hari ini")

    p_stmt = (
        select(BookingParticipant, User)
        .outerjoin(User, BookingParticipant.user_id == User.id)
        .where(BookingParticipant.booking_id == booking_id)
        .order_by(BookingParticipant.created_at.asc())
        .limit(1)
    )
    p_row = (await db.execute(p_stmt)).one_or_none()
    if not p_row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Participant tidak ditemukan untuk booking ini",
        )

    participant, user = p_row
    participant.attended = True
    participant.checked_in_at = datetime.now()
    await db.commit()
    await db.refresh(participant)

    name = user.name if user else (participant.guest_name or "Guest")
    return SuccessResponse(
        data=DoorDisplayCheckInResponse(
            participant_id=participant.id,
            name=name,
            attended=participant.attended,
            checked_in_at=participant.checked_in_at,
        )
    )


@router.post("/extent/{booking_id}", response_model=SuccessResponse)
@router.post("/extend/{booking_id}", response_model=SuccessResponse)
async def extend_booking(
    booking_id: UUID,
    request: Request,
    minutes: int = Query(30, ge=1, le=120, description="Menit perpanjangan"),
    body: Optional[KioskPinBody] = Body(None),
    db: AsyncSession = Depends(get_db),
):
    """Perpanjang rapat yang sedang berjalan. Wajib token kiosk + Master PIN (bila diatur)."""
    booking = (await db.execute(select(Booking).where(Booking.id == booking_id))).scalar_one_or_none()
    if not booking:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Booking tidak ditemukan")
    room = await _kiosk_room_for_booking(db, request, booking)
    _check_pin(request, room, body.pin if body else None, required=False)

    today = date.today()
    if booking.date != today or booking.status != "approved":
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Hanya rapat disetujui hari ini yang dapat diperpanjang")

    old_end = booking.end_time
    new_end_dt = datetime.combine(booking.date, old_end) + timedelta(minutes=minutes)
    if new_end_dt.date() != booking.date:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Perpanjangan melewati tengah malam")
    new_end_time = new_end_dt.time()

    next_conflict_stmt = (
        select(Booking)
        .where(
            and_(
                Booking.room_id == booking.room_id,
                Booking.date == today,
                Booking.id != booking.id,
                Booking.status.in_(["approved", "pending"]),
                Booking.start_time < new_end_time,
                Booking.start_time >= old_end,
            )
        )
        .order_by(Booking.start_time.asc())
        .limit(1)
    )
    conflict = (await db.execute(next_conflict_stmt)).scalar_one_or_none()
    if conflict:
        # Jangan bocorkan judul rapat lain.
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Tidak dapat diperpanjang: ruangan sudah dipesan mulai jam {conflict.start_time.strftime('%H:%M')}",
        )

    booking.end_time = new_end_time
    await db.commit()
    await db.refresh(booking)

    await _broadcast_status(db, room, {
        "event": "booking_extended", "booking_id": str(booking.id),
        "new_end_time": new_end_time.strftime("%H:%M"),
    })

    data = DoorDisplayExtendResponse(
        booking_id=booking.id,
        title=booking.title,
        old_end_time=old_end,
        new_end_time=new_end_time,
        extended_minutes=minutes,
    ).model_dump(mode="json")
    data.update({"success": True, "message": f"Rapat diperpanjang {minutes} menit",
                 "new_end_time": new_end_time.strftime("%H:%M")})
    return SuccessResponse(data=data)


# ============================================================
# 16_02 BOOKING ENDPOINTS - Quick / Available / Cancel
# ============================================================
@router.get("/{room_code}/available-slots", response_model=SuccessResponse)
async def get_available_slots(
    room_code: str,
    request: Request,
    interval_minutes: int = Query(30, ge=5, le=120),
    day_start: str = Query("07:00"),
    day_end: str = Query("20:00"),
    user: Optional[User] = Depends(optional_user),
    db: AsyncSession = Depends(get_db),
):
    room = await _kiosk_or_user_room(db, request, room_code, user)

    today = date.today()
    try:
        sh, sm = day_start.split(":")
        eh, em = day_end.split(":")
        d_start = time(int(sh), int(sm))
        d_end = time(int(eh), int(em))
    except Exception:  # noqa: BLE001
        d_start = time(7, 0)
        d_end = time(20, 0)

    bookings_stmt = (
        select(Booking)
        .where(and_(Booking.room_id == room.id, Booking.date == today, Booking.status.in_(["approved", "pending"])))
        .order_by(Booking.start_time.asc())
    )
    bookings = list((await db.execute(bookings_stmt)).scalars().all())

    slots: List[TimeSlot] = []
    current = datetime.combine(today, d_start)
    end_day = datetime.combine(today, d_end)
    while current < end_day:
        slot_end_dt = current + timedelta(minutes=interval_minutes)
        s_t = current.time()
        e_t = slot_end_dt.time()
        conflict_booking: Optional[Booking] = None
        for b in bookings:
            if not (b.end_time <= s_t or b.start_time >= e_t):
                conflict_booking = b
                break
        slots.append(TimeSlot(
            start=current.strftime("%H:%M"),
            end=slot_end_dt.strftime("%H:%M"),
            available=(conflict_booking is None),
            booking_id=None,
        ))
        current = slot_end_dt

    return SuccessResponse(
        data=DoorAvailableSlotsResponse(room_id=room.id, date=today, slots=slots)
    )


@router.post("/{room_code}/book", response_model=SuccessResponse)
async def quick_book_room(
    room_code: str,
    req: QuickBookingRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Booking cepat dari kiosk. Walk-in (mulai <= 15 menit lagi) langsung disetujui;
    slot yang lebih jauh berstatus pending (menunggu persetujuan)."""
    room = await verify_kiosk_token(db, kiosk_token_from_request(request), room_code)
    rate_limiter.hit(f"kiosk-book:{room.id}", limit=20, window_seconds=3600)

    title = (req.title or "").strip()[:200] or "Walk-in Meeting"
    booked_by = (req.booked_by or "Walk-in Guest").strip()[:100]

    today = date.today()
    try:
        sh, sm = req.start_time.split(":")
        s_time = time(int(sh), int(sm))
    except Exception:  # noqa: BLE001
        raise HTTPException(status_code=400, detail="start_time format harus HH:MM")

    now = datetime.now()
    s_dt = datetime.combine(today, s_time)
    e_dt = s_dt + timedelta(minutes=req.duration_minutes)
    if e_dt.date() != today:
        raise HTTPException(status_code=400, detail="Booking tidak boleh melewati tengah malam")
    if e_dt <= now:
        raise HTTPException(status_code=400, detail="Waktu booking sudah lewat")
    e_time = e_dt.time()

    conflict_stmt = (
        select(Booking.id)
        .where(
            and_(
                Booking.room_id == room.id,
                Booking.date == today,
                Booking.status.in_(["approved", "pending"]),
                Booking.start_time < e_time,
                Booking.end_time > s_time,
            )
        )
        .limit(1)
    )
    if (await db.execute(conflict_stmt)).scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Slot tersebut sudah terpakai. Pilih waktu lain.")

    walk_in = s_dt <= now + timedelta(minutes=WALK_IN_GRACE_MINUTES)
    kiosk_uid = await _kiosk_user_id(db)
    new_booking = Booking(
        room_id=room.id,
        user_id=kiosk_uid,
        created_by=kiosk_uid,
        title=title,
        date=today,
        start_time=s_time,
        end_time=e_time,
        status="approved" if walk_in else "pending",
        approved_at=datetime.now() if walk_in else None,
        description=f"[kiosk] Quick booking via door display. Dipesan oleh: {booked_by}",
        attendees=1,
    )
    db.add(new_booking)
    await db.flush()
    await record_audit(db, None, "create", "bookings", "booking", new_booking.id,
                       {"source": "kiosk", "room_code": room.code, "status": new_booking.status, "booked_by": booked_by},
                       request)
    await db.commit()
    await db.refresh(new_booking)

    await _broadcast_status(db, room, {
        "event": "booking_created", "booking_id": str(new_booking.id), "title": new_booking.title,
    })

    data = QuickBookingResponse(
        booking_id=new_booking.id,
        title=new_booking.title,
        room_id=room.id,
        room_name=room.name,
        start_time=s_time,
        end_time=e_time,
        status=new_booking.status,
    ).model_dump(mode="json")
    data["success"] = True
    data["message"] = (
        "Booking walk-in berhasil" if walk_in else "Booking tercatat dan menunggu persetujuan admin"
    )
    return SuccessResponse(data=data)


@router.post("/{room_code}/cancel/{booking_id}", response_model=SuccessResponse)
async def cancel_booking_from_door(
    room_code: str,
    booking_id: UUID,
    request: Request,
    body: Optional[KioskPinBody] = Body(None),
    db: AsyncSession = Depends(get_db),
):
    """Batalkan rapat dari kiosk. Wajib token kiosk + Master PIN (bila diatur)."""
    room = await verify_kiosk_token(db, kiosk_token_from_request(request), room_code)
    _check_pin(request, room, body.pin if body else None, required=False)

    b_stmt = select(Booking).where(and_(Booking.id == booking_id, Booking.room_id == room.id))
    booking = (await db.execute(b_stmt)).scalar_one_or_none()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking tidak ditemukan untuk ruangan ini")
    if booking.status in ("cancelled", "completed", "rejected"):
        raise HTTPException(status_code=400, detail=f"Booking berstatus {booking.status} tidak dapat dibatalkan")

    old_status = booking.status
    booking.status = "cancelled"
    await record_audit(db, None, "cancel", "bookings", "booking", booking.id,
                       {"source": "kiosk", "room_code": room.code}, request, old_value={"status": old_status})
    await db.commit()
    await db.refresh(booking)

    await _broadcast_status(db, room, {"event": "booking_cancelled", "booking_id": str(booking.id)})

    data = DoorCancelBookingResponse(
        booking_id=booking.id,
        title=booking.title,
        cancelled=True,
        message="Booking berhasil dibatalkan via door display",
    ).model_dump(mode="json")
    data["success"] = True
    return SuccessResponse(data=data)


# ============================================================
# KIOSK SECURITY - Pairing (DSP-09) & Early Release via PIN (DSP-07)
# ============================================================
@router.post("/pair", response_model=SuccessResponse)
async def kiosk_pair(
    req: KioskPairRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """DSP-09: verifikasi pairing key lalu terbitkan token kiosk untuk ruangan tsb."""
    ip = client_ip(request) or "unknown"
    rate_limiter.hit(f"kiosk-pair:{ip}", limit=10, window_seconds=300)

    room = (await db.execute(select(Room).where(Room.code == req.room_code))).scalar_one_or_none()
    supplied = req.pairing_key.strip().upper()
    if not room or not room.pairing_key or not hmac.compare_digest(supplied, room.pairing_key):
        # Pesan sama untuk ruangan tidak ada / key salah (hindari enumerasi).
        rate_limiter.hit(f"kiosk-pair-fail:{req.room_code}", limit=20, window_seconds=900)
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Pairing key tidak cocok. Hubungi admin untuk kunci yang valid.",
        )

    token, expires = create_kiosk_token(room)
    return SuccessResponse(
        data={
            "room_id": str(room.id),
            "room_code": room.code,
            "room_name": room.name,
            "paired": True,
            "has_master_pin": bool(room.master_pin_hash),
            "kiosk_token": token,
            "expires_at": expires.isoformat(),
        }
    )


@router.post("/early-release/{booking_id}", response_model=SuccessResponse)
async def early_release_booking(
    booking_id: UUID,
    req: EarlyReleaseRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """DSP-07: buka ruangan lebih awal dengan Master PIN kiosk.

    Booking draft/pending langsung disetujui; booking approved yang belum mulai
    tetap dipastikan tampil sebagai rapat berjalan di kiosk.
    """
    booking = (await db.execute(select(Booking).where(Booking.id == booking_id))).scalar_one_or_none()
    if not booking:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Booking tidak ditemukan")
    room = await _kiosk_room_for_booking(db, request, booking)
    _check_pin(request, room, req.pin, required=True)

    if booking.status in ("cancelled", "completed", "rejected"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Booking berstatus {booking.status} tidak dapat di-release",
        )
    if booking.date != date.today():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Hanya rapat hari ini yang dapat di-release")

    was_pending = booking.status in ("draft", "pending")
    old_status = booking.status
    booking.status = "approved"
    if was_pending:
        booking.approved_at = datetime.now()
    await record_audit(db, None, "approve", "bookings", "booking", booking.id,
                       {"source": "kiosk_early_release", "room_code": room.code}, request,
                       old_value={"status": old_status})
    await db.commit()
    await db.refresh(booking)

    try:
        payload_raw = await _get_status_payload(db, room)
        if payload_raw:
            await door_ws_manager.broadcast_room(
                room.code,
                {
                    "event": "early_released" if was_pending else "status_changed",
                    "booking_id": str(booking.id),
                    "title": booking.title,
                    "data": payload_raw,
                    "timestamp": datetime.now().isoformat(),
                },
            )
    except Exception:  # noqa: BLE001
        pass

    return SuccessResponse(
        data={
            "booking_id": str(booking.id),
            "title": booking.title,
            "room_code": room.code,
            "status": booking.status,
            "success": True,
            "message": f"Ruangan dibuka lebih awal untuk rapat \"{booking.title}\"",
        }
    )
