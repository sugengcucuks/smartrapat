from fastapi import APIRouter, Depends, HTTPException, status, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_, and_
from typing import Optional
from uuid import UUID
import math
import secrets

from src.api.database import get_db
from src.api.models.user import User
from src.api.models.room import Building, Room
from src.api.schemas.room import (
    SuccessResponse,
    BuildingCreate,
    BuildingUpdate,
    BuildingResponse,
    RoomCreate,
    RoomUpdate,
    RoomResponse,
    PaginatedRoomsResponse,
    PairingKeyResponse,
    MasterPinSetRequest,
    MasterPinResponse,
)
from src.api.utils.auth import get_current_user, get_password_hash
from src.api.utils.audit import record_audit
from src.api.utils.permissions import require_permission

router = APIRouter(tags=["Rooms & Buildings"])

PAIRING_ALPHABET = "23456789ABCDEFGHIJKMNOPQRSTUVWXYZ"
def _generate_pairing_key() -> str:
    return "RM-" + "".join(secrets.choice(PAIRING_ALPHABET) for _ in range(6))


async def _generate_unique_pairing_key(db: AsyncSession) -> str:
    for _ in range(20):
        key = _generate_pairing_key()
        existing = await db.execute(select(Room).where(Room.pairing_key == key))
        if not existing.scalar_one_or_none():
            return key
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail="Gagal membuat pairing key unik",
    )


# ============================================
# Building Endpoints
# ============================================

@router.get("/buildings", response_model=SuccessResponse)
async def list_buildings(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    stmt = select(Building).order_by(Building.name.asc())
    result = await db.execute(stmt)
    buildings = result.scalars().all()

    items = [
        BuildingResponse(
            id=b.id,
            name=b.name,
            code=b.code,
            floors=b.floors,
            address=b.address,
            created_at=b.created_at,
            updated_at=b.updated_at,
        )
        for b in buildings
    ]

    return SuccessResponse(data=items)


@router.post("/buildings", response_model=SuccessResponse)
async def create_building(
    request: BuildingCreate,
    current_user: User = Depends(require_permission("rooms.write")),
    db: AsyncSession = Depends(get_db),
):
    existing_code = await db.execute(select(Building).where(Building.code == request.code))
    if existing_code.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Kode building sudah digunakan",
        )

    existing_name = await db.execute(select(Building).where(Building.name == request.name))
    if existing_name.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Nama building sudah digunakan",
        )

    new_building = Building(
        name=request.name,
        code=request.code,
        floors=request.floors,
        address=request.address,
    )

    db.add(new_building)
    await db.commit()
    await db.refresh(new_building)

    building_data = BuildingResponse(
        id=new_building.id,
        name=new_building.name,
        code=new_building.code,
        floors=new_building.floors,
        address=new_building.address,
        created_at=new_building.created_at,
        updated_at=new_building.updated_at,
    )

    return SuccessResponse(data=building_data)


@router.put("/buildings/{building_id}", response_model=SuccessResponse)
async def update_building(
    building_id: UUID,
    request: BuildingUpdate,
    current_user: User = Depends(require_permission("rooms.write")),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Building).where(Building.id == building_id))
    building = result.scalar_one_or_none()

    if not building:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Building tidak ditemukan",
        )

    if request.code and request.code != building.code:
        existing = await db.execute(select(Building).where(Building.code == request.code))
        if existing.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Kode building sudah digunakan",
            )
        building.code = request.code

    if request.name and request.name != building.name:
        existing = await db.execute(select(Building).where(Building.name == request.name))
        if existing.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Nama building sudah digunakan",
            )
        building.name = request.name

    if request.floors is not None:
        building.floors = request.floors
    if request.address is not None:
        building.address = request.address

    await db.commit()
    await db.refresh(building)

    building_data = BuildingResponse(
        id=building.id,
        name=building.name,
        code=building.code,
        floors=building.floors,
        address=building.address,
        created_at=building.created_at,
        updated_at=building.updated_at,
    )

    return SuccessResponse(data=building_data)


@router.delete("/buildings/{building_id}", response_model=SuccessResponse)
async def delete_building(
    building_id: UUID,
    current_user: User = Depends(require_permission("rooms.write")),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Building).where(Building.id == building_id))
    building = result.scalar_one_or_none()

    if not building:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Building tidak ditemukan",
        )

    room_count_result = await db.execute(
        select(func.count(Room.id)).where(Room.building_id == building_id)
    )
    room_count = room_count_result.scalar() or 0
    if room_count > 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Building masih memiliki {room_count} ruangan, tidak dapat dihapus",
        )

    await db.delete(building)
    await db.commit()

    return SuccessResponse(data={"message": "Building berhasil dihapus"})


# ============================================
# Room Endpoints
# ============================================

@router.get("/rooms", response_model=SuccessResponse)
async def list_rooms(
    search: Optional[str] = Query(None, description="Search by name or code"),
    building_id: Optional[UUID] = Query(None, description="Filter by building ID"),
    status: Optional[str] = Query(None, description="Filter by status"),
    room_type: Optional[str] = Query(None, description="Filter by room type"),
    capacity_min: Optional[int] = Query(None, description="Minimum capacity", ge=1),
    page: int = Query(1, ge=1, description="Page number"),
    per_page: int = Query(10, ge=1, le=100, description="Items per page"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    conditions = []

    if search:
        search_pattern = f"%{search}%"
        conditions.append(
            or_(
                Room.name.ilike(search_pattern),
                Room.code.ilike(search_pattern),
            )
        )

    if building_id:
        conditions.append(Room.building_id == building_id)
    if status:
        conditions.append(Room.status == status)
    if room_type:
        conditions.append(Room.room_type == room_type)
    if capacity_min:
        conditions.append(Room.capacity >= capacity_min)

    where_clause = and_(*conditions) if conditions else True

    count_stmt = select(func.count(Room.id)).where(where_clause)
    total_result = await db.execute(count_stmt)
    total = total_result.scalar() or 0

    offset = (page - 1) * per_page
    stmt = (
        select(Room, Building)
        .outerjoin(Building, Room.building_id == Building.id)
        .where(where_clause)
        .order_by(Room.created_at.desc())
        .offset(offset)
        .limit(per_page)
    )
    result = await db.execute(stmt)
    rows = result.all()

    items = []
    for room, building in rows:
        items.append(
            RoomResponse(
                id=room.id,
                name=room.name,
                code=room.code,
                building_id=room.building_id,
                building_name=building.name if building else None,
                floor=room.floor,
                capacity=room.capacity,
                room_type=room.room_type,
                description=room.description,
                amenities=room.amenities or [],
                layout_url=room.layout_url,
                status=room.status,
                pairing_key=None,
                has_master_pin=bool(room.master_pin_hash),
                created_at=room.created_at,
                updated_at=room.updated_at,
            )
        )

    total_pages = math.ceil(total / per_page) if per_page > 0 else 0

    return SuccessResponse(
        data=PaginatedRoomsResponse(
            items=items,
            total=total,
            page=page,
            per_page=per_page,
            total_pages=total_pages,
        )
    )


@router.post("/rooms", response_model=SuccessResponse)
async def create_room(
    request: RoomCreate,
    current_user: User = Depends(require_permission("rooms.write")),
    db: AsyncSession = Depends(get_db),
):
    existing_code = await db.execute(select(Room).where(Room.code == request.code))
    if existing_code.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Kode ruangan sudah digunakan",
        )

    if request.building_id:
        building_check = await db.execute(select(Building).where(Building.id == request.building_id))
        if not building_check.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Building ID tidak valid",
            )

    new_room = Room(
        name=request.name,
        code=request.code,
        building_id=request.building_id,
        floor=request.floor,
        capacity=request.capacity,
        room_type=request.room_type,
        description=request.description,
        amenities=request.amenities or [],
        layout_url=request.layout_url,
        status=request.status,
        pairing_key=await _generate_unique_pairing_key(db),
    )

    db.add(new_room)
    await db.commit()
    await db.refresh(new_room)

    stmt = (
        select(Room, Building)
        .outerjoin(Building, Room.building_id == Building.id)
        .where(Room.id == new_room.id)
    )
    result = await db.execute(stmt)
    room, building = result.first()

    room_data = RoomResponse(
        id=room.id,
        name=room.name,
        code=room.code,
        building_id=room.building_id,
        building_name=building.name if building else None,
        floor=room.floor,
        capacity=room.capacity,
        room_type=room.room_type,
        description=room.description,
        amenities=room.amenities or [],
        layout_url=room.layout_url,
        status=room.status,
        pairing_key=None,
        has_master_pin=bool(room.master_pin_hash),
        created_at=room.created_at,
        updated_at=room.updated_at,
    )

    return SuccessResponse(data=room_data)


@router.get("/rooms/by-code/{room_code}", response_model=SuccessResponse)
async def get_room_by_code(
    room_code: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Cari ruangan berdasarkan kode (dipakai halaman QR & kontrol mobile)."""
    result = await db.execute(select(Room.id).where(Room.code == room_code))
    room_id = result.scalar_one_or_none()
    if not room_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ruangan tidak ditemukan",
        )
    return await get_room(room_id, current_user, db)


@router.get("/rooms/{room_id}", response_model=SuccessResponse)
async def get_room(
    room_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    stmt = (
        select(Room, Building)
        .outerjoin(Building, Room.building_id == Building.id)
        .where(Room.id == room_id)
    )
    result = await db.execute(stmt)
    row = result.first()

    if not row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ruangan tidak ditemukan",
        )

    room, building = row
    room_data = RoomResponse(
        id=room.id,
        name=room.name,
        code=room.code,
        building_id=room.building_id,
        building_name=building.name if building else None,
        floor=room.floor,
        capacity=room.capacity,
        room_type=room.room_type,
        description=room.description,
        amenities=room.amenities or [],
        layout_url=room.layout_url,
        status=room.status,
        created_at=room.created_at,
        updated_at=room.updated_at,
    )

    return SuccessResponse(data=room_data)


@router.put("/rooms/{room_id}", response_model=SuccessResponse)
async def update_room(
    room_id: UUID,
    request: RoomUpdate,
    current_user: User = Depends(require_permission("rooms.write")),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Room).where(Room.id == room_id))
    room = result.scalar_one_or_none()

    if not room:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ruangan tidak ditemukan",
        )

    if request.code and request.code != room.code:
        existing = await db.execute(select(Room).where(Room.code == request.code))
        if existing.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Kode ruangan sudah digunakan",
            )
        room.code = request.code

    if request.building_id is not None:
        if request.building_id:
            building_check = await db.execute(select(Building).where(Building.id == request.building_id))
            if not building_check.scalar_one_or_none():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Building ID tidak valid",
                )
        room.building_id = request.building_id

    if request.name is not None:
        room.name = request.name
    if request.floor is not None:
        room.floor = request.floor
    if request.capacity is not None:
        room.capacity = request.capacity
    if request.room_type is not None:
        room.room_type = request.room_type
    if request.description is not None:
        room.description = request.description
    if request.amenities is not None:
        room.amenities = request.amenities
    if request.layout_url is not None:
        room.layout_url = request.layout_url
    if request.status is not None:
        room.status = request.status

    await db.commit()
    await db.refresh(room)

    stmt = (
        select(Room, Building)
        .outerjoin(Building, Room.building_id == Building.id)
        .where(Room.id == room_id)
    )
    result = await db.execute(stmt)
    room_updated, building = result.first()

    room_data = RoomResponse(
        id=room_updated.id,
        name=room_updated.name,
        code=room_updated.code,
        building_id=room_updated.building_id,
        building_name=building.name if building else None,
        floor=room_updated.floor,
        capacity=room_updated.capacity,
        room_type=room_updated.room_type,
        description=room_updated.description,
        amenities=room_updated.amenities or [],
        layout_url=room_updated.layout_url,
        status=room_updated.status,
        pairing_key=None,
        has_master_pin=bool(room_updated.master_pin_hash),
        created_at=room_updated.created_at,
        updated_at=room_updated.updated_at,
    )

    return SuccessResponse(data=room_data)


@router.delete("/rooms/{room_id}", response_model=SuccessResponse)
async def delete_room(
    room_id: UUID,
    current_user: User = Depends(require_permission("rooms.write")),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Room).where(Room.id == room_id))
    room = result.scalar_one_or_none()

    if not room:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ruangan tidak ditemukan",
        )

    await db.delete(room)
    await db.commit()

    return SuccessResponse(data={"message": "Ruangan berhasil dihapus"})


# ============================================
# Kiosk Security (ADM-03 Pairing Key / ADM-04 Master PIN)
# ============================================

@router.get("/rooms/{room_id}/pairing-key", response_model=SuccessResponse)
async def get_pairing_key(
    room_id: UUID,
    current_user: User = Depends(require_permission("door_display.manage", "rooms.write")),
    db: AsyncSession = Depends(get_db),
):
    """Tampilkan pairing key kiosk (khusus admin). Tidak pernah ada di list/detail ruangan."""
    room = (await db.execute(select(Room).where(Room.id == room_id))).scalar_one_or_none()
    if not room:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Ruangan tidak ditemukan")
    if not room.pairing_key:
        room.pairing_key = await _generate_unique_pairing_key(db)
        await db.commit()
        await db.refresh(room)
    return SuccessResponse(
        data=PairingKeyResponse(room_id=room.id, room_code=room.code, pairing_key=room.pairing_key)
    )


@router.post("/rooms/{room_id}/pairing-key/regenerate", response_model=SuccessResponse)
async def regenerate_pairing_key(
    room_id: UUID,
    http_request: Request,
    current_user: User = Depends(require_permission("door_display.manage", "rooms.write")),
    db: AsyncSession = Depends(get_db),
):
    """ADM-03: buat ulang pairing key kiosk. Semua kiosk yang sudah dipasangkan
    dengan key lama otomatis tidak berlaku (token kiosk memuat hash key)."""

    result = await db.execute(select(Room).where(Room.id == room_id))
    room = result.scalar_one_or_none()
    if not room:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ruangan tidak ditemukan",
        )

    room.pairing_key = await _generate_unique_pairing_key(db)
    await record_audit(db, current_user, "update", "rooms", "room_pairing_key", room.id,
                       {"action": "regenerate_pairing_key", "room_code": room.code}, http_request)
    await db.commit()
    await db.refresh(room)

    return SuccessResponse(
        data=PairingKeyResponse(
            room_id=room.id,
            room_code=room.code,
            pairing_key=room.pairing_key,
        )
    )


@router.put("/rooms/{room_id}/master-pin", response_model=SuccessResponse)
async def set_master_pin(
    room_id: UUID,
    request: MasterPinSetRequest,
    http_request: Request,
    current_user: User = Depends(require_permission("door_display.manage", "rooms.write")),
    db: AsyncSession = Depends(get_db),
):
    """ADM-04: atur Master PIN kiosk (disimpan sebagai hash bcrypt, min. 6 digit)."""

    result = await db.execute(select(Room).where(Room.id == room_id))
    room = result.scalar_one_or_none()
    if not room:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ruangan tidak ditemukan",
        )

    room.master_pin_hash = get_password_hash(request.pin)
    await record_audit(db, current_user, "update", "rooms", "room_master_pin", room.id,
                       {"action": "set_master_pin", "room_code": room.code}, http_request)
    await db.commit()
    await db.refresh(room)

    return SuccessResponse(
        data=MasterPinResponse(
            room_id=room.id,
            room_code=room.code,
            has_master_pin=True,
            message="Master PIN kiosk berhasil disimpan",
        )
    )
