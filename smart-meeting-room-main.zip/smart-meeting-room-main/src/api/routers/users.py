from fastapi import APIRouter, Depends, HTTPException, status, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_, and_
from typing import Optional
from uuid import UUID
import math

from src.api.database import get_db
from src.api.models.user import User, Role, Department
from src.api.schemas.user import (
    SuccessResponse,
    ErrorResponse,
    DepartmentCreate,
    DepartmentUpdate,
    DepartmentResponse,
    UserCreate,
    UserUpdate,
    UserMeUpdate,
    PasswordUpdate,
    UserResponse,
    PaginatedUsersResponse,
)
from src.api.utils.auth import get_current_user, get_password_hash
from src.api.utils.audit import record_audit
from src.api.utils.permissions import (
    has_permission,
    is_super_admin,
    is_super_admin_role_name,
    normalize_permissions,
    require_permission,
    user_permissions,
)

router = APIRouter(prefix="/users", tags=["Users"])


# ============================================
# Helper Functions
# ============================================

async def _get_user_with_relations(db: AsyncSession, user_id: UUID) -> Optional[UserResponse]:
    stmt = (
        select(User, Role, Department)
        .outerjoin(Role, User.role_id == Role.id)
        .outerjoin(Department, User.department_id == Department.id)
        .where(User.id == user_id)
    )
    result = await db.execute(stmt)
    row = result.first()
    if not row:
        return None
    user, role, dept = row
    return UserResponse(
        id=user.id,
        username=user.username,
        name=user.name,
        email=user.email,
        nik=user.nik,
        rank=user.rank,
        position=user.position,
        role_id=user.role_id,
        role_name=role.name if role else None,
        department_id=user.department_id,
        department_name=dept.name if dept else None,
        avatar_url=user.avatar_url,
        phone=user.phone,
        status=user.status,
        last_login=user.last_login,
        login_attempts=user.login_attempts,
        created_at=user.created_at,
        updated_at=user.updated_at,
    )


async def _get_department_with_head(db: AsyncSession, dept_id: UUID) -> Optional[DepartmentResponse]:
    stmt = (
        select(Department, User)
        .outerjoin(User, Department.head_id == User.id)
        .where(Department.id == dept_id)
    )
    result = await db.execute(stmt)
    row = result.first()
    if not row:
        return None
    dept, head = row
    return DepartmentResponse(
        id=dept.id,
        name=dept.name,
        code=dept.code,
        head_id=dept.head_id,
        head_name=head.name if head else None,
        created_at=dept.created_at,
        updated_at=dept.updated_at,
    )


# ============================================
# Guard RBAC / anti eskalasi hak akses
# ============================================

# Field profil yang boleh diubah sendiri oleh user tanpa izin users.edit.
SELF_EDITABLE_FIELDS = {"name", "email", "phone", "avatar_url"}


def _forbidden(message: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail={"code": "FORBIDDEN", "message": message},
    )


def _role_is_super(role: Optional[Role]) -> bool:
    if role is None:
        return False
    return is_super_admin_role_name(role.name) or "*" in normalize_permissions(role.permissions or [])


async def _load_role(db: AsyncSession, role_id: Optional[UUID]) -> Optional[Role]:
    if not role_id:
        return None
    return (await db.execute(select(Role).where(Role.id == role_id))).scalar_one_or_none()


async def _ensure_can_assign_role(db: AsyncSession, actor: User, role_id: Optional[UUID]) -> None:
    """Non-super-admin hanya boleh memberi role yang izinnya subset izinnya sendiri."""
    if not role_id or is_super_admin(actor):
        return
    role = await _load_role(db, role_id)
    if role is None:
        return  # divalidasi terpisah (400)
    if _role_is_super(role):
        raise _forbidden("Hanya Super Admin yang dapat memberikan role Super Admin")
    extra = normalize_permissions(role.permissions or []) - user_permissions(actor)
    if extra:
        raise _forbidden("Tidak dapat memberikan role dengan izin melebihi izin Anda")


async def _ensure_can_manage_target(db: AsyncSession, actor: User, target: User) -> None:
    """Non-super-admin tidak boleh mengubah/menghapus akun Super Admin."""
    if is_super_admin(actor):
        return
    if _role_is_super(await _load_role(db, target.role_id)):
        raise _forbidden("Hanya Super Admin yang dapat mengelola akun Super Admin")


def _minimal_user(resp: UserResponse) -> UserResponse:
    """Versi direktori (untuk memilih peserta rapat) tanpa data sensitif."""
    return resp.model_copy(update={
        "nik": None, "rank": None, "phone": None, "last_login": None,
        "login_attempts": 0, "role_id": None, "role_name": None,
    })


# ============================================
# User Static Endpoints (list + me, NO param UUID)
# ============================================

@router.get("", response_model=SuccessResponse)
async def list_users(
    search: Optional[str] = Query(None, description="Search by name, username, email, nik"),
    role_id: Optional[UUID] = Query(None, description="Filter by role ID"),
    department_id: Optional[UUID] = Query(None, description="Filter by department ID"),
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    page: int = Query(1, ge=1, description="Page number"),
    per_page: int = Query(10, ge=1, le=100, description="Items per page"),
    current_user: User = Depends(require_permission("users.view", "bookings.create")),
    db: AsyncSession = Depends(get_db),
):
    # Tanpa users.view (mis. user biasa memilih peserta rapat) -> mode direktori:
    # hanya user aktif dan tanpa data sensitif.
    directory_only = not has_permission(current_user, "users.view")
    conditions = []
    if directory_only:
        conditions.append(User.status == "ACTIVE")

    if search:
        search_pattern = f"%{search}%"
        conditions.append(
            or_(
                User.name.ilike(search_pattern),
                User.username.ilike(search_pattern),
                User.email.ilike(search_pattern),
                User.nik.ilike(search_pattern),
            )
        )

    if role_id:
        conditions.append(User.role_id == role_id)

    if department_id:
        conditions.append(User.department_id == department_id)

    if is_active is not None:
        if is_active:
            conditions.append(User.status == "ACTIVE")
        else:
            conditions.append(User.status != "ACTIVE")

    where_clause = and_(*conditions) if conditions else True

    count_stmt = select(func.count(User.id)).where(where_clause)
    total_result = await db.execute(count_stmt)
    total = total_result.scalar() or 0

    offset = (page - 1) * per_page
    stmt = (
        select(User, Role, Department)
        .outerjoin(Role, User.role_id == Role.id)
        .outerjoin(Department, User.department_id == Department.id)
        .where(where_clause)
        .order_by(User.created_at.desc())
        .offset(offset)
        .limit(per_page)
    )
    result = await db.execute(stmt)
    rows = result.all()

    items = []
    for user, role, dept in rows:
        items.append(
            UserResponse(
                id=user.id,
                username=user.username,
                name=user.name,
                email=user.email,
                nik=user.nik,
                rank=user.rank,
                position=user.position,
                role_id=user.role_id,
                role_name=role.name if role else None,
                department_id=user.department_id,
                department_name=dept.name if dept else None,
                avatar_url=user.avatar_url,
                phone=user.phone,
                status=user.status,
                last_login=user.last_login,
                login_attempts=user.login_attempts,
                created_at=user.created_at,
                updated_at=user.updated_at,
            )
        )

    if directory_only:
        items = [_minimal_user(i) for i in items]

    total_pages = math.ceil(total / per_page) if per_page > 0 else 0

    return SuccessResponse(
        data=PaginatedUsersResponse(
            items=items,
            total=total,
            page=page,
            per_page=per_page,
            total_pages=total_pages,
        )
    )


@router.post("", response_model=SuccessResponse)
async def create_user(
    request: UserCreate,
    http_request: Request,
    current_user: User = Depends(require_permission("users.create")),
    db: AsyncSession = Depends(get_db),
):
    await _ensure_can_assign_role(db, current_user, request.role_id)
    if request.status and request.status not in ("ACTIVE", "INACTIVE", "SUSPENDED"):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Status tidak valid")
    existing_username = await db.execute(select(User).where(User.username == request.username))
    if existing_username.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username sudah digunakan",
        )

    existing_email = await db.execute(select(User).where(User.email == request.email))
    if existing_email.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email sudah digunakan",
        )

    if request.nik:
        existing_nik = await db.execute(select(User).where(User.nik == request.nik))
        if existing_nik.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="NIK sudah digunakan",
            )

    if request.role_id:
        role_check = await db.execute(select(Role).where(Role.id == request.role_id))
        if not role_check.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Role ID tidak valid",
            )

    if request.department_id:
        dept_check = await db.execute(select(Department).where(Department.id == request.department_id))
        if not dept_check.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Department ID tidak valid",
            )

    new_user = User(
        username=request.username,
        password_hash=get_password_hash(request.password),
        name=request.name,
        email=request.email,
        nik=request.nik,
        rank=request.rank,
        position=request.position,
        role_id=request.role_id,
        department_id=request.department_id,
        avatar_url=request.avatar_url,
        phone=request.phone,
        status=request.status or "ACTIVE",
    )

    db.add(new_user)
    await db.flush()
    await record_audit(
        db, current_user, "create", "users", "user", new_user.id,
        {"username": new_user.username, "role_id": str(new_user.role_id) if new_user.role_id else None},
        http_request,
    )
    await db.commit()
    await db.refresh(new_user)

    user_data = await _get_user_with_relations(db, new_user.id)
    return SuccessResponse(data=user_data)


@router.get("/me", response_model=SuccessResponse)
async def get_me(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    user_data = await _get_user_with_relations(db, current_user.id)
    if not user_data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User tidak ditemukan",
        )
    return SuccessResponse(data=user_data)


@router.put("/me", response_model=SuccessResponse)
async def update_me(
    request: UserMeUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if request.email and request.email != current_user.email:
        existing_email = await db.execute(select(User).where(User.email == request.email))
        if existing_email.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email sudah digunakan",
            )
        current_user.email = request.email

    if request.name is not None:
        current_user.name = request.name
    if request.avatar_url is not None:
        current_user.avatar_url = request.avatar_url
    if request.phone is not None:
        current_user.phone = request.phone

    await db.commit()
    await db.refresh(current_user)

    user_data = await _get_user_with_relations(db, current_user.id)
    return SuccessResponse(data=user_data)


# ============================================
# Department Static Endpoints (prefix /departments, DI ATAS /{user_id})
# ============================================

@router.get("/departments", response_model=SuccessResponse)
async def list_departments(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    stmt = (
        select(Department, User)
        .outerjoin(User, Department.head_id == User.id)
        .order_by(Department.name.asc())
    )
    result = await db.execute(stmt)
    rows = result.all()

    items = []
    for dept, head in rows:
        items.append(
            DepartmentResponse(
                id=dept.id,
                name=dept.name,
                code=dept.code,
                head_id=dept.head_id,
                head_name=head.name if head else None,
                created_at=dept.created_at,
                updated_at=dept.updated_at,
            )
        )

    return SuccessResponse(data=items)


@router.post("/departments", response_model=SuccessResponse)
async def create_department(
    request: DepartmentCreate,
    current_user: User = Depends(require_permission("users.edit")),
    db: AsyncSession = Depends(get_db),
):
    existing_code = await db.execute(select(Department).where(Department.code == request.code))
    if existing_code.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Kode department sudah digunakan",
        )

    existing_name = await db.execute(select(Department).where(Department.name == request.name))
    if existing_name.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Nama department sudah digunakan",
        )

    if request.head_id:
        head_check = await db.execute(select(User).where(User.id == request.head_id))
        if not head_check.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Head ID (user) tidak valid",
            )

    new_dept = Department(
        name=request.name,
        code=request.code,
        head_id=request.head_id,
    )

    db.add(new_dept)
    await db.commit()
    await db.refresh(new_dept)

    dept_data = await _get_department_with_head(db, new_dept.id)
    return SuccessResponse(data=dept_data)


@router.put("/departments/{dept_id}", response_model=SuccessResponse)
async def update_department(
    dept_id: UUID,
    request: DepartmentUpdate,
    current_user: User = Depends(require_permission("users.edit")),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Department).where(Department.id == dept_id))
    dept = result.scalar_one_or_none()
    if not dept:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Department tidak ditemukan",
        )

    if request.code and request.code != dept.code:
        existing_code = await db.execute(select(Department).where(Department.code == request.code))
        if existing_code.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Kode department sudah digunakan",
            )
        dept.code = request.code

    if request.name and request.name != dept.name:
        existing_name = await db.execute(select(Department).where(Department.name == request.name))
        if existing_name.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Nama department sudah digunakan",
            )
        dept.name = request.name

    if request.head_id is not None:
        if request.head_id:
            head_check = await db.execute(select(User).where(User.id == request.head_id))
            if not head_check.scalar_one_or_none():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Head ID (user) tidak valid",
                )
        dept.head_id = request.head_id

    await db.commit()
    await db.refresh(dept)

    dept_data = await _get_department_with_head(db, dept_id)
    return SuccessResponse(data=dept_data)


@router.delete("/departments/{dept_id}", response_model=SuccessResponse)
async def delete_department(
    dept_id: UUID,
    current_user: User = Depends(require_permission("users.edit")),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Department).where(Department.id == dept_id))
    dept = result.scalar_one_or_none()
    if not dept:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Department tidak ditemukan",
        )

    user_count_result = await db.execute(
        select(func.count(User.id)).where(User.department_id == dept_id)
    )
    user_count = user_count_result.scalar() or 0
    if user_count > 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Department masih memiliki {user_count} user, tidak dapat dihapus",
        )

    await db.delete(dept)
    await db.commit()

    return SuccessResponse(data={"message": "Department berhasil dihapus"})


# ============================================
# User Dynamic Parameter Endpoints (/{user_id}) -> PALING BAWAH
# ============================================

@router.get("/{user_id}", response_model=SuccessResponse)
async def get_user(
    user_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if user_id != current_user.id and not has_permission(current_user, "users.view"):
        raise _forbidden("Anda tidak memiliki izin untuk melihat data pengguna lain")
    user_data = await _get_user_with_relations(db, user_id)
    if not user_data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User tidak ditemukan",
        )
    return SuccessResponse(data=user_data)


@router.put("/{user_id}", response_model=SuccessResponse)
async def update_user(
    user_id: UUID,
    request: UserUpdate,
    http_request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    is_self = user_id == current_user.id
    sent = {k for k, v in request.model_dump(exclude_unset=True).items() if v is not None}
    if not has_permission(current_user, "users.edit"):
        # Tanpa users.edit hanya boleh mengubah profil sendiri (field terbatas).
        if not is_self:
            raise _forbidden("Anda tidak memiliki izin untuk mengubah pengguna lain")
        disallowed = sent - SELF_EDITABLE_FIELDS
        if disallowed:
            raise _forbidden(f"Field berikut tidak boleh diubah sendiri: {', '.join(sorted(disallowed))}")
    elif is_self and not is_super_admin(current_user):
        # Admin tidak boleh mengubah role & status akunnya sendiri.
        if ("role_id" in sent and request.role_id != current_user.role_id) or (
            "status" in sent and request.status != current_user.status
        ):
            raise _forbidden("Tidak dapat mengubah role/status akun sendiri")

    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User tidak ditemukan",
        )
    await _ensure_can_manage_target(db, current_user, user)
    if "role_id" in sent and request.role_id != user.role_id:
        await _ensure_can_assign_role(db, current_user, request.role_id)
    old = {"role_id": str(user.role_id) if user.role_id else None, "status": user.status}

    if request.username and request.username != user.username:
        existing_username = await db.execute(select(User).where(User.username == request.username))
        if existing_username.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username sudah digunakan",
            )
        user.username = request.username

    if request.email and request.email != user.email:
        existing_email = await db.execute(select(User).where(User.email == request.email))
        if existing_email.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email sudah digunakan",
            )
        user.email = request.email

    if request.nik is not None and request.nik != user.nik:
        existing_nik = await db.execute(select(User).where(User.nik == request.nik))
        if existing_nik.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="NIK sudah digunakan",
            )
        user.nik = request.nik

    if request.role_id is not None:
        role_check = await db.execute(select(Role).where(Role.id == request.role_id))
        if not role_check.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Role ID tidak valid",
            )
        user.role_id = request.role_id

    if request.department_id is not None:
        dept_check = await db.execute(select(Department).where(Department.id == request.department_id))
        if not dept_check.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Department ID tidak valid",
            )
        user.department_id = request.department_id

    if request.name is not None:
        user.name = request.name
    if request.rank is not None:
        user.rank = request.rank
    if request.position is not None:
        user.position = request.position
    if request.avatar_url is not None:
        user.avatar_url = request.avatar_url
    if request.phone is not None:
        user.phone = request.phone
    if request.status is not None:
        if request.status not in ("ACTIVE", "INACTIVE", "SUSPENDED"):
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Status tidak valid")
        user.status = request.status

    new = {"role_id": str(user.role_id) if user.role_id else None, "status": user.status}
    if new != old:
        # Role/status berubah -> cabut semua sesi lama user tersebut.
        user.token_version = int(user.token_version or 0) + 1
    await record_audit(
        db, current_user, "update", "users", "user", user.id,
        {"fields": sorted(sent), **new}, http_request, old_value=old,
    )
    await db.commit()
    await db.refresh(user)

    user_data = await _get_user_with_relations(db, user_id)
    return SuccessResponse(data=user_data)


@router.delete("/{user_id}", response_model=SuccessResponse)
async def delete_user(
    user_id: UUID,
    http_request: Request,
    current_user: User = Depends(require_permission("users.delete")),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User tidak ditemukan",
        )

    if user_id == current_user.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Tidak dapat menghapus user sendiri",
        )
    await _ensure_can_manage_target(db, current_user, user)

    await record_audit(
        db, current_user, "delete", "users", "user", user.id,
        {"username": user.username}, http_request,
    )
    await db.delete(user)
    await db.commit()

    return SuccessResponse(data={"message": "User berhasil dihapus"})


@router.put("/{user_id}/password", response_model=SuccessResponse)
async def update_user_password(
    user_id: UUID,
    request: PasswordUpdate,
    http_request: Request,
    current_user: User = Depends(require_permission("users.edit")),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User tidak ditemukan",
        )

    await _ensure_can_manage_target(db, current_user, user)
    if user.username == "kiosk":
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Akun sistem kiosk tidak dapat diberi password")

    user.password_hash = get_password_hash(request.new_password)
    # Cabut semua sesi user target; wajib ganti password saat login berikutnya
    # (kecuali admin mereset password dirinya sendiri).
    user.token_version = int(user.token_version or 0) + 1
    user.must_change_password = user.id != current_user.id
    user.login_attempts = 0
    user.locked_until = None
    await record_audit(
        db, current_user, "update", "users", "user_password", user.id,
        {"action": "reset_password"}, http_request,
    )
    await db.commit()

    return SuccessResponse(data={"message": "Password berhasil diubah"})
