from fastapi import APIRouter, Depends, HTTPException, status, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, desc
from typing import Optional, List
from uuid import UUID
from datetime import datetime, timedelta
import math

from src.api.database import get_db
from src.api.models.user import User
from src.api.models.audit_log import AuditLog
from src.api.schemas.audit_log import (
    SuccessResponse,
    AuditLogCreate,
    AuditLogResponse,
    PaginatedAuditLogsResponse,
    AuditLogPerModuleItem,
    AuditLogPerActionItem,
    AuditLogTopUserItem,
    AuditStatsSummaryResponse,
)
from src.api.utils.auth import get_current_user
from src.api.utils.audit import client_ip
from src.api.utils.permissions import require_permission

router = APIRouter(prefix="/audit", tags=["Audit Logs"])


async def _build_audit_response(
    db: AsyncSession, audit_log: AuditLog
) -> AuditLogResponse:
    user_name = None
    if audit_log.user_id:
        user_stmt = select(User).where(User.id == audit_log.user_id)
        user_result = await db.execute(user_stmt)
        user = user_result.scalar_one_or_none()
        if user:
            user_name = user.name

    return AuditLogResponse(
        id=audit_log.id,
        user_id=audit_log.user_id,
        user_name=user_name,
        action=audit_log.action,
        module=audit_log.module,
        target_type=audit_log.target_type,
        target_id=audit_log.target_id,
        old_value=audit_log.old_value,
        new_value=audit_log.new_value,
        ip_address=str(audit_log.ip_address) if audit_log.ip_address else None,
        user_agent=audit_log.user_agent,
        timestamp=audit_log.timestamp,
    )


@router.get("", response_model=SuccessResponse)
async def list_audit_logs(
    user_id: Optional[UUID] = Query(None, description="Filter by user ID"),
    module: Optional[str] = Query(None, description="Filter by module"),
    action: Optional[str] = Query(None, description="Filter by action"),
    from_date: Optional[datetime] = Query(None, description="Filter from timestamp"),
    to_date: Optional[datetime] = Query(None, description="Filter to timestamp"),
    target_type: Optional[str] = Query(None, description="Filter by target type"),
    target_id: Optional[str] = Query(None, description="Filter by target ID"),
    page: int = Query(1, ge=1, description="Page number"),
    per_page: int = Query(20, ge=1, le=100, description="Items per page"),
    current_user: User = Depends(require_permission("audit.read")),
    db: AsyncSession = Depends(get_db),
):
    conditions = []
    if user_id:
        conditions.append(AuditLog.user_id == user_id)
    if module:
        conditions.append(AuditLog.module == module)
    if action:
        conditions.append(AuditLog.action == action)
    if from_date:
        conditions.append(AuditLog.timestamp >= from_date)
    if to_date:
        conditions.append(AuditLog.timestamp <= to_date)
    if target_type:
        conditions.append(AuditLog.target_type == target_type)
    if target_id:
        conditions.append(AuditLog.target_id == target_id)

    where_clause = and_(*conditions) if conditions else True

    count_stmt = select(func.count(AuditLog.id)).where(where_clause)
    total_result = await db.execute(count_stmt)
    total = total_result.scalar() or 0

    offset = (page - 1) * per_page
    stmt = (
        select(AuditLog)
        .where(where_clause)
        .order_by(desc(AuditLog.timestamp))
        .offset(offset)
        .limit(per_page)
    )
    result = await db.execute(stmt)
    logs = result.scalars().all()

    items = []
    for log in logs:
        items.append(await _build_audit_response(db, log))

    total_pages = math.ceil(total / per_page) if per_page > 0 else 0

    return SuccessResponse(
        data=PaginatedAuditLogsResponse(
            items=items,
            total=total,
            page=page,
            per_page=per_page,
            total_pages=total_pages,
        )
    )


@router.get("/logs", response_model=SuccessResponse)
async def list_audit_logs_alias(
    user_id: Optional[UUID] = Query(None, description="Filter by user ID"),
    module: Optional[str] = Query(None, description="Filter by module"),
    action: Optional[str] = Query(None, description="Filter by action"),
    from_date: Optional[datetime] = Query(None, description="Filter from timestamp"),
    to_date: Optional[datetime] = Query(None, description="Filter to timestamp"),
    target_type: Optional[str] = Query(None, description="Filter by target type"),
    target_id: Optional[str] = Query(None, description="Filter by target ID"),
    page: int = Query(1, ge=1, description="Page number"),
    per_page: int = Query(20, ge=1, le=100, description="Items per page"),
    current_user: User = Depends(require_permission("audit.read")),
    db: AsyncSession = Depends(get_db),
):
    return await list_audit_logs(
        user_id=user_id, module=module, action=action, from_date=from_date,
        to_date=to_date, target_type=target_type, target_id=target_id,
        page=page, per_page=per_page, current_user=current_user, db=db
    )


@router.get("/logs/{audit_id}", response_model=SuccessResponse)
async def get_audit_log_alias(
    audit_id: UUID,
    current_user: User = Depends(require_permission("audit.read")),
    db: AsyncSession = Depends(get_db),
):
    return await get_audit_log(audit_id, current_user, db)


@router.post("/logs", response_model=SuccessResponse)
async def create_audit_log_alias(
    request: AuditLogCreate,
    request_obj: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await create_audit_log(request, request_obj, current_user, db)


@router.post("/log", response_model=SuccessResponse)
async def create_audit_log(
    request: AuditLogCreate,
    request_obj: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    # Identitas pelaku, IP & user-agent SELALU dari server (nilai klien diabaikan).
    ip = client_ip(request_obj)
    user_agent = request_obj.headers.get("user-agent")

    audit_log = AuditLog(
        user_id=current_user.id,
        action=request.action,
        module=request.module,
        target_type=request.target_type,
        target_id=request.target_id,
        old_value=request.old_value,
        new_value=request.new_value,
        ip_address=ip,
        user_agent=(user_agent or "")[:500] or None,
    )
    db.add(audit_log)
    await db.commit()
    await db.refresh(audit_log)

    data = await _build_audit_response(db, audit_log)
    return SuccessResponse(data=data)


@router.get("/stats/summary", response_model=SuccessResponse)
async def get_audit_stats_summary(
    current_user: User = Depends(require_permission("audit.read")),
    db: AsyncSession = Depends(get_db),
):
    thirty_days_ago = datetime.now() - timedelta(days=30)

    total_stmt = select(func.count(AuditLog.id)).where(
        AuditLog.timestamp >= thirty_days_ago
    )
    total_result = await db.execute(total_stmt)
    total_logs_30d = total_result.scalar() or 0

    per_module_stmt = (
        select(AuditLog.module, func.count(AuditLog.id))
        .where(AuditLog.timestamp >= thirty_days_ago)
        .group_by(AuditLog.module)
        .order_by(desc(func.count(AuditLog.id)))
    )
    per_module_result = await db.execute(per_module_stmt)
    per_module = [
        AuditLogPerModuleItem(module=m or "system", count=c)
        for m, c in per_module_result.all()
    ]

    per_action_stmt = (
        select(AuditLog.action, func.count(AuditLog.id))
        .where(AuditLog.timestamp >= thirty_days_ago)
        .group_by(AuditLog.action)
        .order_by(desc(func.count(AuditLog.id)))
        .limit(10)
    )
    per_action_result = await db.execute(per_action_stmt)
    per_action = [
        AuditLogPerActionItem(action=a, count=c)
        for a, c in per_action_result.all()
    ]

    top_users_stmt = (
        select(AuditLog.user_id, User.name, func.count(AuditLog.id))
        .join(User, AuditLog.user_id == User.id)
        .where(AuditLog.timestamp >= thirty_days_ago, AuditLog.user_id.isnot(None))
        .group_by(AuditLog.user_id, User.name)
        .order_by(desc(func.count(AuditLog.id)))
        .limit(10)
    )
    top_users_result = await db.execute(top_users_stmt)
    top_users = [
        AuditLogTopUserItem(user_id=uid, user_name=uname, count=c)
        for uid, uname, c in top_users_result.all()
    ]

    return SuccessResponse(
        data=AuditStatsSummaryResponse(
            total_logs_30d=total_logs_30d,
            per_module=per_module,
            per_action=per_action,
            top_users=top_users,
        )
    )


@router.get("/{audit_id}", response_model=SuccessResponse)
async def get_audit_log(
    audit_id: UUID,
    current_user: User = Depends(require_permission("audit.read")),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(AuditLog).where(AuditLog.id == audit_id))
    audit_log = result.scalar_one_or_none()

    if not audit_log:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Audit log tidak ditemukan",
        )

    data = await _build_audit_response(db, audit_log)
    return SuccessResponse(data=data)
