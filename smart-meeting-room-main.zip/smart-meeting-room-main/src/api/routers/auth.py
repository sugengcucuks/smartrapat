from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from datetime import datetime, timezone
from uuid import UUID

from src.api.database import get_db
from src.api.models.user import User, Role
from src.api.schemas.auth import (
    LoginRequest,
    LoginResponse,
    UserResponse,
    RefreshTokenRequest,
    ChangePasswordRequest,
    ForgotPasswordRequest,
    ResetPasswordRequest,
    MenuItemResponse,
    MenuResponse,
    MessageResponse,
)
from src.api.utils.auth import (
    verify_password,
    create_access_token,
    create_refresh_token,
    decode_token,
    get_current_user,
    get_password_hash,
    get_user_from_payload,
    token_claims,
)
from src.api.utils.permissions import user_permissions
from src.api.utils.rate_limit import rate_limiter
from src.api.utils.mailer import send_email
from sqlalchemy.orm import selectinload
from datetime import timedelta
from fastapi import Request
from jose import jwt as jose_jwt
import hashlib
from src.api.config import settings

router = APIRouter(prefix="/auth", tags=["Authentication"])


def get_menu_for_user(user: User) -> list[dict]:
    """Menu dari izin efektif (bukan nama role), agar konsisten dengan RBAC backend."""
    from src.api.utils.permissions import has_permission as hp

    menu = [{"id": "dashboard", "name": "Dashboard", "icon": "home", "path": "/dashboard"}]
    if hp(user, "users.view"):
        menu += [
            {"id": "users", "name": "Pengguna", "icon": "users", "path": "/users"},
            {"id": "departments", "name": "Departemen", "icon": "shield", "path": "/users/departments"},
        ]
    if hp(user, "roles.view", "roles.write"):
        menu.append({"id": "roles", "name": "Peran", "icon": "shield", "path": "/roles"})
    if hp(user, "rooms.write"):
        menu += [
            {"id": "rooms", "name": "Ruangan", "icon": "door-open", "path": "/rooms"},
            {"id": "buildings", "name": "Gedung", "icon": "home", "path": "/rooms/buildings"},
        ]
    if hp(user, "bookings.view", "bookings.create"):
        menu += [
            {"id": "bookings", "name": "Pemesanan", "icon": "calendar", "path": "/bookings"},
            {"id": "presensi_tickets", "name": "Tiket Presensi", "icon": "qr-code", "path": "/presensi/tickets"},
        ]
    if hp(user, "bookings.approve", "door_display.manage"):
        menu.append({"id": "presensi_scanner", "name": "Scanner Presensi", "icon": "scan", "path": "/presensi/scanner"})
    menu.append({"id": "calendar", "name": "Kalender", "icon": "bar-chart", "path": "/calendar"})
    if hp(user, "notes.view", "notes.write"):
        menu.append({"id": "notes", "name": "Notulensi", "icon": "file-text", "path": "/notes"})
        menu += [
            {"id": "search", "name": "Pencarian", "icon": "search", "path": "/search"},
            {"id": "followups", "name": "Tindak Lanjut", "icon": "list-check", "path": "/followups"},
        ]
    if hp(user, "devices.write"):
        menu += [
            {"id": "equipment", "name": "Perangkat AV", "icon": "tool", "path": "/equipment"},
            {"id": "devices", "name": "Perangkat IoT", "icon": "monitor", "path": "/devices"},
        ]
    if hp(user, "videowall.control"):
        menu.append({"id": "videowall", "name": "Videowall", "icon": "monitor", "path": "/videowall"})
    if hp(user, "audio.control"):
        menu.append({"id": "audio", "name": "Audio", "icon": "volume-2", "path": "/audio"})
    menu.append({"id": "notifications", "name": "Pemberitahuan", "icon": "bell", "path": "/notifications"})
    if hp(user, "reports.view"):
        menu.append({"id": "reports", "name": "Laporan", "icon": "bar-chart", "path": "/reports"})
    if hp(user, "settings.write"):
        menu.append({"id": "settings", "name": "Pengaturan", "icon": "settings", "path": "/settings"})
    if hp(user, "audit.read"):
        menu.append({"id": "audit", "name": "Log Audit", "icon": "file-list", "path": "/audit"})
    if hp(user, "system.maintenance"):
        menu.append({"id": "maintenance", "name": "Pemeliharaan", "icon": "settings-2", "path": "/maintenance"})
    if hp(user, "*"):
        menu.append({"id": "setup", "name": "Panduan Setup", "icon": "magic", "path": "/setup"})
    return menu


def _user_response(user: User) -> UserResponse:
    role = user.role
    return UserResponse(
        id=user.id,
        username=user.username,
        name=user.name,
        email=user.email,
        role=role.name if role else "user",
        permissions=sorted(user_permissions(user)),
        avatar_url=user.avatar_url,
        must_change_password=bool(user.must_change_password),
    )


def _issue_tokens(user: User) -> tuple[str, str]:
    claims = token_claims(user)
    return create_access_token(claims), create_refresh_token(claims)


@router.post("/login", response_model=LoginResponse)
async def login(request: LoginRequest, http_request: Request, db: AsyncSession = Depends(get_db)):
    """User login endpoint (dengan lockout akun & rate limit per IP)."""
    client_ip = http_request.client.host if http_request.client else "unknown"
    rate_limiter.hit(f"login:{client_ip}", limit=20, window_seconds=300)

    result = await db.execute(
        select(User).options(selectinload(User.role)).where(User.username == request.username)
    )
    user = result.scalar_one_or_none()
    now = datetime.now(timezone.utc)

    if user and user.locked_until and user.locked_until > now:
        raise HTTPException(
            status_code=status.HTTP_423_LOCKED,
            detail={"code": "USER_LOCKED", "message": "Akun terkunci. Coba beberapa menit lagi."},
        )

    if not user or not verify_password(request.password, user.password_hash):
        if user:
            user.login_attempts = (user.login_attempts or 0) + 1
            if user.login_attempts >= settings.LOGIN_MAX_ATTEMPTS:
                user.locked_until = now + timedelta(minutes=settings.LOGIN_LOCKOUT_MINUTES)
                user.login_attempts = 0
            await db.commit()
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": "AUTH_INVALID", "message": "Username atau password salah"},
        )

    if user.status != "ACTIVE":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "USER_INACTIVE", "message": "Akun nonaktif"},
        )

    user.login_attempts = 0
    user.locked_until = None
    user.last_login = now
    await db.commit()
    await db.refresh(user, attribute_names=["role"])

    access_token, refresh_token = _issue_tokens(user)
    return LoginResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="Bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        user=_user_response(user),
    )


@router.post("/logout")
async def logout(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Logout: cabut SEMUA token milik user (access & refresh)."""
    current_user.token_version = (current_user.token_version or 0) + 1
    await db.commit()
    return MessageResponse(message="Logout berhasil")


@router.post("/refresh", response_model=dict)
async def refresh_token(request: RefreshTokenRequest, db: AsyncSession = Depends(get_db)):
    """Refresh token. User harus masih ada, aktif, dan versi token masih berlaku."""
    payload = decode_token(request.refresh_token, expected_type="refresh")
    user = await get_user_from_payload(payload, db)
    access_token, new_refresh_token = _issue_tokens(user)
    return {
        "success": True,
        "data": {
            "access_token": access_token,
            "refresh_token": new_refresh_token,
        },
    }


@router.get("/session", response_model=UserResponse)
async def get_session(current_user: User = Depends(get_current_user)):
    """Get current user session."""
    return _user_response(current_user)


@router.get("/menu", response_model=MenuResponse)
async def get_menu(current_user: User = Depends(get_current_user)):
    """Menu berdasarkan izin efektif user."""
    return MenuResponse(menu=get_menu_for_user(current_user))


@router.post("/change-password")
async def change_password(
    request: ChangePasswordRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Ganti password user yang sedang login. Semua sesi lain ikut dicabut."""
    if not verify_password(request.old_password, current_user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"code": "AUTH_INVALID", "message": "Password lama salah"},
        )
    if request.old_password == request.new_password:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"code": "PASSWORD_REUSED", "message": "Password baru harus berbeda"},
        )

    current_user.password_hash = get_password_hash(request.new_password)
    current_user.must_change_password = False
    current_user.token_version = (current_user.token_version or 0) + 1
    await db.commit()

    access_token, refresh_token = _issue_tokens(current_user)
    return {
        "success": True,
        "message": "Password berhasil diubah",
        "data": {"access_token": access_token, "refresh_token": refresh_token},
    }


# ------------------------------------------------------------
# Reset password: token JWT sekali pakai (terikat hash password saat ini)
# ------------------------------------------------------------
RESET_TOKEN_MINUTES = 30


def _pwd_fingerprint(user: User) -> str:
    return hashlib.sha256(user.password_hash.encode()).hexdigest()[:16]


def _create_reset_token(user: User) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=RESET_TOKEN_MINUTES)
    return jose_jwt.encode(
        {"sub": str(user.id), "type": "reset", "pfp": _pwd_fingerprint(user), "exp": exp},
        settings.JWT_SECRET,
        algorithm=settings.JWT_ALGORITHM,
    )


@router.post("/forgot-password", response_model=MessageResponse)
async def forgot_password(
    request: ForgotPasswordRequest,
    http_request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Kirim link reset password via email (SMTP dari Pengaturan)."""
    client_ip = http_request.client.host if http_request.client else "unknown"
    rate_limiter.hit(f"forgot:{client_ip}", limit=5, window_seconds=900)

    generic = MessageResponse(message="Jika email terdaftar, link reset password telah dikirim")
    result = await db.execute(select(User).where(User.email == request.email))
    user = result.scalar_one_or_none()
    if not user or user.status != "ACTIVE":
        return generic

    token = _create_reset_token(user)
    link = f"{settings.WEB_URL.rstrip('/')}/reset-password?token={token}"
    await send_email(
        db,
        to=user.email,
        subject="Reset Password - Smart Meeting Room",
        body=(
            f"Halo {user.name},\n\n"
            f"Klik link berikut untuk mengatur ulang password Anda (berlaku {RESET_TOKEN_MINUTES} menit):\n"
            f"{link}\n\nAbaikan email ini bila Anda tidak meminta reset password."
        ),
    )
    return generic


@router.post("/reset-password", response_model=MessageResponse)
async def reset_password(request: ResetPasswordRequest, db: AsyncSession = Depends(get_db)):
    """Reset password memakai token dari email. Token hangus setelah dipakai."""
    invalid = HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail={"code": "RESET_INVALID", "message": "Link reset tidak valid atau sudah kedaluwarsa"},
    )
    try:
        payload = jose_jwt.decode(request.token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])
    except Exception:
        raise invalid
    if payload.get("type") != "reset":
        raise invalid
    try:
        uid = UUID(str(payload.get("sub")))
    except (ValueError, TypeError):
        raise invalid

    result = await db.execute(select(User).where(User.id == uid))
    user = result.scalar_one_or_none()
    if not user or user.status != "ACTIVE" or payload.get("pfp") != _pwd_fingerprint(user):
        raise invalid

    user.password_hash = get_password_hash(request.new_password)
    user.must_change_password = False
    user.login_attempts = 0
    user.locked_until = None
    user.token_version = (user.token_version or 0) + 1
    await db.commit()
    return MessageResponse(message="Password berhasil direset")
