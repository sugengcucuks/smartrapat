import re
from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text
from typing import Dict, Any, Optional
from datetime import datetime

from src.api.database import get_db
from src.api.models.user import User
from src.api.models.system_setting import SystemSetting
from src.api.schemas.system_setting import (
    SuccessResponse,
    SystemSettingResponse,
    SystemSettingUpdate,
    SystemSettingsBatchUpdate,
)
from src.api.utils.audit import record_audit
from src.api.utils.permissions import require_permission

router = APIRouter(prefix="/settings", tags=["System Settings"])

# Kunci yang mengandung kata ini dianggap rahasia: nilainya tidak pernah dikirim
# ke klien (diganti "" + is_secret: true).
SECRET_MARKERS = ("pass", "secret", "token", "key")
SETTING_KEY_RE = re.compile(r"^[a-z0-9_.\-]{1,100}$")

# Grup default untuk kunci baru yang dibuat dari halaman Pengaturan.
GROUP_BY_PREFIX = {
    "smtp_": "email", "from_email": "email", "email_": "notifications", "push_": "notifications",
    "company_": "company", "maintenance_": "maintenance", "booking_": "booking",
    "auto_approve": "booking", "max_days": "booking", "min_duration": "booking",
    "max_duration": "booking", "allow_extend": "booking", "session_": "authentication",
    "min_password": "authentication", "require_special": "authentication", "max_login": "authentication",
}


def is_secret_key(key: Optional[str]) -> bool:
    k = (key or "").lower()
    return any(m in k for m in SECRET_MARKERS)


def _group_for(key: str) -> str:
    for prefix, group in GROUP_BY_PREFIX.items():
        if key.startswith(prefix):
            return group
    return "general"


async def _build_setting_response(
    db: AsyncSession, setting: SystemSetting
) -> SystemSettingResponse:
    updater_name = None
    if setting.updated_by:
        user_stmt = select(User).where(User.id == setting.updated_by)
        user_result = await db.execute(user_stmt)
        user = user_result.scalar_one_or_none()
        if user:
            updater_name = user.name

    resp = SystemSettingResponse(
        id=setting.id,
        setting_key=setting.setting_key,
        setting_value="" if is_secret_key(setting.setting_key) else setting.setting_value,
        value_type=setting.value_type,
        description=setting.description,
        group_name=setting.group_name,
        is_public=setting.is_public or False,
        updated_at=setting.updated_at,
        updated_by=setting.updated_by,
        updated_by_name=updater_name,
    )
    return resp


async def _build_setting_frontend_friendly(db: AsyncSession, setting: SystemSetting) -> Dict[str, Any]:
    updater_name = None
    if setting.updated_by:
        user_stmt = select(User).where(User.id == setting.updated_by)
        user_result = await db.execute(user_stmt)
        user = user_result.scalar_one_or_none()
        if user:
            updater_name = user.name
    dt = setting.value_type or "string"
    data_type_map = {"string": "string", "number": "integer", "integer": "integer", "boolean": "boolean", "json": "json"}
    secret = is_secret_key(setting.setting_key)
    value = "" if secret else (setting.setting_value or "")
    return {
        "id": str(setting.id),
        "setting_key": setting.setting_key,
        "setting_value": value,
        "value_type": dt,
        "key": setting.setting_key,
        "value": value,
        "is_secret": secret,
        # Untuk rahasia: beri tahu UI apakah sudah terisi tanpa membocorkan nilainya.
        "has_value": bool(setting.setting_value),
        "data_type": data_type_map.get(dt, dt),
        "description": setting.description,
        "group_name": setting.group_name or "general",
        "is_public": bool(setting.is_public),
        "created_at": setting.updated_at.isoformat() if setting.updated_at else None,
        "updated_at": setting.updated_at.isoformat() if setting.updated_at else None,
        "updated_by": str(setting.updated_by) if setting.updated_by else None,
        "updated_by_name": updater_name,
    }


async def _apply_setting(db: AsyncSession, user: User, key: str, value: Optional[str]) -> Optional[str]:
    """Update (atau buat) satu setting. Return key bila berubah, None bila dilewati."""
    if not SETTING_KEY_RE.match(key or ""):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Key setting tidak valid: {key}")
    value = "" if value is None else str(value)
    if len(value) > 10000:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Nilai setting terlalu panjang: {key}")
    secret = is_secret_key(key)
    if secret and value == "":
        # Nilai rahasia dikirim ke UI sebagai "" -> kosong berarti "tidak diubah".
        return None

    setting = (await db.execute(select(SystemSetting).where(SystemSetting.setting_key == key))).scalar_one_or_none()
    if setting:
        if setting.setting_value == value:
            return None
        setting.setting_value = value
        setting.updated_by = user.id
        setting.updated_at = datetime.now()
        return key

    value_type = "boolean" if value.lower() in ("true", "false") else ("number" if value.isdigit() else "string")
    await db.execute(
        text(
            "INSERT INTO system_settings (setting_key, setting_value, value_type, group_name, is_public, updated_by) "
            "VALUES (:k, :v, CAST(:t AS setting_value_type), :g, FALSE, :u)"
        ),
        {"k": key, "v": value, "t": value_type, "g": _group_for(key), "u": user.id},
    )
    return key


@router.get("", response_model=SuccessResponse)
async def list_all_settings_root(
    current_user: User = Depends(require_permission("settings.view")),
    db: AsyncSession = Depends(get_db),
):
    return await list_all_settings(current_user, db)


@router.get("/public", response_model=SuccessResponse)
async def get_public_settings(
    db: AsyncSession = Depends(get_db),
):
    stmt = select(SystemSetting).where(SystemSetting.is_public == True)  # noqa: E712
    result = await db.execute(stmt)
    settings = result.scalars().all()

    items = []
    for s in settings:
        if is_secret_key(s.setting_key):
            continue
        item = await _build_setting_frontend_friendly(db, s)
        item.pop("updated_by", None)
        item.pop("updated_by_name", None)
        items.append(item)

    return SuccessResponse(data=items)


@router.get("/list", response_model=SuccessResponse)
async def list_all_settings(
    current_user: User = Depends(require_permission("settings.view")),
    db: AsyncSession = Depends(get_db),
):
    stmt = select(SystemSetting).order_by(SystemSetting.group_name, SystemSetting.setting_key)
    result = await db.execute(stmt)
    settings = result.scalars().all()

    items = []
    for s in settings:
        items.append(await _build_setting_frontend_friendly(db, s))

    return SuccessResponse(data=items)


@router.put("", response_model=SuccessResponse)
async def batch_update_settings(
    request: SystemSettingsBatchUpdate,
    http_request: Request,
    current_user: User = Depends(require_permission("settings.write")),
    db: AsyncSession = Depends(get_db),
):
    updated = []
    for key, value in request.as_dict().items():
        changed = await _apply_setting(db, current_user, key, value)
        if changed:
            updated.append(changed)

    if updated:
        await record_audit(
            db, current_user, "settings_change", "settings", "system_settings", None,
            {"keys": updated}, http_request,
        )
    await db.commit()

    return SuccessResponse(data={
        "updated_keys": updated,
        "count": len(updated),
        "updated_count": len(updated),
        "message": f"{len(updated)} pengaturan diperbarui",
    })


@router.put("/batch", response_model=SuccessResponse)
async def batch_update_settings_alias(
    request: SystemSettingsBatchUpdate,
    http_request: Request,
    current_user: User = Depends(require_permission("settings.write")),
    db: AsyncSession = Depends(get_db),
):
    return await batch_update_settings(request, http_request, current_user, db)


@router.get("/{setting_key}", response_model=SuccessResponse)
async def get_setting(
    setting_key: str,
    current_user: User = Depends(require_permission("settings.view")),
    db: AsyncSession = Depends(get_db),
):
    stmt = select(SystemSetting).where(SystemSetting.setting_key == setting_key)
    result = await db.execute(stmt)
    setting = result.scalar_one_or_none()

    if not setting:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Setting tidak ditemukan",
        )

    data = await _build_setting_frontend_friendly(db, setting)
    return SuccessResponse(data=data)


@router.put("/{setting_key}", response_model=SuccessResponse)
async def update_setting(
    setting_key: str,
    request: SystemSettingUpdate,
    http_request: Request,
    current_user: User = Depends(require_permission("settings.write")),
    db: AsyncSession = Depends(get_db),
):
    stmt = select(SystemSetting).where(SystemSetting.setting_key == setting_key)
    result = await db.execute(stmt)
    setting = result.scalar_one_or_none()

    if not setting:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Setting tidak ditemukan",
        )

    changed = await _apply_setting(db, current_user, setting_key, request.resolved_value())
    if changed:
        await record_audit(
            db, current_user, "settings_change", "settings", "system_setting", setting_key,
            {"keys": [setting_key]}, http_request,
        )
    await db.commit()
    await db.refresh(setting)

    data = await _build_setting_frontend_friendly(db, setting)
    return SuccessResponse(data=data)
