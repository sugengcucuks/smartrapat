"""Setup Wizard ala WordPress: instalasi terpandu langkah demi langkah.

Seperti layar install WordPress, aplikasi memeriksa sendiri kesiapannya:

    1. Koneksi basis data
    2. Skema (migrasi) terpasang penuh
    3. Akun Super Admin tersedia
    4. Profil organisasi terisi
    5. Lisensi aktif

Endpoint:
    GET  /setup/status   : status tiap langkah (terbuka, tanpa rahasia) agar
                           wizard tetap bisa dibuka sebelum lisensi aktif.
    POST /setup/profile  : simpan profil organisasi (Super Admin).
    POST /setup/complete : tandai instalasi selesai (Super Admin).
"""

from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.database import get_db
from src.api.db.migrator import is_legacy, list_migration_files
from src.api.licensing.service import evaluate
from src.api.models.system_setting import SystemSetting
from src.api.models.user import Role, User
from src.api.schemas.setup import (
    SetupCompleteResponse,
    SetupProfileRequest,
    SetupStatusResponse,
    SetupStep,
)
from src.api.schemas.user import SuccessResponse
from src.api.utils.audit import record_audit
from src.api.utils.permissions import (
    is_super_admin_role_name,
    require_super_admin,
)

router = APIRouter(prefix="/setup", tags=["Setup"])

ORG_KEY_PREFIX = "org."
SETUP_COMPLETED_KEY = "setup.completed"

_ORG_FIELDS = (
    # (field request, key setting, label)
    ("org_name", "org.name", "Nama Organisasi"),
    ("org_address", "org.address", "Alamat"),
    ("org_phone", "org.phone", "Telepon"),
    ("org_email", "org.email", "Email"),
)


async def _get_setting(db: AsyncSession, key: str) -> Optional[SystemSetting]:
    stmt = select(SystemSetting).where(SystemSetting.setting_key == key)
    return (await db.execute(stmt)).scalar_one_or_none()


async def _upsert_setting(
    db: AsyncSession,
    key: str,
    value: str,
    value_type: str,
    group: str,
    description: str,
    user_id: Optional[UUID],
) -> None:
    # Kolom value_type di PostgreSQL bertipe enum setting_value_type, jadi
    # insert lewat SQL mentah dengan CAST (pola yang sama dengan settings.py).
    await db.execute(
        text(
            "INSERT INTO system_settings "
            "(setting_key, setting_value, value_type, group_name, description, is_public, updated_by) "
            "VALUES (:k, :v, CAST(:t AS setting_value_type), :g, :d, TRUE, :u) "
            "ON CONFLICT (setting_key) DO UPDATE SET "
            "setting_value = EXCLUDED.setting_value, updated_by = EXCLUDED.updated_by"
        ),
        {"k": key, "v": value, "t": value_type, "g": group, "d": description, "u": user_id},
    )


async def _pending_migrations(db: AsyncSession) -> list:
    """Replikasi logika baseline migrator: DB lama tanpa riwayat menganggap
    berkas legacy (001-010) sudah terpasang."""
    rows = await db.execute(text("SELECT filename FROM schema_migrations"))
    applied = {r[0] for r in rows}
    pending = [f for f in list_migration_files() if f not in applied]
    if not applied and pending:
        has_users = (
            await db.execute(text("SELECT to_regclass('public.users') IS NOT NULL"))
        ).scalar()
        if has_users:
            return [f for f in pending if not is_legacy(f)]
    return pending


async def _has_super_admin(db: AsyncSession) -> bool:
    rows = (
        await db.execute(
            select(Role.name, Role.permissions).join(User, User.role_id == Role.id)
        )
    ).all()
    for name, perms in rows:
        if is_super_admin_role_name(name):
            return True
        if isinstance(perms, (list, tuple)) and "*" in perms:
            return True
    return False


async def _org_name(db: AsyncSession) -> str:
    setting = await _get_setting(db, "org.name")
    return (setting.setting_value or "").strip() if setting else ""


def _license_step() -> SetupStep:
    st = evaluate()
    if not st.enforced:
        return SetupStep(
            key="license", label="Aktivasi Lisensi", done=True,
            detail="Lisensi tidak diberlakukan (mode bebas).",
        )
    if st.activated:
        detail = "Lisensi aktif."
        if st.days_remaining is not None:
            detail = f"Lisensi aktif, sisa {st.days_remaining} hari."
        return SetupStep(key="license", label="Aktivasi Lisensi", done=True, detail=detail)
    return SetupStep(
        key="license", label="Aktivasi Lisensi", done=False,
        detail=st.reason or "Lisensi belum diaktifkan.",
    )


async def _build_status(db: AsyncSession) -> SetupStatusResponse:
    steps = []

    db_ok = True
    db_detail = "Terhubung."
    try:
        await db.execute(text("SELECT 1"))
    except Exception as exc:  # noqa: BLE001
        db_ok = False
        db_detail = f"Gagal terhubung: {exc}"
    steps.append(SetupStep(key="database", label="Koneksi Basis Data", done=db_ok, detail=db_detail))

    pending = await _pending_migrations(db)
    steps.append(
        SetupStep(
            key="migrations",
            label="Skema Basis Data",
            done=len(pending) == 0,
            detail="Semua migrasi sudah diterapkan." if not pending else f"{len(pending)} migrasi tertunda.",
        )
    )

    has_admin = await _has_super_admin(db)
    steps.append(
        SetupStep(
            key="admin",
            label="Akun Administrator",
            done=has_admin,
            detail="Super Admin tersedia." if has_admin else "Belum ada pengguna Super Admin.",
        )
    )

    org = await _org_name(db)
    steps.append(
        SetupStep(
            key="organization",
            label="Profil Organisasi",
            done=bool(org),
            detail=f'"{org}"' if org else "Nama organisasi belum diisi.",
        )
    )

    steps.append(_license_step())

    completed_setting = await _get_setting(db, SETUP_COMPLETED_KEY)
    is_completed = (completed_setting.setting_value or "").lower() == "true" if completed_setting else False
    steps.append(
        SetupStep(
            key="finalize",
            label="Selesaikan Instalasi",
            done=is_completed,
            detail="Instalasi selesai." if is_completed else "Tandai selesai setelah langkah di atas.",
        )
    )

    return SetupStatusResponse(completed=is_completed, steps=steps)


@router.get("/status", response_model=SuccessResponse)
async def setup_status(db: AsyncSession = Depends(get_db)):
    """Status instalasi. Sengaja tanpa auth: wizard harus bisa dibuka saat
    sistem belum terisi (mis. sebelum lisensi aktif) dan tidak membocorkan
    data sensitif — hanya done/detail per langkah."""
    return SuccessResponse(data=await _build_status(db))


@router.post("/profile", response_model=SuccessResponse)
async def save_profile(
    payload: SetupProfileRequest,
    request: Request,
    current_user: User = Depends(require_super_admin()),
    db: AsyncSession = Depends(get_db),
):
    for field, key, label in _ORG_FIELDS:
        value = getattr(payload, field)
        if value:
            await _upsert_setting(
                db, key, value.strip(), "string", "organization",
                f"Profil organisasi: {label}", current_user.id,
            )

    await record_audit(
        db, current_user, "update", "setup", "system_setting", None,
        details={"org_name": payload.org_name}, request=request,
    )
    await db.commit()
    return SuccessResponse(data=await _build_status(db))


@router.post("/complete", response_model=SuccessResponse)
async def complete_setup(
    request: Request,
    current_user: User = Depends(require_super_admin()),
    db: AsyncSession = Depends(get_db),
):
    if not await _org_name(db):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"code": "SETUP_PROFILE_REQUIRED", "message": "Isi profil organisasi dahulu."},
        )

    await _upsert_setting(
        db, SETUP_COMPLETED_KEY, "true", "boolean", "system",
        "Apakah wizard instalasi sudah diselesaikan.", current_user.id,
    )
    await record_audit(
        db, current_user, "complete", "setup", "system_setting", None,
        details={"completed": True}, request=request,
    )
    await db.commit()
    return SuccessResponse(
        data=SetupCompleteResponse(
            completed=True,
            message="Instalasi selesai. Selamat menggunakan Smart Meeting Room!",
        )
    )
