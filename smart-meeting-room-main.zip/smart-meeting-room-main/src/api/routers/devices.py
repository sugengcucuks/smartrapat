from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, or_
from typing import Optional, Dict, Any
from uuid import UUID
from datetime import datetime, timedelta, timezone
import math

from src.api.database import get_db
from src.api.models.user import User
from src.api.models.room import Room
from src.api.models.device import Device
from src.api.schemas.device import (
    SuccessResponse,
    DeviceCreate,
    DeviceUpdate,
    DeviceResponse,
    DeviceStatusResponse,
    DeviceHealthSummary,
    PaginatedDevicesResponse,
)
from src.api.services import av_service as av
from src.api.services.live_hub import live_hub
from src.api.utils.permissions import require_permission

router = APIRouter(prefix="/devices", tags=["IoT Devices"])

_view = require_permission("devices.view")
_write = require_permission("devices.write")
_control = require_permission("devices.control")


async def _get_device_with_room(db: AsyncSession, dev_id: UUID) -> Optional[DeviceResponse]:
    stmt = (
        select(Device, Room)
        .outerjoin(Room, Device.location_id == Room.id)
        .where(Device.id == dev_id)
    )
    result = await db.execute(stmt)
    row = result.first()
    if not row:
        return None
    dev, room = row
    return DeviceResponse(
        id=dev.id,
        name=dev.name,
        device_type=dev.device_type,
        code=dev.code,
        location_id=dev.location_id,
        room_name=room.name if room else None,
        ip_address=dev.ip_address,
        mac_address=dev.mac_address,
        firmware_version=dev.firmware_version,
        status=dev.status,
        last_seen=dev.last_seen,
        config=dev.config or {},
        last_action=dev.last_action,
        live=live_hub.device_live(str(dev.id), dev.code),
        created_at=dev.created_at,
        updated_at=dev.updated_at,
    )


@router.get("", response_model=SuccessResponse)
async def list_devices(
    search: Optional[str] = Query(None, description="Cari kode/nama/IP"),
    device_type: Optional[str] = Query(None, description="Filter by device type"),
    status: Optional[str] = Query(None, description="Filter by status: online/offline/error/maintenance"),
    room_id: Optional[UUID] = Query(None, description="Filter by room ID"),
    page: int = Query(1, ge=1, description="Page number"),
    per_page: int = Query(10, ge=1, le=100, description="Items per page"),
    current_user: User = Depends(_view),
    db: AsyncSession = Depends(get_db),
):
    conditions = []

    if device_type:
        conditions.append(Device.device_type == device_type)
    if status:
        conditions.append(Device.status == status)
    if room_id:
        conditions.append(Device.location_id == room_id)
    if search and search.strip():
        like = f"%{search.strip()}%"
        conditions.append(or_(Device.code.ilike(like), Device.name.ilike(like), Device.ip_address.ilike(like)))

    where_clause = and_(*conditions) if conditions else True

    count_stmt = select(func.count(Device.id)).where(where_clause)
    total_result = await db.execute(count_stmt)
    total = total_result.scalar() or 0

    offset = (page - 1) * per_page
    stmt = (
        select(Device, Room)
        .outerjoin(Room, Device.location_id == Room.id)
        .where(where_clause)
        .order_by(Device.created_at.desc())
        .offset(offset)
        .limit(per_page)
    )
    result = await db.execute(stmt)
    rows = result.all()

    items = []
    for dev, room in rows:
        items.append(
            DeviceResponse(
                id=dev.id,
                name=dev.name,
                device_type=dev.device_type,
                code=dev.code,
                location_id=dev.location_id,
                room_name=room.name if room else None,
                ip_address=dev.ip_address,
                mac_address=dev.mac_address,
                firmware_version=dev.firmware_version,
                status=dev.status,
                last_seen=dev.last_seen,
                config=dev.config or {},
                last_action=dev.last_action,
                live=live_hub.device_live(str(dev.id), dev.code),
                created_at=dev.created_at,
                updated_at=dev.updated_at,
            )
        )

    total_pages = math.ceil(total / per_page) if per_page > 0 else 0

    return SuccessResponse(
        data=PaginatedDevicesResponse(
            items=items,
            total=total,
            page=page,
            per_page=per_page,
            total_pages=total_pages,
        )
    )


@router.post("", response_model=SuccessResponse)
async def create_device(
    request: DeviceCreate,
    current_user: User = Depends(_write),
    db: AsyncSession = Depends(get_db),
):
    existing_code = await db.execute(select(Device).where(Device.code == request.code))
    if existing_code.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Kode device sudah digunakan",
        )

    if request.location_id:
        room_check = await db.execute(select(Room).where(Room.id == request.location_id))
        if not room_check.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Room ID tidak valid",
            )

    new_dev = Device(
        name=request.name,
        device_type=request.device_type,
        code=request.code,
        location_id=request.location_id,
        ip_address=request.ip_address,
        mac_address=request.mac_address,
        firmware_version=request.firmware_version,
        status=request.status,
        last_seen=request.last_seen,
        config=request.config or {},
    )

    db.add(new_dev)
    await db.commit()
    await db.refresh(new_dev)

    dev_data = await _get_device_with_room(db, new_dev.id)
    return SuccessResponse(data=dev_data)


@router.get("/health", response_model=SuccessResponse)
async def devices_health(
    current_user: User = Depends(_view),
    db: AsyncSession = Depends(get_db),
):
    total_stmt = select(func.count(Device.id))
    online_stmt = select(func.count(Device.id)).where(Device.status == "online")
    offline_stmt = select(func.count(Device.id)).where(Device.status == "offline")
    error_stmt = select(func.count(Device.id)).where(Device.status == "error")
    maint_stmt = select(func.count(Device.id)).where(Device.status == "maintenance")

    total = (await db.execute(total_stmt)).scalar() or 0
    count_online = (await db.execute(online_stmt)).scalar() or 0
    count_offline = (await db.execute(offline_stmt)).scalar() or 0
    count_error = (await db.execute(error_stmt)).scalar() or 0
    count_maintenance = (await db.execute(maint_stmt)).scalar() or 0

    room_stmt = (
        select(Room.id, Room.name, Room.code, Device.status, func.count(Device.id))
        .outerjoin(Device, Room.id == Device.location_id)
        .group_by(Room.id, Room.name, Room.code, Device.status)
        .order_by(Room.name.asc())
    )
    room_result = await db.execute(room_stmt)
    room_rows = room_result.all()

    rooms_map: Dict[str, Any] = {}
    for room_id, room_name, room_code, dev_status, cnt in room_rows:
        if room_id is None:
            room_key = "unassigned"
            room_name_val = "Unassigned"
            room_code_val = "-"
        else:
            room_key = str(room_id)
            room_name_val = room_name
            room_code_val = room_code

        if room_key not in rooms_map:
            rooms_map[room_key] = {
                "room_id": None if room_key == "unassigned" else str(room_id),
                "room_name": room_name_val,
                "room_code": room_code_val,
                "online": 0,
                "offline": 0,
                "error": 0,
                "maintenance": 0,
                "total": 0,
            }

        if dev_status:
            rooms_map[room_key][dev_status] = int(cnt)
        rooms_map[room_key]["total"] += int(cnt)

    list_per_room = list(rooms_map.values())

    return SuccessResponse(
        data=DeviceHealthSummary(
            count_total=total,
            count_online=count_online,
            count_offline=count_offline,
            count_error=count_error,
            count_maintenance=count_maintenance,
            list_per_room=list_per_room,
        )
    )


@router.get("/health/summary", response_model=SuccessResponse)
async def devices_health_summary_frontend_alias(
    current_user: User = Depends(_view),
    db: AsyncSession = Depends(get_db),
):
    return await devices_health(current_user, db)


@router.get("/{device_id}", response_model=SuccessResponse)
async def get_device(
    device_id: UUID,
    current_user: User = Depends(_view),
    db: AsyncSession = Depends(get_db),
):
    dev_data = await _get_device_with_room(db, device_id)
    if not dev_data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device tidak ditemukan",
        )
    return SuccessResponse(data=dev_data)


@router.get("/{device_id}/status", response_model=SuccessResponse)
async def get_device_status(
    device_id: UUID,
    current_user: User = Depends(_view),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Device).where(Device.id == device_id))
    dev = result.scalar_one_or_none()
    if not dev:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device tidak ditemukan",
        )

    is_healthy = dev.status == "online"
    uptime_suggestion = None
    if dev.last_seen:
        delta = datetime.now(timezone.utc) - dev.last_seen if dev.last_seen.tzinfo else datetime.now() - dev.last_seen
        if delta < timedelta(minutes=5):
            uptime_suggestion = "Normal - baru saja terhubung"
        elif delta < timedelta(hours=1):
            uptime_suggestion = f"Terakhir terhubung {int(delta.seconds / 60)} menit lalu"
        else:
            uptime_suggestion = f"Terakhir terhubung {int(delta.total_seconds() / 3600)} jam lalu"
    else:
        uptime_suggestion = "Belum pernah terhubung"

    return SuccessResponse(
        data=DeviceStatusResponse(
            id=dev.id,
            name=dev.name,
            code=dev.code,
            status=dev.status,
            last_seen=dev.last_seen,
            uptime_suggestion=uptime_suggestion,
            is_healthy=is_healthy,
        )
    )


@router.put("/{device_id}", response_model=SuccessResponse)
async def update_device(
    device_id: UUID,
    request: DeviceUpdate,
    current_user: User = Depends(_write),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Device).where(Device.id == device_id))
    dev = result.scalar_one_or_none()
    if not dev:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device tidak ditemukan",
        )

    if request.code and request.code != dev.code:
        existing_code = await db.execute(select(Device).where(Device.code == request.code))
        if existing_code.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Kode device sudah digunakan",
            )
        dev.code = request.code

    if request.location_id is not None:
        if request.location_id:
            room_check = await db.execute(select(Room).where(Room.id == request.location_id))
            if not room_check.scalar_one_or_none():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Room ID tidak valid",
                )
        dev.location_id = request.location_id

    if request.name is not None:
        dev.name = request.name
    if request.device_type is not None:
        dev.device_type = request.device_type
    if request.ip_address is not None:
        dev.ip_address = request.ip_address
    if request.mac_address is not None:
        dev.mac_address = request.mac_address
    if request.firmware_version is not None:
        dev.firmware_version = request.firmware_version
    if request.status is not None:
        # Status manual hanya untuk menandai maintenance/offline; online/offline
        # sebenarnya diperbarui otomatis dari MQTT (state/agent status).
        dev.status = request.status
    if request.config is not None:
        dev.config = request.config

    await db.commit()
    await db.refresh(dev)

    dev_data = await _get_device_with_room(db, device_id)
    return SuccessResponse(data=dev_data)


# ---------------------------------------------------------------------------
# Perintah perangkat: lewat MQTT + tunggu ack agent (<= 3 detik).
# Status online/offline TIDAK diubah di sini; status datang dari topic
# state/agent (src/api/services/live_hub.py).
# Respons: {"cmd_id", "status": "acked"|"failed"|"timeout", "error", "results"}
# 503 {"code": "MQTT_NOT_CONFIGURED"|"MQTT_NOT_CONNECTED"} bila broker tidak siap.
# ---------------------------------------------------------------------------

async def _device_command(device_id: UUID, action: str, user: User, db: AsyncSession) -> Dict[str, Any]:
    dev = (await db.execute(select(Device).where(Device.id == device_id))).scalar_one_or_none()
    if not dev:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Device tidak ditemukan")
    return await av.device_command(db, dev, action, user)


@router.post("/{device_id}/power-on", response_model=SuccessResponse)
async def power_on_device(device_id: UUID, current_user: User = Depends(_control), db: AsyncSession = Depends(get_db)):
    return SuccessResponse(data=await _device_command(device_id, "power_on", current_user, db))


@router.post("/{device_id}/power-off", response_model=SuccessResponse)
async def power_off_device(device_id: UUID, current_user: User = Depends(_control), db: AsyncSession = Depends(get_db)):
    return SuccessResponse(data=await _device_command(device_id, "power_off", current_user, db))


@router.post("/{device_id}/lock", response_model=SuccessResponse)
async def lock_device(device_id: UUID, current_user: User = Depends(_control), db: AsyncSession = Depends(get_db)):
    return SuccessResponse(data=await _device_command(device_id, "lock", current_user, db))


@router.post("/{device_id}/unlock", response_model=SuccessResponse)
async def unlock_device(device_id: UUID, current_user: User = Depends(_control), db: AsyncSession = Depends(get_db)):
    return SuccessResponse(data=await _device_command(device_id, "unlock", current_user, db))


@router.post("/{device_id}/restart", response_model=SuccessResponse)
async def restart_device(device_id: UUID, current_user: User = Depends(_control), db: AsyncSession = Depends(get_db)):
    return SuccessResponse(data=await _device_command(device_id, "restart", current_user, db))


@router.delete("/{device_id}", response_model=SuccessResponse)
async def delete_device(
    device_id: UUID,
    current_user: User = Depends(_write),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Device).where(Device.id == device_id))
    dev = result.scalar_one_or_none()
    if not dev:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device tidak ditemukan",
        )

    await db.delete(dev)
    await db.commit()

    return SuccessResponse(data={"message": "Device berhasil dihapus"})
