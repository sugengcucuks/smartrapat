from fastapi import APIRouter, Depends, HTTPException, status, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from typing import Iterable, Optional
from uuid import UUID
import math

from src.api.database import get_db
from src.api.models.user import User, Role
from src.api.schemas.role import (
    SuccessResponse,
    RoleCreate,
    RoleUpdate,
    RoleResponse,
    RolePermissionSync,
)
from src.api.utils.audit import record_audit
from src.api.utils.permissions import (
    PERMISSIONS,
    PERMISSION_CODES,
    PERMISSION_ID_TO_CODE,
    LEGACY_MAP,
    is_super_admin,
    is_super_admin_role_name,
    normalize_permissions,
    require_permission,
    user_permissions,
)

router = APIRouter(prefix="/roles", tags=["Roles & Permissions"])

STRUCTURED_PERMISSIONS = PERMISSIONS
CODE_TO_PERMISSION_ID = {v: k for k, v in PERMISSION_ID_TO_CODE.items()}


# ============================================
# Helper
# ============================================

def _forbidden(message: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail={"code": "FORBIDDEN", "message": message},
    )


def _is_super_role(role: Role) -> bool:
    return is_super_admin_role_name(role.name) or "*" in normalize_permissions(role.permissions or [])


def _role_response(role: Role) -> dict:
    codes = sorted(normalize_permissions(role.permissions or []))
    data = RoleResponse(
        id=role.id,
        name=role.name,
        description=role.description,
        permissions=codes,
        is_active=role.is_active,
        created_at=role.created_at,
        updated_at=role.updated_at,
    ).model_dump(mode="json")
    # `permission_ids` (perm_*) dipakai modal izin di frontend.
    data["permission_ids"] = ["*"] if "*" in codes else [CODE_TO_PERMISSION_ID[c] for c in codes if c in CODE_TO_PERMISSION_ID]
    data["permission_count"] = len(PERMISSION_CODES) if "*" in codes else len(codes)
    data["is_system"] = _is_super_role(role)
    return data


def _validate_and_normalize(actor: User, raw: Iterable[str]) -> list:
    """Validasi daftar izin (kode baru / id perm_* / kode lama) -> list kode baru."""
    raw = list(raw or [])
    invalid = [
        p for p in raw
        if not (p == "*" or p in PERMISSION_CODES or p in PERMISSION_ID_TO_CODE or p in LEGACY_MAP)
    ]
    if invalid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Permission tidak valid: {', '.join(map(str, invalid))}",
        )
    codes = normalize_permissions(raw)
    if not is_super_admin(actor):
        if "*" in codes:
            raise _forbidden("Hanya Super Admin yang dapat memberikan izin penuh (*)")
        extra = codes - user_permissions(actor)
        if extra:
            raise _forbidden(f"Tidak dapat memberikan izin yang tidak Anda miliki: {', '.join(sorted(extra))}")
    return sorted(codes)


def _ensure_role_name_allowed(actor: User, name: Optional[str]) -> None:
    # Role bernama "Super Admin" otomatis mendapat semua izin -> hanya Super Admin.
    if name and is_super_admin_role_name(name) and not is_super_admin(actor):
        raise _forbidden("Nama role tersebut hanya dapat dipakai oleh Super Admin")


def _ensure_can_modify(actor: User, role: Role) -> None:
    if _is_super_role(role) and not is_super_admin(actor):
        raise _forbidden("Role Super Admin hanya dapat diubah oleh Super Admin")


async def _get_role_or_404(db: AsyncSession, role_id: UUID) -> Role:
    role = (await db.execute(select(Role).where(Role.id == role_id))).scalar_one_or_none()
    if not role:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Role tidak ditemukan")
    return role


# ============================================
# Endpoint
# ============================================

@router.get("", response_model=SuccessResponse)
async def list_roles(
    page: int = Query(1, ge=1, description="Page number"),
    per_page: int = Query(10, ge=1, le=100, description="Items per page"),
    # users.create/edit perlu daftar role untuk dropdown form pengguna.
    current_user: User = Depends(require_permission("roles.view", "users.create", "users.edit")),
    db: AsyncSession = Depends(get_db),
):
    count_stmt = select(func.count(Role.id))
    count_result = await db.execute(count_stmt)
    total = count_result.scalar() or 0

    offset = (page - 1) * per_page
    stmt = select(Role).order_by(Role.name.asc()).offset(offset).limit(per_page)
    result = await db.execute(stmt)
    roles = result.scalars().all()

    items = [_role_response(role) for role in roles]
    total_pages = math.ceil(total / per_page) if per_page > 0 else 0

    return SuccessResponse(data={
        "items": items,
        "total": total,
        "page": page,
        "per_page": per_page,
        "total_pages": total_pages,
    })


@router.get("/permissions", response_model=SuccessResponse)
async def list_permissions(
    current_user: User = Depends(require_permission("roles.view")),
):
    return SuccessResponse(data=STRUCTURED_PERMISSIONS)


@router.post("", response_model=SuccessResponse)
async def create_role(
    request: RoleCreate,
    http_request: Request,
    current_user: User = Depends(require_permission("roles.write")),
    db: AsyncSession = Depends(get_db),
):
    _ensure_role_name_allowed(current_user, request.name)
    existing = await db.execute(select(Role).where(Role.name == request.name))
    if existing.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Nama role sudah digunakan",
        )

    codes = _validate_and_normalize(current_user, request.all_permissions())
    new_role = Role(
        name=request.name,
        description=request.description,
        permissions=codes,
        is_active=request.is_active if request.is_active is not None else True,
    )

    db.add(new_role)
    await db.flush()
    await record_audit(
        db, current_user, "create", "roles", "role", new_role.id,
        {"name": new_role.name, "permissions": codes}, http_request,
    )
    await db.commit()
    await db.refresh(new_role)
    return SuccessResponse(data=_role_response(new_role))


@router.get("/{role_id}", response_model=SuccessResponse)
async def get_role(
    role_id: UUID,
    current_user: User = Depends(require_permission("roles.view")),
    db: AsyncSession = Depends(get_db),
):
    role = await _get_role_or_404(db, role_id)
    return SuccessResponse(data=_role_response(role))


@router.put("/{role_id}", response_model=SuccessResponse)
async def update_role(
    role_id: UUID,
    request: RoleUpdate,
    http_request: Request,
    current_user: User = Depends(require_permission("roles.write")),
    db: AsyncSession = Depends(get_db),
):
    role = await _get_role_or_404(db, role_id)
    _ensure_can_modify(current_user, role)
    old = {"name": role.name, "is_active": role.is_active, "permissions": list(role.permissions or [])}

    if request.name and request.name != role.name:
        _ensure_role_name_allowed(current_user, request.name)
        existing = await db.execute(select(Role).where(Role.name == request.name))
        if existing.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Nama role sudah digunakan",
            )
        role.name = request.name

    if request.description is not None:
        role.description = request.description
    if request.is_active is not None:
        if role.id == current_user.role_id and not request.is_active:
            raise _forbidden("Tidak dapat menonaktifkan role Anda sendiri")
        role.is_active = request.is_active
    perms = request.all_permissions()
    if perms is not None:
        role.permissions = _validate_and_normalize(current_user, perms)

    await record_audit(
        db, current_user, "update", "roles", "role", role.id,
        {"name": role.name, "is_active": role.is_active, "permissions": list(role.permissions or [])},
        http_request, old_value=old,
    )
    await db.commit()
    await db.refresh(role)
    return SuccessResponse(data=_role_response(role))


@router.delete("/{role_id}", response_model=SuccessResponse)
async def delete_role(
    role_id: UUID,
    http_request: Request,
    current_user: User = Depends(require_permission("roles.write")),
    db: AsyncSession = Depends(get_db),
):
    role = await _get_role_or_404(db, role_id)
    if _is_super_role(role):
        raise _forbidden("Role Super Admin tidak dapat dihapus")

    user_count_result = await db.execute(
        select(func.count(User.id)).where(User.role_id == role_id)
    )
    user_count = user_count_result.scalar() or 0
    if user_count > 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Role masih memiliki {user_count} user, tidak dapat dihapus",
        )

    await record_audit(db, current_user, "delete", "roles", "role", role.id, {"name": role.name}, http_request)
    await db.delete(role)
    await db.commit()

    return SuccessResponse(data={"message": "Role berhasil dihapus"})


@router.post("/{role_id}/permissions", response_model=SuccessResponse)
async def sync_role_permissions(
    role_id: UUID,
    request: RolePermissionSync,
    http_request: Request,
    current_user: User = Depends(require_permission("roles.write")),
    db: AsyncSession = Depends(get_db),
):
    role = await _get_role_or_404(db, role_id)
    _ensure_can_modify(current_user, role)

    old = list(role.permissions or [])
    role.permissions = _validate_and_normalize(current_user, request.all_permissions() or [])
    await record_audit(
        db, current_user, "update", "roles", "role_permissions", role.id,
        {"permissions": role.permissions}, http_request, old_value={"permissions": old},
    )
    await db.commit()
    await db.refresh(role)
    return SuccessResponse(data=_role_response(role))
