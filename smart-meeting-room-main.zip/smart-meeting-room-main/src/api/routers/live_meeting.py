"""Denah kursi, pemetaan mic -> kursi -> peserta, dan state live meeting.

Kontrak: docs/architecture/LIVE_MEETING.md (bagian 4 & 5).

Rantai atribusi pembicara:
    kanal audio -> audio_channels -> room_seats.audio_channel_id
    -> booking_seat_assignments (per rapat) -> booking_participants -> nama

Endpoint:
- GET/PUT  /rooms/{room_id}/seats, POST /rooms/{room_id}/seats/generate
- GET      /bookings/{id}/live
- POST     /bookings/{id}/meeting/start | end | extend
- GET/PUT  /bookings/{id}/seat-assignments, POST /bookings/{id}/seat-assignments/auto
"""
from __future__ import annotations

import inspect
import logging
import math
from datetime import date, datetime, time, timedelta
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import and_, delete, func, or_, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.database import get_db
from src.api.models.booking import Booking, BookingParticipant
from src.api.models.live import AudioChannel, BookingSeatAssignment, MeetingRecording, RoomSeat
from src.api.models.note import MeetingNote
from src.api.models.room import Room
from src.api.models.user import User
from src.api.schemas.live_meeting import (
    MeetingExtendRequest,
    SeatAssignmentBatch,
    SeatAutoAssignRequest,
    SeatBatchUpdate,
    SeatGenerateRequest,
)
from src.api.schemas.user import SuccessResponse
from src.api.utils.audit import record_audit
from src.api.utils.auth import get_current_user
from src.api.utils.permissions import has_permission, require_permission

from src.api.services.live_hub import live_hub

router = APIRouter(tags=["Live Meeting & Denah Kursi"])
logger = logging.getLogger("smr.live_meeting")

# Rapat boleh dimulai 30 menit sebelum jadwal (sama dengan jendela presensi).
START_OPEN_BEFORE_MINUTES = 30
ACTIVE_RECORDING_STATUSES = ("recording", "paused")
# Kursi yang boleh diisi otomatis saat presensi, urut prioritas.
CHECKIN_SEAT_TYPES = ("delegate", "guest")


# ============================================================
# Util umum
# ============================================================

def _now() -> datetime:
    """Waktu lokal server (naive) - konsisten dengan kolom date/time booking."""
    return datetime.now()


def _now_aware() -> datetime:
    return datetime.now().astimezone()


def _iso_local(d: date, t: time) -> str:
    return datetime.combine(d, t).astimezone().isoformat()


def _forbidden(message: str) -> HTTPException:
    return HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail={"code": "FORBIDDEN", "message": message})


def _bad_request(message: str, code: str = "INVALID") -> HTTPException:
    return HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail={"code": code, "message": message})


def _conflict(message: str, code: str = "CONFLICT") -> HTTPException:
    return HTTPException(status_code=status.HTTP_409_CONFLICT, detail={"code": code, "message": message})


async def _hub_call(method: str, *args: Any) -> None:
    """Panggil live_hub.<method> bila modul tersedia; best effort (sync/async)."""
    if live_hub is None:
        return
    fn = getattr(live_hub, method, None)
    if fn is None:
        return
    try:
        res = fn(*args)
        if inspect.isawaitable(res):
            await res
    except Exception:  # noqa: BLE001 - siaran tidak boleh menggagalkan aksi utama
        logger.debug("live_hub.%s gagal", method, exc_info=True)


async def hub_broadcast(room_id: Any, event: str, data: Dict[str, Any]) -> None:
    await _hub_call("broadcast", str(room_id), event, data)


async def hub_invalidate(room_id: Any) -> None:
    await _hub_call("invalidate_room", str(room_id))


async def _door_broadcast(db: AsyncSession, room: Optional[Room], extra: Optional[dict] = None) -> None:
    """Kabari kiosk pintu (status_changed) agar jam selesai/ketersediaan ikut ter-update."""
    if room is None:
        return
    try:
        from src.api.routers.door_display import door_ws_manager, _get_status_payload

        payload = await _get_status_payload(db, room)
        if payload:
            await door_ws_manager.broadcast_room(
                room.code,
                {"event": "status_changed", "data": payload, "timestamp": _now().isoformat()},
            )
        if extra:
            await door_ws_manager.broadcast_room(room.code, {**extra, "timestamp": _now().isoformat()})
    except Exception:  # noqa: BLE001
        logger.debug("Broadcast door display gagal", exc_info=True)


async def _get_room(db: AsyncSession, room_id: UUID) -> Room:
    room = (await db.execute(select(Room).where(Room.id == room_id))).scalar_one_or_none()
    if room is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Ruangan tidak ditemukan")
    return room


async def _get_booking(db: AsyncSession, booking_id: UUID) -> Booking:
    booking = (await db.execute(select(Booking).where(Booking.id == booking_id))).scalar_one_or_none()
    if booking is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Booking tidak ditemukan")
    return booking


def can_control(user: User, booking: Booking) -> bool:
    """Pemilik booking atau pemegang bookings.approve."""
    return booking.user_id == user.id or has_permission(user, "bookings.approve")


def _ensure_control(user: User, booking: Booking) -> None:
    if not can_control(user, booking):
        raise _forbidden("Hanya pemilik booking atau approver yang dapat mengelola rapat ini")


async def _ensure_view(db: AsyncSession, user: User, booking: Booking) -> None:
    """Pemilik, peserta rapat (akun terdaftar), atau pemegang bookings.view."""
    if booking.user_id == user.id or has_permission(user, "bookings.view", "bookings.approve"):
        return
    is_participant = await db.scalar(
        select(func.count(BookingParticipant.id)).where(
            BookingParticipant.booking_id == booking.id,
            BookingParticipant.user_id == user.id,
        )
    )
    if not is_participant:
        raise _forbidden("Anda tidak berhak melihat rapat ini")


def participant_name(p: BookingParticipant, user: Optional[User]) -> str:
    """Normalisasi nama peserta: nama akun, lalu nama tamu."""
    if user is not None and user.name:
        return user.name
    if p.guest_name:
        return p.guest_name
    return "Tamu" if p.is_guest else "Peserta"


# ============================================================
# Serialisasi
# ============================================================

def _channel_dict(ch: Optional[AudioChannel]) -> Optional[Dict[str, Any]]:
    if ch is None:
        return None
    return {
        "id": str(ch.id),
        "room_id": str(ch.room_id),
        "channel_no": ch.channel_no,
        "label": ch.label,
        "receiver_label": ch.receiver_label,
        "mixer_channel": ch.mixer_channel,
        "capture_channel": ch.capture_channel,
        "device_id": str(ch.device_id) if ch.device_id else None,
        "enabled": bool(ch.is_enabled),
    }


def _seat_dict(seat: RoomSeat, channels: Dict[UUID, AudioChannel]) -> Dict[str, Any]:
    ch = channels.get(seat.audio_channel_id) if seat.audio_channel_id else None
    return {
        "id": str(seat.id),
        "room_id": str(seat.room_id),
        "seat_no": seat.seat_no,
        "label": seat.label,
        "seat_type": seat.seat_type,
        "pos_x": float(seat.pos_x),
        "pos_y": float(seat.pos_y),
        "rotation": int(seat.rotation or 0),
        "audio_channel_id": str(seat.audio_channel_id) if seat.audio_channel_id else None,
        "channel": _channel_dict(ch),
    }


async def _load_channels(db: AsyncSession, room_id: UUID) -> List[AudioChannel]:
    res = await db.execute(
        select(AudioChannel).where(AudioChannel.room_id == room_id).order_by(AudioChannel.channel_no.asc())
    )
    return list(res.scalars().all())


async def _load_seats(db: AsyncSession, room_id: UUID) -> List[RoomSeat]:
    res = await db.execute(
        select(RoomSeat).where(RoomSeat.room_id == room_id).order_by(RoomSeat.seat_no.asc())
    )
    return list(res.scalars().all())


async def _seat_map_payload(db: AsyncSession, room: Room) -> Dict[str, Any]:
    channels = await _load_channels(db, room.id)
    by_id = {c.id: c for c in channels}
    seats = await _load_seats(db, room.id)
    return {
        "room_id": str(room.id),
        "room_name": room.name,
        "room_code": room.code,
        "capacity": room.capacity,
        "layout": room.seat_layout,
        "seats": [_seat_dict(s, by_id) for s in seats],
        "audio_channels": [_channel_dict(c) for c in channels],
    }


async def _load_participants(db: AsyncSession, booking_id: UUID) -> List[Tuple[BookingParticipant, Optional[User]]]:
    res = await db.execute(
        select(BookingParticipant, User)
        .outerjoin(User, BookingParticipant.user_id == User.id)
        .where(BookingParticipant.booking_id == booking_id)
        .order_by(BookingParticipant.created_at.asc(), BookingParticipant.id.asc())
    )
    return list(res.all())


async def _load_assignments(db: AsyncSession, booking_id: UUID) -> List[BookingSeatAssignment]:
    res = await db.execute(select(BookingSeatAssignment).where(BookingSeatAssignment.booking_id == booking_id))
    return list(res.scalars().all())


def _assignment_dict(
    a: BookingSeatAssignment,
    seat: Optional[RoomSeat],
    names: Dict[UUID, str],
) -> Dict[str, Any]:
    name = names.get(a.participant_id) if a.participant_id else None
    return {
        "id": str(a.id),
        "booking_id": str(a.booking_id),
        "seat_id": str(a.seat_id),
        "seat_no": seat.seat_no if seat else None,
        "seat_label": seat.label if seat else None,
        "participant_id": str(a.participant_id) if a.participant_id else None,
        "display_name": a.display_name,
        "name": name or a.display_name,
        "role_label": a.role_label,
        "assigned_via": a.assigned_via,
    }


async def _assignments_payload(db: AsyncSession, booking: Booking) -> List[Dict[str, Any]]:
    seats = {s.id: s for s in await _load_seats(db, booking.room_id)}
    names = {p.id: participant_name(p, u) for p, u in await _load_participants(db, booking.id)}
    items = [
        _assignment_dict(a, seats.get(a.seat_id), names)
        for a in await _load_assignments(db, booking.id)
        if a.seat_id in seats
    ]
    items.sort(key=lambda x: x["seat_no"] or 0)
    return items


def _effective_end(booking: Booking) -> datetime:
    return datetime.combine(booking.date, booking.end_time)


def _meeting_status_payload(booking: Booking) -> Dict[str, Any]:
    return {
        "booking_id": str(booking.id),
        "meeting_status": booking.meeting_status,
        "status": booking.status,
        "end_time": booking.end_time.strftime("%H:%M:%S"),
        "end_time_effective": _iso_local(booking.date, booking.end_time),
        "extended_minutes": booking.extended_minutes or 0,
        "actual_start_at": booking.actual_start_at.isoformat() if booking.actual_start_at else None,
        "actual_end_at": booking.actual_end_at.isoformat() if booking.actual_end_at else None,
    }


# ============================================================
# Generator denah
# ============================================================

def _r(v: float) -> float:
    return round(max(0.0, min(100.0, v)), 1)


def _spread(n: int, lo: float, hi: float) -> List[float]:
    """n titik merata di dalam [lo, hi] (tengah-tengah tiap slot)."""
    if n <= 0:
        return []
    step = (hi - lo) / n
    return [lo + step * (i + 0.5) for i in range(n)]


def _face_center(x: float, y: float, cx: float, cy: float) -> int:
    """Rotasi (derajat, 0 = menghadap atas, searah jarum jam) agar kursi menghadap titik (cx, cy)."""
    # Kanvas 16:10 -> satu persen x lebih lebar dari satu persen y.
    dx = (cx - x) * 1.6
    dy = cy - y
    if dx == 0 and dy == 0:
        return 0
    return int(round(math.degrees(math.atan2(dx, -dy)))) % 360


def generate_layout(layout: str, count: int, chair_count: int) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Hitung posisi kursi (persen) + bentuk meja untuk tata letak standar.

    Kursi pimpinan (chair) selalu bernomor 1..chair_count, sisanya delegate.
    """
    chair_count = max(0, min(chair_count, count))
    rest = count - chair_count
    pos: List[Tuple[float, float, int]] = []  # chair dulu, lalu delegate
    tables: List[Dict[str, Any]] = []

    if layout == "boardroom":
        tx, ty, tw, th = 16.0, 33.0, 68.0, 34.0
        tables.append({"shape": "rect", "x": tx, "y": ty, "w": tw, "h": th, "label": "Meja Rapat"})
        # Pimpinan di ujung kiri meja.
        for y in _spread(chair_count, 50 - 6 * chair_count, 50 + 6 * chair_count):
            pos.append((8.0, y, 90))
        top = math.ceil(rest / 2)
        bottom = rest - top
        for x in _spread(top, tx + 2, tx + tw - 2):
            pos.append((x, 22.0, 180))
        for x in reversed(_spread(bottom, tx + 2, tx + tw - 2)):
            pos.append((x, 78.0, 0))
    elif layout == "classroom":
        tables.append({"shape": "rect", "x": 34.0, "y": 13.0, "w": 32.0, "h": 6.0, "label": "Meja Pimpinan"})
        for x in _spread(chair_count, 50 - 7 * chair_count, 50 + 7 * chair_count):
            pos.append((x, 6.0, 180))
        cols = max(1, min(8, math.ceil(math.sqrt(max(rest, 1) * 1.6))))
        rows = math.ceil(rest / cols) if rest else 0
        y0, y1 = 36.0, 92.0
        gap = min(16.0, (y1 - y0) / max(rows - 1, 1)) if rows > 1 else 0.0
        idx = 0
        for r in range(rows):
            in_row = min(cols, rest - idx)
            y = y0 + gap * r
            xs = _spread(cols, 8, 92)[:in_row] if in_row == cols else _spread(in_row, 50 - 42 * in_row / cols, 50 + 42 * in_row / cols)
            tables.append({"shape": "rect", "x": _r(xs[0] - 4), "y": _r(y - 7), "w": _r(xs[-1] - xs[0] + 8), "h": 3.5})
            for x in xs:
                pos.append((x, y, 0))
            idx += in_row
    elif layout == "circle":
        cx, cy = 50.0, 51.0
        tables.append({"shape": "ellipse", "x": 26.0, "y": 19.0, "w": 48.0, "h": 64.0, "label": "Meja Bundar"})
        rx, ry = 36.0, 42.0
        for i in range(count):
            a = -math.pi / 2 + 2 * math.pi * i / count
            x, y = cx + rx * math.cos(a), cy + ry * math.sin(a)
            pos.append((x, y, _face_center(x, y, cx, cy)))
    else:  # u_shape: alas U di atas (pimpinan), terbuka ke bawah (layar/videowall)
        ux, uy, uw, uh, utx, uty = 20.0, 18.0, 60.0, 56.0, 8.0, 12.0
        tables.append({"shape": "u", "x": ux, "y": uy, "w": uw, "h": uh, "tx": utx, "ty": uty, "label": "Meja U"})
        base_total = max(chair_count, min(rest + chair_count, round(count * 0.25) or 1))
        base_x = _spread(base_total, ux + 3, ux + uw - 3)
        # Pimpinan di tengah alas.
        mid = (base_total - chair_count) // 2
        chair_idx = list(range(mid, mid + chair_count))
        for i in chair_idx:
            pos.append((base_x[i], 9.0, 180))
        for i, x in enumerate(base_x):
            if i not in chair_idx:
                pos.append((x, 9.0, 180))
        arms = count - base_total
        left = math.ceil(arms / 2)
        right = arms - left
        for y in _spread(left, uy + uty + 2, uy + uh):
            pos.append((ux - 7, y, 90))
        for y in _spread(right, uy + uty + 2, uy + uh):
            pos.append((ux + uw + 7, y, 270))

    seats = []
    for i, (x, y, rot) in enumerate(pos[:count]):
        n = i + 1
        seats.append({
            "seat_no": n,
            "label": str(n),
            "seat_type": "chair" if n <= chair_count else "delegate",
            "pos_x": _r(x),
            "pos_y": _r(y),
            "rotation": int(rot) % 360,
        })
    return seats, {"type": layout, "tables": tables}


def default_receiver_label(n: int) -> str:
    """Kanal ke-n -> label receiver Ashley M118 (A: CH1-8, B: CH1-8, ...)."""
    rx = chr(ord("A") + (n - 1) // 8)
    return f"M118-{rx} CH{(n - 1) % 8 + 1}"


# ============================================================
# Denah kursi (per ruangan)
# ============================================================

async def _live_booking_ids_for_seats(db: AsyncSession, seat_ids: Sequence[UUID]) -> List[str]:
    """Judul rapat LIVE yang masih memakai kursi-kursi ini."""
    if not seat_ids:
        return []
    res = await db.execute(
        select(Booking.title)
        .join(BookingSeatAssignment, BookingSeatAssignment.booking_id == Booking.id)
        .where(
            BookingSeatAssignment.seat_id.in_(list(seat_ids)),
            Booking.meeting_status == "live",
        )
        .distinct()
    )
    return [r[0] for r in res.all()]


@router.get("/rooms/{room_id}/seats", response_model=SuccessResponse)
async def get_room_seats(
    room_id: UUID,
    current_user: User = Depends(require_permission("rooms.view", "bookings.view")),
    db: AsyncSession = Depends(get_db),
):
    room = await _get_room(db, room_id)
    return SuccessResponse(data=await _seat_map_payload(db, room))


@router.put("/rooms/{room_id}/seats", response_model=SuccessResponse)
async def save_room_seats(
    room_id: UUID,
    body: SeatBatchUpdate,
    request: Request,
    current_user: User = Depends(require_permission("rooms.write")),
    db: AsyncSession = Depends(get_db),
):
    """Simpan denah secara batch: upsert per `id`, kursi yang tidak dikirim dihapus."""
    room = await _get_room(db, room_id)
    existing = {s.id: s for s in await _load_seats(db, room_id)}
    channels = {c.id: c for c in await _load_channels(db, room_id)}

    seen_no: set = set()
    seen_ids: set = set()
    seen_ch: set = set()
    for it in body.items:
        if it.seat_no in seen_no:
            raise _bad_request(f"Nomor kursi {it.seat_no} dipakai lebih dari sekali", "DUPLICATE_SEAT_NO")
        seen_no.add(it.seat_no)
        if it.id is not None:
            if it.id not in existing:
                raise _bad_request("Kursi tidak ditemukan di ruangan ini", "SEAT_NOT_IN_ROOM")
            if it.id in seen_ids:
                raise _bad_request("Kursi yang sama dikirim lebih dari sekali", "DUPLICATE_SEAT")
            seen_ids.add(it.id)
        if it.audio_channel_id is not None:
            if it.audio_channel_id not in channels:
                raise _bad_request("Kanal mic bukan milik ruangan ini", "CHANNEL_NOT_IN_ROOM")
            if it.audio_channel_id in seen_ch:
                ch = channels[it.audio_channel_id]
                raise _bad_request(f"{ch.label} dipasang di lebih dari satu kursi", "DUPLICATE_CHANNEL")
            seen_ch.add(it.audio_channel_id)

    to_delete = [sid for sid in existing if sid not in seen_ids]
    live_titles = await _live_booking_ids_for_seats(db, to_delete)
    if live_titles:
        raise _conflict(
            "Kursi yang akan dihapus sedang dipakai rapat berlangsung: " + ", ".join(live_titles),
            "SEAT_IN_LIVE_MEETING",
        )

    if to_delete:
        await db.execute(delete(RoomSeat).where(RoomSeat.id.in_(to_delete)))
    # Lepas nomor & kanal sementara agar penukaran antarkursi tidak melanggar indeks unik.
    keep = [sid for sid in existing if sid in seen_ids]
    if keep:
        await db.execute(
            update(RoomSeat)
            .where(RoomSeat.id.in_(keep))
            .values(seat_no=RoomSeat.seat_no + 100000, audio_channel_id=None)
            .execution_options(synchronize_session=False)
        )
    await db.flush()

    for it in body.items:
        values = dict(
            seat_no=it.seat_no, label=it.label, seat_type=it.seat_type,
            pos_x=round(it.pos_x, 2), pos_y=round(it.pos_y, 2), rotation=int(it.rotation) % 360,
            audio_channel_id=it.audio_channel_id,
        )
        if it.id is not None:
            await db.execute(
                update(RoomSeat).where(RoomSeat.id == it.id).values(**values)
                .execution_options(synchronize_session=False)
            )
        else:
            db.add(RoomSeat(room_id=room_id, **values))

    if body.layout is not None:
        room.seat_layout = body.layout.model_dump()

    await record_audit(
        db, current_user, "update", "rooms", "room_seats", room_id,
        {"seats": len(body.items), "deleted": len(to_delete)}, request,
    )
    try:
        await db.commit()
    except IntegrityError as exc:
        await db.rollback()
        raise _conflict("Denah bentrok dengan perubahan lain, muat ulang lalu coba lagi") from exc

    db.expire_all()
    await hub_invalidate(room_id)
    return SuccessResponse(data=await _seat_map_payload(db, await _get_room(db, room_id)))


@router.post("/rooms/{room_id}/seats/generate", response_model=SuccessResponse)
async def generate_room_seats(
    room_id: UUID,
    body: SeatGenerateRequest,
    request: Request,
    current_user: User = Depends(require_permission("rooms.write")),
    db: AsyncSession = Depends(get_db),
):
    """Buat ulang denah dari tata letak standar (mengganti seluruh kursi ruangan)."""
    room = await _get_room(db, room_id)
    existing = await _load_seats(db, room_id)
    live_titles = await _live_booking_ids_for_seats(db, [s.id for s in existing])
    if live_titles:
        raise _conflict(
            "Denah tidak dapat dibuat ulang saat rapat berlangsung: " + ", ".join(live_titles),
            "SEAT_IN_LIVE_MEETING",
        )

    seats, layout = generate_layout(body.layout, body.count, body.chair_count)

    channels = await _load_channels(db, room_id)
    created_channels = 0
    if body.link_channels and not channels:
        for n in range(1, body.count + 1):
            ch = AudioChannel(
                room_id=room_id, channel_no=n, label=f"Mic {n}",
                receiver_label=default_receiver_label(n), mixer_channel=n, capture_channel=n,
            )
            db.add(ch)
            channels.append(ch)
            created_channels += 1
        await db.flush()
    ch_by_no = {c.channel_no: c for c in channels} if body.link_channels else {}

    await db.execute(delete(RoomSeat).where(RoomSeat.room_id == room_id))
    await db.flush()
    for s in seats:
        ch = ch_by_no.get(s["seat_no"])
        db.add(RoomSeat(room_id=room_id, audio_channel_id=ch.id if ch else None, **s))
    room.seat_layout = layout

    await record_audit(
        db, current_user, "generate", "rooms", "room_seats", room_id,
        {"layout": body.layout, "count": body.count, "channels_created": created_channels}, request,
    )
    await db.commit()
    db.expire_all()
    await hub_invalidate(room_id)
    data = await _seat_map_payload(db, await _get_room(db, room_id))
    data["channels_created"] = created_channels
    return SuccessResponse(data=data)


# ============================================================
# Penugasan kursi (per rapat)
# ============================================================

def _pick_free_seat(
    seats: Iterable[RoomSeat], taken: set, types: Sequence[str]
) -> Optional[RoomSeat]:
    ordered = sorted(seats, key=lambda s: s.seat_no)
    for t in types:
        for s in ordered:
            if s.seat_type == t and s.id not in taken:
                return s
    return None


async def assign_seat_on_checkin(
    db: AsyncSession, booking: Booking, participant: BookingParticipant
) -> Optional[Dict[str, Any]]:
    """Dipanggil presensi setelah check-in sukses.

    Mengembalikan kursi peserta ({seat_id, seat_no, label}) - kursi yang sudah
    ditugaskan, atau kursi kosong pertama (delegate, lalu guest). Tidak pernah
    memilih kursi chair/secretary/operator. Aman terhadap check-in bersamaan.
    """
    for _attempt in range(3):
        seats = await _load_seats(db, booking.room_id)
        if not seats:
            return None
        by_id = {s.id: s for s in seats}
        assigns = await _load_assignments(db, booking.id)
        for a in assigns:
            if a.participant_id == participant.id and a.seat_id in by_id:
                s = by_id[a.seat_id]
                return {"seat_id": str(s.id), "seat_no": s.seat_no, "label": s.label}
        seat = _pick_free_seat(seats, {a.seat_id for a in assigns}, CHECKIN_SEAT_TYPES)
        if seat is None:
            return None
        try:
            async with db.begin_nested():
                db.add(BookingSeatAssignment(
                    booking_id=booking.id, seat_id=seat.id, participant_id=participant.id,
                    role_label="Peserta", assigned_via="checkin",
                ))
            await db.commit()
            return {"seat_id": str(seat.id), "seat_no": seat.seat_no, "label": seat.label}
        except IntegrityError:
            # Kursi baru saja diambil check-in lain -> coba kursi berikutnya.
            continue
    return None


async def broadcast_seats_changed(db: AsyncSession, booking: Booking) -> None:
    await hub_broadcast(booking.room_id, "seats_changed", {
        "booking_id": str(booking.id),
        "assignments": await _assignments_payload(db, booking),
    })
    await hub_invalidate(booking.room_id)


@router.get("/bookings/{booking_id}/seat-assignments", response_model=SuccessResponse)
async def list_seat_assignments(
    booking_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    booking = await _get_booking(db, booking_id)
    await _ensure_view(db, current_user, booking)
    return SuccessResponse(data={"booking_id": str(booking.id), "items": await _assignments_payload(db, booking)})


@router.put("/bookings/{booking_id}/seat-assignments", response_model=SuccessResponse)
async def save_seat_assignments(
    booking_id: UUID,
    body: SeatAssignmentBatch,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Upsert penugasan per kursi. Item tanpa participant_id & display_name = kosongkan kursi."""
    booking = await _get_booking(db, booking_id)
    _ensure_control(current_user, booking)
    if booking.meeting_status == "ended":
        raise _conflict("Rapat sudah selesai; penugasan kursi dikunci", "MEETING_ENDED")

    seats = {s.id: s for s in await _load_seats(db, booking.room_id)}
    participants = {p.id: p for p, _u in await _load_participants(db, booking.id)}

    seen_seats: set = set()
    seen_parts: set = set()
    for it in body.items:
        if it.seat_id not in seats:
            raise _bad_request("Kursi bukan bagian dari denah ruangan rapat ini", "SEAT_NOT_IN_ROOM")
        if it.seat_id in seen_seats:
            raise _bad_request(f"Kursi {seats[it.seat_id].label} dikirim lebih dari sekali", "DUPLICATE_SEAT")
        seen_seats.add(it.seat_id)
        if it.participant_id is not None:
            if it.participant_id not in participants:
                raise _bad_request("Peserta bukan bagian dari rapat ini", "PARTICIPANT_NOT_IN_BOOKING")
            if it.participant_id in seen_parts:
                raise _bad_request("Satu peserta hanya boleh menempati satu kursi", "DUPLICATE_PARTICIPANT")
            seen_parts.add(it.participant_id)

    conds = [BookingSeatAssignment.seat_id.in_(list(seen_seats))] if seen_seats else []
    if seen_parts:
        conds.append(BookingSeatAssignment.participant_id.in_(list(seen_parts)))
    if body.replace:
        await db.execute(delete(BookingSeatAssignment).where(BookingSeatAssignment.booking_id == booking.id))
    elif conds:
        await db.execute(
            delete(BookingSeatAssignment).where(BookingSeatAssignment.booking_id == booking.id, or_(*conds))
        )
    await db.flush()

    for it in body.items:
        name = (it.display_name or "").strip() or None
        if it.participant_id is None and name is None:
            continue  # kursi dikosongkan
        db.add(BookingSeatAssignment(
            booking_id=booking.id, seat_id=it.seat_id, participant_id=it.participant_id,
            display_name=name, role_label=(it.role_label or "").strip() or None, assigned_via="manual",
        ))

    await record_audit(
        db, current_user, "seat_assign", "bookings", "booking", booking.id,
        {"items": len(body.items), "replace": body.replace}, request,
    )
    try:
        await db.commit()
    except IntegrityError as exc:
        await db.rollback()
        raise _conflict("Penugasan bentrok dengan perubahan lain, muat ulang lalu coba lagi") from exc

    db.expire_all()
    await db.refresh(booking)
    await broadcast_seats_changed(db, booking)
    return SuccessResponse(data={"booking_id": str(booking.id), "items": await _assignments_payload(db, booking)})


@router.post("/bookings/{booking_id}/seat-assignments/auto", response_model=SuccessResponse)
async def auto_seat_assignments(
    booking_id: UUID,
    body: SeatAutoAssignRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Isi kursi kosong dengan peserta yang belum punya kursi.

    - Pemilik booking (bila terdaftar sebagai peserta) -> kursi pimpinan (chair).
    - Kursi notulis (secretary) & operator tidak diisi.
    - Tamu diutamakan ke kursi guest, lainnya ke kursi delegate.
    - strategy=attended_first: peserta yang sudah hadir diurutkan lebih dulu
      (berdasarkan jam presensi); strategy=all: urutan pendaftaran.
    """
    booking = await _get_booking(db, booking_id)
    _ensure_control(current_user, booking)
    if booking.meeting_status == "ended":
        raise _conflict("Rapat sudah selesai; penugasan kursi dikunci", "MEETING_ENDED")

    seats = await _load_seats(db, booking.room_id)
    if not seats:
        raise _bad_request("Ruangan belum memiliki denah kursi", "NO_SEATS")
    assigns = await _load_assignments(db, booking.id)
    taken = {a.seat_id for a in assigns}
    seated = {a.participant_id for a in assigns if a.participant_id}

    rows = [(p, u) for p, u in await _load_participants(db, booking.id) if p.id not in seated]
    if body.strategy == "attended_first":
        far = datetime.max.replace(tzinfo=None)
        rows.sort(key=lambda r: (
            0 if r[0].attended else 1,
            r[0].checked_in_at.replace(tzinfo=None) if r[0].checked_in_at else far,
        ))

    created = 0
    for p, u in rows:
        is_owner = p.user_id is not None and p.user_id == booking.user_id
        if is_owner:
            types: Tuple[str, ...] = ("chair", "delegate", "guest")
        elif p.is_guest:
            types = ("guest", "delegate")
        else:
            types = ("delegate", "guest")
        seat = _pick_free_seat(seats, taken, types)
        if seat is None:
            continue
        taken.add(seat.id)
        db.add(BookingSeatAssignment(
            booking_id=booking.id, seat_id=seat.id, participant_id=p.id,
            role_label="Pimpinan Rapat" if seat.seat_type == "chair" else "Peserta",
            assigned_via="auto",
        ))
        created += 1

    await record_audit(
        db, current_user, "seat_auto", "bookings", "booking", booking.id,
        {"strategy": body.strategy, "assigned": created}, request,
    )
    try:
        await db.commit()
    except IntegrityError as exc:
        await db.rollback()
        raise _conflict("Penugasan bentrok dengan perubahan lain, coba lagi") from exc

    db.expire_all()
    await db.refresh(booking)
    await broadcast_seats_changed(db, booking)
    return SuccessResponse(data={
        "booking_id": str(booking.id),
        "assigned": created,
        "items": await _assignments_payload(db, booking),
    })


# ============================================================
# Snapshot live
# ============================================================

async def build_live_snapshot(db: AsyncSession, booking: Booking, viewer: Optional[User] = None) -> Dict[str, Any]:
    room = (await db.execute(select(Room).where(Room.id == booking.room_id))).scalar_one_or_none()
    owner = (await db.execute(select(User).where(User.id == booking.user_id))).scalar_one_or_none()
    channels = await _load_channels(db, booking.room_id)
    ch_by_id = {c.id: c for c in channels}
    seats = await _load_seats(db, booking.room_id)
    seat_by_id = {s.id: s for s in seats}
    prow = await _load_participants(db, booking.id)
    names = {p.id: participant_name(p, u) for p, u in prow}
    assigns = [a for a in await _load_assignments(db, booking.id) if a.seat_id in seat_by_id]
    by_seat = {a.seat_id: a for a in assigns}
    by_part = {a.participant_id: a for a in assigns if a.participant_id}

    participants = []
    attended = 0
    for p, u in prow:
        if p.attended:
            attended += 1
        a = by_part.get(p.id)
        s = seat_by_id.get(a.seat_id) if a else None
        participants.append({
            "id": str(p.id),
            "user_id": str(p.user_id) if p.user_id else None,
            "name": names[p.id],
            "is_guest": bool(p.is_guest),
            "is_organizer": bool(p.user_id and p.user_id == booking.user_id),
            "position": getattr(u, "position", None) if u else None,
            "attended": bool(p.attended),
            "checked_in_at": p.checked_in_at.isoformat() if p.checked_in_at else None,
            "seat": {"seat_id": str(s.id), "seat_no": s.seat_no, "label": s.label} if s else None,
        })

    seat_items = []
    for s in seats:
        d = _seat_dict(s, ch_by_id)
        a = by_seat.get(s.id)
        d["assignment"] = _assignment_dict(a, s, names) if a else None
        seat_items.append(d)

    rec = (await db.execute(
        select(MeetingRecording)
        .where(MeetingRecording.booking_id == booking.id, MeetingRecording.status.in_(ACTIVE_RECORDING_STATUSES))
        .order_by(MeetingRecording.started_at.desc())
        .limit(1)
    )).scalar_one_or_none()
    note_id = (await db.execute(
        select(MeetingNote.id).where(MeetingNote.booking_id == booking.id)
        .order_by(MeetingNote.created_at.desc()).limit(1)
    )).scalar_one_or_none()

    original_end = (datetime.combine(booking.date, booking.end_time)
                    - timedelta(minutes=booking.extended_minutes or 0)).time()

    return {
        "server_time": _now_aware().isoformat(),
        "booking": {
            "id": str(booking.id),
            "title": booking.title,
            "description": booking.description,
            "room_id": str(booking.room_id),
            "room_name": room.name if room else None,
            "room_code": room.code if room else None,
            "date": booking.date.isoformat(),
            "start_time": booking.start_time.strftime("%H:%M:%S"),
            "end_time": booking.end_time.strftime("%H:%M:%S"),
            "original_end_time": original_end.strftime("%H:%M:%S"),
            "start_at": _iso_local(booking.date, booking.start_time),
            "end_at_effective": _iso_local(booking.date, booking.end_time),
            "status": booking.status,
            "meeting_status": booking.meeting_status or "scheduled",
            "actual_start_at": booking.actual_start_at.isoformat() if booking.actual_start_at else None,
            "actual_end_at": booking.actual_end_at.isoformat() if booking.actual_end_at else None,
            "extended_minutes": booking.extended_minutes or 0,
            "organizer_id": str(booking.user_id),
            "organizer_name": owner.name if owner else None,
        },
        "permissions": {
            "can_control": bool(viewer and can_control(viewer, booking)),
            "can_edit_notes": bool(viewer and has_permission(viewer, "notes.write")),
            "can_edit_layout": bool(viewer and has_permission(viewer, "rooms.write")),
        },
        "attendance": {"attended": attended, "total": len(prow)},
        "participants": participants,
        "seats": seat_items,
        "layout": room.seat_layout if room else None,
        "audio_channels": [_channel_dict(c) for c in channels],
        "recording": {
            "id": str(rec.id),
            "status": rec.status,
            "source": rec.source,
            "channel_count": rec.channel_count,
            "started_at": rec.started_at.isoformat() if rec.started_at else None,
        } if rec else None,
        "note_id": str(note_id) if note_id else None,
    }


@router.get("/bookings/{booking_id}/live", response_model=SuccessResponse)
async def get_live_snapshot(
    booking_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    booking = await _get_booking(db, booking_id)
    await _ensure_view(db, current_user, booking)
    return SuccessResponse(data=await build_live_snapshot(db, booking, current_user))


# ============================================================
# State rapat: mulai / perpanjang / akhiri
# ============================================================

async def _after_meeting_change(db: AsyncSession, booking: Booking, extra: Optional[dict] = None) -> None:
    room = (await db.execute(select(Room).where(Room.id == booking.room_id))).scalar_one_or_none()
    await hub_broadcast(booking.room_id, "meeting_status", _meeting_status_payload(booking))
    await hub_invalidate(booking.room_id)
    await _door_broadcast(db, room, extra)


@router.post("/bookings/{booking_id}/meeting/start", response_model=SuccessResponse)
async def start_meeting(
    booking_id: UUID,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    booking = await _get_booking(db, booking_id)
    _ensure_control(current_user, booking)
    if booking.meeting_status == "live":
        return SuccessResponse(data=await build_live_snapshot(db, booking, current_user))
    if booking.meeting_status == "ended":
        raise _conflict("Rapat sudah diakhiri", "MEETING_ENDED")
    if booking.status != "approved":
        raise _bad_request("Rapat belum disetujui sehingga belum dapat dimulai", "NOT_APPROVED")
    now = _now()
    if booking.date != now.date():
        raise _bad_request("Rapat hanya dapat dimulai pada tanggal pelaksanaannya", "NOT_TODAY")
    open_at = datetime.combine(booking.date, booking.start_time) - timedelta(minutes=START_OPEN_BEFORE_MINUTES)
    if now < open_at:
        raise _bad_request(f"Rapat dapat dimulai mulai pukul {open_at.strftime('%H:%M')}", "TOO_EARLY")
    if now > _effective_end(booking):
        raise _bad_request("Jadwal rapat sudah lewat", "TOO_LATE")

    booking.meeting_status = "live"
    booking.actual_start_at = _now_aware()
    await record_audit(
        db, current_user, "meeting_start", "bookings", "booking", booking.id,
        {"actual_start_at": booking.actual_start_at}, request, old_value={"meeting_status": "scheduled"},
    )
    await db.commit()
    await db.refresh(booking)
    await _after_meeting_change(db, booking)
    return SuccessResponse(data=await build_live_snapshot(db, booking, current_user))


@router.post("/bookings/{booking_id}/meeting/extend", response_model=SuccessResponse)
async def extend_meeting(
    booking_id: UUID,
    body: MeetingExtendRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    booking = await _get_booking(db, booking_id)
    _ensure_control(current_user, booking)
    if booking.meeting_status == "ended" or booking.status != "approved":
        raise _conflict("Hanya rapat disetujui yang belum berakhir yang dapat diperpanjang", "NOT_EXTENDABLE")
    if booking.date != _now().date():
        raise _bad_request("Hanya rapat hari ini yang dapat diperpanjang", "NOT_TODAY")

    old_end = booking.end_time
    new_end_dt = datetime.combine(booking.date, old_end) + timedelta(minutes=body.minutes)
    if new_end_dt.date() != booking.date:
        raise _bad_request("Perpanjangan melewati tengah malam", "PAST_MIDNIGHT")
    new_end = new_end_dt.time()

    conflict = (await db.execute(
        select(Booking)
        .where(and_(
            Booking.room_id == booking.room_id,
            Booking.date == booking.date,
            Booking.id != booking.id,
            Booking.status.in_(["approved", "pending"]),
            Booking.start_time < new_end,
            Booking.end_time > old_end,
        ))
        .order_by(Booking.start_time.asc())
        .limit(1)
    )).scalar_one_or_none()
    if conflict is not None:
        # Jangan bocorkan judul rapat lain.
        raise _conflict(
            f"Tidak dapat diperpanjang: ruangan sudah dipesan mulai pukul {conflict.start_time.strftime('%H:%M')}",
            "SCHEDULE_CONFLICT",
        )

    booking.end_time = new_end
    booking.extended_minutes = (booking.extended_minutes or 0) + body.minutes
    await record_audit(
        db, current_user, "meeting_extend", "bookings", "booking", booking.id,
        {"minutes": body.minutes, "end_time": new_end.strftime("%H:%M")}, request,
        old_value={"end_time": old_end.strftime("%H:%M")},
    )
    await db.commit()
    await db.refresh(booking)
    await _after_meeting_change(db, booking, {
        "event": "booking_extended", "booking_id": str(booking.id),
        "new_end_time": new_end.strftime("%H:%M"),
    })
    return SuccessResponse(data=await build_live_snapshot(db, booking, current_user))


@router.post("/bookings/{booking_id}/meeting/end", response_model=SuccessResponse)
async def end_meeting(
    booking_id: UUID,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Akhiri rapat: meeting_status=ended, booking completed (ruangan bebas), rekaman dihentikan."""
    booking = await _get_booking(db, booking_id)
    _ensure_control(current_user, booking)
    if booking.meeting_status == "ended":
        return SuccessResponse(data=await build_live_snapshot(db, booking, current_user))
    if booking.meeting_status != "live":
        raise _conflict("Rapat belum dimulai", "MEETING_NOT_LIVE")

    now = _now_aware()
    old_status = booking.status
    booking.meeting_status = "ended"
    booking.actual_end_at = now
    if booking.status == "approved":
        booking.status = "completed"

    recs = (await db.execute(
        select(MeetingRecording).where(
            MeetingRecording.booking_id == booking.id,
            MeetingRecording.status.in_(ACTIVE_RECORDING_STATUSES),
        )
    )).scalars().all()
    for rec in recs:
        rec.status = "stopped"
        rec.ended_at = now

    await record_audit(
        db, current_user, "meeting_end", "bookings", "booking", booking.id,
        {"actual_end_at": now, "recordings_stopped": len(recs)}, request,
        old_value={"meeting_status": "live", "status": old_status},
    )
    await db.commit()
    await db.refresh(booking)
    await _after_meeting_change(db, booking)
    for rec in recs:
        await hub_broadcast(booking.room_id, "recording_status", {
            "booking_id": str(booking.id), "recording_id": str(rec.id), "status": "stopped",
        })
    return SuccessResponse(data=await build_live_snapshot(db, booking, current_user))
