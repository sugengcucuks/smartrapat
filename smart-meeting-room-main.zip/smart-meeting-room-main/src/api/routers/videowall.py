"""Videowall: konfigurasi tersimpan (skenario) + pembungkus kontrol per ruangan.

Kontrol sebenarnya ada di src/api/services/av_service.py (dipakai juga oleh
/rooms/{room_id}/av/videowall/*). Preset & sumber valid = capabilities ruangan.
Respons perintah: {"cmd_id", "status": "acked"|"failed"|"timeout", "error", "results"}.
"""
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.database import get_db
from src.api.models.device import Device
from src.api.models.room import Room
from src.api.models.user import User
from src.api.models.videowall import VideowallConfig
from src.api.schemas.videowall import (
    SuccessResponse,
    VideowallCreate,
    VideowallInput,
    VideowallLayoutRequest,
    VideowallResponse,
    VideowallSource,
    VideowallUpdate,
)
from src.api.services import av_service as av
from src.api.utils.permissions import require_permission

router = APIRouter(prefix="/videowall", tags=["Videowall Control"])

_view = require_permission("devices.view", "videowall.control", "rooms.view")
_write = require_permission("devices.write", "videowall.control")
_control = require_permission("videowall.control")


def _to_response(vw: VideowallConfig, room: Optional[Room], device: Optional[Device]) -> VideowallResponse:
    inputs = []
    for inp in vw.inputs or []:
        if isinstance(inp, dict):
            inputs.append(VideowallInput(**{k: inp.get(k) for k in ("input", "label", "window") if k in inp}))
        else:
            inputs.append(VideowallInput(input=str(inp)))
    return VideowallResponse(
        id=vw.id,
        room_id=vw.room_id,
        room_name=room.name if room else None,
        device_id=vw.device_id,
        device_name=device.name if device else None,
        config_name=vw.config_name,
        layout_mode=vw.layout_mode,
        inputs=inputs,
        last_action=vw.last_action,
        created_at=vw.created_at,
        updated_at=vw.updated_at,
    )


async def _get_with_relations(db: AsyncSession, vw_id: UUID) -> Optional[VideowallResponse]:
    row = (await db.execute(
        select(VideowallConfig, Room, Device)
        .outerjoin(Room, VideowallConfig.room_id == Room.id)
        .outerjoin(Device, VideowallConfig.device_id == Device.id)
        .where(VideowallConfig.id == vw_id)
    )).first()
    return _to_response(*row) if row else None


async def _validate(db: AsyncSession, room_id: UUID, layout_mode: Optional[str], inputs) -> None:
    """Preset & sumber harus ada di capabilities ruangan."""
    rd = await av.load_room_devices(db, room_id)
    if layout_mode is not None:
        ids = [p["id"] for p in av.videowall_presets(rd.controller)]
        if layout_mode not in ids:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                                detail=f"Layout '{layout_mode}' tidak dikenal. Pilihan: {', '.join(ids)}")
    if inputs:
        src_ids = [s["id"] for s in av.videowall_sources(rd.controller)]
        for inp in inputs:
            if inp.input not in src_ids:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                                    detail=f"Sumber '{inp.input}' tidak dikenal. Pilihan: {', '.join(src_ids)}")


async def _check_controller(db: AsyncSession, device_id: Optional[UUID]) -> None:
    if not device_id:
        return
    ok = (await db.execute(select(Device).where(
        Device.id == device_id, Device.device_type.in_(list(av.CONTROLLER_TYPES))
    ))).scalar_one_or_none()
    if not ok:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Device ID tidak valid atau bukan videowall_controller")


# ---------------------------------------------------------------------------
# Konfigurasi tersimpan
# ---------------------------------------------------------------------------

@router.get("", response_model=SuccessResponse)
async def list_videowall_configs(
    room_id: Optional[UUID] = Query(None, description="Filter by room ID"),
    current_user: User = Depends(_view),
    db: AsyncSession = Depends(get_db),
):
    where = and_(VideowallConfig.room_id == room_id) if room_id else True
    rows = (await db.execute(
        select(VideowallConfig, Room, Device)
        .outerjoin(Room, VideowallConfig.room_id == Room.id)
        .outerjoin(Device, VideowallConfig.device_id == Device.id)
        .where(where)
        .order_by(VideowallConfig.config_name.asc())
    )).all()
    return SuccessResponse(data=[_to_response(*r) for r in rows])


@router.post("", response_model=SuccessResponse)
async def create_videowall_config(
    request: VideowallCreate,
    current_user: User = Depends(_write),
    db: AsyncSession = Depends(get_db),
):
    await _validate(db, request.room_id, request.layout_mode, request.inputs)
    await _check_controller(db, request.device_id)
    vw = VideowallConfig(
        room_id=request.room_id,
        device_id=request.device_id,
        config_name=request.config_name,
        layout_mode=request.layout_mode,
        inputs=[i.model_dump(exclude_none=True) for i in (request.inputs or [])],
    )
    db.add(vw)
    await db.commit()
    await db.refresh(vw)
    return SuccessResponse(data=await _get_with_relations(db, vw.id))


@router.get("/{videowall_id}", response_model=SuccessResponse)
async def get_videowall_config(
    videowall_id: UUID,
    current_user: User = Depends(_view),
    db: AsyncSession = Depends(get_db),
):
    data = await _get_with_relations(db, videowall_id)
    if not data:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Konfigurasi videowall tidak ditemukan")
    return SuccessResponse(data=data)


@router.put("/{videowall_id}", response_model=SuccessResponse)
async def update_videowall_config(
    videowall_id: UUID,
    request: VideowallUpdate,
    current_user: User = Depends(_write),
    db: AsyncSession = Depends(get_db),
):
    vw = (await db.execute(select(VideowallConfig).where(VideowallConfig.id == videowall_id))).scalar_one_or_none()
    if not vw:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Konfigurasi videowall tidak ditemukan")
    room_id = request.room_id or vw.room_id
    await _validate(db, room_id, request.layout_mode, request.inputs)
    if request.device_id is not None:
        await _check_controller(db, request.device_id)
        vw.device_id = request.device_id
    vw.room_id = room_id
    if request.config_name is not None:
        vw.config_name = request.config_name
    if request.layout_mode is not None:
        vw.layout_mode = request.layout_mode
    if request.inputs is not None:
        vw.inputs = [i.model_dump(exclude_none=True) for i in request.inputs]
    await db.commit()
    return SuccessResponse(data=await _get_with_relations(db, videowall_id))


@router.delete("/{videowall_id}", response_model=SuccessResponse)
async def delete_videowall_config(
    videowall_id: UUID,
    current_user: User = Depends(_write),
    db: AsyncSession = Depends(get_db),
):
    vw = (await db.execute(select(VideowallConfig).where(VideowallConfig.id == videowall_id))).scalar_one_or_none()
    if not vw:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Konfigurasi videowall tidak ditemukan")
    await db.delete(vw)
    await db.commit()
    return SuccessResponse(data={"message": "Konfigurasi videowall berhasil dihapus"})


@router.post("/{videowall_id}/apply", response_model=SuccessResponse)
async def apply_videowall_config(
    videowall_id: UUID,
    current_user: User = Depends(_control),
    db: AsyncSession = Depends(get_db),
):
    """Terapkan preset + sumber per jendela ke videowall ruangan konfigurasi ini."""
    vw = (await db.execute(select(VideowallConfig).where(VideowallConfig.id == videowall_id))).scalar_one_or_none()
    if not vw:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Konfigurasi videowall tidak ditemukan")
    result = await av.videowall_apply(db, vw.room_id, vw.layout_mode, list(vw.inputs or []), current_user)
    vw.last_action = f"Terapkan '{vw.config_name}' [{result['status']}]"[:200]
    await db.commit()
    return SuccessResponse(data=result)


@router.post("/{videowall_id}/power-on", response_model=SuccessResponse)
async def power_on_by_config(videowall_id: UUID, current_user: User = Depends(_control),
                             db: AsyncSession = Depends(get_db)):
    vw = (await db.execute(select(VideowallConfig).where(VideowallConfig.id == videowall_id))).scalar_one_or_none()
    if not vw:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Konfigurasi videowall tidak ditemukan")
    return SuccessResponse(data=await av.videowall_power(db, vw.room_id, True, current_user))


@router.post("/{videowall_id}/power-off", response_model=SuccessResponse)
async def power_off_by_config(videowall_id: UUID, current_user: User = Depends(_control),
                              db: AsyncSession = Depends(get_db)):
    vw = (await db.execute(select(VideowallConfig).where(VideowallConfig.id == videowall_id))).scalar_one_or_none()
    if not vw:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Konfigurasi videowall tidak ditemukan")
    return SuccessResponse(data=await av.videowall_power(db, vw.room_id, False, current_user))


# ---------------------------------------------------------------------------
# Pembungkus per ruangan (sama dengan /rooms/{room_id}/av/videowall/*)
# ---------------------------------------------------------------------------

@router.post("/rooms/{room_id}/power-on", response_model=SuccessResponse)
async def room_power_on(room_id: UUID, current_user: User = Depends(_control), db: AsyncSession = Depends(get_db)):
    return SuccessResponse(data=await av.videowall_power(db, room_id, True, current_user))


@router.post("/rooms/{room_id}/power-off", response_model=SuccessResponse)
async def room_power_off(room_id: UUID, current_user: User = Depends(_control), db: AsyncSession = Depends(get_db)):
    return SuccessResponse(data=await av.videowall_power(db, room_id, False, current_user))


@router.post("/rooms/{room_id}/layout", response_model=SuccessResponse)
async def room_layout(room_id: UUID, request: VideowallLayoutRequest, current_user: User = Depends(_control),
                      db: AsyncSession = Depends(get_db)):
    return SuccessResponse(data=await av.videowall_layout(db, room_id, request.preset, current_user))


@router.post("/rooms/{room_id}/source", response_model=SuccessResponse)
async def room_source(room_id: UUID, request: VideowallSource, current_user: User = Depends(_control),
                      db: AsyncSession = Depends(get_db)):
    return SuccessResponse(data=await av.videowall_source(db, room_id, request.source, request.window, current_user))
