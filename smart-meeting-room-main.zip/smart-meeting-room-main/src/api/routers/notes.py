"""Notulensi rapat: CRUD, rekaman, transkrip, ringkasan AI, finalisasi & export.

Kontrak: docs/architecture/LIVE_MEETING.md §4 "Notulensi".

Hak akses:
- Baca: izin `notes.view`.
- Buat/hapus notulen, buka kembali notulen final: izin `notes.write`.
- Ubah notulen (isi, transkrip, action item, ringkas, unggah rekaman, finalisasi):
  `notes.write` ATAU pembuat notulen ATAU pemilik booking.
- Kontrol rekaman & unggah potongan browser: `notes.write` ATAU pemilik booking.
- Unggah segmen recorder: header `X-Agent-Key` (= AGENT_API_KEY) ATAU JWT ber-izin `notes.write`.
- Notulen berstatus `final` dikunci; buka kembali (`/reopen`) untuk mengubah.
"""
from __future__ import annotations

import asyncio
import hmac
import math
import uuid
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import quote
from uuid import UUID

from fastapi import APIRouter, Depends, File, Form, Header, HTTPException, Query, Request, Response, UploadFile, status
from fastapi.responses import StreamingResponse
from sqlalchemy import and_, delete, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.config import settings
from src.api.database import get_db
from src.api.models.booking import Booking, BookingParticipant
from src.api.models.live import AudioChannel, BookingSeatAssignment, MeetingRecording, RoomSeat, TranscriptSegment
from src.api.models.note import MeetingNote, MeetingNoteActionItem
from src.api.models.room import Room
from src.api.models.user import User
from src.api.schemas.note import (
    ActionItemBase,
    ActionItemResponse,
    ActionItemUpdate,
    LegacyRecordingStart,
    MeetingNoteCreate,
    MeetingNoteResponse,
    MeetingNoteUpdate,
    PaginatedNotesResponse,
    RecordingStartBody,
    SegmentCreate,
    SegmentUpdate,
    SuccessResponse,
    TranscriptLine,
)
from src.api.services import audio_io, note_export
from src.api.services.summarizer import OllamaClient, SummarizerError, summarize_segments
from src.api.services.transcription import (
    TranscriptionJob,
    broadcast,
    recording_dir,
    serialize_segment,
    transcription_service,
)
from src.api.utils.audit import record_audit
from src.api.utils.auth import decode_token, get_user_from_payload
from src.api.utils.permissions import has_permission, require_permission

router = APIRouter(prefix="/notes", tags=["Notulensi"])

ACTIVE_STATUSES = ("recording", "paused")
LIVE_SOURCES = ("multichannel", "mix", "browser")
SEGMENT_MAX_BYTES = 25 * 1024 * 1024
CHUNK_MAX_BYTES = 25 * 1024 * 1024
_summarizing: set = set()


# ---------------------------------------------------------------------------
# Helper umum
# ---------------------------------------------------------------------------
def _err(code: int, key: str, message: str) -> HTTPException:
    return HTTPException(status_code=code, detail={"code": key, "message": message})


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _uuid_or_none(v: Optional[str]) -> Optional[UUID]:
    if v in (None, ""):
        return None
    try:
        return UUID(str(v))
    except ValueError:
        raise _err(400, "BAD_ID", "ID tidak valid")


def _fmt_ts(ms: int) -> str:
    return note_export.fmt_ms(ms)


def _is_booking_owner(user: User, booking: Optional[Booking]) -> bool:
    return booking is not None and user.id in (booking.user_id, booking.created_by)


def _can_edit(user: User, note: MeetingNote, booking: Optional[Booking]) -> bool:
    return has_permission(user, "notes.write") or note.created_by == user.id or _is_booking_owner(user, booking)


async def _get_note(db: AsyncSession, note_id: UUID) -> MeetingNote:
    note = await db.get(MeetingNote, note_id)
    if note is None:
        raise _err(404, "NOTE_NOT_FOUND", "Notulensi tidak ditemukan")
    return note


async def _get_booking(db: AsyncSession, booking_id: UUID) -> Booking:
    booking = await db.get(Booking, booking_id)
    if booking is None:
        raise _err(404, "BOOKING_NOT_FOUND", "Booking tidak ditemukan")
    return booking


async def _note_for_edit(db: AsyncSession, note_id: UUID, user: User, allow_final: bool = False):
    note = await _get_note(db, note_id)
    booking = await db.get(Booking, note.booking_id) if note.booking_id else None
    if not _can_edit(user, note, booking):
        raise _err(403, "FORBIDDEN", "Anda tidak memiliki izin mengubah notulensi ini")
    if not allow_final and note.status == "final":
        raise _err(409, "NOTE_FINAL", "Notulensi sudah final. Buka kembali (reopen) untuk mengubah.")
    return note, booking


def _ensure_recording_control(user: User, booking: Booking) -> None:
    if not (has_permission(user, "notes.write") or _is_booking_owner(user, booking)):
        raise _err(403, "FORBIDDEN", "Hanya pemilik booking atau notulis yang dapat mengontrol rekaman")


async def _ensure_note_for_booking(db: AsyncSession, booking: Booking, user: Optional[User]) -> MeetingNote:
    note = (await db.execute(
        select(MeetingNote).where(MeetingNote.booking_id == booking.id).order_by(MeetingNote.created_at).limit(1)
    )).scalar_one_or_none()
    if note is not None:
        return note
    names = await _attended_names(db, booking.id, only_attended=False)
    note = MeetingNote(
        booking_id=booking.id, room_id=booking.room_id, title=booking.title, date=booking.date,
        start_time=booking.start_time, end_time=booking.end_time, participants=names,
        transcript=[], transcript_processing=False, status="draft",
        created_by=user.id if user else booking.user_id,
    )
    db.add(note)
    await db.flush()
    return note


async def _attended_names(db: AsyncSession, booking_id: UUID, only_attended: bool = True) -> List[str]:
    stmt = (select(BookingParticipant, User).outerjoin(User, BookingParticipant.user_id == User.id)
            .where(BookingParticipant.booking_id == booking_id).order_by(BookingParticipant.created_at))
    if only_attended:
        stmt = stmt.where(BookingParticipant.attended.is_(True))
    out = []
    for p, u in (await db.execute(stmt)).all():
        name = (u.name if u else None) or p.guest_name
        if name and name not in out:
            out.append(name)
    return out


def _action_item_out(a: MeetingNoteActionItem) -> ActionItemResponse:
    return ActionItemResponse(
        id=a.id, note_id=a.note_id, task=a.task, owner=a.owner, assignee=a.owner, due_date=a.due_date,
        status=a.status, source=a.source or "manual", created_at=a.created_at, updated_at=a.updated_at,
    )


async def _seat_labels(db: AsyncSession, seat_ids) -> Dict[UUID, str]:
    ids = {s for s in seat_ids if s}
    if not ids:
        return {}
    rows = (await db.execute(select(RoomSeat.id, RoomSeat.label).where(RoomSeat.id.in_(ids)))).all()
    return {r[0]: r[1] for r in rows}


def _segment_order():
    # Urut per sesi rekaman (waktu mulai rekaman), lalu offset di dalam rekaman.
    return (func.coalesce(MeetingRecording.started_at, TranscriptSegment.created_at),
            TranscriptSegment.start_ms, TranscriptSegment.created_at)


def _segment_select():
    return (select(TranscriptSegment)
            .outerjoin(MeetingRecording, MeetingRecording.id == TranscriptSegment.recording_id))


async def _segments(db: AsyncSession, note_id: UUID) -> List[TranscriptSegment]:
    return list((await db.execute(
        _segment_select().where(TranscriptSegment.note_id == note_id).order_by(*_segment_order())
    )).scalars().all())


async def _note_response(db: AsyncSession, note: MeetingNote, include_transcript: bool = True) -> MeetingNoteResponse:
    room = await db.get(Room, note.room_id) if note.room_id else None
    creator = await db.get(User, note.created_by) if note.created_by else None
    finalizer = await db.get(User, note.finalized_by) if note.finalized_by else None
    booking = await db.get(Booking, note.booking_id) if note.booking_id else None
    items = (await db.execute(
        select(MeetingNoteActionItem).where(MeetingNoteActionItem.note_id == note.id)
        .order_by(MeetingNoteActionItem.created_at)
    )).scalars().all()
    transcript: List[TranscriptLine] = []
    if include_transcript:
        segs = await _segments(db, note.id)
        seg_count = len(segs)
        transcript = [TranscriptLine(speaker=s.speaker_name, text=s.text, timestamp=_fmt_ts(s.start_ms)) for s in segs]
    else:
        seg_count = (await db.execute(
            select(func.count(TranscriptSegment.id)).where(TranscriptSegment.note_id == note.id)
        )).scalar() or 0
    return MeetingNoteResponse(
        id=note.id, booking_id=note.booking_id, room_id=note.room_id, room_name=room.name if room else None,
        title=note.title, date=note.date, start_time=note.start_time, end_time=note.end_time,
        participants=list(note.participants or []), summary=note.summary, decisions=list(note.decisions or []),
        action_items=[_action_item_out(a) for a in items], transcript=transcript,
        transcript_processing=bool(note.transcript_processing) or transcription_service.pending_for_note(note.id) > 0,
        ai_model=note.ai_model, generated_at=note.generated_at, created_by=note.created_by,
        created_by_name=creator.name if creator else None, created_at=note.created_at, updated_at=note.updated_at,
        status=note.status or "draft", summary_json=note.summary_json, finalized_at=note.finalized_at,
        finalized_by=note.finalized_by, finalized_by_name=finalizer.name if finalizer else None,
        segment_count=seg_count, booking_title=booking.title if booking else None,
    )


def _content_disposition(filename: str) -> str:
    return f"attachment; filename=\"{filename}\"; filename*=UTF-8''{quote(filename)}"


async def _save_upload(upload: UploadFile, dest: Path, max_bytes: int) -> int:
    """Salin unggahan ke disk per 1 MB (tidak memuat seluruh file ke memori)."""
    size = 0
    try:
        with open(dest, "wb") as f:
            while True:
                chunk = await upload.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > max_bytes:
                    raise _err(413, "FILE_TOO_LARGE", f"Ukuran file melebihi batas {max_bytes // (1024 * 1024)} MB")
                await asyncio.to_thread(f.write, chunk)
    except BaseException:
        audio_io.safe_unlink(str(dest))
        raise
    if size == 0:
        audio_io.safe_unlink(str(dest))
        raise _err(400, "EMPTY_FILE", "File audio kosong")
    return size


def _check_audio(upload: Optional[UploadFile]) -> str:
    if upload is None:
        raise _err(400, "NO_FILE", "File audio wajib diunggah")
    name = upload.filename or ""
    if not audio_io.is_allowed_audio(name, upload.content_type):
        allowed = ", ".join(sorted(audio_io.AUDIO_EXTENSIONS))
        raise _err(415, "UNSUPPORTED_AUDIO", f"Format file tidak didukung. Gunakan: {allowed}")
    return Path(name).suffix.lower()


# ---------------------------------------------------------------------------
# Rekaman: helper
# ---------------------------------------------------------------------------
def _elapsed_ms(rec: MeetingRecording, now: Optional[datetime] = None) -> int:
    if rec.started_at is None:
        return 0
    end = rec.ended_at or (rec.paused_at if rec.status == "paused" else None) or now or _now()
    ms = int((end - rec.started_at).total_seconds() * 1000) - int(rec.paused_ms or 0)
    return max(0, ms)


async def _active_recording(db: AsyncSession, booking_id: UUID) -> Optional[MeetingRecording]:
    return (await db.execute(
        select(MeetingRecording).where(
            MeetingRecording.booking_id == booking_id, MeetingRecording.status.in_(ACTIVE_STATUSES),
            MeetingRecording.source.in_(LIVE_SOURCES),
        ).order_by(MeetingRecording.created_at.desc()).limit(1)
    )).scalar_one_or_none()


async def _latest_recording(db: AsyncSession, booking_id: UUID) -> Optional[MeetingRecording]:
    return (await db.execute(
        select(MeetingRecording).where(MeetingRecording.booking_id == booking_id)
        .order_by(MeetingRecording.created_at.desc()).limit(1)
    )).scalar_one_or_none()


async def _recording_payload(db: AsyncSession, booking_id: UUID, rec: Optional[MeetingRecording]) -> Dict[str, Any]:
    if rec is None:
        return {"booking_id": str(booking_id), "status": "idle", "recording_id": None, "duration_seconds": 0,
                "elapsed_ms": 0, "segment_count": 0, "pending_jobs": 0}
    seg_count = (await db.execute(
        select(func.count(TranscriptSegment.id)).where(TranscriptSegment.recording_id == rec.id)
    )).scalar() or 0
    elapsed = _elapsed_ms(rec)
    return {
        "booking_id": str(rec.booking_id), "recording_id": str(rec.id),
        "note_id": str(rec.note_id) if rec.note_id else None, "status": rec.status, "source": rec.source,
        "channel_count": rec.channel_count,
        "started_at": rec.started_at.isoformat() if rec.started_at else None,
        "paused_at": rec.paused_at.isoformat() if rec.paused_at else None,
        "ended_at": rec.ended_at.isoformat() if rec.ended_at else None,
        "elapsed_ms": elapsed, "duration_seconds": elapsed // 1000, "segment_count": seg_count,
        "pending_jobs": transcription_service.pending_for_recording(rec.id),
        "progress": transcription_service.progress.get(str(rec.id)), "error": rec.error,
    }


async def _emit_recording(db: AsyncSession, booking: Booking, rec: MeetingRecording) -> Dict[str, Any]:
    payload = await _recording_payload(db, booking.id, rec)
    await broadcast(booking.room_id, "recording_status", payload)
    return payload


async def _agent_or_writer(request: Request, db: AsyncSession = Depends(get_db)) -> Optional[User]:
    """Autentikasi recorder (X-Agent-Key) atau user JWT ber-izin notes.write."""
    key = request.headers.get("x-agent-key")
    if key is not None:
        expected = settings.AGENT_API_KEY or ""
        if not expected:
            raise _err(401, "AGENT_KEY_DISABLED", "AGENT_API_KEY belum dikonfigurasi di server")
        if not hmac.compare_digest(key.encode(), expected.encode()):
            raise _err(401, "AGENT_KEY_INVALID", "X-Agent-Key tidak valid")
        return None
    auth = request.headers.get("authorization") or ""
    if not auth.lower().startswith("bearer "):
        raise _err(401, "AUTH_REQUIRED", "Butuh X-Agent-Key atau token login")
    payload = decode_token(auth.split(" ", 1)[1].strip(), expected_type="access")
    user = await get_user_from_payload(payload, db)
    if user.must_change_password:
        raise _err(403, "PASSWORD_CHANGE_REQUIRED", "Silakan ganti password default terlebih dahulu")
    if not has_permission(user, "notes.write"):
        raise _err(403, "FORBIDDEN", "Anda tidak memiliki izin untuk aksi ini")
    return user


async def _require_agent(x_agent_key: Optional[str] = Header(None, alias="X-Agent-Key")) -> None:
    expected = settings.AGENT_API_KEY or ""
    if not expected:
        raise _err(401, "AGENT_KEY_DISABLED", "AGENT_API_KEY belum dikonfigurasi di server")
    if not x_agent_key or not hmac.compare_digest(x_agent_key.encode(), expected.encode()):
        raise _err(401, "AGENT_KEY_INVALID", "X-Agent-Key tidak valid")


# ===========================================================================
# STATUS MESIN
# ===========================================================================
@router.get("/stt/status", response_model=SuccessResponse)
async def stt_status(current_user: User = Depends(require_permission("notes.view"))):
    return SuccessResponse(data=transcription_service.status())


@router.get("/llm/status", response_model=SuccessResponse)
async def llm_status(current_user: User = Depends(require_permission("notes.view"))):
    return SuccessResponse(data=await OllamaClient().status())


# ===========================================================================
# DAFTAR & CRUD
# ===========================================================================
@router.get("", response_model=SuccessResponse)
async def list_notes(
    search: Optional[str] = Query(None, max_length=100),
    date_from: Optional[date] = Query(None),
    date_to: Optional[date] = Query(None),
    room_id: Optional[UUID] = Query(None),
    booking_id: Optional[UUID] = Query(None),
    status_filter: Optional[str] = Query(None, alias="status", pattern="^(draft|final)$"),
    page: int = Query(1, ge=1),
    per_page: int = Query(10, ge=1, le=100),
    current_user: User = Depends(require_permission("notes.view")),
    db: AsyncSession = Depends(get_db),
):
    conds = []
    if search and search.strip():
        conds.append(MeetingNote.title.ilike(f"%{search.strip()}%"))
    if date_from:
        conds.append(MeetingNote.date >= date_from)
    if date_to:
        conds.append(MeetingNote.date <= date_to)
    if room_id:
        conds.append(MeetingNote.room_id == room_id)
    if booking_id:
        conds.append(MeetingNote.booking_id == booking_id)
    if status_filter:
        conds.append(MeetingNote.status == status_filter)
    where = and_(*conds) if conds else True
    total = (await db.execute(select(func.count(MeetingNote.id)).where(where))).scalar() or 0
    notes = (await db.execute(
        select(MeetingNote).where(where).order_by(MeetingNote.date.desc(), MeetingNote.created_at.desc())
        .offset((page - 1) * per_page).limit(per_page)
    )).scalars().all()
    items = [await _note_response(db, n, include_transcript=False) for n in notes]
    return SuccessResponse(data=PaginatedNotesResponse(
        items=items, total=total, page=page, per_page=per_page,
        total_pages=math.ceil(total / per_page) if per_page else 0,
    ))


@router.post("", response_model=SuccessResponse, status_code=201)
async def create_note(
    body: MeetingNoteCreate,
    current_user: User = Depends(require_permission("notes.write")),
    db: AsyncSession = Depends(get_db),
):
    if body.room_id and not await db.get(Room, body.room_id):
        raise _err(400, "BAD_ROOM", "Ruangan tidak valid")
    if body.booking_id and not await db.get(Booking, body.booking_id):
        raise _err(400, "BAD_BOOKING", "Booking tidak valid")
    if body.start_time >= body.end_time:
        raise _err(400, "BAD_TIME", "Jam selesai harus setelah jam mulai")
    note = MeetingNote(
        booking_id=body.booking_id, room_id=body.room_id, title=body.title, date=body.date,
        start_time=body.start_time, end_time=body.end_time, participants=list(body.participants or []),
        summary=body.summary, decisions=list(body.decisions or []), transcript=[], transcript_processing=False,
        status="draft", created_by=current_user.id,
    )
    db.add(note)
    await db.flush()
    for ai in body.action_items or []:
        db.add(MeetingNoteActionItem(note_id=note.id, task=ai.task, owner=ai.owner, due_date=ai.due_date,
                                     status=ai.status, source="manual"))
    await db.commit()
    return SuccessResponse(data=await _note_response(db, note))


# --- per booking (harus sebelum /{note_id}) ---------------------------------
@router.get("/by-booking/{booking_id}", response_model=SuccessResponse)
async def get_note_by_booking(
    booking_id: UUID,
    current_user: User = Depends(require_permission("notes.view")),
    db: AsyncSession = Depends(get_db),
):
    note = (await db.execute(
        select(MeetingNote).where(MeetingNote.booking_id == booking_id).order_by(MeetingNote.created_at).limit(1)
    )).scalar_one_or_none()
    return SuccessResponse(data=await _note_response(db, note) if note else None)


@router.post("/by-booking/{booking_id}", response_model=SuccessResponse)
async def ensure_note_for_booking(
    booking_id: UUID,
    current_user: User = Depends(require_permission("notes.view")),
    db: AsyncSession = Depends(get_db),
):
    booking = await _get_booking(db, booking_id)
    existing = (await db.execute(
        select(MeetingNote.id).where(MeetingNote.booking_id == booking_id).limit(1)
    )).scalar_one_or_none()
    if existing is None:
        _ensure_recording_control(current_user, booking)
    note = await _ensure_note_for_booking(db, booking, current_user)
    await db.commit()
    return SuccessResponse(data=await _note_response(db, note))


# ===========================================================================
# REKAMAN (DB-backed, satu rekaman aktif per booking)
# ===========================================================================
@router.get("/recording/active")
async def recording_active_for_room(
    room_code: str = Query(..., min_length=1, max_length=20),
    _: None = Depends(_require_agent),
    db: AsyncSession = Depends(get_db),
):
    """Dipanggil recorder (X-Agent-Key) tiap ±2 detik. 204 bila tidak ada rekaman aktif."""
    room = (await db.execute(select(Room).where(Room.code == room_code))).scalar_one_or_none()
    if room is None:
        raise _err(404, "ROOM_NOT_FOUND", "Ruangan tidak ditemukan")
    rec = (await db.execute(
        select(MeetingRecording).join(Booking, Booking.id == MeetingRecording.booking_id)
        .where(Booking.room_id == room.id, MeetingRecording.status.in_(ACTIVE_STATUSES),
               MeetingRecording.source.in_(("multichannel", "mix")))
        .order_by(MeetingRecording.created_at.desc()).limit(1)
    )).scalar_one_or_none()
    if rec is None:
        return Response(status_code=204)
    channels = (await db.execute(
        select(AudioChannel).where(AudioChannel.room_id == room.id).order_by(AudioChannel.channel_no)
    )).scalars().all()
    return SuccessResponse(data={
        "recording_id": str(rec.id), "booking_id": str(rec.booking_id),
        "note_id": str(rec.note_id) if rec.note_id else None, "room_id": str(room.id),
        "status": rec.status, "source": rec.source, "elapsed_ms": _elapsed_ms(rec),
        "started_at": rec.started_at.isoformat() if rec.started_at else None,
        "channels": [{"channel_no": c.channel_no, "capture_channel": c.capture_channel, "label": c.label,
                      "enabled": bool(c.is_enabled)} for c in channels],
    })


async def _start_recording(db: AsyncSession, booking: Booking, source: str, user: User) -> Dict[str, Any]:
    _ensure_recording_control(user, booking)
    active = await _active_recording(db, booking.id)
    if active is not None:
        if active.source != source:
            raise _err(409, "RECORDING_ACTIVE",
                       f"Rekaman lain ({active.source}) sedang berjalan untuk rapat ini. Hentikan dulu.")
        return await _recording_payload(db, booking.id, active)
    note = await _ensure_note_for_booking(db, booking, user)
    if note.status == "final":
        raise _err(409, "NOTE_FINAL", "Notulensi sudah final. Buka kembali untuk merekam lagi.")
    if source == "multichannel":
        count = (await db.execute(
            select(func.count(AudioChannel.id)).where(AudioChannel.room_id == booking.room_id,
                                                      AudioChannel.is_enabled.is_(True))
        )).scalar() or 0
        channel_count = max(int(count), 1)
    else:
        channel_count = 2 if source == "mix" else 1
    rec = MeetingRecording(booking_id=booking.id, note_id=note.id, source=source, status="recording",
                           channel_count=channel_count, started_at=_now(), paused_ms=0, created_by=user.id)
    db.add(rec)
    await db.commit()
    await db.refresh(rec)
    return await _emit_recording(db, booking, rec)


@router.post("/recording/start", response_model=SuccessResponse)
async def start_recording_legacy(
    body: LegacyRecordingStart,
    current_user: User = Depends(require_permission("notes.view")),
    db: AsyncSession = Depends(get_db),
):
    """Alias lama: body {booking_id, source?}."""
    booking = await _get_booking(db, body.booking_id)
    data = await _start_recording(db, booking, body.source, current_user)
    data["message"] = "Rekaman dimulai"
    return SuccessResponse(data=data)


@router.post("/recording/{booking_id}/start", response_model=SuccessResponse)
async def start_recording(
    booking_id: UUID,
    body: Optional[RecordingStartBody] = None,
    current_user: User = Depends(require_permission("notes.view")),
    db: AsyncSession = Depends(get_db),
):
    booking = await _get_booking(db, booking_id)
    data = await _start_recording(db, booking, (body or RecordingStartBody()).source, current_user)
    data["message"] = "Rekaman dimulai"
    return SuccessResponse(data=data)


async def _transition(db: AsyncSession, booking_id: UUID, user: User, action: str) -> Dict[str, Any]:
    booking = await _get_booking(db, booking_id)
    _ensure_recording_control(user, booking)
    rec = await _active_recording(db, booking_id)
    if rec is None:
        raise _err(409, "NO_ACTIVE_RECORDING", "Tidak ada rekaman aktif untuk rapat ini")
    now = _now()
    if action == "pause":
        if rec.status != "recording":
            raise _err(409, "BAD_STATE", "Rekaman tidak sedang berjalan")
        rec.status, rec.paused_at = "paused", now
    elif action == "resume":
        if rec.status != "paused":
            raise _err(409, "BAD_STATE", "Rekaman tidak sedang dijeda")
        if rec.paused_at:
            rec.paused_ms = int(rec.paused_ms or 0) + int((now - rec.paused_at).total_seconds() * 1000)
        rec.status, rec.paused_at = "recording", None
    elif action == "stop":
        if rec.status == "paused" and rec.paused_at:
            rec.paused_ms = int(rec.paused_ms or 0) + int((now - rec.paused_at).total_seconds() * 1000)
            rec.paused_at = None
        rec.ended_at = now
        rec.status = "processing" if transcription_service.pending_for_recording(rec.id) > 0 else "done"
    await db.commit()
    await db.refresh(rec)
    return await _emit_recording(db, booking, rec)


@router.post("/recording/{booking_id}/pause", response_model=SuccessResponse)
async def pause_recording(booking_id: UUID, current_user: User = Depends(require_permission("notes.view")),
                          db: AsyncSession = Depends(get_db)):
    data = await _transition(db, booking_id, current_user, "pause")
    data["message"] = "Rekaman dijeda"
    return SuccessResponse(data=data)


@router.post("/recording/{booking_id}/resume", response_model=SuccessResponse)
async def resume_recording(booking_id: UUID, current_user: User = Depends(require_permission("notes.view")),
                           db: AsyncSession = Depends(get_db)):
    data = await _transition(db, booking_id, current_user, "resume")
    data["message"] = "Rekaman dilanjutkan"
    return SuccessResponse(data=data)


@router.post("/recording/{booking_id}/stop", response_model=SuccessResponse)
async def stop_recording(booking_id: UUID, current_user: User = Depends(require_permission("notes.view")),
                         db: AsyncSession = Depends(get_db)):
    data = await _transition(db, booking_id, current_user, "stop")
    data["message"] = ("Rekaman dihentikan; sisa audio sedang ditranskrip" if data["status"] == "processing"
                       else "Rekaman dihentikan")
    return SuccessResponse(data=data)


@router.get("/recording/{booking_id}/status", response_model=SuccessResponse)
async def recording_status(booking_id: UUID, current_user: User = Depends(require_permission("notes.view")),
                           db: AsyncSession = Depends(get_db)):
    rec = await _active_recording(db, booking_id) or await _latest_recording(db, booking_id)
    return SuccessResponse(data=await _recording_payload(db, booking_id, rec))


@router.post("/recording/{booking_id}/segments", status_code=202, response_model=SuccessResponse)
async def upload_segment(
    booking_id: UUID,
    audio: UploadFile = File(...),
    channel_no: Optional[int] = Form(None, ge=1, le=64),
    start_ms: int = Form(0, ge=0),
    end_ms: Optional[int] = Form(None, ge=0),
    recording_id: Optional[str] = Form(None),
    segment_uid: Optional[str] = Form(None, max_length=64),
    actor: Optional[User] = Depends(_agent_or_writer),
    db: AsyncSession = Depends(get_db),
):
    """Segmen audio pendek dari recorder (WAV/FLAC 16 kHz mono) -> antrean STT."""
    ext = _check_audio(audio)
    booking = await _get_booking(db, booking_id)
    rid = _uuid_or_none(recording_id)
    if rid is not None:
        rec = await db.get(MeetingRecording, rid)
        if rec is None or rec.booking_id != booking.id:
            raise _err(404, "RECORDING_NOT_FOUND", "Rekaman tidak ditemukan untuk booking ini")
    else:
        rec = await _active_recording(db, booking.id)
        if rec is None:
            raise _err(409, "NO_ACTIVE_RECORDING", "Tidak ada rekaman aktif untuk rapat ini")
    if rec.status == "failed" and rec.ended_at is not None:
        raise _err(409, "RECORDING_FAILED", "Rekaman sudah ditutup dengan status gagal")
    note = await db.get(MeetingNote, rec.note_id) if rec.note_id else None
    if note is None:
        note = await _ensure_note_for_booking(db, booking, actor)
        rec.note_id = note.id

    folder = recording_dir(booking.id, rec.id)
    uid = uuid.UUID(segment_uid).hex if segment_uid and _is_uuid(segment_uid) else uuid.uuid4().hex
    dest = folder / f"seg_{channel_no or 0:02d}_{int(start_ms):010d}_{uid}{ext}"
    if dest.exists() or Path(str(dest) + ".job.failed.json").exists():
        await db.commit()
        return SuccessResponse(data={"duplicate": True, "recording_id": str(rec.id)})
    await _save_upload(audio, dest, SEGMENT_MAX_BYTES)

    if rec.status in ("done",):
        rec.status = "processing"  # segmen terlambat (spool recorder) setelah stop
    note.transcript_processing = True
    await db.commit()
    job = TranscriptionJob(kind="segment", note_id=str(note.id), booking_id=str(booking.id), audio_path=str(dest),
                           recording_id=str(rec.id), channel_no=channel_no, start_ms=int(start_ms),
                           end_ms=int(end_ms) if end_ms is not None else None)
    await transcription_service.enqueue(job)
    return SuccessResponse(data={"queued": True, "job_id": job.job_id, "recording_id": str(rec.id),
                                 "queue_size": transcription_service.queue_size()})


def _is_uuid(v: str) -> bool:
    try:
        uuid.UUID(str(v))
        return True
    except ValueError:
        return False


@router.post("/recording/{booking_id}/chunks", status_code=202, response_model=SuccessResponse)
async def upload_browser_chunk(
    booking_id: UUID,
    audio: UploadFile = File(...),
    start_ms: Optional[int] = Form(None, ge=0),
    duration_ms: Optional[int] = Form(None, ge=0),
    speaker_name: Optional[str] = Form(None, max_length=200),
    participant_id: Optional[str] = Form(None),
    chunk_uid: Optional[str] = Form(None, max_length=64),
    current_user: User = Depends(require_permission("notes.view")),
    db: AsyncSession = Depends(get_db),
):
    """Potongan audio mode browser (webm/ogg/wav) -> antrean STT."""
    ext = _check_audio(audio)
    booking = await _get_booking(db, booking_id)
    _ensure_recording_control(current_user, booking)
    rec = await _active_recording(db, booking.id)
    if rec is None:
        raise _err(409, "NO_ACTIVE_RECORDING", "Tidak ada rekaman aktif. Mulai rekaman terlebih dahulu.")
    note = await db.get(MeetingNote, rec.note_id) if rec.note_id else None
    if note is None:
        note = await _ensure_note_for_booking(db, booking, current_user)
        rec.note_id = note.id
    if start_ms is None:  # perkiraan server: akhir potongan = sekarang
        start_ms = max(0, _elapsed_ms(rec) - int(duration_ms or 10000))
    folder = recording_dir(booking.id, rec.id)
    uid = uuid.UUID(chunk_uid).hex if chunk_uid and _is_uuid(chunk_uid) else uuid.uuid4().hex
    dest = folder / f"chunk_{int(start_ms):010d}_{uid}{ext}"
    if dest.exists():
        await db.commit()
        return SuccessResponse(data={"duplicate": True, "recording_id": str(rec.id)})
    await _save_upload(audio, dest, CHUNK_MAX_BYTES)
    note.transcript_processing = True
    await db.commit()
    job = TranscriptionJob(kind="chunk", note_id=str(note.id), booking_id=str(booking.id), audio_path=str(dest),
                           recording_id=str(rec.id), start_ms=int(start_ms),
                           speaker_name=(speaker_name or "").strip() or None,
                           participant_id=str(_uuid_or_none(participant_id)) if participant_id else None)
    await transcription_service.enqueue(job)
    return SuccessResponse(data={"queued": True, "job_id": job.job_id, "recording_id": str(rec.id),
                                 "queue_size": transcription_service.queue_size()})


# ===========================================================================
# ALIAS LAMA PER BOOKING (/meetings/{booking_id}/...)
# ===========================================================================
@router.post("/meetings/{booking_id}/summarize", response_model=SuccessResponse)
async def summarize_by_booking(booking_id: UUID, current_user: User = Depends(require_permission("notes.view")),
                               db: AsyncSession = Depends(get_db)):
    note = (await db.execute(select(MeetingNote).where(MeetingNote.booking_id == booking_id).limit(1))).scalar_one_or_none()
    if note is None:
        raise _err(404, "NOTE_NOT_FOUND", "Notulensi untuk booking ini belum ada")
    await _do_summarize(db, note.id, current_user)
    return SuccessResponse(data={"success": True, "status": "completed", "note_id": str(note.id),
                                 "booking_id": str(booking_id), "message": "Ringkasan AI selesai dibuat"})


@router.get("/meetings/{booking_id}/summary", response_model=SuccessResponse)
async def summary_by_booking(booking_id: UUID, current_user: User = Depends(require_permission("notes.view")),
                             db: AsyncSession = Depends(get_db)):
    note = (await db.execute(select(MeetingNote).where(MeetingNote.booking_id == booking_id).limit(1))).scalar_one_or_none()
    if note is None or not (note.summary or note.summary_json):
        raise _err(404, "NO_SUMMARY", "Ringkasan belum tersedia")
    resp = await _note_response(db, note, include_transcript=False)
    sj = note.summary_json or {}
    return SuccessResponse(data={
        "note_id": str(note.id), "booking_id": str(booking_id), "title": note.title,
        "summary_text": note.summary or "", "key_points": [p.get("judul", "") for p in sj.get("pokok_bahasan", [])],
        "decisions": [{"id": str(i), "topic": "Keputusan", "decision": d} for i, d in enumerate(note.decisions or [])],
        "action_items": [a.model_dump(mode="json") for a in resp.action_items],
        "participants_mentioned": sj.get("peserta_aktif", []),
        "generated_at": note.generated_at.isoformat() if note.generated_at else None, "processing": False,
        "summary_json": sj,
    })


@router.get("/meetings/{booking_id}/action-items", response_model=SuccessResponse)
async def list_booking_action_items(booking_id: UUID, current_user: User = Depends(require_permission("notes.view")),
                                    db: AsyncSession = Depends(get_db)):
    nid = (await db.execute(select(MeetingNote.id).where(MeetingNote.booking_id == booking_id).limit(1))).scalar_one_or_none()
    if nid is None:
        return SuccessResponse(data=[])
    items = (await db.execute(select(MeetingNoteActionItem).where(MeetingNoteActionItem.note_id == nid)
                              .order_by(MeetingNoteActionItem.created_at))).scalars().all()
    return SuccessResponse(data=[_action_item_out(a) for a in items])


@router.post("/meetings/{booking_id}/action-items", response_model=SuccessResponse)
async def add_booking_action_item(booking_id: UUID, item: ActionItemBase,
                                  current_user: User = Depends(require_permission("notes.view")),
                                  db: AsyncSession = Depends(get_db)):
    booking = await _get_booking(db, booking_id)
    note = (await db.execute(select(MeetingNote).where(MeetingNote.booking_id == booking_id).limit(1))).scalar_one_or_none()
    if note is None:
        _ensure_recording_control(current_user, booking)
        note = await _ensure_note_for_booking(db, booking, current_user)
        await db.commit()
    return await add_action_item(note.id, item, current_user, db)


# ===========================================================================
# EXPORT (alias lama /export/{note_id}/{fmt})
# ===========================================================================
async def _export_context(db: AsyncSession, note: MeetingNote, include_transcript: bool) -> note_export.ExportContext:
    from src.api.models.system_setting import SystemSetting

    rows = (await db.execute(select(SystemSetting.setting_key, SystemSetting.setting_value).where(
        SystemSetting.setting_key.in_(("org_name", "org_address", "app_title"))))).all()
    sysv = {k: v for k, v in rows if v}
    org = sysv.get("org_name") or sysv.get("app_title") or settings.APP_NAME
    room = await db.get(Room, note.room_id) if note.room_id else None
    booking = await db.get(Booking, note.booking_id) if note.booking_id else None
    creator = await db.get(User, note.created_by) if note.created_by else None

    waktu = f"{note_export.jam(note.start_time)} – {note_export.jam(note.end_time)} WIB"
    pimpinan = None
    peserta: List[str] = []
    if booking is not None:
        if booking.actual_start_at:
            end = booking.actual_end_at
            waktu = (f"{note_export.jam(booking.actual_start_at.astimezone())} – "
                     f"{note_export.jam(end.astimezone()) if end else 'selesai'} WIB")
        chair = (await db.execute(
            select(BookingSeatAssignment, BookingParticipant, User)
            .join(RoomSeat, RoomSeat.id == BookingSeatAssignment.seat_id)
            .outerjoin(BookingParticipant, BookingParticipant.id == BookingSeatAssignment.participant_id)
            .outerjoin(User, User.id == BookingParticipant.user_id)
            .where(BookingSeatAssignment.booking_id == booking.id,
                   or_(RoomSeat.seat_type == "chair", BookingSeatAssignment.role_label.ilike("pimpinan%")))
            .limit(1)
        )).first()
        if chair:
            a, p, u = chair
            pimpinan = (u.name if u else None) or (p.guest_name if p else None) or a.display_name
        peserta = await _attended_names(db, booking.id, only_attended=True)
    if not peserta:
        peserta = list(note.participants or [])

    sj = note.summary_json or {}
    items = (await db.execute(select(MeetingNoteActionItem).where(MeetingNoteActionItem.note_id == note.id)
                              .order_by(MeetingNoteActionItem.created_at))).scalars().all()
    transcript = []
    if include_transcript:
        transcript = [{"start_ms": s.start_ms, "speaker_name": s.speaker_name, "text": s.text}
                      for s in await _segments(db, note.id)]
    return note_export.ExportContext(
        org_name=org, org_address=sysv.get("org_address"), title=note.title,
        tanggal=note_export.tanggal_indo(note.date), waktu=waktu,
        tempat=room.name if room else "-", pimpinan=pimpinan, notulis=creator.name if creator else None,
        peserta=peserta, ringkasan=sj.get("ringkasan") or note.summary or "",
        pokok_bahasan=[{"judul": p.get("judul", ""), "uraian": p.get("uraian", "")} for p in sj.get("pokok_bahasan", [])
                       if isinstance(p, dict)],
        keputusan=list(note.decisions or []),
        tindak_lanjut=[{"tugas": a.task, "pic": a.owner, "tenggat": a.due_date, "status": a.status} for a in items],
        transcript=transcript, status=note.status or "draft", finalized_at=note.finalized_at, ai_model=note.ai_model,
    )


async def _export(db: AsyncSession, note_id: UUID, fmt: str, include_transcript: bool) -> StreamingResponse:
    fmt = fmt.lower()
    if fmt not in note_export.RENDERERS:
        raise _err(400, "BAD_FORMAT", "Format tidak valid. Gunakan pdf, docx, txt, atau html")
    note = await _get_note(db, note_id)
    ctx = await _export_context(db, note, include_transcript)
    render, media = note_export.RENDERERS[fmt]
    content = await asyncio.to_thread(render, ctx)
    filename = note_export.safe_filename(note.title, fmt)
    return StreamingResponse(iter([content]), media_type=media, headers={
        "Content-Disposition": _content_disposition(filename), "Content-Length": str(len(content)),
        "Cache-Control": "no-store",
    })


@router.get("/export/{note_id}/{fmt}")
async def export_note_legacy(note_id: UUID, fmt: str, include_transcript: bool = Query(False),
                             current_user: User = Depends(require_permission("notes.view")),
                             db: AsyncSession = Depends(get_db)):
    return await _export(db, note_id, fmt, include_transcript)


# ===========================================================================
# NOTE BY ID
# ===========================================================================
@router.get("/{note_id}", response_model=SuccessResponse)
async def get_note(note_id: UUID, current_user: User = Depends(require_permission("notes.view")),
                   db: AsyncSession = Depends(get_db)):
    note = await _get_note(db, note_id)
    return SuccessResponse(data=await _note_response(db, note))


@router.put("/{note_id}", response_model=SuccessResponse)
async def update_note(note_id: UUID, body: MeetingNoteUpdate,
                      current_user: User = Depends(require_permission("notes.view")),
                      db: AsyncSession = Depends(get_db)):
    note, _ = await _note_for_edit(db, note_id, current_user)
    data = body.model_dump(exclude_unset=True)
    if "room_id" in data and data["room_id"] and not await db.get(Room, data["room_id"]):
        raise _err(400, "BAD_ROOM", "Ruangan tidak valid")
    if "booking_id" in data and data["booking_id"] and not await db.get(Booking, data["booking_id"]):
        raise _err(400, "BAD_BOOKING", "Booking tidak valid")
    for field in ("booking_id", "room_id", "title", "date", "start_time", "end_time", "summary"):
        if field in data and (data[field] is not None or field in ("summary", "booking_id", "room_id")):
            setattr(note, field, data[field])
    if data.get("participants") is not None:
        note.participants = [p.strip() for p in data["participants"] if p and p.strip()]
    if "summary_json" in data and data["summary_json"] is not None:
        sj = dict(note.summary_json or {})
        sj.update(data["summary_json"])
        sj["edited"] = True
        note.summary_json = sj
        if "summary" not in data and isinstance(sj.get("ringkasan"), str):
            note.summary = sj["ringkasan"]
        if "decisions" not in data and isinstance(sj.get("keputusan"), list):
            note.decisions = [str(k).strip() for k in sj["keputusan"] if str(k).strip()]
    if data.get("decisions") is not None:
        note.decisions = [d.strip() for d in data["decisions"] if d and d.strip()]
        if note.summary_json:
            note.summary_json = {**note.summary_json, "keputusan": list(note.decisions)}
    if note.start_time and note.end_time and note.start_time >= note.end_time:
        raise _err(400, "BAD_TIME", "Jam selesai harus setelah jam mulai")
    if body.action_items is not None:
        # Sinkronisasi penuh daftar action item (kompatibilitas FE lama).
        existing = {a.id: a for a in (await db.execute(
            select(MeetingNoteActionItem).where(MeetingNoteActionItem.note_id == note.id))).scalars().all()}
        keep = set()
        for ai in body.action_items:
            if ai.id and ai.id in existing:
                row = existing[ai.id]
                row.task, row.owner, row.due_date, row.status = ai.task, ai.owner, ai.due_date, ai.status
                keep.add(ai.id)
            else:
                db.add(MeetingNoteActionItem(note_id=note.id, task=ai.task, owner=ai.owner, due_date=ai.due_date,
                                             status=ai.status, source="manual"))
        for aid, row in existing.items():
            if aid not in keep:
                await db.delete(row)
    await db.commit()
    await db.refresh(note)
    return SuccessResponse(data=await _note_response(db, note))


@router.delete("/{note_id}", response_model=SuccessResponse)
async def delete_note(note_id: UUID, request: Request, current_user: User = Depends(require_permission("notes.write")),
                      db: AsyncSession = Depends(get_db)):
    note = await _get_note(db, note_id)
    if note.status == "final":
        raise _err(409, "NOTE_FINAL", "Notulensi final tidak dapat dihapus. Buka kembali terlebih dahulu.")
    await record_audit(db, current_user, "delete", "notes", "meeting_note", note.id,
                       details={"title": note.title}, request=request)
    await db.execute(delete(TranscriptSegment).where(TranscriptSegment.note_id == note.id))
    await db.delete(note)
    await db.commit()
    return SuccessResponse(data={"message": "Notulensi berhasil dihapus"})


# --- transkrip ---------------------------------------------------------------
@router.get("/{note_id}/segments", response_model=SuccessResponse)
async def list_segments(
    note_id: UUID,
    after: Optional[datetime] = Query(None, description="Hanya segmen yang dibuat/diubah setelah waktu ini (ISO)"),
    limit: int = Query(2000, ge=1, le=5000),
    current_user: User = Depends(require_permission("notes.view")),
    db: AsyncSession = Depends(get_db),
):
    await _get_note(db, note_id)
    stmt = _segment_select().where(TranscriptSegment.note_id == note_id)
    if after is not None:
        if after.tzinfo is None:
            after = after.replace(tzinfo=timezone.utc)
        stmt = stmt.where(TranscriptSegment.updated_at > after)
    segs = (await db.execute(stmt.order_by(*_segment_order()).limit(limit))).scalars().all()
    labels = await _seat_labels(db, [s.seat_id for s in segs])
    total = (await db.execute(select(func.count(TranscriptSegment.id)).where(TranscriptSegment.note_id == note_id))).scalar() or 0
    cursor = max((s.updated_at for s in segs if s.updated_at), default=after)
    return SuccessResponse(data={
        "items": [serialize_segment(s, labels.get(s.seat_id)) for s in segs], "total": total,
        "cursor": cursor.isoformat() if cursor else None, "server_time": _now().isoformat(),
        "transcript_processing": transcription_service.pending_for_note(note_id) > 0,
    })


async def _participant_name(db: AsyncSession, participant_id: UUID, booking_id: Optional[UUID]) -> str:
    row = (await db.execute(select(BookingParticipant, User).outerjoin(User, User.id == BookingParticipant.user_id)
                            .where(BookingParticipant.id == participant_id))).first()
    if row is None or (booking_id is not None and row[0].booking_id != booking_id):
        raise _err(400, "BAD_PARTICIPANT", "Peserta tidak terdaftar pada rapat ini")
    p, u = row
    return (u.name if u else None) or p.guest_name or "Peserta"


async def _room_of(db: AsyncSession, note: MeetingNote):
    if note.booking_id:
        b = await db.get(Booking, note.booking_id)
        if b:
            return b.room_id
    return note.room_id


@router.post("/{note_id}/segments", response_model=SuccessResponse, status_code=201)
async def add_segment(note_id: UUID, body: SegmentCreate,
                      current_user: User = Depends(require_permission("notes.view")),
                      db: AsyncSession = Depends(get_db)):
    """Tambah baris transkrip manual (mis. koreksi notulis)."""
    note, _ = await _note_for_edit(db, note_id, current_user)
    name = body.speaker_name
    if body.participant_id:
        pname = await _participant_name(db, body.participant_id, note.booking_id)
        name = name or pname
    seg = TranscriptSegment(note_id=note.id, booking_id=note.booking_id, start_ms=body.start_ms,
                            end_ms=body.end_ms if body.end_ms is not None else body.start_ms,
                            participant_id=body.participant_id, speaker_name=(name or "Peserta").strip(),
                            text=body.text.strip(), is_edited=True, language=settings.STT_LANGUAGE or None)
    db.add(seg)
    await db.commit()
    await db.refresh(seg)
    payload = serialize_segment(seg)
    await broadcast(await _room_of(db, note), "transcript_segment", payload)
    return SuccessResponse(data=payload)


@router.patch("/{note_id}/segments/{segment_id}", response_model=SuccessResponse)
async def update_segment(note_id: UUID, segment_id: UUID, body: SegmentUpdate,
                         current_user: User = Depends(require_permission("notes.view")),
                         db: AsyncSession = Depends(get_db)):
    note, _ = await _note_for_edit(db, note_id, current_user)
    seg = await db.get(TranscriptSegment, segment_id)
    if seg is None or seg.note_id != note.id:
        raise _err(404, "SEGMENT_NOT_FOUND", "Segmen transkrip tidak ditemukan")
    data = body.model_dump(exclude_unset=True)
    if "text" in data and data["text"] is not None:
        seg.text = data["text"].strip()
    if body.clear_participant:
        seg.participant_id = None
    if data.get("participant_id"):
        pname = await _participant_name(db, body.participant_id, note.booking_id)
        seg.participant_id = body.participant_id
        if not data.get("speaker_name"):
            seg.speaker_name = pname
    if data.get("speaker_name"):
        seg.speaker_name = data["speaker_name"].strip()
    seg.is_edited = True
    seg.updated_at = _now()
    await db.commit()
    await db.refresh(seg)
    labels = await _seat_labels(db, [seg.seat_id])
    payload = serialize_segment(seg, labels.get(seg.seat_id))
    await broadcast(await _room_of(db, note), "transcript_segment", payload)
    return SuccessResponse(data=payload)


@router.delete("/{note_id}/segments/{segment_id}", response_model=SuccessResponse)
async def delete_segment(note_id: UUID, segment_id: UUID,
                         current_user: User = Depends(require_permission("notes.view")),
                         db: AsyncSession = Depends(get_db)):
    note, _ = await _note_for_edit(db, note_id, current_user)
    seg = await db.get(TranscriptSegment, segment_id)
    if seg is None or seg.note_id != note.id:
        raise _err(404, "SEGMENT_NOT_FOUND", "Segmen transkrip tidak ditemukan")
    await db.delete(seg)
    await db.commit()
    await broadcast(await _room_of(db, note), "transcript_segment",
                    {"id": str(segment_id), "note_id": str(note.id), "deleted": True})
    return SuccessResponse(data={"message": "Segmen dihapus", "id": str(segment_id)})


@router.post("/{note_id}/transcribe-audio", status_code=202, response_model=SuccessResponse)
async def transcribe_audio(
    note_id: UUID,
    audio_file: Optional[UploadFile] = File(None),
    audio: Optional[UploadFile] = File(None),
    offset_ms: int = Form(0, ge=0),
    speaker_name: Optional[str] = Form(None, max_length=200),
    current_user: User = Depends(require_permission("notes.view")),
    db: AsyncSession = Depends(get_db),
):
    """Unggah rekaman penuh (mode upload). Diproses di latar; pantau via status/segments."""
    upload = audio_file or audio
    note, booking = await _note_for_edit(db, note_id, current_user)
    ext = _check_audio(upload)
    max_bytes = int(settings.MAX_FILE_SIZE_MB) * 1024 * 1024
    rec = None
    if booking is not None:
        rec = MeetingRecording(booking_id=booking.id, note_id=note.id, source="upload", status="processing",
                               channel_count=1, started_at=_now(), paused_ms=0, created_by=current_user.id)
        db.add(rec)
        await db.flush()
        folder = recording_dir(booking.id, rec.id)
    else:
        folder = recording_dir(note.id, uuid.uuid4())
    dest = folder / f"upload_{uuid.uuid4().hex}{ext}"
    try:
        size = await _save_upload(upload, dest, max_bytes)
    except HTTPException:
        await db.rollback()
        raise
    if rec is not None:
        rec.file_path = str(dest)
    note.transcript_processing = True
    await db.commit()
    job = TranscriptionJob(kind="file", note_id=str(note.id), booking_id=str(booking.id) if booking else "",
                           audio_path=str(dest), recording_id=str(rec.id) if rec else None, start_ms=int(offset_ms),
                           speaker_name=(speaker_name or "").strip() or None)
    await transcription_service.enqueue(job)
    return SuccessResponse(data={
        "queued": True, "job_id": job.job_id, "recording_id": str(rec.id) if rec else None, "size_bytes": size,
        "queue_size": transcription_service.queue_size(),
        "message": "File diterima dan sedang ditranskripsi di latar belakang",
    })


# --- ringkasan AI -----------------------------------------------------------
async def _do_summarize(db: AsyncSession, note_id: UUID, user: User) -> MeetingNote:
    note, booking = await _note_for_edit(db, note_id, user)
    key = str(note.id)
    if key in _summarizing:
        raise _err(409, "SUMMARY_RUNNING", "Ringkasan untuk notulensi ini sedang diproses")
    _summarizing.add(key)
    try:
        segs = await _segments(db, note.id)
        room = await db.get(Room, note.room_id) if note.room_id else None
        meta = {"judul": note.title, "tanggal": note_export.tanggal_indo(note.date),
                "waktu": f"{note_export.jam(note.start_time)}–{note_export.jam(note.end_time)}",
                "tempat": room.name if room else None,
                "peserta": (await _attended_names(db, booking.id) if booking else None) or list(note.participants or [])}
        try:
            result, info = await summarize_segments(segs, meta)
        except SummarizerError as e:
            raise _err(e.status_code, e.code, e.message)
        now = _now()
        note.summary = result.ringkasan
        note.decisions = list(result.keputusan)
        note.summary_json = {**result.model_dump(), "model": info["model"], "chunks": info["chunks"],
                             "generated_at": now.isoformat(), "segment_count": len(segs)}
        note.ai_model = (info["model"] or "")[:50]
        note.generated_at = now
        await db.execute(delete(MeetingNoteActionItem).where(MeetingNoteActionItem.note_id == note.id,
                                                             MeetingNoteActionItem.source == "ai"))
        for t in result.tindak_lanjut:
            db.add(MeetingNoteActionItem(
                note_id=note.id, task=t.tugas, owner=(t.pic or None) and t.pic[:100],
                due_date=date.fromisoformat(t.tenggat) if t.tenggat else None, status="open", source="ai",
            ))
        await db.commit()
        await db.refresh(note)
        return note
    finally:
        _summarizing.discard(key)


@router.post("/{note_id}/summarize", response_model=SuccessResponse)
async def summarize_note(note_id: UUID, current_user: User = Depends(require_permission("notes.view")),
                         db: AsyncSession = Depends(get_db)):
    note = await _do_summarize(db, note_id, current_user)
    return SuccessResponse(data=await _note_response(db, note))


@router.post("/{note_id}/regenerate-summary", response_model=SuccessResponse)
async def regenerate_summary(note_id: UUID, current_user: User = Depends(require_permission("notes.view")),
                             db: AsyncSession = Depends(get_db)):
    """Alias lama untuk /summarize."""
    return await summarize_note(note_id, current_user, db)


# --- finalisasi -------------------------------------------------------------
@router.post("/{note_id}/finalize", response_model=SuccessResponse)
async def finalize_note(note_id: UUID, request: Request, current_user: User = Depends(require_permission("notes.view")),
                        db: AsyncSession = Depends(get_db)):
    note, booking = await _note_for_edit(db, note_id, current_user)
    if booking is not None and await _active_recording(db, booking.id) is not None:
        raise _err(409, "RECORDING_ACTIVE", "Hentikan rekaman sebelum memfinalisasi notulensi")
    if transcription_service.pending_for_note(note.id) > 0:
        raise _err(409, "TRANSCRIBING", "Transkripsi masih diproses. Tunggu hingga selesai.")
    note.status = "final"
    note.finalized_at = _now()
    note.finalized_by = current_user.id
    await record_audit(db, current_user, "finalize", "notes", "meeting_note", note.id,
                       details={"title": note.title}, request=request)
    await db.commit()
    await db.refresh(note)
    return SuccessResponse(data=await _note_response(db, note))


@router.post("/{note_id}/reopen", response_model=SuccessResponse)
async def reopen_note(note_id: UUID, request: Request, current_user: User = Depends(require_permission("notes.write")),
                      db: AsyncSession = Depends(get_db)):
    note = await _get_note(db, note_id)
    if note.status != "final":
        raise _err(409, "NOT_FINAL", "Notulensi belum final")
    note.status = "draft"
    note.finalized_at = None
    note.finalized_by = None
    await record_audit(db, current_user, "reopen", "notes", "meeting_note", note.id,
                       details={"title": note.title}, request=request)
    await db.commit()
    await db.refresh(note)
    return SuccessResponse(data=await _note_response(db, note))


@router.get("/{note_id}/export/{fmt}")
async def export_note(note_id: UUID, fmt: str, include_transcript: bool = Query(False),
                      current_user: User = Depends(require_permission("notes.view")),
                      db: AsyncSession = Depends(get_db)):
    return await _export(db, note_id, fmt, include_transcript)


# --- action items -----------------------------------------------------------
@router.get("/{note_id}/action-items", response_model=SuccessResponse)
async def list_action_items(note_id: UUID, current_user: User = Depends(require_permission("notes.view")),
                            db: AsyncSession = Depends(get_db)):
    await _get_note(db, note_id)
    items = (await db.execute(select(MeetingNoteActionItem).where(MeetingNoteActionItem.note_id == note_id)
                              .order_by(MeetingNoteActionItem.created_at))).scalars().all()
    return SuccessResponse(data=[_action_item_out(a) for a in items])


@router.post("/{note_id}/action-items", response_model=SuccessResponse, status_code=201)
async def add_action_item(note_id: UUID, item: ActionItemBase,
                          current_user: User = Depends(require_permission("notes.view")),
                          db: AsyncSession = Depends(get_db)):
    note, _ = await _note_for_edit(db, note_id, current_user)
    row = MeetingNoteActionItem(note_id=note.id, task=item.task.strip(), owner=item.owner, due_date=item.due_date,
                                status=item.status, source="manual")
    db.add(row)
    await db.commit()
    await db.refresh(row)
    return SuccessResponse(data=_action_item_out(row))


async def _get_item(db: AsyncSession, note: MeetingNote, item_id: UUID) -> MeetingNoteActionItem:
    row = await db.get(MeetingNoteActionItem, item_id)
    if row is None or row.note_id != note.id:
        raise _err(404, "ITEM_NOT_FOUND", "Action item tidak ditemukan")
    return row


@router.patch("/{note_id}/action-items/{item_id}", response_model=SuccessResponse)
async def update_action_item(note_id: UUID, item_id: UUID, body: ActionItemUpdate,
                             current_user: User = Depends(require_permission("notes.view")),
                             db: AsyncSession = Depends(get_db)):
    note, _ = await _note_for_edit(db, note_id, current_user)
    row = await _get_item(db, note, item_id)
    data = body.model_dump(exclude_unset=True)
    for f in ("task", "owner", "due_date", "status"):
        if f in data and (data[f] is not None or f in ("owner", "due_date")):
            setattr(row, f, data[f])
    await db.commit()
    await db.refresh(row)
    return SuccessResponse(data=_action_item_out(row))


@router.delete("/{note_id}/action-items/{item_id}", response_model=SuccessResponse)
async def delete_action_item(note_id: UUID, item_id: UUID,
                             current_user: User = Depends(require_permission("notes.view")),
                             db: AsyncSession = Depends(get_db)):
    note, _ = await _note_for_edit(db, note_id, current_user)
    row = await _get_item(db, note, item_id)
    await db.delete(row)
    await db.commit()
    return SuccessResponse(data={"message": "Action item dihapus", "id": str(item_id)})
