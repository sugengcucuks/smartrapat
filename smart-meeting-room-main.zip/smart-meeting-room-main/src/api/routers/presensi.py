import logging

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, func
from typing import List, Optional
from uuid import UUID
from datetime import datetime, date, timedelta

from src.api.database import get_db
from src.api.models.user import User
from src.api.models.room import Room
from src.api.models.booking import Booking, BookingParticipant
from src.api.schemas.presensi import (
    SuccessResponse,
    TicketItem,
    MyTicketsResponse,
    PresensiScanRequest,
    PresensiScanResponse,
    AttendanceParticipantItem,
    BookingAttendanceResponse,
)
from src.api.utils.auth import get_current_user
from src.api.utils.ticket import normalize_ticket_code, generate_ticket_code
from src.api.utils.audit import client_ip
from src.api.utils.kiosk import kiosk_token_from_request, optional_user, verify_kiosk_token
from src.api.utils.permissions import has_permission
from src.api.utils.rate_limit import rate_limiter

router = APIRouter(prefix="/presensi", tags=["Presensi & Scanner"])
logger = logging.getLogger("smr.presensi")

# Status booking yang tiketnya masih relevan ditampilkan / di-scan.
ACTIVE_BOOKING_STATUSES = ("draft", "pending", "approved")
# Presensi dibuka 30 menit sebelum rapat mulai sampai rapat selesai.
CHECKIN_OPEN_BEFORE_MINUTES = 30


async def _ensure_unique_ticket(db: AsyncSession) -> str:
    """Buat kode tiket yang dijamin belum dipakai peserta lain."""
    for _ in range(20):
        candidate = generate_ticket_code()
        existing = await db.execute(
            select(BookingParticipant.id).where(BookingParticipant.ticket_code == candidate)
        )
        if existing.scalar_one_or_none() is None:
            return candidate
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail="Gagal membuat kode tiket unik",
    )


async def _resolve_name(db: AsyncSession, participant: BookingParticipant) -> str:
    """Nama tampilan peserta: nama user login, atau nama tamu."""
    if participant.is_guest:
        return participant.guest_name or "Tamu"
    if participant.user_id:
        res = await db.execute(select(User).where(User.id == participant.user_id))
        user = res.scalar_one_or_none()
        if user:
            return user.name
    return participant.guest_name or "Peserta"


async def _attendance_counts(db: AsyncSession, booking_id: UUID):
    """Kembalikan (jumlah hadir, total peserta) untuk sebuah booking."""
    total = await db.scalar(
        select(func.count(BookingParticipant.id)).where(
            BookingParticipant.booking_id == booking_id
        )
    )
    attended = await db.scalar(
        select(func.count(BookingParticipant.id)).where(
            and_(
                BookingParticipant.booking_id == booking_id,
                BookingParticipant.attended.is_(True),
            )
        )
    )
    return (attended or 0), (total or 0)


async def _checkin_seat(db: AsyncSession, booking: Booking, participant: BookingParticipant) -> Optional[dict]:
    """Kursi peserta (yang sudah ada / ditugaskan otomatis). Gagal -> None, presensi tetap sukses."""
    try:
        from src.api.routers.live_meeting import assign_seat_on_checkin

        return await assign_seat_on_checkin(db, booking, participant)
    except Exception:  # noqa: BLE001
        logger.warning("Penugasan kursi otomatis gagal", exc_info=True)
        try:
            await db.rollback()
            await db.refresh(participant)
            await db.refresh(booking)
        except Exception:  # noqa: BLE001
            pass
        return None


async def _get_room(db: AsyncSession, room_id: Optional[UUID]) -> Optional[Room]:
    if not room_id:
        return None
    res = await db.execute(select(Room).where(Room.id == room_id))
    return res.scalar_one_or_none()


async def _build_ticket_item(
    db: AsyncSession, participant: BookingParticipant, booking: Booking
) -> TicketItem:
    room = await _get_room(db, booking.room_id)
    attended_count, total = await _attendance_counts(db, booking.id)

    return TicketItem(
        participant_id=participant.id,
        booking_id=booking.id,
        ticket_code=participant.ticket_code,
        booking_title=booking.title,
        room_name=room.name if room else None,
        room_code=room.code if room else None,
        date=booking.date,
        start_time=booking.start_time,
        end_time=booking.end_time,
        booking_status=booking.status,
        attended=participant.attended,
        checked_in_at=participant.checked_in_at,
        attended_count=attended_count,
        total_participants=total,
    )


# ============================================================
# TIKET SAYA
# ============================================================

@router.get("/tickets/my", response_model=SuccessResponse)
async def list_my_tickets(
    include_past: bool = False,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Tiket milik user login, termasuk seluruh peserta rapat yang dia buat."""
    today = date.today()

    conditions = [Booking.status.in_(ACTIVE_BOOKING_STATUSES)]
    if not include_past:
        conditions.append(Booking.date >= today)

    # Tiket sebagai peserta langsung, digabung tiket seluruh peserta rapat
    # yang dia selenggarakan (sebagai organizer).
    stmt = (
        select(BookingParticipant, Booking)
        .join(Booking, BookingParticipant.booking_id == Booking.id)
        .where(
            and_(
                or_(
                    BookingParticipant.user_id == current_user.id,
                    Booking.user_id == current_user.id,
                ),
                *conditions,
            )
        )
    )

    result = await db.execute(stmt)
    rows = list(result.all())

    seen = set()
    items: List[TicketItem] = []
    for participant, booking in rows:
        if participant.id in seen:
            continue
        seen.add(participant.id)

        # Tiket peserta lama yang belum punya kode -> generate saat diakses.
        if not participant.ticket_code:
            participant.ticket_code = await _ensure_unique_ticket(db)

        items.append(await _build_ticket_item(db, participant, booking))

    if items:
        await db.commit()

    items.sort(key=lambda t: (t.date, t.start_time))
    return SuccessResponse(data=MyTicketsResponse(items=items, total=len(items)))


@router.get("/tickets/{participant_id}", response_model=SuccessResponse)
async def get_ticket_detail(
    participant_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    stmt = (
        select(BookingParticipant, Booking)
        .join(Booking, BookingParticipant.booking_id == Booking.id)
        .where(BookingParticipant.id == participant_id)
    )
    result = await db.execute(stmt)
    row = result.one_or_none()

    if not row:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Tiket tidak ditemukan")

    participant, booking = row

    if participant.user_id != current_user.id and booking.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Anda tidak berhak mengakses tiket ini",
        )

    if not participant.ticket_code:
        participant.ticket_code = await _ensure_unique_ticket(db)
        await db.commit()
        await db.refresh(participant)

    return SuccessResponse(data=await _build_ticket_item(db, participant, booking))


# ============================================================
# SCANNER PRESENSI (public - dipakai kiosk di pintu ruangan)
# ============================================================

@router.post("/scan", response_model=SuccessResponse)
async def scan_ticket(
    request: PresensiScanRequest,
    http_request: Request,
    user: Optional[User] = Depends(optional_user),
    db: AsyncSession = Depends(get_db),
):
    """Validasi hasil scan QR / input kode tiket manual, lalu catat kehadiran.

    Pemanggil: kiosk yang sudah dipasangkan (header X-Kiosk-Token, hanya untuk
    ruangannya sendiri) atau petugas login dengan izin bookings.approve /
    door_display.manage.
    """
    ip = client_ip(http_request) or "unknown"
    rate_limiter.hit(f"presensi-scan:{ip}", limit=30, window_seconds=60)

    kiosk_room: Optional[Room] = None
    kiosk_token = kiosk_token_from_request(http_request)
    if kiosk_token:
        kiosk_room = await verify_kiosk_token(db, kiosk_token)
    elif user is None or not has_permission(user, "bookings.approve", "door_display.manage"):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED if user is None else status.HTTP_403_FORBIDDEN,
            detail={"code": "KIOSK_UNPAIRED" if user is None else "FORBIDDEN",
                    "message": "Scanner presensi hanya untuk kiosk terpasang atau petugas"},
        )

    raw_code = (request.code or "").strip()

    # QR bisa berisi kode polos, URL, atau payload apa pun -> normalisasi dulu.
    ticket_code = normalize_ticket_code(raw_code) or raw_code.upper()

    stmt = (
        select(BookingParticipant, Booking)
        .join(Booking, BookingParticipant.booking_id == Booking.id)
        .where(BookingParticipant.ticket_code == ticket_code)
    )
    result = await db.execute(stmt)
    row = result.one_or_none()

    if not row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Kode tiket tidak dikenal",
        )

    participant, booking = row
    room = await _get_room(db, booking.room_id)

    # Kiosk hanya boleh memproses tiket untuk ruangannya sendiri.
    if kiosk_room is not None and booking.room_id != kiosk_room.id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Tiket ini bukan untuk ruangan ini")
    if request.room_code and room is not None and request.room_code != room.code:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Tiket ini bukan untuk ruangan ini")

    if booking.status != "approved":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Rapat belum disetujui admin, presensi belum dapat dilakukan",
        )
    now = datetime.now()
    if booking.date != now.date():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Tiket bukan untuk rapat hari ini")
    window_start = datetime.combine(booking.date, booking.start_time) - timedelta(minutes=CHECKIN_OPEN_BEFORE_MINUTES)
    window_end = datetime.combine(booking.date, booking.end_time)
    if now < window_start:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Presensi dibuka mulai {window_start.strftime('%H:%M')}",
        )
    if now > window_end:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Rapat sudah selesai")

    name = await _resolve_name(db, participant)
    room_name = room.name if room else None

    if participant.attended:
        seat = await _checkin_seat(db, booking, participant)
        attended_count, total = await _attendance_counts(db, booking.id)
        return SuccessResponse(
            data=PresensiScanResponse(
                success=True,
                message=f"{name} sudah melakukan presensi sebelumnya",
                participant_id=participant.id,
                participant_name=name,
                booking_id=booking.id,
                booking_title=booking.title,
                room_name=room_name,
                attended=True,
                already_checked_in=True,
                checked_in_at=participant.checked_in_at,
                attended_count=attended_count,
                total_participants=total,
                seat=seat,
            )
        )

    participant.attended = True
    participant.checked_in_at = datetime.now()
    await db.commit()
    await db.refresh(participant)

    # Denah kursi: tugaskan kursi kosong bila peserta belum punya kursi.
    seat = await _checkin_seat(db, booking, participant)
    attended_count, total = await _attendance_counts(db, booking.id)

    # Kabari layar pintu ruangan agar counter kehadiran ikut ter-update.
    if room:
        try:
            from src.api.routers.door_display import door_ws_manager, _get_status_payload

            payload = await _get_status_payload(db, room)
            await door_ws_manager.broadcast_room(
                room.code,
                {
                    "event": "attendance_changed",
                    "booking_id": str(booking.id),
                    "participant_name": name,
                    "attended_count": attended_count,
                    "total_participants": total,
                    "seat": seat,
                    "data": payload,
                    "timestamp": datetime.now().isoformat(),
                },
            )
        except Exception:
            pass

    # Konsol live meeting (WebSocket per ruangan).
    try:
        from src.api.routers.live_meeting import hub_broadcast, hub_invalidate

        await hub_broadcast(booking.room_id, "attendance_changed", {
            "booking_id": str(booking.id),
            "participant_id": str(participant.id),
            "participant_name": name,
            "attended": True,
            "checked_in_at": participant.checked_in_at.isoformat() if participant.checked_in_at else None,
            "attended_count": attended_count,
            "total_participants": total,
            "seat": seat,
        })
        if seat:
            await hub_invalidate(booking.room_id)
    except Exception:  # noqa: BLE001 - siaran best effort
        pass

    return SuccessResponse(
        data=PresensiScanResponse(
            success=True,
            message=f"Selamat datang, {name}!",
            participant_id=participant.id,
            participant_name=name,
            booking_id=booking.id,
            booking_title=booking.title,
            room_name=room_name,
            attended=True,
            already_checked_in=False,
            checked_in_at=participant.checked_in_at,
            attended_count=attended_count,
            total_participants=total,
            seat=seat,
        )
    )


# ============================================================
# LIVE COUNTER KEHADIRAN
# ============================================================

@router.get("/bookings/{booking_id}/attendance", response_model=SuccessResponse)
async def get_booking_attendance(
    booking_id: UUID,
    http_request: Request,
    user: Optional[User] = Depends(optional_user),
    db: AsyncSession = Depends(get_db),
):
    """Daftar hadir: kiosk ruangan terkait, pemilik booking, atau pemegang bookings.view."""
    res = await db.execute(select(Booking).where(Booking.id == booking_id))
    booking = res.scalar_one_or_none()
    if not booking:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Booking tidak ditemukan")

    kiosk_token = kiosk_token_from_request(http_request)
    if kiosk_token:
        kiosk_room = await verify_kiosk_token(db, kiosk_token)
        if kiosk_room.id != booking.room_id:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Booking bukan milik ruangan kiosk ini")
    elif user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": "AUTH_REQUIRED", "message": "Login diperlukan"},
        )
    elif booking.user_id != user.id and not has_permission(user, "bookings.view"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "FORBIDDEN", "message": "Anda tidak berhak melihat daftar hadir ini"},
        )

    room = await _get_room(db, booking.room_id)

    p_res = await db.execute(
        select(BookingParticipant)
        .where(BookingParticipant.booking_id == booking_id)
        .order_by(BookingParticipant.attended.desc(), BookingParticipant.created_at.asc())
    )
    participants = list(p_res.scalars().all())

    items: List[AttendanceParticipantItem] = []
    attended_count = 0
    for p in participants:
        if p.attended:
            attended_count += 1
        items.append(
            AttendanceParticipantItem(
                participant_id=p.id,
                name=await _resolve_name(db, p),
                is_guest=p.is_guest,
                attended=p.attended,
                checked_in_at=p.checked_in_at,
            )
        )

    return SuccessResponse(
        data=BookingAttendanceResponse(
            booking_id=booking.id,
            booking_title=booking.title,
            room_name=room.name if room else None,
            attended_count=attended_count,
            total_participants=len(items),
            participants=items,
        )
    )
