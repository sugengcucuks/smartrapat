"""Dashboard Tindak Lanjut lintas rapat.

Agregasi seluruh action item dari semua notulen rapat:
- `/followups/summary`: ringkasan status, overdue, jatuh tempo, per owner,
- `/followups/items`  : daftar item dengan konteks rapat (judul, tanggal, ruangan),
- PATCH `/followups/items/{id}`: ubah task/owner/due_date/status cepat.

Hak akses:
- Lihat: izin `notes.view`.
- Ubah: `notes.write` ATAU pembuat notulen ATAU pemilik booking
  (aturan sama dengan endpoint action item di notes.py).
"""
from __future__ import annotations

import math
from datetime import date, timedelta
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.database import get_db
from src.api.models.booking import Booking
from src.api.models.note import MeetingNote, MeetingNoteActionItem
from src.api.models.room import Room
from src.api.models.user import User
from src.api.schemas.followup import (
    FollowupItemResponse,
    FollowupItemUpdate,
    FollowupItemsResponse,
    FollowupOwnerStat,
    FollowupSummary,
)
from src.api.schemas.user import SuccessResponse
from src.api.utils.audit import record_audit
from src.api.utils.permissions import has_permission, require_permission

router = APIRouter(prefix="/followups", tags=["Tindak Lanjut"])

# Status yang masih dianggap "perlu dikerjakan".
ACTIVE_STATUSES = ("open", "in_progress")


def _item_response(item: MeetingNoteActionItem, **ctx) -> FollowupItemResponse:
    return FollowupItemResponse(
        id=item.id,
        note_id=item.note_id,
        task=item.task,
        owner=item.owner,
        assignee=item.owner,
        due_date=item.due_date,
        status=item.status,
        source=item.source,
        created_at=item.created_at,
        updated_at=item.updated_at,
        **ctx,
    )


async def _load_editable(db: AsyncSession, item_id: UUID, user: User):
    """Muat item + note + booking, cek izin ubah. Raise 404/403."""
    item = (
        await db.execute(select(MeetingNoteActionItem).where(MeetingNoteActionItem.id == item_id))
    ).scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail={"code": "NOT_FOUND", "message": "Item tidak ditemukan"})
    note = (
        await db.execute(select(MeetingNote).where(MeetingNote.id == item.note_id))
    ).scalar_one_or_none()
    booking_id = note.booking_id if note else None
    owner_id = None
    if booking_id:
        owner_id = (
            await db.execute(select(Booking.user_id).where(Booking.id == booking_id))
        ).scalar_one_or_none()
    if not (
        has_permission(user, "notes.write")
        or (note is not None and note.created_by == user.id)
        or (owner_id == user.id)
    ):
        raise HTTPException(
            status_code=403,
            detail={"code": "FORBIDDEN", "message": "Anda tidak berhak mengubah item ini"},
        )
    return item, note


@router.get("/summary", response_model=SuccessResponse)
async def followup_summary(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("notes.view")),
):
    """Ringkasan tindak lanjut seluruh rapat untuk kartu dashboard."""
    today = date.today()
    week_end = today + timedelta(days=7)
    active = and_(MeetingNoteActionItem.status.in_(ACTIVE_STATUSES),)

    total = (
        await db.execute(select(func.count(MeetingNoteActionItem.id)))
    ).scalar() or 0

    by_status = dict(
        (
            await db.execute(
                select(MeetingNoteActionItem.status, func.count(MeetingNoteActionItem.id))
                .group_by(MeetingNoteActionItem.status)
            )
        ).all()
    )

    overdue = (
        await db.execute(
            select(func.count(MeetingNoteActionItem.id)).where(
                active,
                MeetingNoteActionItem.due_date.isnot(None),
                MeetingNoteActionItem.due_date < today,
            )
        )
    ).scalar() or 0
    due_today = (
        await db.execute(
            select(func.count(MeetingNoteActionItem.id)).where(
                active, MeetingNoteActionItem.due_date == today
            )
        )
    ).scalar() or 0
    due_this_week = (
        await db.execute(
            select(func.count(MeetingNoteActionItem.id)).where(
                active,
                MeetingNoteActionItem.due_date >= today,
                MeetingNoteActionItem.due_date <= week_end,
            )
        )
    ).scalar() or 0

    owner_rows = (
        await db.execute(
            select(MeetingNoteActionItem.owner, func.count(MeetingNoteActionItem.id))
            .where(active, MeetingNoteActionItem.owner.isnot(None), MeetingNoteActionItem.owner != "")
            .group_by(MeetingNoteActionItem.owner)
            .order_by(func.count(MeetingNoteActionItem.id).desc())
            .limit(10)
        )
    ).all()

    return SuccessResponse(
        data=FollowupSummary(
            total=total,
            open=by_status.get("open", 0),
            in_progress=by_status.get("in_progress", 0),
            done=by_status.get("done", 0),
            cancelled=by_status.get("cancelled", 0),
            overdue=overdue,
            due_today=due_today,
            due_this_week=due_this_week,
            by_owner=[FollowupOwnerStat(owner=o or "-", total=c) for o, c in owner_rows],
        )
    )


@router.get("/items", response_model=SuccessResponse)
async def followup_items(
    status: str = Query("all", description="all | open | in_progress | done | cancelled | overdue | due_this_week"),
    owner: str = Query("", max_length=100),
    q: str = Query("", max_length=200),
    booking_id: UUID | None = Query(None),
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("notes.view")),
):
    """Daftar seluruh tindak lanjut lintas rapat, terbaru dulu."""
    today = date.today()
    conds = []
    if status == "overdue":
        conds += [
            MeetingNoteActionItem.status.in_(ACTIVE_STATUSES),
            MeetingNoteActionItem.due_date.isnot(None),
            MeetingNoteActionItem.due_date < today,
        ]
    elif status == "due_this_week":
        conds += [
            MeetingNoteActionItem.status.in_(ACTIVE_STATUSES),
            MeetingNoteActionItem.due_date >= today,
            MeetingNoteActionItem.due_date <= today + timedelta(days=7),
        ]
    elif status != "all":
        conds.append(MeetingNoteActionItem.status == status)
    if owner:
        conds.append(MeetingNoteActionItem.owner.ilike(f"%{owner}%"))
    if q:
        conds.append(MeetingNoteActionItem.task.ilike(f"%{q}%"))
    if booking_id:
        conds.append(MeetingNote.booking_id == booking_id)

    base = (
        select(MeetingNoteActionItem, MeetingNote, Booking, Room)
        .join(MeetingNote, MeetingNote.id == MeetingNoteActionItem.note_id)
        .outerjoin(Booking, Booking.id == MeetingNote.booking_id)
        .outerjoin(Room, Room.id == MeetingNote.room_id)
    )
    where = and_(*conds) if conds else None

    total = (
        await db.execute(
            select(func.count(MeetingNoteActionItem.id))
            .join(MeetingNote, MeetingNote.id == MeetingNoteActionItem.note_id)
            .outerjoin(Booking, Booking.id == MeetingNote.booking_id)
            .where(*conds) if conds else
            select(func.count(MeetingNoteActionItem.id))
            .join(MeetingNote, MeetingNote.id == MeetingNoteActionItem.note_id)
            .outerjoin(Booking, Booking.id == MeetingNote.booking_id)
        )
    ).scalar() or 0

    rows = (
        await db.execute(
            (base.where(where) if where is not None else base)
            .order_by(MeetingNote.date.desc(), MeetingNoteActionItem.created_at.desc())
            .offset((page - 1) * per_page)
            .limit(per_page)
        )
    ).all()

    items = [
        _item_response(
            it,
            note_title=note.title,
            booking_title=booking.title if booking else None,
            booking_id=booking.id if booking else None,
            meeting_date=note.date,
            room_name=room.name if room else None,
        )
        for it, note, booking, room in rows
    ]
    return SuccessResponse(
        data=FollowupItemsResponse(
            items=items,
            total=total,
            page=page,
            per_page=per_page,
            total_pages=max(1, math.ceil(total / per_page)),
        )
    )


@router.patch("/items/{item_id}", response_model=SuccessResponse)
async def update_followup_item(
    item_id: UUID,
    body: FollowupItemUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("notes.view")),
):
    """Perbarui item tindak lanjut (status/owner/tenggat/task) dari dashboard."""
    item, note = await _load_editable(db, item_id, current_user)

    if body.task is not None:
        item.task = body.task
    if body.owner is not None:
        item.owner = body.owner or None
    if body.due_date is not None:
        item.due_date = body.due_date
    if body.status is not None:
        item.status = body.status

    await db.commit()
    await db.refresh(item)

    note_title = note.title if note else None
    booking = None
    room = None
    if note:
        if note.booking_id:
            booking = (
                await db.execute(select(Booking).where(Booking.id == note.booking_id))
            ).scalar_one_or_none()
        if note.room_id:
            room = (
                await db.execute(select(Room).where(Room.id == note.room_id))
            ).scalar_one_or_none()

    await record_audit(
        db,
        user=current_user,
        action="update",
        module="followups",
        target_type="action_item",
        target_id=str(item.id),
        details={"status": item.status, "owner": item.owner},
    )
    await db.commit()

    return SuccessResponse(
        data=_item_response(
            item,
            note_title=note_title,
            booking_title=booking.title if booking else None,
            booking_id=booking.id if booking else None,
            meeting_date=note.date if note else None,
            room_name=room.name if room else None,
        )
    )
