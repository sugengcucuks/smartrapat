from fastapi import APIRouter, Depends, HTTPException, status, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, or_, not_
from typing import Optional, List
from uuid import UUID
from datetime import datetime, date
import math

from src.api.database import get_db
from src.api.models.user import User
from src.api.models.room import Room
from src.api.models.booking import Booking, BookingParticipant
from src.api.schemas.booking import (
    SuccessResponse,
    BookingCreate,
    BookingUpdate,
    BookingApprove,
    BookingResponse,
    BookingParticipantResponse,
    PaginatedBookingsResponse,
)
from src.api.models.system_setting import SystemSetting
from src.api.utils.auth import get_current_user
from src.api.utils.audit import record_audit
from src.api.utils.permissions import has_permission, require_permission
from src.api.utils.ticket import generate_ticket_code

router = APIRouter(prefix="/bookings", tags=["Bookings"])


# ============================================
# Helper Functions
# ============================================

async def _generate_unique_ticket(db: AsyncSession) -> str:
    """Buat kode tiket presensi yang belum dipakai peserta lain."""
    for _ in range(20):
        candidate = generate_ticket_code()
        existing = await db.execute(
            select(BookingParticipant.id).where(BookingParticipant.ticket_code == candidate)
        )
        if existing.scalar_one_or_none() is None:
            return candidate
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail="Gagal membuat kode tiket unik",
    )


async def _ensure_owner_or_approver_by_id(db: AsyncSession, user: User, booking_id: UUID) -> None:
    booking = (await db.execute(select(Booking).where(Booking.id == booking_id))).scalar_one_or_none()
    if booking is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Booking tidak ditemukan")
    _ensure_owner_or_approver(user, booking)


async def _check_conflict(
    db: AsyncSession,
    room_id: UUID,
    booking_date: date,
    start_time,
    end_time,
    exclude_booking_id: Optional[UUID] = None,
) -> Optional[Booking]:
    conditions = [
        Booking.room_id == room_id,
        Booking.date == booking_date,
        Booking.status.in_(["approved", "pending"]),
        start_time < Booking.end_time,
        end_time > Booking.start_time,
    ]
    if exclude_booking_id:
        conditions.append(Booking.id != exclude_booking_id)

    stmt = select(Booking).where(and_(*conditions)).limit(1)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def _build_booking_response(
    db: AsyncSession,
    booking: Booking,
    participants: Optional[List[BookingParticipant]] = None,
    viewer: Optional[User] = None,
) -> BookingResponse:
    # Kode tiket presensi hanya untuk pemilik booking / approver; peserta hanya
    # melihat tiketnya sendiri.
    show_all_tickets = viewer is None or booking.user_id == viewer.id or _is_approver(viewer)
    stmt_user = select(User).where(User.id == booking.user_id)
    user_result = await db.execute(stmt_user)
    user = user_result.scalar_one_or_none()

    stmt_room = select(Room).where(Room.id == booking.room_id)
    room_result = await db.execute(stmt_room)
    room = room_result.scalar_one_or_none()

    building_id = None
    building_name = None
    if room and room.building_id:
        building_id = room.building_id
        from src.api.models.room import Building
        stmt_building = select(Building).where(Building.id == room.building_id)
        building_result = await db.execute(stmt_building)
        building_obj = building_result.scalar_one_or_none()
        if building_obj:
            building_name = building_obj.name

    approver_name = None
    if booking.approved_by:
        stmt_approver = select(User).where(User.id == booking.approved_by)
        approver_result = await db.execute(stmt_approver)
        approver = approver_result.scalar_one_or_none()
        if approver:
            approver_name = approver.name

    if participants is None:
        stmt_p = select(BookingParticipant, User).outerjoin(
            User, BookingParticipant.user_id == User.id
        ).where(BookingParticipant.booking_id == booking.id)
        p_result = await db.execute(stmt_p)
        p_rows = p_result.all()
    else:
        p_rows = []
        for p in participants:
            u = None
            if p.user_id:
                stmt_u = select(User).where(User.id == p.user_id)
                u_result = await db.execute(stmt_u)
                u = u_result.scalar_one_or_none()
            p_rows.append((p, u))

    participant_responses = []
    for p, u in p_rows:
        participant_responses.append(
            BookingParticipantResponse(
                id=p.id,
                booking_id=p.booking_id,
                user_id=p.user_id,
                user_name=u.name if u else None,
                guest_name=p.guest_name,
                guest_email=p.guest_email,
                is_guest=p.is_guest,
                ticket_code=p.ticket_code if (show_all_tickets or (p.user_id and p.user_id == viewer.id)) else None,
                attended=p.attended,
                checked_in_at=p.checked_in_at,
                created_at=p.created_at,
            )
        )

    return BookingResponse(
        id=booking.id,
        user_id=booking.user_id,
        user_name=user.name if user else None,
        room_id=booking.room_id,
        room_name=room.name if room else None,
        building_id=building_id,
        building_name=building_name,
        title=booking.title,
        description=booking.description,
        date=booking.date,
        start_time=booking.start_time,
        end_time=booking.end_time,
        attendees=booking.attendees,
        status=booking.status,
        approval_notes=booking.approval_notes,
        created_by=booking.created_by,
        organizer_id=booking.user_id,
        organizer_name=user.name if user else None,
        approved_by=booking.approved_by,
        approved_by_name=approver_name,
        approved_at=booking.approved_at,
        created_at=booking.created_at,
        updated_at=booking.updated_at,
        participants=participant_responses,
        participant_count=len(participant_responses) or booking.attendees,
    )


# ============================================
# Otorisasi
# ============================================

def _forbidden(message: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail={"code": "FORBIDDEN", "message": message},
    )


def _is_approver(user: User) -> bool:
    return has_permission(user, "bookings.approve")


def _ensure_owner_or_approver(user: User, booking: Booking, extra_codes: tuple = ()) -> None:
    """Hanya pemilik booking atau pemegang bookings.approve (atau izin tambahan)."""
    if booking.user_id == user.id or has_permission(user, "bookings.approve", *extra_codes):
        return
    raise _forbidden("Hanya pemilik booking atau approver yang dapat melakukan aksi ini")


async def _get_setting(db: AsyncSession, key: str) -> Optional[str]:
    try:
        row = await db.execute(select(SystemSetting.setting_value).where(SystemSetting.setting_key == key))
        return row.scalar_one_or_none()
    except Exception:  # noqa: BLE001 - setting opsional
        return None


async def _resolve_create_status(db: AsyncSession, user: User, requested: Optional[str]) -> str:
    """Status booking baru ditentukan server, bukan klien.

    - "draft" boleh dipilih klien (simpan sebagai draf).
    - "approved" hanya bila pembuat punya bookings.approve, atau pengaturan sistem
      booking_default_status = approved / auto_approve_staff = true.
    - Selain itu -> "pending" (menunggu persetujuan).
    """
    if requested == "draft":
        return "draft"
    if requested == "approved" and _is_approver(user):
        return "approved"
    default_status = (await _get_setting(db, "booking_default_status") or "pending").strip().lower()
    auto_staff = (await _get_setting(db, "auto_approve_staff") or "false").strip().lower() == "true"
    if default_status == "approved" or auto_staff:
        return "approved"
    return "pending"


# ============================================
# Booking Endpoints
# ============================================

@router.get("", response_model=SuccessResponse)
async def list_bookings(
    date_from: Optional[date] = Query(None, description="Filter from date (inclusive)"),
    date_to: Optional[date] = Query(None, description="Filter to date (inclusive)"),
    status: Optional[str] = Query(None, description="Filter by status"),
    room_id: Optional[UUID] = Query(None, description="Filter by room ID"),
    user_id: Optional[UUID] = Query(None, description="Filter by user ID"),
    page: int = Query(1, ge=1, description="Page number"),
    per_page: int = Query(10, ge=1, le=100, description="Items per page"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    conditions = []

    if date_from:
        conditions.append(Booking.date >= date_from)
    if date_to:
        conditions.append(Booking.date <= date_to)
    if status:
        conditions.append(Booking.status == status)
    if room_id:
        conditions.append(Booking.room_id == room_id)
    if user_id:
        conditions.append(Booking.user_id == user_id)

    where_clause = and_(*conditions) if conditions else True

    count_stmt = select(func.count(Booking.id)).where(where_clause)
    total_result = await db.execute(count_stmt)
    total = total_result.scalar() or 0

    offset = (page - 1) * per_page
    stmt = (
        select(Booking)
        .where(where_clause)
        .order_by(Booking.date.desc(), Booking.start_time.desc())
        .offset(offset)
        .limit(per_page)
    )
    result = await db.execute(stmt)
    bookings = result.scalars().all()

    items = []
    for booking in bookings:
        items.append(await _build_booking_response(db, booking, viewer=current_user))

    total_pages = math.ceil(total / per_page) if per_page > 0 else 0

    return SuccessResponse(
        data=PaginatedBookingsResponse(
            items=items,
            total=total,
            page=page,
            per_page=per_page,
            total_pages=total_pages,
        )
    )


@router.get("/upcoming", response_model=SuccessResponse)
async def get_my_upcoming_bookings(
    limit: int = Query(10, ge=1, le=100, description="Maximum number of bookings"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    today = date.today()
    stmt = (
        select(Booking)
        .where(
            and_(
                Booking.user_id == current_user.id,
                Booking.date >= today,
                Booking.status.in_(["pending", "approved", "draft"]),
            )
        )
        .order_by(Booking.date.asc(), Booking.start_time.asc())
        .limit(limit)
    )
    result = await db.execute(stmt)
    bookings = result.scalars().all()

    items = []
    for booking in bookings:
        items.append(await _build_booking_response(db, booking, viewer=current_user))

    return SuccessResponse(data=items)


@router.post("", response_model=SuccessResponse)
async def create_booking(
    request: BookingCreate,
    http_request: Request,
    current_user: User = Depends(require_permission("bookings.create")),
    db: AsyncSession = Depends(get_db),
):
    if request.start_time >= request.end_time:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Waktu mulai harus lebih awal dari waktu selesai",
        )

    room_check = await db.execute(select(Room).where(Room.id == request.room_id))
    if not room_check.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Room ID tidak valid",
        )

    conflict = await _check_conflict(
        db,
        room_id=request.room_id,
        booking_date=request.date,
        start_time=request.start_time,
        end_time=request.end_time,
    )
    if conflict:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Ruangan sudah dibooking pada tanggal {request.date} jam {conflict.start_time} - {conflict.end_time}",
        )

    new_booking = Booking(
        user_id=current_user.id,
        room_id=request.room_id,
        title=request.title,
        description=request.description,
        date=request.date,
        start_time=request.start_time,
        end_time=request.end_time,
        attendees=request.attendees,
        status=await _resolve_create_status(db, current_user, request.status),
        created_by=current_user.id,
    )
    if new_booking.status == "approved":
        new_booking.approved_by = current_user.id
        new_booking.approved_at = datetime.now()

    db.add(new_booking)
    await db.flush()

    participant_objects = []
    for p in (request.participants or []):
        if p.is_guest and (not p.guest_name or not p.guest_email):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Guest participant harus memiliki guest_name dan guest_email",
            )
        if not p.is_guest and not p.user_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Non-guest participant harus memiliki user_id",
            )
        bp = BookingParticipant(
            booking_id=new_booking.id,
            user_id=None if p.is_guest else p.user_id,
            guest_name=p.guest_name if p.is_guest else None,
            guest_email=p.guest_email if p.is_guest else None,
            is_guest=p.is_guest,
            ticket_code=await _generate_unique_ticket(db),
        )
        db.add(bp)
        participant_objects.append(bp)

    await db.commit()
    await db.refresh(new_booking)

    booking_data = await _build_booking_response(db, new_booking, participant_objects, viewer=current_user)
    return SuccessResponse(data=booking_data)


@router.get("/{booking_id}", response_model=SuccessResponse)
async def get_booking(
    booking_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Booking).where(Booking.id == booking_id))
    booking = result.scalar_one_or_none()

    if not booking:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Booking tidak ditemukan",
        )

    booking_data = await _build_booking_response(db, booking, viewer=current_user)
    return SuccessResponse(data=booking_data)


@router.put("/{booking_id}", response_model=SuccessResponse)
async def update_booking(
    booking_id: UUID,
    request: BookingUpdate,
    http_request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Booking).where(Booking.id == booking_id))
    booking = result.scalar_one_or_none()

    if not booking:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Booking tidak ditemukan",
        )

    _ensure_owner_or_approver(current_user, booking)
    approver = _is_approver(current_user)
    if request.status is not None and request.status != booking.status and not approver:
        # Pemilik hanya boleh: draft -> pending (ajukan) atau membatalkan.
        allowed = request.status == "cancelled" or (request.status == "pending" and booking.status == "draft")
        if not allowed:
            raise _forbidden("Status booking hanya dapat diubah oleh approver")

    new_room_id = request.room_id if request.room_id is not None else booking.room_id
    new_date = request.date if request.date is not None else booking.date
    new_start = request.start_time if request.start_time is not None else booking.start_time
    new_end = request.end_time if request.end_time is not None else booking.end_time

    if new_start >= new_end:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Waktu mulai harus lebih awal dari waktu selesai",
        )

    room_changed = (
        request.room_id is not None or
        request.date is not None or
        request.start_time is not None or
        request.end_time is not None
    )

    if room_changed:
        if request.room_id is not None:
            room_check = await db.execute(select(Room).where(Room.id == request.room_id))
            if not room_check.scalar_one_or_none():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Room ID tidak valid",
                )

        conflict = await _check_conflict(
            db,
            room_id=new_room_id,
            booking_date=new_date,
            start_time=new_start,
            end_time=new_end,
            exclude_booking_id=booking_id,
        )
        if conflict:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Ruangan sudah dibooking pada tanggal {new_date} jam {conflict.start_time} - {conflict.end_time}",
            )

    if request.room_id is not None:
        booking.room_id = request.room_id
    if request.title is not None:
        booking.title = request.title
    if request.description is not None:
        booking.description = request.description
    if request.date is not None:
        booking.date = request.date
    if request.start_time is not None:
        booking.start_time = request.start_time
    if request.end_time is not None:
        booking.end_time = request.end_time
    if request.attendees is not None:
        booking.attendees = request.attendees
    if request.status is not None:
        booking.status = request.status
    elif room_changed and not approver and booking.status == "approved":
        # Jadwal/ruangan diubah pemilik -> perlu persetujuan ulang.
        booking.status = "pending"
        booking.approved_by = None
        booking.approved_at = None

    if request.participants is not None:
        await db.execute(
            BookingParticipant.__table__.delete().where(BookingParticipant.booking_id == booking_id)
        )
        for p in request.participants:
            if p.is_guest and (not p.guest_name or not p.guest_email):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Guest participant harus memiliki guest_name dan guest_email",
                )
            if not p.is_guest and not p.user_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Non-guest participant harus memiliki user_id",
                )
            bp = BookingParticipant(
                booking_id=booking.id,
                user_id=None if p.is_guest else p.user_id,
                guest_name=p.guest_name if p.is_guest else None,
                guest_email=p.guest_email if p.is_guest else None,
                is_guest=p.is_guest,
                ticket_code=await _generate_unique_ticket(db),
            )
            db.add(bp)

    await db.commit()
    await db.refresh(booking)

    booking_data = await _build_booking_response(db, booking, viewer=current_user)
    return SuccessResponse(data=booking_data)


@router.delete("/{booking_id}", response_model=SuccessResponse)
async def delete_booking(
    booking_id: UUID,
    http_request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Booking).where(Booking.id == booking_id))
    booking = result.scalar_one_or_none()

    if not booking:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Booking tidak ditemukan",
        )

    _ensure_owner_or_approver(current_user, booking, extra_codes=("bookings.delete",))
    await record_audit(
        db, current_user, "delete", "bookings", "booking", booking.id,
        {"title": booking.title, "date": str(booking.date)}, http_request,
    )
    await db.delete(booking)
    await db.commit()

    return SuccessResponse(data={"message": "Booking berhasil dihapus"})


@router.put("/{booking_id}/approve", response_model=SuccessResponse)
async def approve_booking(
    booking_id: UUID,
    request: BookingApprove,
    http_request: Request,
    current_user: User = Depends(require_permission("bookings.approve")),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Booking).where(Booking.id == booking_id))
    booking = result.scalar_one_or_none()

    if not booking:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Booking tidak ditemukan",
        )

    conflict = await _check_conflict(
        db, booking.room_id, booking.date, booking.start_time, booking.end_time,
        exclude_booking_id=booking.id,
    )
    if conflict is not None and conflict.status == "approved":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Sudah ada booking disetujui pada jam {conflict.start_time} - {conflict.end_time}",
        )
    old_status = booking.status
    booking.status = "approved"
    booking.approval_notes = request.approval_notes
    booking.approved_by = current_user.id
    booking.approved_at = datetime.now()
    await record_audit(
        db, current_user, "approve", "bookings", "booking", booking.id,
        {"status": "approved", "notes": request.approval_notes}, http_request,
        old_value={"status": old_status},
    )

    await db.commit()
    await db.refresh(booking)

    booking_data = await _build_booking_response(db, booking, viewer=current_user)
    return SuccessResponse(data=booking_data)


@router.put("/{booking_id}/reject", response_model=SuccessResponse)
async def reject_booking(
    booking_id: UUID,
    request: BookingApprove,
    http_request: Request,
    current_user: User = Depends(require_permission("bookings.approve")),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Booking).where(Booking.id == booking_id))
    booking = result.scalar_one_or_none()

    if not booking:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Booking tidak ditemukan",
        )

    old_status = booking.status
    booking.status = "rejected"
    booking.approval_notes = request.approval_notes
    booking.approved_by = current_user.id
    booking.approved_at = datetime.now()
    await record_audit(
        db, current_user, "reject", "bookings", "booking", booking.id,
        {"status": "rejected", "notes": request.approval_notes}, http_request,
        old_value={"status": old_status},
    )

    await db.commit()
    await db.refresh(booking)

    booking_data = await _build_booking_response(db, booking, viewer=current_user)
    return SuccessResponse(data=booking_data)


@router.put("/{booking_id}/cancel", response_model=SuccessResponse)
async def cancel_booking(
    booking_id: UUID,
    http_request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Booking).where(Booking.id == booking_id))
    booking = result.scalar_one_or_none()

    if not booking:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Booking tidak ditemukan",
        )

    _ensure_owner_or_approver(current_user, booking)
    old_status = booking.status
    booking.status = "cancelled"
    await record_audit(
        db, current_user, "cancel", "bookings", "booking", booking.id,
        {"status": "cancelled"}, http_request, old_value={"status": old_status},
    )

    await db.commit()
    await db.refresh(booking)

    booking_data = await _build_booking_response(db, booking, viewer=current_user)
    return SuccessResponse(data=booking_data)
