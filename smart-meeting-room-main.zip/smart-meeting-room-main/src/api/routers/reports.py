from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, cast, Date, Integer
from typing import Optional, List, Dict, Any
from uuid import UUID
from datetime import datetime, date, time, timedelta
import csv
import io
import logging

from src.api.database import get_db
from src.api.models.user import User, Role
from src.api.models.room import Room, Building
from src.api.models.booking import Booking, BookingParticipant
from src.api.models.equipment import Equipment
from src.api.models.device import Device
from src.api.schemas.report import (
    SuccessResponse,
    DashboardSummaryResponse,
    BookingPerStatusItem,
    BookingPerRoomItem,
    BookingPerDayItem,
    BookingsReportResponse,
    BookingsReportDownloadResponse,
    RoomUtilizationItem,
    AttendanceParticipantItem,
    AttendanceReportResponse,
    EquipmentInventoryItem,
    EquipmentInventoryResponse,
    ExportAllResponse,
)
from src.api.utils.auth import get_current_user
from src.api.utils.permissions import has_permission, require_permission
from src.api.utils.reports_generator import (
    generate_bookings_pdf,
    generate_bookings_xlsx,
    generate_equipment_pdf,
    generate_equipment_xlsx,
    safe_cell,
)

router = APIRouter(prefix="/reports", tags=["Reports"])
logger = logging.getLogger("smr.reports")


@router.get("/dashboard-summary", response_model=SuccessResponse)
async def get_dashboard_summary(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    today = date.today()
    now = datetime.now().time()

    rooms_count = await db.execute(select(func.count(Room.id)))
    total_rooms = rooms_count.scalar() or 0

    users_count = await db.execute(select(func.count(User.id)).where(User.status == "ACTIVE"))
    total_users = users_count.scalar() or 0

    bookings_today = await db.execute(
        select(func.count(Booking.id)).where(
            and_(Booking.date == today, Booking.status.in_(["approved", "pending", "completed"]))
        )
    )
    total_bookings_today = bookings_today.scalar() or 0

    ongoing_stmt = select(func.count(Booking.id)).where(
        and_(
            Booking.date == today,
            Booking.status == "approved",
            Booking.start_time <= now,
            Booking.end_time >= now,
        )
    )
    ongoing_result = await db.execute(ongoing_stmt)
    ongoing_meetings = ongoing_result.scalar() or 0

    devices_online_stmt = select(func.count(Device.id)).where(Device.status == "online")
    devices_online_result = await db.execute(devices_online_stmt)
    devices_online = devices_online_result.scalar() or 0

    pending_stmt = select(func.count(Booking.id)).where(Booking.status == "pending")
    pending_result = await db.execute(pending_stmt)
    pending_approvals = pending_result.scalar() or 0

    utilization_pct = 0.0
    avg_duration = 0.0
    if total_rooms > 0:
        week_ago = today - timedelta(days=7)
        # Durasi dihitung di Python: PostgreSQL tidak bisa meng-cast kolom TIME
        # langsung ke DATE, sehingga agregasi di SQL akan gagal.
        duration_stmt = select(Booking.start_time, Booking.end_time).where(
            and_(
                Booking.date >= week_ago,
                Booking.date <= today,
                Booking.status.in_(["approved", "completed"]),
            )
        )
        duration_result = await db.execute(duration_stmt)
        durations = duration_result.all()
        if durations:
            total_minutes = 0
            for st, et in durations:
                total_minutes += max(0, (et.hour * 60 + et.minute) - (st.hour * 60 + st.minute))
            total_booked_hours = total_minutes / 60.0
            total_available_hours = total_rooms * 7 * 10.0
            if total_available_hours > 0:
                utilization_pct = round((total_booked_hours / total_available_hours) * 100, 2)
            avg_duration = round(total_minutes / len(durations), 2)

    return SuccessResponse(
        data=DashboardSummaryResponse(
            total_rooms=total_rooms,
            total_users=total_users,
            today_bookings=total_bookings_today,
            ongoing_meetings=ongoing_meetings,
            online_devices=devices_online,
            pending_approvals=pending_approvals,
            room_utilization_percent=utilization_pct,
            avg_meeting_duration_minutes=avg_duration,
        )
    )


# ============================================
# Helper: rentang tanggal, pengumpulan data & streaming file
# ============================================

def _resolve_range(*pairs) -> tuple:
    """Terima beberapa nama parameter (from/to, from_date/to_date, date_from/date_to)."""
    start = next((a for a, _ in pairs if a), None)
    end = next((b for _, b in pairs if b), None)
    if start and end and start > end:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Tanggal mulai melewati tanggal akhir")
    return start, end


STATUS_LABEL = {
    "draft": "Draf",
    "pending": "Menunggu",
    "approved": "Disetujui",
    "rejected": "Ditolak",
    "cancelled": "Dibatalkan",
    "completed": "Selesai",
}

EQUIPMENT_STATUS_LABEL = {
    "active": "Aktif",
    "maintenance": "Pemeliharaan",
    "broken": "Rusak",
    "disposed": "Dihapus",
}

XLSX_MEDIA = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def _stream_file(buf: io.BytesIO, media_type: str, filename: str) -> StreamingResponse:
    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type=media_type,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Access-Control-Expose-Headers": "Content-Disposition",
            "Cache-Control": "no-store",
        },
    )


def _generation_failed(kind: str, exc: Exception) -> HTTPException:
    # Detail error hanya di log server, bukan di respons.
    logger.exception("Gagal membuat laporan %s", kind, exc_info=exc)
    return HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail=f"Gagal membuat file laporan {kind}. Hubungi administrator.",
    )


async def _collect_bookings(
    db: AsyncSession,
    from_date: Optional[date],
    to_date: Optional[date],
    status_filter: Optional[str] = None,
    room_id: Optional[UUID] = None,
    limit: int = 5000,
) -> tuple:
    conditions = []
    if from_date:
        conditions.append(Booking.date >= from_date)
    if to_date:
        conditions.append(Booking.date <= to_date)
    if status_filter:
        conditions.append(Booking.status == status_filter)
    if room_id:
        conditions.append(Booking.room_id == room_id)
    where_clause = and_(*conditions) if conditions else True

    participant_counts = (
        select(BookingParticipant.booking_id, func.count(BookingParticipant.id).label("cnt"))
        .group_by(BookingParticipant.booking_id)
        .subquery()
    )
    stmt = (
        select(
            Booking.id, Booking.title, Booking.date, Booking.start_time, Booking.end_time,
            Booking.status, Booking.user_id, Booking.attendees,
            Room.name.label("room_name"), Room.code.label("room_code"),
            Building.name.label("building_name"),
            User.name.label("organizer_name"),
            participant_counts.c.cnt.label("participant_count"),
        )
        .outerjoin(Room, Booking.room_id == Room.id)
        .outerjoin(Building, Room.building_id == Building.id)
        .outerjoin(User, Booking.user_id == User.id)
        .outerjoin(participant_counts, participant_counts.c.booking_id == Booking.id)
        .where(where_clause)
        .order_by(Booking.date.desc(), Booking.start_time.desc())
        .limit(limit)
    )
    rows = (await db.execute(stmt)).all()

    bookings_list: List[Dict[str, Any]] = []
    by_status: Dict[str, int] = {}
    total_minutes = 0
    total_participants = 0
    for row in rows:
        start_dt = datetime.combine(row.date or date.today(), row.start_time or time.min)
        end_dt = datetime.combine(row.date or date.today(), row.end_time or time.min)
        duration_min = max(0, int((end_dt - start_dt).total_seconds() / 60))
        pcount = int(row.participant_count or 0) or int(row.attendees or 0)
        total_minutes += duration_min
        total_participants += pcount
        by_status[row.status or "unknown"] = by_status.get(row.status or "unknown", 0) + 1
        bookings_list.append({
            "id": str(row.id),
            "date": str(row.date),
            "title": row.title or "-",
            "room_name": row.room_name or "-",
            "room_code": row.room_code or "-",
            "building_name": row.building_name or "-",
            "organizer_id": str(row.user_id) if row.user_id else None,
            "organizer_name": row.organizer_name or "-",
            "start_time": row.start_time.strftime("%H:%M") if row.start_time else "-",
            "end_time": row.end_time.strftime("%H:%M") if row.end_time else "-",
            "duration_minutes": duration_min,
            "participant_count": pcount,
            "status": row.status or "-",
            "status_label": STATUS_LABEL.get(row.status or "", row.status or "-"),
        })

    summary = {
        "total_bookings": len(bookings_list),
        "total_duration_minutes": total_minutes,
        "total_participants": total_participants,
        "by_status": by_status,
        "period_from": str(from_date) if from_date else None,
        "period_to": str(to_date) if to_date else None,
        "generated_at": datetime.now().isoformat(),
    }
    return bookings_list, summary


async def _collect_equipment(db: AsyncSession) -> tuple:
    eq_stmt = (
        select(
            Equipment.id, Equipment.name, Equipment.code, Equipment.category,
            Equipment.status, Equipment.brand, Equipment.model, Equipment.serial_number,
            Equipment.purchase_date, Equipment.location_id, Equipment.notes,
            Room.name.label("room_name"), Room.code.label("room_code"),
        )
        .outerjoin(Room, Equipment.location_id == Room.id)
        .order_by(Equipment.category.asc(), Equipment.name.asc())
    )
    eq_rows = (await db.execute(eq_stmt)).all()

    equipment_list: List[Dict[str, Any]] = []
    by_cat: Dict[str, Dict[str, Any]] = {}
    for row in eq_rows:
        cat = row.category or "other"
        equipment_list.append({
            "id": str(row.id),
            "code": row.code or "-",
            "name": row.name or "-",
            "category": cat,
            "status": EQUIPMENT_STATUS_LABEL.get(row.status or "", row.status or "-"),
            "status_raw": row.status,
            "brand": row.brand or "-",
            "model": row.model or "-",
            "serial_number": row.serial_number or "-",
            "purchase_date": str(row.purchase_date) if row.purchase_date else "-",
            "room_id": str(row.location_id) if row.location_id else None,
            "room_name": row.room_name or "-",
            "room_code": row.room_code or "-",
            "notes": row.notes or "-",
        })
        c = by_cat.setdefault(cat, {"category": cat, "total": 0, "active": 0, "maintenance": 0, "broken": 0, "damaged": 0, "disposed": 0})
        c["total"] += 1
        st = row.status or ""
        if st in c:
            c[st] += 1
        if st == "broken":
            c["damaged"] += 1
    return equipment_list, list(by_cat.values())


async def _bookings_file(db, fmt, from_date, to_date, status_filter=None, room_id=None) -> StreamingResponse:
    bookings_list, summary = await _collect_bookings(db, from_date, to_date, status_filter, room_id)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    if fmt == "pdf":
        try:
            buf = generate_bookings_pdf(bookings_list, summary, from_date, to_date)
        except Exception as e:  # noqa: BLE001
            raise _generation_failed("PDF", e)
        return _stream_file(buf, "application/pdf", f"laporan_booking_{ts}.pdf")
    if fmt == "csv":
        return _stream_file(_bookings_csv(bookings_list), "text/csv; charset=utf-8", f"laporan_booking_{ts}.csv")
    try:
        buf = generate_bookings_xlsx(bookings_list, summary, from_date, to_date)
    except Exception as e:  # noqa: BLE001
        raise _generation_failed("Excel", e)
    return _stream_file(buf, XLSX_MEDIA, f"laporan_booking_{ts}.xlsx")


def _bookings_csv(bookings_list: List[Dict[str, Any]]) -> io.BytesIO:
    out = io.StringIO()
    cols = ["date", "title", "room_name", "building_name", "organizer_name",
            "start_time", "end_time", "duration_minutes", "participant_count", "status_label"]
    writer = csv.writer(out)
    writer.writerow(["Tanggal", "Judul", "Ruangan", "Gedung", "Penyelenggara",
                     "Mulai", "Selesai", "Durasi (mnt)", "Peserta", "Status"])
    for b in bookings_list:
        writer.writerow([safe_cell(b.get(c, "")) for c in cols])
    return io.BytesIO(("﻿" + out.getvalue()).encode("utf-8"))


async def _equipment_file(db, fmt) -> StreamingResponse:
    equipment_list, summary_by_category = await _collect_equipment(db)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    if fmt == "pdf":
        try:
            buf = generate_equipment_pdf(equipment_list, summary_by_category)
        except Exception as e:  # noqa: BLE001
            raise _generation_failed("PDF", e)
        return _stream_file(buf, "application/pdf", f"laporan_inventori_alat_{ts}.pdf")
    try:
        buf = generate_equipment_xlsx(equipment_list, summary_by_category)
    except Exception as e:  # noqa: BLE001
        raise _generation_failed("Excel", e)
    return _stream_file(buf, XLSX_MEDIA, f"laporan_inventori_alat_{ts}.xlsx")


# ============================================
# Download laporan (file asli)
# ============================================

@router.get("/bookings/download")
async def download_bookings_report(
    format: str = Query("pdf", pattern="^(pdf|xlsx|csv)$", description="Format output: pdf, xlsx atau csv"),
    from_date: Optional[date] = Query(None, alias="from", description="Tanggal mulai (YYYY-MM-DD)"),
    to_date: Optional[date] = Query(None, alias="to", description="Tanggal akhir (YYYY-MM-DD)"),
    date_from: Optional[date] = Query(None, description="Alias tanggal mulai"),
    date_to: Optional[date] = Query(None, description="Alias tanggal akhir"),
    status_filter: Optional[str] = Query(None, alias="status"),
    room_id: Optional[UUID] = Query(None),
    current_user: User = Depends(require_permission("reports.export")),
    db: AsyncSession = Depends(get_db),
):
    start, end = _resolve_range((from_date, to_date), (date_from, date_to))
    return await _bookings_file(db, format, start, end, status_filter, room_id)


@router.get("/equipment/download")
async def download_equipment_report(
    format: str = Query("pdf", pattern="^(pdf|xlsx)$", description="Format output: pdf atau xlsx"),
    current_user: User = Depends(require_permission("reports.export")),
    db: AsyncSession = Depends(get_db),
):
    return await _equipment_file(db, format)


@router.get("/bookings")
async def get_bookings_report(
    from_q: Optional[date] = Query(None, alias="from", description="Start date"),
    to_q: Optional[date] = Query(None, alias="to", description="End date"),
    from_date: Optional[date] = Query(None, description="Start date"),
    to_date: Optional[date] = Query(None, description="End date"),
    date_from: Optional[date] = Query(None, description="Alias start date"),
    date_to: Optional[date] = Query(None, description="Alias end date"),
    status_filter: Optional[str] = Query(None, alias="status"),
    room_id: Optional[UUID] = Query(None),
    format: str = Query("json", pattern="^(json|xlsx|pdf|csv)$", description="Output format"),
    current_user: User = Depends(require_permission("reports.view")),
    db: AsyncSession = Depends(get_db),
):
    start, end = _resolve_range((from_q, to_q), (from_date, to_date), (date_from, date_to))
    if format != "json":
        if not has_permission(current_user, "reports.export"):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={"code": "FORBIDDEN", "message": "Anda tidak memiliki izin export laporan"},
            )
        return await _bookings_file(db, format, start, end, status_filter, room_id)

    conditions = []
    if start:
        conditions.append(Booking.date >= start)
    if end:
        conditions.append(Booking.date <= end)
    if status_filter:
        conditions.append(Booking.status == status_filter)
    if room_id:
        conditions.append(Booking.room_id == room_id)
    where_clause = and_(*conditions) if conditions else True

    total_stmt = select(func.count(Booking.id)).where(where_clause)
    total_result = await db.execute(total_stmt)
    total_bookings = total_result.scalar() or 0

    per_status_stmt = (
        select(Booking.status, func.count(Booking.id))
        .where(where_clause)
        .group_by(Booking.status)
    )
    per_status_result = await db.execute(per_status_stmt)
    per_status = [
        BookingPerStatusItem(status=s or "unknown", count=c)
        for s, c in per_status_result.all()
    ]

    per_room_stmt = (
        select(Booking.room_id, Room.name, func.count(Booking.id))
        .join(Room, Booking.room_id == Room.id)
        .where(where_clause)
        .group_by(Booking.room_id, Room.name)
    )
    per_room_result = await db.execute(per_room_stmt)
    per_room = [
        BookingPerRoomItem(room_id=rid, room_name=rname, count=c)
        for rid, rname, c in per_room_result.all()
    ]

    per_day_stmt = (
        select(Booking.date, func.count(Booking.id))
        .where(where_clause)
        .group_by(Booking.date)
        .order_by(Booking.date)
    )
    per_day_result = await db.execute(per_day_stmt)
    per_day = [
        BookingPerDayItem(date=d, count=c) for d, c in per_day_result.all()
    ]

    return SuccessResponse(
        data=BookingsReportResponse(
            total_bookings=total_bookings,
            per_status=per_status,
            per_room=per_room,
            per_day=per_day,
            from_date=start,
            to_date=end,
        )
    )


@router.get("/rooms/utilization", response_model=SuccessResponse)
async def get_rooms_utilization(
    from_date: Optional[date] = Query(None, description="Start date"),
    to_date: Optional[date] = Query(None, description="End date"),
    room_id: Optional[UUID] = Query(None, description="Filter by specific room ID"),
    date_from: Optional[date] = Query(None, description="Alias start date"),
    date_to: Optional[date] = Query(None, description="Alias end date"),
    current_user: User = Depends(require_permission("reports.view")),
    db: AsyncSession = Depends(get_db),
):
    from_date, to_date = _resolve_range((from_date, to_date), (date_from, date_to))
    today = date.today()
    if not from_date:
        from_date = today - timedelta(days=30)
    if not to_date:
        to_date = today
    if from_date > to_date:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Tanggal mulai melewati tanggal akhir")

    rooms_conditions = []
    if room_id:
        rooms_conditions.append(Room.id == room_id)
    rooms_stmt = select(Room).where(and_(*rooms_conditions) if rooms_conditions else True)
    rooms_result = await db.execute(rooms_stmt)
    rooms = rooms_result.scalars().all()

    days_diff = (to_date - from_date).days + 1
    working_hours_per_day = 10

    items = []
    for room in rooms:
        total_hours_available = days_diff * working_hours_per_day

        bookings_stmt = (
            select(Booking.start_time, Booking.end_time)
            .where(
                and_(
                    Booking.room_id == room.id,
                    Booking.date >= from_date,
                    Booking.date <= to_date,
                    Booking.status.in_(["approved", "completed"]),
                )
            )
        )
        bookings_result = await db.execute(bookings_stmt)
        bookings_rows = bookings_result.all()

        total_hours_booked = 0.0
        for st, et in bookings_rows:
            total_hours_booked += max(0, (et.hour * 60 + et.minute) - (st.hour * 60 + st.minute)) / 60.0

        utilization_pct = 0.0
        if total_hours_available > 0:
            utilization_pct = round((total_hours_booked / total_hours_available) * 100, 2)

        booking_count_stmt = select(func.count(Booking.id)).where(
            and_(
                Booking.room_id == room.id,
                Booking.date >= from_date,
                Booking.date <= to_date,
            )
        )
        bc_result = await db.execute(booking_count_stmt)
        booking_count = bc_result.scalar() or 0

        items.append(
            RoomUtilizationItem(
                room_id=room.id,
                room_name=room.name,
                total_hours_available=round(total_hours_available, 2),
                total_hours_booked=round(total_hours_booked, 2),
                utilization_percent=utilization_pct,
                booking_count=booking_count,
            )
        )

    return SuccessResponse(data=items)


@router.get("/rooms-utilization", response_model=SuccessResponse)
async def get_rooms_utilization_frontend_alias(
    from_date: Optional[date] = Query(None, description="Start date"),
    to_date: Optional[date] = Query(None, description="End date"),
    room_id: Optional[UUID] = Query(None, description="Filter by specific room ID"),
    date_from: Optional[date] = Query(None, description="Alias start date"),
    date_to: Optional[date] = Query(None, description="Alias end date"),
    current_user: User = Depends(require_permission("reports.view")),
    db: AsyncSession = Depends(get_db),
):
    return await get_rooms_utilization(from_date, to_date, room_id, date_from, date_to, current_user, db)


@router.get("/equipment-inventory", response_model=SuccessResponse)
async def get_equipment_inventory_frontend_alias(
    current_user: User = Depends(require_permission("reports.view")),
    db: AsyncSession = Depends(get_db),
):
    return await get_equipment_inventory(current_user, db)


@router.get("/export")
async def export_report(
    format: str = Query("xlsx", pattern="^(json|xlsx|pdf|csv)$", description="Format export"),
    report_type: str = Query("bookings", pattern="^(bookings|equipment|all)$"),
    from_q: Optional[date] = Query(None, alias="from"),
    to_q: Optional[date] = Query(None, alias="to"),
    date_from: Optional[date] = Query(None),
    date_to: Optional[date] = Query(None),
    current_user: User = Depends(require_permission("reports.export")),
    db: AsyncSession = Depends(get_db),
):
    """Export laporan sebagai file (xlsx/pdf/csv) atau JSON baris data."""
    start, end = _resolve_range((from_q, to_q), (date_from, date_to))
    if format == "json":
        data: Dict[str, Any] = {"generated_at": datetime.now().isoformat()}
        if report_type in ("bookings", "all"):
            rows, summary = await _collect_bookings(db, start, end)
            data["bookings"] = rows
            data["bookings_summary"] = summary
        if report_type in ("equipment", "all"):
            rows, summary = await _collect_equipment(db)
            data["equipment"] = rows
            data["equipment_summary"] = summary
        return SuccessResponse(data=data)
    if report_type == "equipment":
        if format == "csv":
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Format csv hanya untuk laporan booking")
        return await _equipment_file(db, format)
    if report_type == "all" and format == "xlsx":
        return await _export_all_xlsx(db, start, end)
    return await _bookings_file(db, format, start, end)


async def _export_all_xlsx(db: AsyncSession, start: Optional[date], end: Optional[date]) -> StreamingResponse:
    from openpyxl import Workbook

    bookings_list, _ = await _collect_bookings(db, start, end)
    equipment_list, _ = await _collect_equipment(db)
    wb = Workbook()
    ws = wb.active
    ws.title = "Pemesanan"
    bcols = ["date", "title", "room_name", "building_name", "organizer_name",
             "start_time", "end_time", "duration_minutes", "participant_count", "status_label"]
    ws.append(["Tanggal", "Judul", "Ruangan", "Gedung", "Penyelenggara", "Mulai", "Selesai",
               "Durasi (mnt)", "Peserta", "Status"])
    for b in bookings_list:
        ws.append([safe_cell(b.get(c, "")) for c in bcols])
    ws2 = wb.create_sheet("Perangkat")
    ecols = ["code", "name", "category", "brand", "model", "serial_number", "room_name", "status", "purchase_date"]
    ws2.append(["Kode", "Nama", "Kategori", "Merek", "Model", "No. Seri", "Ruangan", "Status", "Tanggal Beli"])
    for e in equipment_list:
        ws2.append([safe_cell(e.get(c, "")) for c in ecols])
    buf = io.BytesIO()
    try:
        wb.save(buf)
    except Exception as e:  # noqa: BLE001
        raise _generation_failed("Excel", e)
    return _stream_file(buf, XLSX_MEDIA, f"export_smr_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx")


@router.get("/attendance", response_model=SuccessResponse)
async def get_attendance_report(
    booking_id: Optional[UUID] = Query(None, description="Booking ID (detail satu rapat)"),
    date_from: Optional[date] = Query(None),
    date_to: Optional[date] = Query(None),
    from_date: Optional[date] = Query(None),
    to_date: Optional[date] = Query(None),
    room_id: Optional[UUID] = Query(None),
    current_user: User = Depends(require_permission("reports.view")),
    db: AsyncSession = Depends(get_db),
):
    if booking_id is None:
        return await _attendance_summary(db, *_resolve_range((date_from, date_to), (from_date, to_date)), room_id)

    booking_stmt = select(Booking).where(Booking.id == booking_id)
    booking_result = await db.execute(booking_stmt)
    booking = booking_result.scalar_one_or_none()

    if not booking:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Booking tidak ditemukan",
        )

    participants_stmt = (
        select(BookingParticipant, User)
        .outerjoin(User, BookingParticipant.user_id == User.id)
        .where(BookingParticipant.booking_id == booking_id)
    )
    participants_result = await db.execute(participants_stmt)
    p_rows = participants_result.all()

    participants = []
    attended_count = 0
    for bp, user in p_rows:
        name = user.name if user else (bp.guest_name or "Guest")
        email = user.email if user else bp.guest_email
        if bp.attended:
            attended_count += 1
        participants.append(
            AttendanceParticipantItem(
                participant_id=bp.id,
                user_id=bp.user_id,
                name=name,
                email=email,
                is_guest=bp.is_guest,
                attended=bp.attended,
                checked_in_at=bp.checked_in_at,
            )
        )

    total = len(participants)
    return SuccessResponse(
        data=AttendanceReportResponse(
            booking_id=booking.id,
            booking_title=booking.title,
            date=booking.date,
            start_time=booking.start_time,
            end_time=booking.end_time,
            total_participants=total,
            attended_count=attended_count,
            absent_count=total - attended_count,
            participants=participants,
        )
    )


async def _attendance_summary(db: AsyncSession, start: Optional[date], end: Optional[date], room_id: Optional[UUID]):
    """Ringkasan kehadiran per rapat (format yang dipakai halaman Laporan)."""
    today = date.today()
    start = start or (today - timedelta(days=30))
    end = end or today
    conditions = [Booking.date >= start, Booking.date <= end, Booking.status.in_(["approved", "completed"])]
    if room_id:
        conditions.append(Booking.room_id == room_id)
    stmt = (
        select(
            Booking.id, Booking.title, Booking.date, Room.name.label("room_name"), User.name.label("organizer_name"),
            func.count(BookingParticipant.id).label("total"),
            func.coalesce(func.sum(cast(BookingParticipant.attended, Integer)), 0).label("present"),
        )
        .outerjoin(Room, Booking.room_id == Room.id)
        .outerjoin(User, Booking.user_id == User.id)
        .outerjoin(BookingParticipant, BookingParticipant.booking_id == Booking.id)
        .where(and_(*conditions))
        .group_by(Booking.id, Booking.title, Booking.date, Room.name, User.name)
        .order_by(Booking.date.desc())
        .limit(500)
    )
    items = []
    for r in (await db.execute(stmt)).all():
        total = int(r.total or 0)
        present = int(r.present or 0)
        items.append({
            "meeting_id": str(r.id),
            "meeting_title": r.title,
            "date": str(r.date),
            "room_name": r.room_name or "-",
            "organizer_name": r.organizer_name or "-",
            "total_participants": total,
            "present_count": present,
            "absent_count": total - present,
            "attendance_percent": round(present / total * 100, 1) if total else 0.0,
        })
    return SuccessResponse(data={"items": items, "total": len(items)})


@router.get("/equipment/inventory", response_model=SuccessResponse)
async def get_equipment_inventory(
    current_user: User = Depends(require_permission("reports.view")),
    db: AsyncSession = Depends(get_db),
):
    categories_stmt = (
        select(
            Equipment.category,
            func.count(Equipment.id),
            func.sum(func.cast((Equipment.status == "active"), Integer)),
            func.sum(func.cast((Equipment.status == "maintenance"), Integer)),
            func.sum(func.cast((Equipment.status == "broken"), Integer)),
            func.sum(func.cast((Equipment.status == "disposed"), Integer)),
        )
        .group_by(Equipment.category)
    )
    categories_result = await db.execute(categories_stmt)
    rows = categories_result.all()

    items = []
    grand_total = 0
    for cat, total, active, maint, broken, disposed in rows:
        total_i = total or 0
        grand_total += total_i
        items.append(
            EquipmentInventoryItem(
                category=cat or "other",
                total=total_i,
                active=active or 0,
                maintenance=maint or 0,
                broken=broken or 0,
                disposed=disposed or 0,
            )
        )

    return SuccessResponse(
        data=EquipmentInventoryResponse(items=items, grand_total=grand_total)
    )


@router.get("/export/all")
async def export_all_data(
    format: str = Query("xlsx", pattern="^(xlsx|csv|json)$", description="Export format"),
    current_user: User = Depends(require_permission("reports.export")),
    db: AsyncSession = Depends(get_db),
):
    if format == "xlsx":
        return await _export_all_xlsx(db, None, None)
    if format == "json":
        return await export_report(format="json", report_type="all", from_q=None, to_q=None,
                                   date_from=None, date_to=None, current_user=current_user, db=db)
    return await _bookings_file(db, "csv", None, None)
