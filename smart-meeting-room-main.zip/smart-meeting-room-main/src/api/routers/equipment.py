from fastapi import APIRouter, Depends, HTTPException, status, Query, Body
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_, and_
from typing import Optional, Dict, Any
from uuid import UUID
import math

from src.api.database import get_db
from src.api.models.user import User
from src.api.models.room import Room
from src.api.models.equipment import Equipment
from src.api.schemas.equipment import (
    SuccessResponse,
    EquipmentCreate,
    EquipmentUpdate,
    EquipmentAssignRoom,
    EquipmentResponse,
    PaginatedEquipmentResponse,
)
from src.api.utils.auth import get_current_user
from src.api.utils.permissions import require_permission

router = APIRouter(prefix="/equipment", tags=["Equipment"])


async def _get_equipment_with_room(db: AsyncSession, eq_id: UUID) -> Optional[EquipmentResponse]:
    stmt = (
        select(Equipment, Room)
        .outerjoin(Room, Equipment.location_id == Room.id)
        .where(Equipment.id == eq_id)
    )
    result = await db.execute(stmt)
    row = result.first()
    if not row:
        return None
    eq, room = row
    return EquipmentResponse(
        id=eq.id,
        name=eq.name,
        code=eq.code,
        category=eq.category,
        brand=eq.brand,
        model=eq.model,
        serial_number=eq.serial_number,
        purchase_date=eq.purchase_date,
        warranty_until=eq.warranty_until,
        status=eq.status,
        notes=eq.notes,
        location_id=eq.location_id,
        room_name=room.name if room else None,
        created_at=eq.created_at,
        updated_at=eq.updated_at,
    )


@router.get("", response_model=SuccessResponse)
async def list_equipment(
    search: Optional[str] = Query(None, description="Search by name, code, brand"),
    category: Optional[str] = Query(None, description="Filter by category: display/audio/input/network/camera/other"),
    status: Optional[str] = Query(None, description="Filter by status: active/maintenance/broken/disposed"),
    room_id: Optional[UUID] = Query(None, description="Filter by room ID"),
    page: int = Query(1, ge=1, description="Page number"),
    per_page: int = Query(10, ge=1, le=100, description="Items per page"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    conditions = []

    if search:
        search_pattern = f"%{search}%"
        conditions.append(
            or_(
                Equipment.name.ilike(search_pattern),
                Equipment.code.ilike(search_pattern),
                Equipment.brand.ilike(search_pattern),
                Equipment.model.ilike(search_pattern),
            )
        )

    if category:
        conditions.append(Equipment.category == category)
    if status:
        conditions.append(Equipment.status == status)
    if room_id:
        conditions.append(Equipment.location_id == room_id)

    where_clause = and_(*conditions) if conditions else True

    count_stmt = select(func.count(Equipment.id)).where(where_clause)
    total_result = await db.execute(count_stmt)
    total = total_result.scalar() or 0

    offset = (page - 1) * per_page
    stmt = (
        select(Equipment, Room)
        .outerjoin(Room, Equipment.location_id == Room.id)
        .where(where_clause)
        .order_by(Equipment.created_at.desc())
        .offset(offset)
        .limit(per_page)
    )
    result = await db.execute(stmt)
    rows = result.all()

    items = []
    for eq, room in rows:
        items.append(
            EquipmentResponse(
                id=eq.id,
                name=eq.name,
                code=eq.code,
                category=eq.category,
                brand=eq.brand,
                model=eq.model,
                serial_number=eq.serial_number,
                purchase_date=eq.purchase_date,
                warranty_until=eq.warranty_until,
                status=eq.status,
                notes=eq.notes,
                location_id=eq.location_id,
                room_name=room.name if room else None,
                created_at=eq.created_at,
                updated_at=eq.updated_at,
            )
        )

    total_pages = math.ceil(total / per_page) if per_page > 0 else 0

    return SuccessResponse(
        data=PaginatedEquipmentResponse(
            items=items,
            total=total,
            page=page,
            per_page=per_page,
            total_pages=total_pages,
        )
    )


@router.post("", response_model=SuccessResponse)
async def create_equipment(
    request: EquipmentCreate,
    current_user: User = Depends(require_permission("devices.write")),
    db: AsyncSession = Depends(get_db),
):
    existing_code = await db.execute(select(Equipment).where(Equipment.code == request.code))
    if existing_code.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Kode equipment sudah digunakan",
        )

    if request.location_id:
        room_check = await db.execute(select(Room).where(Room.id == request.location_id))
        if not room_check.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Room ID tidak valid",
            )

    new_eq = Equipment(
        name=request.name,
        code=request.code,
        category=request.category,
        brand=request.brand,
        model=request.model,
        serial_number=request.serial_number,
        purchase_date=request.purchase_date,
        warranty_until=request.warranty_until,
        status=request.status,
        notes=request.notes,
        location_id=request.location_id,
    )

    db.add(new_eq)
    await db.commit()
    await db.refresh(new_eq)

    eq_data = await _get_equipment_with_room(db, new_eq.id)
    return SuccessResponse(data=eq_data)


@router.get("/{equipment_id}", response_model=SuccessResponse)
async def get_equipment(
    equipment_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    eq_data = await _get_equipment_with_room(db, equipment_id)
    if not eq_data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Equipment tidak ditemukan",
        )
    return SuccessResponse(data=eq_data)


@router.put("/{equipment_id}", response_model=SuccessResponse)
async def update_equipment(
    equipment_id: UUID,
    request: EquipmentUpdate,
    current_user: User = Depends(require_permission("devices.write")),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Equipment).where(Equipment.id == equipment_id))
    eq = result.scalar_one_or_none()
    if not eq:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Equipment tidak ditemukan",
        )

    if request.code and request.code != eq.code:
        existing_code = await db.execute(select(Equipment).where(Equipment.code == request.code))
        if existing_code.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Kode equipment sudah digunakan",
            )
        eq.code = request.code

    if request.location_id is not None:
        if request.location_id:
            room_check = await db.execute(select(Room).where(Room.id == request.location_id))
            if not room_check.scalar_one_or_none():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Room ID tidak valid",
                )
        eq.location_id = request.location_id

    if request.name is not None:
        eq.name = request.name
    if request.category is not None:
        eq.category = request.category
    if request.brand is not None:
        eq.brand = request.brand
    if request.model is not None:
        eq.model = request.model
    if request.serial_number is not None:
        eq.serial_number = request.serial_number
    if request.purchase_date is not None:
        eq.purchase_date = request.purchase_date
    if request.warranty_until is not None:
        eq.warranty_until = request.warranty_until
    if request.status is not None:
        eq.status = request.status
    if request.notes is not None:
        eq.notes = request.notes

    await db.commit()
    await db.refresh(eq)

    eq_data = await _get_equipment_with_room(db, equipment_id)
    return SuccessResponse(data=eq_data)


@router.put("/{equipment_id}/assign-room", response_model=SuccessResponse)
async def assign_equipment_room(
    equipment_id: UUID,
    request: EquipmentAssignRoom = Body(...),
    current_user: User = Depends(require_permission("devices.write")),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Equipment).where(Equipment.id == equipment_id))
    eq = result.scalar_one_or_none()
    if not eq:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Equipment tidak ditemukan",
        )

    if request.location_id is not None:
        if request.location_id:
            room_check = await db.execute(select(Room).where(Room.id == request.location_id))
            if not room_check.scalar_one_or_none():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Room ID tidak valid",
                )
        eq.location_id = request.location_id
    else:
        eq.location_id = None

    await db.commit()
    await db.refresh(eq)

    eq_data = await _get_equipment_with_room(db, equipment_id)
    return SuccessResponse(data=eq_data)


@router.put("/{equipment_id}/assign", response_model=SuccessResponse)
async def assign_equipment_room_frontend_alias(
    equipment_id: UUID,
    request: Dict[str, Any] = Body(...),
    current_user: User = Depends(require_permission("devices.write")),
    db: AsyncSession = Depends(get_db),
):
    loc_id: Optional[UUID] = None
    if "location_id" in request:
        loc_id = request.get("location_id")
    elif "room_id" in request:
        loc_id = request.get("room_id")

    result = await db.execute(select(Equipment).where(Equipment.id == equipment_id))
    eq = result.scalar_one_or_none()
    if not eq:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Equipment tidak ditemukan",
        )

    if loc_id is not None and loc_id != Ellipsis:
        if loc_id:
            room_check = await db.execute(select(Room).where(Room.id == loc_id))
            if not room_check.scalar_one_or_none():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Room ID tidak valid",
                )
            eq.location_id = loc_id
        else:
            eq.location_id = None

    await db.commit()
    await db.refresh(eq)

    eq_data = await _get_equipment_with_room(db, equipment_id)
    return SuccessResponse(data=eq_data)


@router.delete("/{equipment_id}", response_model=SuccessResponse)
async def delete_equipment(
    equipment_id: UUID,
    current_user: User = Depends(require_permission("devices.write")),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Equipment).where(Equipment.id == equipment_id))
    eq = result.scalar_one_or_none()
    if not eq:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Equipment tidak ditemukan",
        )

    await db.delete(eq)
    await db.commit()

    return SuccessResponse(data={"message": "Equipment berhasil dihapus"})
