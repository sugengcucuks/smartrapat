"""Pencarian lintas rapat (Full-Text Search Postgres).

Mencari satu kata kunci ke seluruh arsip rapat:
- Notulen   : judul + ringkasan (+ keputusan via fallback ILIKE),
- Transkrip : isi percatatan speaker (indeks GIN, migration 019),
- Tindak Lanjut: task/owner action item.

Hasil diberi sorotan (`ts_headline`) berupa <mark>...</mark> agar FE
tinggal merender. Konfigurasi 'simple' konsisten dengan migration 019.

Hak akses: izin `notes.view`.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.database import get_db
from src.api.models.user import User
from src.api.schemas.search import (
    SearchActionItem,
    SearchCounts,
    SearchNoteItem,
    SearchResponse,
    SearchTranscriptItem,
)
from src.api.schemas.user import SuccessResponse
from src.api.utils.permissions import require_permission

router = APIRouter(prefix="/search", tags=["Pencarian"])

# Sorotan headline: maks 2 fragmen per dokumen.
_HEADLINE_OPTS = "StartSel=<mark>,StopSel=</mark>,MaxFragments=2,MaxWords=40,MinWords=15,FragmentDelimiter= … "

_NOTES_SQL = text(
    """
    SELECT n.id, n.id AS note_id, n.booking_id, n.title, n.date,
           to_char(n.start_time, 'HH24:MI') AS start_time,
           to_char(n.end_time, 'HH24:MI') AS end_time,
           b.title AS booking_title,
           ts_headline('simple',
               coalesce(n.title, '') || ' ' || coalesce(n.summary, ''),
               q, :headline) AS snippet,
           ts_rank(n.search_vector, q) AS rank
    FROM meeting_notes n
    LEFT JOIN bookings b ON b.id = n.booking_id
    CROSS JOIN websearch_to_tsquery('simple', :q) q
    WHERE n.search_vector @@ q
       OR coalesce(array_to_string(n.decisions, ' '), '') ILIKE :like
    ORDER BY rank DESC, n.date DESC
    LIMIT :limit OFFSET :offset
    """
)

_NOTES_COUNT_SQL = text(
    """
    SELECT count(*) FROM meeting_notes n
    CROSS JOIN websearch_to_tsquery('simple', :q) q
    WHERE n.search_vector @@ q
       OR coalesce(array_to_string(n.decisions, ' '), '') ILIKE :like
    """
)

_TRANSCRIPTS_SQL = text(
    """
    SELECT s.id, s.note_id, s.booking_id, s.speaker_name, s.start_ms,
           n.title AS note_title, n.date,
           b.title AS booking_title,
           ts_headline('simple', s.text, q, :headline) AS snippet,
           ts_rank(s.search_vector, q) AS rank
    FROM meeting_transcript_segments s
    JOIN meeting_notes n ON n.id = s.note_id
    LEFT JOIN bookings b ON b.id = s.booking_id
    CROSS JOIN websearch_to_tsquery('simple', :q) q
    WHERE s.search_vector @@ q
    ORDER BY rank DESC, n.date DESC, s.start_ms ASC
    LIMIT :limit OFFSET :offset
    """
)

_TRANSCRIPTS_COUNT_SQL = text(
    """
    SELECT count(*) FROM meeting_transcript_segments s
    CROSS JOIN websearch_to_tsquery('simple', :q) q
    WHERE s.search_vector @@ q
    """
)

_ACTIONS_SQL = text(
    """
    SELECT a.id, a.note_id, a.task, a.owner, a.due_date, a.status, a.source,
           n.title AS note_title, n.date,
           b.id AS booking_id, b.title AS booking_title
    FROM meeting_note_action_items a
    JOIN meeting_notes n ON n.id = a.note_id
    LEFT JOIN bookings b ON b.id = n.booking_id
    WHERE to_tsvector('simple', a.task) @@ websearch_to_tsquery('simple', :q)
       OR a.task ILIKE :like OR a.owner ILIKE :like
    ORDER BY n.date DESC
    LIMIT :limit OFFSET :offset
    """
)

_ACTIONS_COUNT_SQL = text(
    """
    SELECT count(*) FROM meeting_note_action_items a
    WHERE to_tsvector('simple', a.task) @@ websearch_to_tsquery('simple', :q)
       OR a.task ILIKE :like OR a.owner ILIKE :like
    """
)


def _like_of(q: str) -> str:
    escaped = q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


def _note_item(r) -> SearchNoteItem:
    data = dict(r)
    rank = float(data.pop("rank") or 0)
    return SearchNoteItem(**data, rank=rank)


def _transcript_item(r) -> SearchTranscriptItem:
    data = dict(r)
    rank = float(data.pop("rank") or 0)
    return SearchTranscriptItem(**data, rank=rank)


@router.get("", response_model=SuccessResponse)
async def search(
    q: str = Query(..., min_length=2, max_length=200, description="Kata kunci pencarian"),
    type: str = Query("all", pattern="^(all|notes|transcripts|actions)$"),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("notes.view")),
):
    """Cari notulen, transkrip, dan tindak lanjut di seluruh rapat."""
    like = _like_of(q)
    params = {"q": q, "like": like, "headline": _HEADLINE_OPTS, "limit": limit, "offset": offset}

    counts = SearchCounts()
    results: dict = {"notes": [], "transcripts": [], "actions": []}

    if type in ("all", "notes"):
        rows = (await db.execute(_NOTES_SQL, params)).mappings().all()
        counts.notes = (await db.execute(_NOTES_COUNT_SQL, {"q": q, "like": like})).scalar() or 0
        results["notes"] = [_note_item(r) for r in rows]

    if type in ("all", "transcripts"):
        rows = (await db.execute(_TRANSCRIPTS_SQL, params)).mappings().all()
        counts.transcripts = (await db.execute(_TRANSCRIPTS_COUNT_SQL, {"q": q})).scalar() or 0
        results["transcripts"] = [_transcript_item(r) for r in rows]

    if type in ("all", "actions"):
        rows = (await db.execute(_ACTIONS_SQL, params)).mappings().all()
        counts.actions = (await db.execute(_ACTIONS_COUNT_SQL, {"q": q, "like": like})).scalar() or 0
        results["actions"] = [SearchActionItem(**dict(r)) for r in rows]

    counts.total = counts.notes + counts.transcripts + counts.actions
    return SuccessResponse(data=SearchResponse(query=q, counts=counts, results=results))
