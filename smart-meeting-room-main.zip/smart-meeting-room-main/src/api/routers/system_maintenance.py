"""Pemeliharaan sistem: health, migrasi, backup/restore database, cache, data demo.

Semua endpoint memerlukan izin `system.maintenance` (Super Admin otomatis punya).
Restore database hanya untuk Super Admin + konfirmasi eksplisit.
"""
import asyncio
import logging
import os
import re
import shutil
import subprocess
import tempfile
from datetime import datetime, timedelta, date, time
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile, status
from fastapi.responses import FileResponse
from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.config import settings
from src.api.database import engine, get_db
from src.api.db.migrator import MIGRATIONS_DIR, list_migration_files, run_pending
from src.api.models.booking import Booking
from src.api.models.room import Room
from src.api.models.user import Role, User
from src.api.routers.notifications import ws_manager
from src.api.schemas.system_maintenance import (
    BackupDBResponse,
    CacheClearResponse,
    MigrationFileItem,
    MigrationsListResponse,
    MigrationsRunResponse,
    RestoreDBResponse,
    SeedDemoResponse,
    SuccessResponse,
    SystemHealthResponse,
)
from src.api.utils.audit import record_audit
from src.api.utils.permissions import require_permission, require_super_admin

router = APIRouter(tags=["System Maintenance"])
logger = logging.getLogger("smr.maintenance")

APP_STARTED_AT = datetime.now()
BACKUP_NAME_RE = re.compile(r"^smr_backup_\d{8}_\d{6}(_pre_restore)?\.(dump|sql)$")
RESTORE_CONFIRM_WORD = "RESTORE"
SUBPROCESS_TIMEOUT = 30 * 60

require_maintenance = require_permission("system.maintenance")


# ============================================
# Helper
# ============================================

def _backup_dir() -> Path:
    d = Path(settings.UPLOAD_DIR).resolve() / "backups"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _pg_env() -> dict:
    env = os.environ.copy()
    env["PGPASSWORD"] = settings.DB_PASSWORD
    return env


def _pg_conn_args() -> List[str]:
    return ["-h", settings.DB_HOST, "-p", str(settings.DB_PORT), "-U", settings.DB_USER]


def _require_binary(name: str) -> str:
    """Cari binary PostgreSQL (pg_dump/pg_restore/psql). Bisa diarahkan via PG_BIN_DIR."""
    bin_dir = os.getenv("PG_BIN_DIR")
    if bin_dir:
        for cand in (Path(bin_dir) / name, Path(bin_dir) / f"{name}.exe"):
            if cand.is_file():
                return str(cand)
    found = shutil.which(name)
    if not found:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                f"'{name}' tidak ditemukan di server. Install PostgreSQL client tools "
                f"atau set PG_BIN_DIR ke folder bin PostgreSQL."
            ),
        )
    return found


async def _run(args: List[str]) -> subprocess.CompletedProcess:
    # args berupa list (tanpa shell) -> aman dari command injection.
    return await asyncio.to_thread(
        subprocess.run, args, env=_pg_env(), capture_output=True, timeout=SUBPROCESS_TIMEOUT, check=False,
    )


def _resolve_backup(filename: str) -> Path:
    if not BACKUP_NAME_RE.match(filename or ""):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Nama file backup tidak valid")
    base = _backup_dir()
    path = (base / filename).resolve()
    if path.parent != base or not path.is_file():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File backup tidak ditemukan")
    return path


async def _create_backup(suffix: str = "") -> Path:
    pg_dump = _require_binary("pg_dump")
    now = datetime.now()
    path = _backup_dir() / f"smr_backup_{now.strftime('%Y%m%d_%H%M%S')}{suffix}.dump"
    args = [pg_dump, *_pg_conn_args(), "-d", settings.DB_NAME, "-Fc", "--no-owner", "-f", str(path)]
    proc = await _run(args)
    if proc.returncode != 0 or not path.exists():
        logger.error("pg_dump gagal (%s): %s", proc.returncode, proc.stderr.decode(errors="replace")[-2000:])
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Backup database gagal. Lihat log server.")
    return path


def _backup_info(path: Path) -> dict:
    st = path.stat()
    return {
        "filename": path.name,
        "size_bytes": st.st_size,
        "created_at": datetime.fromtimestamp(st.st_mtime).isoformat(),
        "download_url": f"/api/v1/system/backups/{path.name}/download",
    }


# ============================================
# Health
# ============================================

@router.get("/health", response_model=SuccessResponse)
async def system_health(
    current_user: User = Depends(require_maintenance),
    db: AsyncSession = Depends(get_db),
):
    db_status = "disconnected"
    try:
        await db.execute(text("SELECT 1"))
        db_status = "connected"
    except Exception:  # noqa: BLE001
        db_status = "disconnected"

    total_users = (await db.execute(select(func.count(User.id)))).scalar() or 0
    total_rooms = (await db.execute(select(func.count(Room.id)))).scalar() or 0
    total_bookings = (await db.execute(select(func.count(Booking.id)))).scalar() or 0

    storage_used_pct = 0.0
    try:
        upload_dir = Path(settings.UPLOAD_DIR).resolve()
        upload_dir.mkdir(parents=True, exist_ok=True)
        du = shutil.disk_usage(upload_dir)
        storage_used_pct = round(du.used / du.total * 100, 1) if du.total else 0.0
    except OSError:
        logger.warning("Gagal membaca penggunaan disk", exc_info=True)

    backups = sorted(_backup_dir().glob("smr_backup_*"), key=lambda p: p.stat().st_mtime, reverse=True)
    pending_backup = not backups or (
        datetime.now() - datetime.fromtimestamp(backups[0].stat().st_mtime) > timedelta(days=7)
    )

    uptime_seconds = int((datetime.now() - APP_STARTED_AT).total_seconds())

    return SuccessResponse(
        data=SystemHealthResponse(
            db_status=db_status,
            total_users=total_users,
            total_rooms=total_rooms,
            total_bookings=total_bookings,
            pending_backup=pending_backup,
            storage_used_pct=storage_used_pct,
            uptime_seconds=uptime_seconds,
            started_at=APP_STARTED_AT,
        )
    )


# ============================================
# Migrasi
# ============================================

@router.get("/migrations/list", response_model=SuccessResponse)
async def list_migrations(
    current_user: User = Depends(require_maintenance),
    db: AsyncSession = Depends(get_db),
):
    await db.execute(text(
        "CREATE TABLE IF NOT EXISTS schema_migrations ("
        "filename VARCHAR(255) PRIMARY KEY, "
        "applied_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP)"
    ))
    await db.commit()
    rows = (await db.execute(text("SELECT filename, applied_at FROM schema_migrations"))).all()
    applied = {fn: at for fn, at in rows}

    migrations = []
    for fname in list_migration_files(MIGRATIONS_DIR):
        is_applied = fname in applied
        migrations.append(
            MigrationFileItem(
                filename=fname,
                status="applied" if is_applied else "pending",
                applied_at=applied.get(fname),
            )
        )
    total_applied = sum(1 for m in migrations if m.status == "applied")
    return SuccessResponse(
        data=MigrationsListResponse(
            migrations=migrations,
            total_applied=total_applied,
            total_pending=len(migrations) - total_applied,
        )
    )


@router.get("/migrations", response_model=SuccessResponse)
async def list_migrations_short_alias(
    current_user: User = Depends(require_maintenance),
    db: AsyncSession = Depends(get_db),
):
    return await list_migrations(current_user, db)


@router.post("/migrations/run", response_model=SuccessResponse)
async def run_migrations(
    request: Request,
    current_user: User = Depends(require_maintenance),
    db: AsyncSession = Depends(get_db),
):
    logs: List[str] = []
    try:
        results = await run_pending(settings.SYNC_DATABASE_URL, log=logs.append)
    except Exception:  # noqa: BLE001
        logger.exception("Menjalankan migrasi gagal")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Migrasi gagal. Lihat log server.")
    for line in logs:
        logger.info("migrate: %s", line)
    files_run = [r.filename for r in results if r.ok]
    errors = [{"file": r.filename, "error": "Gagal diterapkan (lihat log server)"} for r in results if not r.ok]
    for r in results:
        if r.error:
            logger.error("Migrasi %s gagal: %s", r.filename, r.error)
    await record_audit(db, current_user, "update", "system", "migrations", None,
                       {"files_run": files_run, "errors": len(errors)}, request, commit=True)
    data = MigrationsRunResponse(files_run=files_run, errors=errors).model_dump()
    data["applied"] = len(files_run)
    data["message"] = f"{len(files_run)} migrasi diterapkan" + (f", {len(errors)} gagal" if errors else "")
    return SuccessResponse(data=data)


# ============================================
# Backup / Restore
# ============================================

@router.post("/backup/db", response_model=SuccessResponse)
async def backup_database(
    request: Request,
    current_user: User = Depends(require_maintenance),
    db: AsyncSession = Depends(get_db),
):
    path = await _create_backup()
    info = _backup_info(path)
    await record_audit(db, current_user, "export", "system", "database_backup", path.name,
                       {"size_bytes": info["size_bytes"]}, request, commit=True)
    return SuccessResponse(
        data=BackupDBResponse(
            download_url=info["download_url"],
            size_bytes=info["size_bytes"],
            created_at=datetime.fromtimestamp(path.stat().st_mtime),
            filename=path.name,
        )
    )


@router.post("/backup", response_model=SuccessResponse)
async def backup_database_short_alias(
    request: Request,
    current_user: User = Depends(require_maintenance),
    db: AsyncSession = Depends(get_db),
):
    return await backup_database(request, current_user, db)


@router.get("/backups", response_model=SuccessResponse)
async def list_backups(
    current_user: User = Depends(require_maintenance),
):
    files = [p for p in _backup_dir().iterdir() if p.is_file() and BACKUP_NAME_RE.match(p.name)]
    files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return SuccessResponse(data=[_backup_info(p) for p in files])


@router.get("/backups/{filename}/download")
async def download_backup(
    filename: str,
    request: Request,
    current_user: User = Depends(require_maintenance),
    db: AsyncSession = Depends(get_db),
):
    path = _resolve_backup(filename)
    await record_audit(db, current_user, "export", "system", "database_backup_download", path.name,
                       None, request, commit=True)
    return FileResponse(path, media_type="application/octet-stream", filename=path.name)


@router.delete("/backups/{filename}", response_model=SuccessResponse)
async def delete_backup(
    filename: str,
    request: Request,
    current_user: User = Depends(require_super_admin()),
    db: AsyncSession = Depends(get_db),
):
    path = _resolve_backup(filename)
    path.unlink()
    await record_audit(db, current_user, "delete", "system", "database_backup", filename, None, request, commit=True)
    return SuccessResponse(data={"message": "File backup dihapus"})


async def _save_upload_limited(file: UploadFile, dest: Path) -> int:
    limit = settings.MAX_FILE_SIZE_MB * 1024 * 1024
    size = 0
    with open(dest, "wb") as out:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            if size > limit:
                raise HTTPException(
                    status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                    detail=f"Ukuran file melebihi batas {settings.MAX_FILE_SIZE_MB} MB",
                )
            out.write(chunk)
    return size


@router.post("/restore/db", response_model=SuccessResponse)
async def restore_database(
    request: Request,
    file: UploadFile = File(..., description="File backup (.dump dari pg_dump -Fc, atau .sql)"),
    confirm: str = Form("", description=f"Ketik {RESTORE_CONFIRM_WORD} untuk konfirmasi"),
    current_user: User = Depends(require_super_admin()),
    db: AsyncSession = Depends(get_db),
):
    """Restore database dari file backup. Hanya Super Admin; DATA SAAT INI DITIMPA.
    Backup otomatis (`*_pre_restore.dump`) dibuat sebelum restore."""
    if (confirm or "").strip() != RESTORE_CONFIRM_WORD:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Konfirmasi diperlukan: kirim field 'confirm' berisi {RESTORE_CONFIRM_WORD}",
        )
    fname = file.filename or ""
    if not fname.lower().endswith((".dump", ".sql", ".backup")):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="File harus .dump, .backup atau .sql")

    with tempfile.TemporaryDirectory(prefix="smr_restore_") as tmp:
        tmp_path = Path(tmp) / "upload.bin"
        await _save_upload_limited(file, tmp_path)
        with open(tmp_path, "rb") as fh:
            is_custom = fh.read(5) == b"PGDMP"

        tool = _require_binary("pg_restore" if is_custom else "psql")
        safety = await _create_backup(suffix="_pre_restore")

        if is_custom:
            args = [tool, *_pg_conn_args(), "-d", settings.DB_NAME, "--clean", "--if-exists",
                    "--no-owner", "--single-transaction", str(tmp_path)]
        else:
            args = [tool, *_pg_conn_args(), "-d", settings.DB_NAME, "-v", "ON_ERROR_STOP=1",
                    "--single-transaction", "-f", str(tmp_path)]
        # Tutup koneksi session ini agar tidak memegang lock selama restore.
        await db.close()
        proc = await _run(args)
        # Skema dibuat ulang -> buang koneksi pool (cache prepared statement basi).
        await engine.dispose()

    if proc.returncode != 0:
        logger.error("Restore gagal (%s): %s", proc.returncode, proc.stderr.decode(errors="replace")[-4000:])
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Restore gagal dan dibatalkan (transaksi tunggal). Backup sebelum restore: {safety.name}",
        )

    await record_audit(db, current_user, "import", "system", "database_restore", fname[:100],
                       {"pre_restore_backup": safety.name}, request, commit=True)
    return SuccessResponse(
        data=RestoreDBResponse(
            success=True,
            filename=fname,
            restored_at=datetime.now(),
            message=f"Backup {fname} berhasil direstore. Backup sebelumnya disimpan sebagai {safety.name}",
        )
    )


@router.post("/restore", response_model=SuccessResponse)
async def restore_database_short_alias(
    request: Request,
    file: UploadFile = File(..., description="File backup (.dump / .sql)"),
    confirm: str = Form(""),
    current_user: User = Depends(require_super_admin()),
    db: AsyncSession = Depends(get_db),
):
    return await restore_database(request, file, confirm, current_user, db)


# ============================================
# Cache & data demo
# ============================================

@router.post("/cache/clear", response_model=SuccessResponse)
async def clear_cache(
    current_user: User = Depends(require_maintenance),
):
    cleared = []

    ws_manager.clear_all()
    cleared.append("notification_websocket_connections")

    data = CacheClearResponse(
        success=True,
        cleared_caches=cleared,
        message=f"Berhasil membersihkan {len(cleared)} cache(s)",
    ).model_dump()
    data["cleared"] = len(cleared)
    return SuccessResponse(data=data)


@router.post("/clear-cache", response_model=SuccessResponse)
async def clear_cache_short_alias(
    current_user: User = Depends(require_maintenance),
):
    return await clear_cache(current_user)


@router.post("/users/seed-demo", response_model=SuccessResponse)
async def seed_demo_data(
    request: Request,
    current_user: User = Depends(require_maintenance),
    db: AsyncSession = Depends(get_db),
):
    from src.api.utils.auth import get_password_hash
    import random
    import secrets
    import uuid as uuid_lib

    first_names = ["Budi", "Siti", "Ahmad", "Dewi", "Rudi", "Sari", "Andi", "Rina", "Fajar", "Wulan",
                   "Eko", "Maya", "Dika", "Putri", "Rizki", "Ayu", "Bayu", "Lina", "Hendra", "Nia"]
    last_names = ["Santoso", "Rahayu", "Wijaya", "Lestari", "Hartono", "Pratama", "Nugroho", "Marlina",
                  "Perdana", "Kusuma", "Permana", "Sari", "Saputra", "Wati", "Yulianto"]

    # Akun demo SELALU memakai role 'User' (tidak pernah role pertama / admin).
    role_result = await db.execute(select(Role).where(func.lower(Role.name) == "user"))
    user_role = role_result.scalar_one_or_none()
    if user_role is None:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Role 'User' tidak ditemukan")

    rooms_result = await db.execute(select(Room.id).limit(5))
    room_ids = [r[0] for r in rooms_result.all()]

    created_users = 0
    user_ids = []
    suffix = datetime.now().strftime("%H%M%S")
    for i in range(20):
        fn = random.choice(first_names)
        ln = random.choice(last_names)
        uname = f"{fn.lower()}{ln.lower()}{suffix}{i+1}"[:50]
        user = User(
            id=uuid_lib.uuid4(),
            username=uname,
            # Password acak yang tidak diketahui siapa pun -> akun demo tidak bisa login.
            password_hash=get_password_hash(secrets.token_urlsafe(24)),
            name=f"{fn} {ln}",
            email=f"{uname}@demo.local",
            position="Staff",
            role_id=user_role.id,
            status="ACTIVE",
        )
        db.add(user)
        user_ids.append(user.id)
        created_users += 1

    await db.flush()

    created_bookings = 0
    today = date.today()
    start_times_list = [time(8, 0), time(9, 0), time(10, 0), time(11, 0),
                        time(13, 0), time(14, 0), time(15, 0), time(16, 0)]
    durations = [30, 45, 60, 90, 120]
    statuses = ["draft", "pending", "approved", "approved", "approved", "completed", "cancelled", "rejected"]

    for i in range(50):
        if not room_ids:
            break
        b_date = today + timedelta(days=random.randint(-5, 14))
        uid = random.choice(user_ids)
        st = random.choice(start_times_list)
        et = (datetime.combine(b_date, st) + timedelta(minutes=random.choice(durations))).time()
        db.add(Booking(
            user_id=uid,
            room_id=random.choice(room_ids),
            title=f"Meeting Demo #{i+1}",
            description=f"Demo booking otomatis #{i+1}",
            date=b_date,
            start_time=st,
            end_time=et,
            attendees=random.randint(2, 15),
            status=random.choice(statuses),
            created_by=uid,
        ))
        created_bookings += 1

    await record_audit(db, current_user, "create", "system", "seed_demo", None,
                       {"users": created_users, "bookings": created_bookings}, request)
    await db.commit()

    data = SeedDemoResponse(
        success=True,
        users_created=created_users,
        bookings_created=created_bookings,
        message=f"Berhasil generate {created_users} users dan {created_bookings} bookings demo",
    ).model_dump()
    data["created"] = {"users": created_users, "bookings": created_bookings}
    return SuccessResponse(data=data)


@router.post("/seed-demo", response_model=SuccessResponse)
async def seed_demo_data_short_alias(
    request: Request,
    current_user: User = Depends(require_maintenance),
    db: AsyncSession = Depends(get_db),
):
    return await seed_demo_data(request, current_user, db)
