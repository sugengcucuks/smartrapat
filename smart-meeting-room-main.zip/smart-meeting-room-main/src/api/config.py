from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # App
    APP_NAME: str = "Smart Meeting Room"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False

    # Database
    DB_USER: str = "smr_admin"
    DB_PASSWORD: str = "smr_secret_password"
    DB_HOST: str = "localhost"
    DB_PORT: int = 5432
    DB_NAME: str = "smart_meeting_room"

    # JWT
    # WAJIB diisi lewat .env (min. 32 karakter acak). Aplikasi menolak start bila kosong/lemah.
    JWT_SECRET: str = ""
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # Security
    BCRYPT_ROUNDS: int = 12
    LOGIN_MAX_ATTEMPTS: int = 5
    LOGIN_LOCKOUT_MINUTES: int = 15

    # Server
    API_HOST: str = "localhost"
    API_PORT: int = 8000
    API_DEBUG: bool = False
    # Aktifkan /docs & /redoc hanya bila perlu (development).
    ENABLE_API_DOCS: bool = False

    # Frontend
    WEB_PORT: int = 3000
    WEB_URL: str = "http://localhost:3000"

    # CORS
    ALLOWED_ORIGINS: str = "http://localhost:3000,http://localhost:5173"

    # AI (Ollama) - ringkasan notulensi
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "llama3.1:8b"

    # Whisper (STT) - transkripsi notulensi
    WHISPER_MODEL: str = "small"         # tiny|base|small|medium|large-v3 (lihat docs/modules/11_NOTULENSI.md)

    # File Upload
    UPLOAD_DIR: str = "./uploads"
    MAX_FILE_SIZE_MB: int = 100

    # Licensing
    LICENSE_ENFORCED: bool = True
    LICENSE_DIR: str = "."
    LICENSE_FILE: str = ""

    # Device agent / recorder -> backend (header X-Agent-Key). Wajib diisi bila recorder dipakai.
    AGENT_API_KEY: str = ""

    # Notulensi: bahasa default transkrip & perangkat inferensi Whisper
    STT_LANGUAGE: str = "id"
    WHISPER_DEVICE: str = "cpu"          # cpu | cuda
    WHISPER_COMPUTE_TYPE: str = "int8"   # int8 (CPU) | float16 (GPU)
    # Mesin STT: "faster_whisper" (produksi). "fake" HANYA untuk pengujian otomatis
    # (menghasilkan teks uji berlabel, bukan transkrip nyata) — jangan dipakai di produksi.
    STT_ENGINE: str = "faster_whisper"
    # Folder cache model Whisper (kosong = default HuggingFace cache). WHISPER_MODEL juga
    # boleh berupa path folder model hasil konversi CTranslate2 (untuk server offline).
    WHISPER_MODEL_DIR: str = ""
    # Batas waktu permintaan ke Ollama (detik); model 7-8B di CPU bisa butuh beberapa menit.
    OLLAMA_TIMEOUT_SECONDS: float = 600.0
    # Hapus file audio rekaman yang lebih tua dari N hari (0 = simpan selamanya).
    RECORDING_RETENTION_DAYS: int = 0

    # Kiosk Security
    KIOSK_SESSION_MINUTES: int = 480

    @property
    def allowed_origins_list(self) -> list[str]:
        return [o.strip() for o in self.ALLOWED_ORIGINS.split(",") if o.strip()]

    @property
    def DATABASE_URL(self) -> str:
        return f"postgresql+asyncpg://{self.DB_USER}:{self.DB_PASSWORD}@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"

    @property
    def SYNC_DATABASE_URL(self) -> str:
        return f"postgresql://{self.DB_USER}:{self.DB_PASSWORD}@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"

    class Config:
        env_file = ".env"
        case_sensitive = True
        extra = "ignore"


@lru_cache()
def get_settings() -> Settings:
    return Settings()


WEAK_JWT_SECRETS = {
    "",
    "your-super-secret-jwt-key-change-in-production",
    "changeme",
    "secret",
}


def validate_security_settings(s: Settings) -> None:
    """Tolak start bila secret JWT kosong/default/pendek (token bisa dipalsukan)."""
    if s.JWT_SECRET in WEAK_JWT_SECRETS or len(s.JWT_SECRET) < 32:
        raise RuntimeError(
            "JWT_SECRET belum diset atau terlalu lemah. Isi JWT_SECRET di .env dengan "
            "minimal 32 karakter acak, contoh: python -c \"import secrets;print(secrets.token_urlsafe(48))\""
        )


settings = get_settings()
