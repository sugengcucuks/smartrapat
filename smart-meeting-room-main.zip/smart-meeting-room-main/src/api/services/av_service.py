"""Logika kontrol AV per ruangan (videowall Digibird + panel LG, mixer X-Air).

Dipakai oleh src/api/routers/av_control.py dan pembungkus lama
(videowall.py, audio.py, devices.py). Semua perintah lewat MQTT dengan ack.

Sumber kebenaran preset layout & sumber input = `devices.config` milik
videowall controller di ruangan tsb, contoh:

    {
      "presets": [{"id": "fullscreen", "label": "Fullscreen", "scene": 1,
                   "windows": [{"id": 1, "x": 0, "y": 0, "w": 1, "h": 1}]}, ...],
      "sources": [{"id": "hdmi1", "label": "HDMI 1", "code": 1}, ...],
      "grid": {"cols": 3, "rows": 2},
      "panels": ["TV-PANEL-1", ...]        # opsional: kode panel; default semua 'tv' di ruangan
    }

Bila kosong, dipakai DEFAULT_PRESETS/DEFAULT_SOURCES (wall LG 3x2, HDMI 1-4).
Agent memvalidasi angka scene/input/window (whitelist) sebelum dikirim ke perangkat.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.models.device import Device
from src.api.models.live import AudioChannel
from src.api.models.room import Room
from src.api.models.user import User
from src.api.utils.mqtt_client import MqttError, mqtt_manager

logger = logging.getLogger(__name__)

ACK_TIMEOUT = 3.0

# Tipe perangkat (kolom devices.device_type)
CONTROLLER_TYPES = {"videowall_controller", "videowall"}
PANEL_TYPES = {"tv", "display"}
MIXER_TYPES = {"audio_mixer"}
# audio_processor lama dianggap mixer hanya bila config.driver == "xair"

DEVICE_TYPES = [
    "tv", "projector", "ac", "cctv", "lights", "curtain", "sensor_temp", "sensor_humidity",
    "door_lock", "videowall_controller", "audio_mixer", "audio_processor", "tablet",
]

# Layout default untuk wall 3x2 (6 panel LG 55VL5PJ). Koordinat jendela dalam
# pecahan 0..1 dari seluruh wall (untuk pratinjau di UI). `scene` = nomor scene
# yang harus DISIMPAN dulu di processor Digibird ([save,ID]).
DEFAULT_PRESETS: List[Dict[str, Any]] = [
    {"id": "fullscreen", "label": "Fullscreen (1 layar penuh)", "scene": 1,
     "windows": [{"id": 1, "x": 0, "y": 0, "w": 1, "h": 1}]},
    {"id": "split2", "label": "2 Layar (kiri | kanan)", "scene": 2,
     "windows": [{"id": 1, "x": 0, "y": 0, "w": 0.5, "h": 1},
                 {"id": 2, "x": 0.5, "y": 0, "w": 0.5, "h": 1}]},
    {"id": "main_side", "label": "Utama + 2 samping", "scene": 3,
     "windows": [{"id": 1, "x": 0, "y": 0, "w": 2 / 3, "h": 1},
                 {"id": 2, "x": 2 / 3, "y": 0, "w": 1 / 3, "h": 0.5},
                 {"id": 3, "x": 2 / 3, "y": 0.5, "w": 1 / 3, "h": 0.5}]},
    {"id": "quad", "label": "4 Jendela (2x2)", "scene": 4,
     "windows": [{"id": 1, "x": 0, "y": 0, "w": 0.5, "h": 0.5},
                 {"id": 2, "x": 0.5, "y": 0, "w": 0.5, "h": 0.5},
                 {"id": 3, "x": 0, "y": 0.5, "w": 0.5, "h": 0.5},
                 {"id": 4, "x": 0.5, "y": 0.5, "w": 0.5, "h": 0.5}]},
    {"id": "panels6", "label": "6 Panel terpisah (3x2)", "scene": 5,
     "windows": [{"id": i * 3 + j + 1, "x": j / 3, "y": i / 2, "w": 1 / 3, "h": 0.5}
                 for i in range(2) for j in range(3)]},
]

DEFAULT_SOURCES: List[Dict[str, Any]] = [
    {"id": f"hdmi{n}", "label": f"HDMI {n}", "code": n} for n in range(1, 5)
]

DEFAULT_GRID = {"cols": 3, "rows": 2}


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------

def http_error(code: int, err_code: str, message: str) -> HTTPException:
    return HTTPException(status_code=code, detail={"code": err_code, "message": message})


def mqtt_http_error(exc: MqttError) -> HTTPException:
    return http_error(status.HTTP_503_SERVICE_UNAVAILABLE, exc.code, str(exc))


MIXER_ABSENT_MESSAGE = "Mixer tidak terpasang; atur manual di receiver"


# ---------------------------------------------------------------------------
# Resolusi perangkat ruangan
# ---------------------------------------------------------------------------

def is_mixer(dev: Device) -> bool:
    if dev.device_type in MIXER_TYPES:
        return True
    cfg = dev.config or {}
    return dev.device_type == "audio_processor" and str(cfg.get("driver", "")).lower() == "xair"


class RoomDevices:
    def __init__(self, room: Room, devices: Sequence[Device]):
        self.room = room
        self.all = list(devices)
        self.controller: Optional[Device] = next(
            (d for d in self.all if d.device_type in CONTROLLER_TYPES), None
        )
        cfg = (self.controller.config or {}) if self.controller else {}
        panel_codes = cfg.get("panels")
        tvs = [d for d in self.all if d.device_type in PANEL_TYPES]
        if isinstance(panel_codes, list) and panel_codes:
            wanted = [str(c) for c in panel_codes]
            self.panels = [d for d in tvs if d.code in wanted or str(d.id) in wanted]
        else:
            self.panels = tvs
        self.panels.sort(key=lambda d: d.code)
        self.mixer: Optional[Device] = next((d for d in self.all if is_mixer(d)), None)

    @property
    def audio_mode(self) -> str:
        if self.mixer is None:
            return "none"
        return str((self.mixer.config or {}).get("driver", "xair")).lower()


async def get_room(db: AsyncSession, room_id: UUID) -> Room:
    room = (await db.execute(select(Room).where(Room.id == room_id))).scalar_one_or_none()
    if room is None:
        raise http_error(status.HTTP_404_NOT_FOUND, "ROOM_NOT_FOUND", "Ruangan tidak ditemukan")
    return room


async def load_room_devices(db: AsyncSession, room_id: UUID) -> RoomDevices:
    room = await get_room(db, room_id)
    devices = (await db.execute(
        select(Device).where(Device.location_id == room_id).order_by(Device.code.asc())
    )).scalars().all()
    return RoomDevices(room, devices)


def videowall_presets(controller: Optional[Device]) -> List[Dict[str, Any]]:
    cfg = (controller.config or {}) if controller else {}
    presets = cfg.get("presets")
    if isinstance(presets, list) and presets:
        out = []
        for p in presets:
            if isinstance(p, dict) and p.get("id") and p.get("scene") is not None:
                out.append({"id": str(p["id"]), "label": str(p.get("label") or p["id"]),
                            "scene": int(p["scene"]), "windows": p.get("windows") or []})
        if out:
            return out
    return [dict(p) for p in DEFAULT_PRESETS]


def videowall_sources(controller: Optional[Device]) -> List[Dict[str, Any]]:
    cfg = (controller.config or {}) if controller else {}
    sources = cfg.get("sources")
    if isinstance(sources, list) and sources:
        out = []
        for s in sources:
            if isinstance(s, dict) and s.get("id") and s.get("code") is not None:
                out.append({"id": str(s["id"]), "label": str(s.get("label") or s["id"]),
                            "code": int(s["code"])})
        if out:
            return out
    return [dict(s) for s in DEFAULT_SOURCES]


def device_brief(dev: Device) -> Dict[str, Any]:
    from src.api.services.live_hub import live_hub
    return {
        "id": str(dev.id),
        "code": dev.code,
        "name": dev.name,
        "device_type": dev.device_type,
        "status": dev.status,
        "last_seen": dev.last_seen.isoformat() if dev.last_seen else None,
        "last_action": dev.last_action,
        "live": live_hub.device_live(str(dev.id), dev.code),
    }


async def audio_channels(db: AsyncSession, room_id: UUID) -> List[AudioChannel]:
    return list((await db.execute(
        select(AudioChannel).where(AudioChannel.room_id == room_id).order_by(AudioChannel.channel_no.asc())
    )).scalars().all())


def channel_dict(ch: AudioChannel) -> Dict[str, Any]:
    return {
        "id": str(ch.id),
        "room_id": str(ch.room_id),
        "channel_no": ch.channel_no,
        "label": ch.label,
        "receiver_label": ch.receiver_label,
        "mixer_channel": ch.mixer_channel,
        "capture_channel": ch.capture_channel,
        "device_id": str(ch.device_id) if ch.device_id else None,
        "enabled": bool(ch.is_enabled),
    }


async def capabilities(db: AsyncSession, room_id: UUID) -> Dict[str, Any]:
    rd = await load_room_devices(db, room_id)
    cfg = (rd.controller.config or {}) if rd.controller else {}
    chans = await audio_channels(db, room_id)
    mixer_cfg = (rd.mixer.config or {}) if rd.mixer else {}
    return {
        "room_id": str(rd.room.id),
        "room_code": rd.room.code,
        "room_name": rd.room.name,
        "mqtt": mqtt_manager.status(),
        "videowall": {
            "available": rd.controller is not None or bool(rd.panels),
            "controller": device_brief(rd.controller) if rd.controller else None,
            "panels": [device_brief(p) for p in rd.panels],
            "grid": cfg.get("grid") or DEFAULT_GRID,
            "presets": videowall_presets(rd.controller),
            "sources": videowall_sources(rd.controller),
        },
        "audio": {
            "mode": rd.audio_mode,                      # "xair" | "none"
            "can_control": rd.mixer is not None,
            "has_meters": rd.mixer is not None,         # mode none: level dari recorder bila ada
            "message": None if rd.mixer else MIXER_ABSENT_MESSAGE,
            "mixer": device_brief(rd.mixer) if rd.mixer else None,
            "max_channels": int(mixer_cfg.get("max_channels", 16)),
            "channels": [channel_dict(c) for c in chans],
        },
        "devices": [device_brief(d) for d in rd.all],
    }


# ---------------------------------------------------------------------------
# Eksekusi perintah
# ---------------------------------------------------------------------------

Target = Tuple[Device, str, Dict[str, Any]]


def _base_payload(dev: Device, user: Optional[User]) -> Dict[str, Any]:
    return {
        "device_id": str(dev.id),
        "device_code": dev.code,
        "device_type": dev.device_type,
        "room_id": str(dev.location_id) if dev.location_id else None,
        "user": getattr(user, "username", None),
    }


async def run_commands(
    db: AsyncSession,
    targets: List[Target],
    user: Optional[User],
    label: str,
    timeout: float = ACK_TIMEOUT,
) -> Dict[str, Any]:
    """Publish semua perintah (paralel), tunggu ack <= timeout, agregasi hasil.

    Respons: {"cmd_id", "status": "acked"|"failed"|"timeout", "error", "results": [...]}
    """
    if not targets:
        raise http_error(status.HTTP_404_NOT_FOUND, "DEVICE_NOT_FOUND", "Tidak ada perangkat untuk perintah ini")
    try:
        mqtt_manager.ensure_ready()
    except MqttError as exc:
        raise mqtt_http_error(exc)

    sent: List[Tuple[Device, str, str]] = []
    try:
        for dev, action, params in targets:
            payload = {**_base_payload(dev, user), **params}
            cmd_id = mqtt_manager.publish_command(str(dev.id), action, payload)
            sent.append((dev, action, cmd_id))
    except MqttError as exc:
        raise mqtt_http_error(exc)

    acks = await asyncio.gather(*(mqtt_manager.wait_ack(cid, timeout) for _, _, cid in sent))

    results = []
    for (dev, action, cmd_id), ack in zip(sent, acks):
        if ack is None:
            st, err, resp = "timeout", f"Tidak ada respons dari agent dalam {timeout:g} detik", None
        elif ack.get("ok"):
            st, err, resp = "acked", None, ack.get("response")
        else:
            st, err, resp = "failed", ack.get("error") or "Perintah gagal di perangkat", ack.get("response")
        results.append({
            "device_id": str(dev.id), "device_code": dev.code, "device_name": dev.name,
            "action": action, "cmd_id": cmd_id, "status": st, "error": err, "response": resp,
        })
        dev.last_action = f"{label} [{st}]"[:200]

    if any(r["status"] == "failed" for r in results):
        overall = "failed"
    elif any(r["status"] == "timeout" for r in results):
        overall = "timeout"
    else:
        overall = "acked"
    errors = [f"{r['device_code']}: {r['error']}" for r in results if r["error"]]
    result = {
        "cmd_id": results[0]["cmd_id"],
        "status": overall,
        "error": "; ".join(errors) if errors else None,
        "results": results,
    }
    try:
        await db.commit()
    except Exception:  # pragma: no cover
        await db.rollback()
    await write_audit(db, user, "DEVICE_COMMAND", label, result)
    return result


async def write_audit(db: AsyncSession, user: Optional[User], action: str, label: str, result: Dict[str, Any]) -> None:
    """Catat ke log audit bila src/api/utils/audit.py (record_audit) tersedia."""
    try:
        from src.api.utils.audit import record_audit  # type: ignore
    except ImportError:
        return
    try:
        await record_audit(
            db,
            user,
            action,
            "devices",
            target_type="device_command",
            target_id=result.get("cmd_id"),
            details={"label": label, "status": result.get("status"), "error": result.get("error"),
                     "devices": [r.get("device_code") for r in result.get("results", [])]},
            commit=True,
        )
    except Exception as exc:  # audit tidak boleh menggagalkan perintah
        logger.debug("audit gagal: %s", exc)


# ---------------------------------------------------------------------------
# Videowall
# ---------------------------------------------------------------------------

def _require_videowall(rd: RoomDevices, need_controller: bool = False) -> None:
    if need_controller and rd.controller is None:
        raise http_error(status.HTTP_404_NOT_FOUND, "VIDEOWALL_NOT_CONFIGURED",
                         "Ruangan ini belum punya perangkat videowall_controller")
    if rd.controller is None and not rd.panels:
        raise http_error(status.HTTP_404_NOT_FOUND, "VIDEOWALL_NOT_CONFIGURED",
                         "Ruangan ini belum punya perangkat videowall (controller/panel)")


async def videowall_power(db: AsyncSession, room_id: UUID, on: bool, user: Optional[User]) -> Dict[str, Any]:
    rd = await load_room_devices(db, room_id)
    _require_videowall(rd)
    action = "power_on" if on else "power_off"
    targets: List[Target] = [(p, action, {}) for p in rd.panels]
    if rd.controller is not None:
        targets.append((rd.controller, action, {}))
    return await run_commands(db, targets, user, f"Videowall {'ON' if on else 'OFF'} ({rd.room.code})")


async def videowall_layout(db: AsyncSession, room_id: UUID, preset_id: str, user: Optional[User]) -> Dict[str, Any]:
    rd = await load_room_devices(db, room_id)
    _require_videowall(rd, need_controller=True)
    preset = next((p for p in videowall_presets(rd.controller) if p["id"] == preset_id), None)
    if preset is None:
        raise http_error(status.HTTP_400_BAD_REQUEST, "INVALID_PRESET", f"Preset layout '{preset_id}' tidak dikenal")
    return await run_commands(
        db, [(rd.controller, "apply_layout", {"preset": preset["id"], "scene": preset["scene"]})],
        user, f"Layout {preset['label']}",
    )


async def videowall_source(db: AsyncSession, room_id: UUID, source_id: str, window: int, user: Optional[User]) -> Dict[str, Any]:
    rd = await load_room_devices(db, room_id)
    _require_videowall(rd, need_controller=True)
    src = next((s for s in videowall_sources(rd.controller) if s["id"] == source_id), None)
    if src is None:
        raise http_error(status.HTTP_400_BAD_REQUEST, "INVALID_SOURCE", f"Sumber '{source_id}' tidak dikenal")
    if window < 1 or window > 16:
        raise http_error(status.HTTP_400_BAD_REQUEST, "INVALID_WINDOW", "Nomor jendela harus 1-16")
    return await run_commands(
        db, [(rd.controller, "change_source", {"source": src["id"], "input": src["code"], "window": window})],
        user, f"Sumber {src['label']} -> jendela {window}",
    )


# ---------------------------------------------------------------------------
# Audio mixer
# ---------------------------------------------------------------------------

async def _require_mixer(db: AsyncSession, room_id: UUID) -> RoomDevices:
    rd = await load_room_devices(db, room_id)
    if rd.mixer is None:
        raise http_error(status.HTTP_409_CONFLICT, "MIXER_NOT_INSTALLED", MIXER_ABSENT_MESSAGE)
    return rd


async def _channel(db: AsyncSession, room_id: UUID, channel_no: int) -> AudioChannel:
    ch = (await db.execute(
        select(AudioChannel).where(AudioChannel.room_id == room_id, AudioChannel.channel_no == channel_no)
    )).scalar_one_or_none()
    if ch is None:
        raise http_error(status.HTTP_404_NOT_FOUND, "CHANNEL_NOT_FOUND",
                         f"Kanal mic {channel_no} belum dikonfigurasi di ruangan ini")
    if ch.mixer_channel is None:
        raise http_error(status.HTTP_409_CONFLICT, "CHANNEL_NOT_ON_MIXER",
                         f"Kanal mic {channel_no} tidak terhubung ke mixer (mixer_channel kosong)")
    return ch


async def mic_mute(db: AsyncSession, room_id: UUID, channel_no: int, mute: bool, user: Optional[User]) -> Dict[str, Any]:
    rd = await _require_mixer(db, room_id)
    ch = await _channel(db, room_id, channel_no)
    action = "mute" if mute else "unmute"
    return await run_commands(
        db, [(rd.mixer, action, {"channel_no": ch.channel_no, "mixer_channel": ch.mixer_channel})],
        user, f"{'Mute' if mute else 'Unmute'} {ch.label}",
    )


async def mute_all(db: AsyncSession, room_id: UUID, mute: bool, user: Optional[User]) -> Dict[str, Any]:
    rd = await _require_mixer(db, room_id)
    chans = [c for c in await audio_channels(db, room_id) if c.mixer_channel is not None and c.is_enabled]
    action = "mute_all" if mute else "unmute_all"
    return await run_commands(
        db, [(rd.mixer, action, {"mixer_channels": sorted({int(c.mixer_channel) for c in chans})})],
        user, f"{'Mute' if mute else 'Unmute'} semua mic",
    )


async def set_fader(db: AsyncSession, room_id: UUID, target: Any, value: float, user: Optional[User]) -> Dict[str, Any]:
    if not (0.0 <= float(value) <= 1.0):
        raise http_error(status.HTTP_400_BAD_REQUEST, "INVALID_VALUE", "Nilai fader harus 0..1")
    rd = await _require_mixer(db, room_id)
    if str(target) == "main":
        params: Dict[str, Any] = {"target": "main", "value": float(value)}
        label = f"Fader utama {round(float(value) * 100)}%"
    else:
        try:
            ch_no = int(target)
        except (TypeError, ValueError):
            raise http_error(status.HTTP_400_BAD_REQUEST, "INVALID_TARGET", "target harus nomor kanal atau 'main'")
        ch = await _channel(db, room_id, ch_no)
        params = {"target": "channel", "channel_no": ch.channel_no, "mixer_channel": ch.mixer_channel,
                  "value": float(value)}
        label = f"Fader {ch.label} {round(float(value) * 100)}%"
    return await run_commands(db, [(rd.mixer, "set_fader", params)], user, label)


async def set_gain(db: AsyncSession, room_id: UUID, channel_no: int, db_value: float, user: Optional[User]) -> Dict[str, Any]:
    if not (-12.0 <= float(db_value) <= 60.0):
        raise http_error(status.HTTP_400_BAD_REQUEST, "INVALID_VALUE", "Gain harus -12..60 dB")
    rd = await _require_mixer(db, room_id)
    ch = await _channel(db, room_id, channel_no)
    return await run_commands(
        db, [(rd.mixer, "set_gain", {"channel_no": ch.channel_no, "mixer_channel": ch.mixer_channel,
                                     "db": float(db_value)})],
        user, f"Gain {ch.label} {float(db_value):.0f} dB",
    )


# ---------------------------------------------------------------------------
# Perintah perangkat tunggal (DeviceListPage)
# ---------------------------------------------------------------------------

async def device_command(db: AsyncSession, dev: Device, action: str, user: Optional[User],
                         params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    return await run_commands(db, [(dev, action, params or {})], user, f"{action} {dev.code}")


def unique_ints(values: Iterable[int]) -> bool:
    vals = list(values)
    return len(vals) == len(set(vals))


def merge_results(parts: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Gabungkan beberapa hasil run_commands (dijalankan berurutan)."""
    results = [r for p in parts for r in p.get("results", [])]
    statuses = [p["status"] for p in parts]
    overall = "failed" if "failed" in statuses else "timeout" if "timeout" in statuses else "acked"
    errors = [p["error"] for p in parts if p.get("error")]
    return {"cmd_id": parts[0]["cmd_id"] if parts else None, "status": overall,
            "error": "; ".join(errors) if errors else None, "results": results}


async def videowall_apply(db: AsyncSession, room_id: UUID, preset_id: str,
                          inputs: List[Dict[str, Any]], user: Optional[User]) -> Dict[str, Any]:
    """Terapkan preset lalu sumber per jendela, berurutan; berhenti bila ada kegagalan."""
    parts = [await videowall_layout(db, room_id, preset_id, user)]
    for idx, inp in enumerate(inputs or []):
        if parts[-1]["status"] != "acked":
            break
        parts.append(await videowall_source(db, room_id, str(inp.get("input")),
                                            int(inp.get("window") or idx + 1), user))
    return merge_results(parts)
