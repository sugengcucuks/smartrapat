"""ENG-03: Autonomous Status Scheduler.

Penjadwal mandiri yang berjalan di dalam proses API untuk menjaga kebenaran
status rapat tanpa intervensi manual dan tanpa ketergantungan Redis:

    approved (menunggu/berjalan)  ->  completed (selesai)
    approved (tak kunjung mulai)  ->  cancelled (ruangan dilepas)

Rapat yang sudah melewati jam selesainya otomatis ditutup, lalu:
- status baru disiarkan ke seluruh layar kiosk ruangan terkait via WebSocket,
- penyelenggara menerima notifikasi realtime,
- rapat tanpa satu pun peserta yang presensi ditandai sebagai no-show.

Selain itu, rapat yang tidak kunjung dimulai dalam GRACE_PERIOD menit sejak
jadwal mulai (masih dalam slot hari itu) dilepas otomatis: ruangan kembali
tersedia untuk pemesanan lain dan penyelenggara diberi tahu.

Dijalankan sebagai satu pass saat startup (agar rapat yang terlewat selama
server mati langsung direkonsiliasi), lalu diulang berkala.
"""

import asyncio
from datetime import datetime, time, timedelta
from typing import Any, Dict, List, Optional
from uuid import UUID

from sqlalchemy import and_, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.database import async_session
from src.api.models.booking import Booking, BookingParticipant
from src.api.models.room import Room
from src.api.routers.door_display import _get_status_payload, door_ws_manager
from src.api.routers.notifications import _create_notification

# Selang antar penyapuan status (detik).
SWEEP_INTERVAL_SECONDS = 60

# Notifikasi hanya dikirim untuk rapat yang baru saja berakhir. Rapat lama yang
# baru direkonsiliasi saat startup tetap ditutup tanpa membanjiri notifikasi.
NOTIFY_WINDOW_MINUTES = 60

# Rapat yang tidak pernah dimulai selepas grace ini sejak jadwal mulai dilepas
# otomatis (ruangan kembali tersedia) selama slot-nya masih berjalan hari itu.
NO_SHOW_GRACE_MINUTES = 15


async def _count_attendance(db: AsyncSession, booking_id: UUID) -> int:
    stmt = select(func.count(BookingParticipant.id)).where(
        and_(
            BookingParticipant.booking_id == booking_id,
            BookingParticipant.attended.is_(True),
        )
    )
    result = await db.execute(stmt)
    return result.scalar() or 0


def _is_recent(booking: Booking) -> bool:
    """True bila rapat baru saja berakhir (dalam jendela notifikasi)."""
    end_dt = datetime.combine(booking.date, booking.end_time)
    age_minutes = (datetime.now() - end_dt).total_seconds() / 60
    return 0 <= age_minutes <= NOTIFY_WINDOW_MINUTES


async def _find_bookings_to_complete(db: AsyncSession) -> List[Booking]:
    """Rapat 'approved' yang jam selesainya sudah terlewat."""
    now = datetime.now()
    today = now.date()
    now_time: time = now.time()

    stmt = select(Booking).where(
        and_(
            Booking.status == "approved",
            or_(
                Booking.date < today,
                and_(Booking.date == today, Booking.end_time < now_time),
            ),
        )
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def _find_bookings_to_release(db: AsyncSession) -> List[Booking]:
    """Rapat 'approved' hari ini yang tidak pernah dimulai melewati grace.

    Hanya slot yang MASIH berjalan (end belum lewat) yang dilepas; bila end
    sudah lewat, penutupan completed + penandaan no-show oleh sweep utama
    yang lebih tepat.
    """
    now = datetime.now()
    grace_cutoff_time: time = (now - timedelta(minutes=NO_SHOW_GRACE_MINUTES)).time()

    stmt = select(Booking).where(
        and_(
            Booking.status == "approved",
            Booking.meeting_status == "scheduled",
            Booking.actual_start_at.is_(None),
            Booking.date == now.date(),
            Booking.start_time <= grace_cutoff_time,
            Booking.end_time > now.time(),
        )
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def _get_room(db: AsyncSession, room_id: UUID) -> Optional[Room]:
    result = await db.execute(select(Room).where(Room.id == room_id))
    return result.scalar_one_or_none()


async def _broadcast_room_status(db: AsyncSession, room: Room) -> None:
    """Kirim ulang payload status ruangan ke seluruh kiosk ruangan tersebut."""
    try:
        payload = await _get_status_payload(db, room)
        if payload:
            await door_ws_manager.broadcast_room(
                room.code,
                {
                    "event": "status_changed",
                    "data": payload,
                    "room_code": room.code,
                    "timestamp": datetime.now().isoformat(),
                },
            )
    except Exception as exc:  # noqa: BLE001
        print(f"[StatusScheduler] Gagal broadcast status ruangan {room.code}: {exc}")


async def run_sweep() -> Dict[str, Any]:
    """Jalankan satu siklus pelepasan & penutupan rapat otomatis.

    Mengembalikan ringkasan hasil untuk keperluan log dan pengujian.
    """
    completed: List[Dict[str, Any]] = []
    released: List[Dict[str, Any]] = []
    touched_room_ids: set[UUID] = set()

    async with async_session() as db:
        # 1) Auto-release: rapat yang tak kunjung dimulai -> ruangan dilepas.
        for booking in await _find_bookings_to_release(db):
            old_status = booking.status
            booking.status = "cancelled"
            touched_room_ids.add(booking.room_id)

            room = await _get_room(db, booking.room_id)
            room_label = f'"{room.name}"' if room else "ruangan"
            await _create_notification(
                db,
                user_id=booking.user_id,
                type="booking_released",
                title="Ruangan Dilepas Otomatis",
                message=(
                    f'Rapat "{booking.title}" tidak kunjung dimulai dalam '
                    f"{NO_SHOW_GRACE_MINUTES} menit pertama; {room_label} "
                    f"dilepas dan kembali tersedia."
                ),
                data={
                    "booking_id": str(booking.id),
                    "room_id": str(booking.room_id),
                    "previous_status": old_status,
                    "reason": "no_show_start",
                },
            )
            released.append(
                {
                    "booking_id": str(booking.id),
                    "title": booking.title,
                    "room_id": str(booking.room_id),
                    "date": booking.date.isoformat(),
                    "start_time": booking.start_time.strftime("%H:%M"),
                }
            )

        # 2) Penutupan: rapat yang melewati jam selesai -> completed.
        bookings = await _find_bookings_to_complete(db)

        for booking in bookings:
            attended_count = await _count_attendance(db, booking.id)
            booking.status = "completed"
            if booking.meeting_status == "live":
                # Rapat live yang tidak diakhiri manual ditutup otomatis.
                booking.meeting_status = "ended"
                booking.actual_end_at = datetime.now().astimezone()
            touched_room_ids.add(booking.room_id)

            is_no_show = attended_count == 0
            if is_no_show:
                title = "Rapat Tidak Dihadiri"
                message = (
                    f'Rapat "{booking.title}" berakhir tanpa satu pun peserta '
                    f"yang melakukan presensi."
                )
            else:
                title = "Rapat Selesai"
                message = (
                    f'Rapat "{booking.title}" telah selesai dengan '
                    f"{attended_count} peserta hadir."
                )

            if _is_recent(booking):
                await _create_notification(
                    db,
                    user_id=booking.user_id,
                    type="booking_completed",
                    title=title,
                    message=message,
                    data={
                        "booking_id": str(booking.id),
                        "room_id": str(booking.room_id),
                        "attended_count": attended_count,
                        "no_show": is_no_show,
                    },
                )

            completed.append(
                {
                    "booking_id": str(booking.id),
                    "title": booking.title,
                    "room_id": str(booking.room_id),
                    "date": booking.date.isoformat(),
                    "end_time": booking.end_time.strftime("%H:%M"),
                    "attended_count": attended_count,
                    "no_show": is_no_show,
                }
            )

        await db.commit()

        # Siarkan setelah commit agar kiosk tidak menarik status yang belum tersimpan.
        for room_id in touched_room_ids:
            room = await _get_room(db, room_id)
            if room:
                await _broadcast_room_status(db, room)

    for item in released:
        print(
            f"[StatusScheduler] Dilepas: {item['title']} "
            f"({item['date']} {item['start_time']}) - tidak pernah dimulai"
        )

    for item in completed:
        flag = " [NO-SHOW]" if item["no_show"] else ""
        print(
            f"[StatusScheduler] Selesai: {item['title']} "
            f"({item['date']} {item['end_time']}){flag}"
        )

    return {"completed": len(completed), "released": len(released), "items": completed}


class StatusScheduler:
    """Pengelola siklus hidup background task penjadwal status."""

    def __init__(self, interval_seconds: int = SWEEP_INTERVAL_SECONDS) -> None:
        self.interval_seconds = interval_seconds
        self._task: Optional[asyncio.Task] = None
        self._stopping = False

    async def _loop(self) -> None:
        while not self._stopping:
            try:
                await run_sweep()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                print(f"[StatusScheduler] Siklus gagal: {exc}")

            try:
                await asyncio.sleep(self.interval_seconds)
            except asyncio.CancelledError:
                raise

    def start(self) -> None:
        if self._task is not None and not self._task.done():
            return
        self._stopping = False
        self._task = asyncio.create_task(self._loop())
        print(
            f"[StatusScheduler] Aktif, siklus setiap {self.interval_seconds} detik"
        )

    async def stop(self) -> None:
        self._stopping = True
        if self._task is None:
            return
        self._task.cancel()
        try:
            await self._task
        except asyncio.CancelledError:
            pass
        self._task = None
        print("[StatusScheduler] Dihentikan")


status_scheduler = StatusScheduler()
