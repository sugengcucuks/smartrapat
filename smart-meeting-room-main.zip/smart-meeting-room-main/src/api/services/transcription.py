"""Antrean & worker speech-to-text notulensi (faster-whisper, lokal).

Alur (lihat docs/architecture/LIVE_MEETING.md §2 & §4):

    recorder / browser / unggahan -> file audio di UPLOAD_DIR/recordings/<booking>/<recording>/
        -> TranscriptionJob (antrean asyncio, 1 worker) -> mesin STT (thread terpisah)
        -> baris meeting_transcript_segments (pembicara dari kanal mic -> kursi -> peserta)
        -> event WS `transcript_segment` & `recording_status` (bila live_hub tersedia)

Jenis job:
- ``segment``: potongan pendek dari recorder multikanal (1 kanal mic = 1 pembicara).
- ``chunk``  : potongan ~10 detik dari browser (mode C), pembicara "Peserta"/pilihan.
- ``file``   : unggahan rekaman penuh; diproses per potongan ±5 menit dengan progres.

Ketahanan: setiap job ditulis juga sebagai file ``<audio>.job.json``. Bila server
restart (atau model Whisper belum terpasang), job dimuat ulang saat start sehingga
audio tidak hilang. Job yang gagal permanen (audio rusak) diubah menjadi
``.job.failed.json``.

Tidak pernah mengarang teks: bila mesin STT tidak tersedia, job gagal dengan pesan
jelas. Mesin ``fake`` (STT_ENGINE=fake) hanya untuk pengujian otomatis.
"""
from __future__ import annotations

import asyncio
import inspect
import json
import logging
import math
import os
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Protocol, Tuple

import numpy as np
from sqlalchemy import select

from src.api.config import settings
from src.api.services import audio_io
from src.api.services.audio_io import SAMPLE_RATE, AudioDecodeError

try:  # dibangun paralel oleh modul live meeting; opsional
    from src.api.services.live_hub import live_hub  # type: ignore
except ImportError:  # pragma: no cover - tergantung versi kode
    live_hub = None

log = logging.getLogger("smr.transcription")

# Mode B (mix): kanal 1 = output mix receiver A, kanal 2 = receiver B.
MIX_GROUP_NAMES = {1: "Grup A (Mic 1–8)", 2: "Grup B (Mic 9–16)"}
DEFAULT_SPEAKER = "Peserta"
FILE_PIECE_SECONDS = 300
FILE_CUT_SEARCH_SECONDS = 3


# ---------------------------------------------------------------------------
# Mesin STT (dapat diganti/di-inject untuk pengujian)
# ---------------------------------------------------------------------------
class STTUnavailableError(RuntimeError):
    """Mesin STT tidak tersedia (paket/model belum terpasang). Job disimpan untuk dicoba lagi."""


@dataclass
class EngineSegment:
    start: float          # detik, relatif terhadap awal audio yang diberikan
    end: float
    text: str
    confidence: Optional[float] = None


class STTEngine(Protocol):
    name: str

    def load(self) -> None: ...

    def transcribe(self, audio: np.ndarray, language: Optional[str]) -> Tuple[List[EngineSegment], Optional[str]]: ...


class FasterWhisperEngine:
    """faster-whisper; model dimuat sekali (lazy) dan dipakai satu thread pada satu waktu."""

    def __init__(self, model_name: str, device: str, compute_type: str, download_root: str = ""):
        self.model_name = model_name
        self.device = device
        self.compute_type = compute_type
        self.download_root = download_root or None
        self.name = f"faster-whisper:{model_name}"
        self._model = None
        self._lock = threading.Lock()

    @property
    def loaded(self) -> bool:
        return self._model is not None

    @staticmethod
    def package_available() -> Tuple[bool, Optional[str]]:
        import importlib.util
        if importlib.util.find_spec("faster_whisper") is None:
            return False, "paket faster-whisper tidak terpasang (pip install -r requirements.txt)"
        return True, None

    def load(self) -> None:
        with self._lock:
            if self._model is not None:
                return
            try:
                from faster_whisper import WhisperModel
            except Exception as e:
                raise STTUnavailableError(f"Model Whisper belum terpasang: paket faster-whisper tidak ditemukan ({e})") from e
            try:
                self._model = WhisperModel(
                    self.model_name, device=self.device, compute_type=self.compute_type,
                    download_root=self.download_root,
                )
            except Exception as e:
                raise STTUnavailableError(
                    f"Model Whisper belum terpasang: gagal memuat model '{self.model_name}' "
                    f"({self.device}/{self.compute_type}): {e}"
                ) from e

    def transcribe(self, audio: np.ndarray, language: Optional[str]) -> Tuple[List[EngineSegment], Optional[str]]:
        self.load()
        with self._lock:
            segments, info = self._model.transcribe(
                audio, language=language or None, vad_filter=True, beam_size=5,
            )
            out: List[EngineSegment] = []
            for s in segments:  # generator: inferensi terjadi di sini
                text = (s.text or "").strip()
                if not text:
                    continue
                conf = None
                if getattr(s, "avg_logprob", None) is not None:
                    conf = round(float(math.exp(min(0.0, s.avg_logprob))), 3)
                out.append(EngineSegment(float(s.start), float(s.end), text, conf))
        return out, getattr(info, "language", language)


class FakeSTTEngine:
    """HANYA untuk pengujian otomatis (STT_ENGINE=fake). Teks diberi label jelas
    "[STT uji]" sehingga tidak bisa tertukar dengan transkrip nyata."""

    name = "fake"
    loaded = True

    def load(self) -> None:
        return None

    def transcribe(self, audio: np.ndarray, language: Optional[str]) -> Tuple[List[EngineSegment], Optional[str]]:
        dur = len(audio) / SAMPLE_RATE
        if dur <= 0 or audio_io.rms_dbfs(audio) < -60:
            return [], language
        return [EngineSegment(0.0, round(dur, 3), f"[STT uji] audio {dur:.1f} detik", 1.0)], language


def stt_language() -> Optional[str]:
    lang = (settings.STT_LANGUAGE or "").strip().lower()
    return None if lang in ("", "auto") else lang


def build_engine_from_settings() -> STTEngine:
    engine = (settings.STT_ENGINE or "faster_whisper").strip().lower()
    if engine == "fake":
        log.warning("STT_ENGINE=fake aktif — hanya untuk pengujian, bukan transkrip nyata")
        return FakeSTTEngine()
    return FasterWhisperEngine(
        settings.WHISPER_MODEL, settings.WHISPER_DEVICE, settings.WHISPER_COMPUTE_TYPE,
        settings.WHISPER_MODEL_DIR,
    )


# ---------------------------------------------------------------------------
# Penyimpanan file
# ---------------------------------------------------------------------------
def recordings_root() -> Path:
    return (Path(settings.UPLOAD_DIR) / "recordings").resolve()


def recording_dir(booking_id: Any, recording_id: Any) -> Path:
    """UPLOAD_DIR/recordings/<booking_uuid>/<recording_uuid>/ — hanya dari UUID (path-safe)."""
    b = str(uuid.UUID(str(booking_id)))
    r = str(uuid.UUID(str(recording_id)))
    root = recordings_root()
    path = (root / b / r).resolve()
    path.relative_to(root)  # ValueError bila keluar dari root
    path.mkdir(parents=True, exist_ok=True)
    return path


# ---------------------------------------------------------------------------
# Atribusi pembicara
# ---------------------------------------------------------------------------
def pick_speaker_name(
    participant_name: Optional[str],
    assignment_display_name: Optional[str],
    seat_label: Optional[str],
    channel_label: Optional[str],
    channel_no: Optional[int],
) -> str:
    for cand in (participant_name, assignment_display_name, seat_label, channel_label):
        if cand and str(cand).strip():
            return str(cand).strip()
    if channel_no is not None:
        return f"Mic {channel_no}"
    return DEFAULT_SPEAKER


async def resolve_speaker(db, booking_id: Any, room_id: Any, channel_no: Optional[int], source: Optional[str]) -> Dict[str, Any]:
    """kanal mic -> audio_channels -> room_seats -> booking_seat_assignments -> peserta -> nama."""
    from src.api.models.booking import BookingParticipant
    from src.api.models.live import AudioChannel, BookingSeatAssignment, RoomSeat
    from src.api.models.user import User

    res: Dict[str, Any] = {"seat_id": None, "seat_label": None, "participant_id": None, "speaker_name": None}
    if channel_no is None:
        res["speaker_name"] = DEFAULT_SPEAKER
        return res
    if source == "mix":
        res["speaker_name"] = MIX_GROUP_NAMES.get(int(channel_no), f"Mic {channel_no}")
        return res

    ch = None
    if room_id is not None:
        ch = (await db.execute(
            select(AudioChannel).where(AudioChannel.room_id == room_id, AudioChannel.channel_no == int(channel_no))
        )).scalar_one_or_none()
    seat = asg = None
    pname = None
    if ch is not None:
        seat = (await db.execute(select(RoomSeat).where(RoomSeat.audio_channel_id == ch.id))).scalar_one_or_none()
    if seat is not None:
        asg = (await db.execute(
            select(BookingSeatAssignment).where(
                BookingSeatAssignment.booking_id == booking_id, BookingSeatAssignment.seat_id == seat.id,
            )
        )).scalar_one_or_none()
    if asg is not None and asg.participant_id is not None:
        row = (await db.execute(
            select(BookingParticipant, User).outerjoin(User, BookingParticipant.user_id == User.id)
            .where(BookingParticipant.id == asg.participant_id)
        )).first()
        if row:
            p, u = row
            pname = (u.name if u else None) or p.guest_name
            res["participant_id"] = p.id
    res["seat_id"] = seat.id if seat else None
    res["seat_label"] = seat.label if seat else None
    res["speaker_name"] = pick_speaker_name(
        pname, asg.display_name if asg else None, seat.label if seat else None,
        ch.label if ch else None, channel_no,
    )
    return res


# ---------------------------------------------------------------------------
# Serialisasi & broadcast
# ---------------------------------------------------------------------------
def _iso(v: Optional[datetime]) -> Optional[str]:
    return v.isoformat() if v else None


def serialize_segment(seg, seat_label: Optional[str] = None) -> Dict[str, Any]:
    """Bentuk item `GET /notes/{id}/segments` & event WS `transcript_segment`."""
    return {
        "id": str(seg.id),
        "note_id": str(seg.note_id),
        "booking_id": str(seg.booking_id) if seg.booking_id else None,
        "recording_id": str(seg.recording_id) if seg.recording_id else None,
        "start_ms": int(seg.start_ms or 0),
        "end_ms": int(seg.end_ms or 0),
        "audio_channel_no": seg.audio_channel_no,
        "seat_id": str(seg.seat_id) if seg.seat_id else None,
        "seat_label": seat_label,
        "participant_id": str(seg.participant_id) if seg.participant_id else None,
        "speaker_name": seg.speaker_name,
        "text": seg.text,
        "confidence": seg.confidence,
        "language": seg.language,
        "is_edited": bool(seg.is_edited),
        "created_at": _iso(seg.created_at),
        "updated_at": _iso(seg.updated_at),
    }


async def broadcast(room_id: Any, event: str, data: Dict[str, Any]) -> None:
    """Kirim event ke WS live ruangan bila live_hub tersedia. Tidak pernah melempar."""
    if live_hub is None or room_id is None:
        return
    try:
        result = live_hub.broadcast(str(room_id), event, data)
        if inspect.isawaitable(result):
            await result
    except Exception as e:  # pragma: no cover - defensif
        log.warning("broadcast %s gagal: %s", event, e)


# ---------------------------------------------------------------------------
# Job & service
# ---------------------------------------------------------------------------
@dataclass
class TranscriptionJob:
    kind: str                       # segment | chunk | file
    note_id: str
    booking_id: str
    audio_path: str
    recording_id: Optional[str] = None
    channel_no: Optional[int] = None
    start_ms: int = 0
    end_ms: Optional[int] = None
    speaker_name: Optional[str] = None
    participant_id: Optional[str] = None
    job_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    created_at: float = field(default_factory=time.time)

    @property
    def sidecar(self) -> str:
        return self.audio_path + ".job.json"

    def to_json(self) -> str:
        return json.dumps(asdict(self))

    @classmethod
    def from_json(cls, raw: str) -> "TranscriptionJob":
        d = json.loads(raw)
        allowed = set(cls.__dataclass_fields__.keys())
        return cls(**{k: v for k, v in d.items() if k in allowed})


class TranscriptionService:
    def __init__(self, session_factory: Optional[Callable] = None, engine: Optional[STTEngine] = None):
        self._session_factory = session_factory
        self._engine: Optional[STTEngine] = engine
        self._queue: Optional[asyncio.Queue] = None
        self._worker: Optional[asyncio.Task] = None
        self._housekeeping: Optional[asyncio.Task] = None
        self._pending_note: Dict[str, int] = {}
        self._pending_rec: Dict[str, int] = {}
        self.progress: Dict[str, float] = {}      # recording_id -> 0..1 (job file)
        self.last_error: Optional[str] = None
        self.last_error_at: Optional[str] = None
        self.processed = 0
        self.current_job: Optional[str] = None

    # --- konfigurasi -------------------------------------------------------
    @property
    def engine(self) -> STTEngine:
        if self._engine is None:
            self._engine = build_engine_from_settings()
        return self._engine

    def set_engine(self, engine: Optional[STTEngine]) -> None:
        self._engine = engine

    def set_session_factory(self, factory: Callable) -> None:
        self._session_factory = factory

    def _session(self):
        if self._session_factory is None:
            from src.api.database import async_session
            self._session_factory = async_session
        return self._session_factory()

    # --- lifecycle ---------------------------------------------------------
    @property
    def running(self) -> bool:
        return self._worker is not None and not self._worker.done()

    async def start(self) -> None:
        if self.running:
            return
        self._queue = asyncio.Queue()
        self._worker = asyncio.create_task(self._run(), name="stt-worker")
        self._housekeeping = asyncio.create_task(self._housekeeping_loop(), name="stt-housekeeping")
        try:
            jobs = await asyncio.to_thread(self._scan_sidecars)
            for job in jobs:
                await self.enqueue(job, persist=False)
            if jobs:
                log.info("STT: %d job tertunda dimuat ulang dari disk", len(jobs))
        except Exception as e:  # pragma: no cover
            log.warning("STT: gagal memuat job tertunda: %s", e)

    async def stop(self) -> None:
        for t in (self._worker, self._housekeeping):
            if t is not None:
                t.cancel()
                try:
                    await t
                except (asyncio.CancelledError, Exception):
                    pass
        self._worker = self._housekeeping = None

    def _scan_sidecars(self) -> List[TranscriptionJob]:
        root = recordings_root()
        if not root.exists():
            return []
        jobs = []
        for p in sorted(root.rglob("*.job.json"), key=lambda x: x.stat().st_mtime):
            try:
                job = TranscriptionJob.from_json(p.read_text(encoding="utf-8"))
                if Path(job.audio_path).exists():
                    jobs.append(job)
            except Exception as e:
                log.warning("STT: sidecar rusak %s: %s", p, e)
        return jobs

    async def _housekeeping_loop(self) -> None:
        while True:
            days = int(settings.RECORDING_RETENTION_DAYS or 0)
            if days > 0:
                try:
                    n = await asyncio.to_thread(self._purge_old_audio, days)
                    if n:
                        log.info("STT: %d file audio lama dihapus (retensi %d hari)", n, days)
                except Exception as e:  # pragma: no cover
                    log.warning("STT: retensi gagal: %s", e)
            await asyncio.sleep(6 * 3600)

    def _purge_old_audio(self, days: int) -> int:
        root = recordings_root()
        if not root.exists():
            return 0
        cutoff = time.time() - days * 86400
        n = 0
        for p in root.rglob("*"):
            if p.is_file() and not p.name.endswith(".job.json") and p.stat().st_mtime < cutoff:
                if Path(str(p) + ".job.json").exists():
                    continue  # masih menunggu diproses
                audio_io.safe_unlink(str(p))
                n += 1
        return n

    # --- status ------------------------------------------------------------
    def queue_size(self) -> int:
        return self._queue.qsize() if self._queue is not None else 0

    def pending_for_recording(self, recording_id: Any) -> int:
        return self._pending_rec.get(str(recording_id), 0)

    def pending_for_note(self, note_id: Any) -> int:
        return self._pending_note.get(str(note_id), 0)

    def status(self) -> Dict[str, Any]:
        eng = self._engine
        engine_name = (settings.STT_ENGINE or "faster_whisper").lower()
        if engine_name == "fake" or isinstance(eng, FakeSTTEngine):
            available, reason = True, None
        elif eng is not None and not isinstance(eng, FasterWhisperEngine):
            available, reason = True, None  # mesin injeksi (uji)
        else:
            available, reason = FasterWhisperEngine.package_available()
        return {
            "engine": getattr(eng, "name", None) or engine_name,
            "engine_available": bool(available),
            "engine_error": reason,
            "model": settings.WHISPER_MODEL,
            "model_loaded": bool(getattr(eng, "loaded", False)),
            "device": settings.WHISPER_DEVICE,
            "compute_type": settings.WHISPER_COMPUTE_TYPE,
            "language": settings.STT_LANGUAGE,
            "ffmpeg_available": audio_io.ffmpeg_path() is not None,
            "worker_running": self.running,
            "queue_size": self.queue_size(),
            "current_job": self.current_job,
            "processed": self.processed,
            "last_error": self.last_error,
            "last_error_at": self.last_error_at,
        }

    # --- antrean -----------------------------------------------------------
    async def enqueue(self, job: TranscriptionJob, persist: bool = True) -> None:
        if persist:
            await asyncio.to_thread(Path(job.sidecar).write_text, job.to_json(), "utf-8")
        self._pending_note[job.note_id] = self._pending_note.get(job.note_id, 0) + 1
        if job.recording_id:
            self._pending_rec[job.recording_id] = self._pending_rec.get(job.recording_id, 0) + 1
        if self._queue is None:
            self._queue = asyncio.Queue()
        await self._queue.put(job)

    async def _run(self) -> None:
        assert self._queue is not None
        while True:
            job = await self._queue.get()
            try:
                await self.process(job)
            except asyncio.CancelledError:
                raise
            except Exception as e:  # pragma: no cover - process() sudah menangani
                log.exception("STT: job %s error tak terduga: %s", job.job_id, e)
            finally:
                self._queue.task_done()

    async def drain(self, timeout: float = 30.0) -> None:
        """Tunggu antrean kosong (untuk pengujian)."""
        if self._queue is not None:
            await asyncio.wait_for(self._queue.join(), timeout)

    # --- pemrosesan --------------------------------------------------------
    def _set_error(self, msg: str) -> None:
        self.last_error = msg
        self.last_error_at = datetime.now(timezone.utc).isoformat()

    async def process(self, job: TranscriptionJob) -> None:
        self.current_job = f"{job.kind}:{job.job_id}"
        error: Optional[str] = None
        retry_later = False
        try:
            if job.kind == "file":
                await self._process_file(job)
            else:
                await self._process_short(job)
            self.processed += 1
            await asyncio.to_thread(audio_io.safe_unlink, job.sidecar)
        except STTUnavailableError as e:
            error, retry_later = str(e), True
        except AudioDecodeError as e:
            error = f"Audio tidak dapat dibaca: {e}"
        except Exception as e:
            log.exception("STT: job %s gagal", job.job_id)
            error = f"Transkripsi gagal: {e}"
        finally:
            self.current_job = None

        if error:
            self._set_error(error)
            log.warning("STT: job %s (%s) gagal: %s", job.job_id, job.kind, error)
            if not retry_later:
                try:
                    os.replace(job.sidecar, job.audio_path + ".job.failed.json")
                except OSError:
                    pass
        await self._finish(job, error)

    async def _load_context(self, db, job: TranscriptionJob):
        from src.api.models.booking import Booking
        from src.api.models.live import MeetingRecording
        from src.api.models.note import MeetingNote

        note = await db.get(MeetingNote, uuid.UUID(job.note_id))
        booking = await db.get(Booking, uuid.UUID(job.booking_id)) if job.booking_id else None
        rec = await db.get(MeetingRecording, uuid.UUID(job.recording_id)) if job.recording_id else None
        return note, booking, rec

    async def _process_short(self, job: TranscriptionJob) -> None:
        audio = await asyncio.to_thread(audio_io.read_audio_16k, job.audio_path)
        segs, lang = await asyncio.to_thread(self.engine.transcribe, audio, stt_language())
        await self._persist(job, segs, lang, offset_ms=int(job.start_ms or 0))

    async def _process_file(self, job: TranscriptionJob) -> None:
        src = job.audio_path
        wav = src + ".16k.wav"
        try:
            await asyncio.to_thread(audio_io.convert_to_wav16k, src, wav)
            total = await asyncio.to_thread(audio_io.wav_frames, wav)
            piece = FILE_PIECE_SECONDS * SAMPLE_RATE
            search = FILE_CUT_SEARCH_SECONDS * SAMPLE_RATE
            pos = 0
            rec_key = job.recording_id or job.job_id
            self.progress[rec_key] = 0.0
            while pos < total:
                chunk = await asyncio.to_thread(audio_io.read_wav_range, wav, pos, piece)
                if chunk.size == 0:
                    break
                if pos + chunk.size < total:
                    cut = audio_io.find_quiet_cut(chunk, chunk.size - search, chunk.size)
                    chunk = chunk[:max(cut, SAMPLE_RATE)]
                segs, lang = await asyncio.to_thread(self.engine.transcribe, chunk, stt_language())
                offset_ms = int(job.start_ms or 0) + int(pos * 1000 / SAMPLE_RATE)
                await self._persist(job, segs, lang, offset_ms=offset_ms)
                pos += chunk.size
                self.progress[rec_key] = min(1.0, pos / max(total, 1))
                await self._broadcast_recording(job, status="processing", progress=self.progress[rec_key])
        finally:
            await asyncio.to_thread(audio_io.safe_unlink, wav)

    async def _persist(self, job: TranscriptionJob, segs: List[EngineSegment], lang: Optional[str], offset_ms: int) -> None:
        from src.api.models.live import TranscriptSegment

        if not segs:
            return
        async with self._session() as db:
            note, booking, rec = await self._load_context(db, job)
            if note is None:
                log.info("STT: note %s sudah dihapus; hasil job dibuang", job.note_id)
                return
            source = rec.source if rec is not None else None
            room_id = booking.room_id if booking is not None else note.room_id
            if job.kind == "segment":
                spk = await resolve_speaker(db, note.booking_id, room_id, job.channel_no, source)
            else:
                spk = {"seat_id": None, "seat_label": None, "participant_id": None,
                       "speaker_name": job.speaker_name or DEFAULT_SPEAKER}
                if job.participant_id:
                    spk["participant_id"] = await self._valid_participant(db, note.booking_id, job.participant_id)
            rows = []
            for s in segs:
                start = offset_ms + int(round(s.start * 1000))
                end = offset_ms + int(round(s.end * 1000))
                if job.kind == "segment" and job.end_ms:
                    end = min(max(end, start), int(job.end_ms))
                row = TranscriptSegment(
                    note_id=note.id, booking_id=note.booking_id,
                    recording_id=uuid.UUID(job.recording_id) if job.recording_id else None,
                    start_ms=start, end_ms=max(end, start), audio_channel_no=job.channel_no,
                    seat_id=spk["seat_id"], participant_id=spk["participant_id"],
                    speaker_name=spk["speaker_name"], text=s.text.strip(),
                    confidence=s.confidence, language=(lang or settings.STT_LANGUAGE or None),
                    audio_path=job.audio_path,
                )
                db.add(row)
                rows.append(row)
            await db.commit()
            for r in rows:
                await db.refresh(r)
            payloads = [serialize_segment(r, spk.get("seat_label")) for r in rows]
        for p in payloads:
            await broadcast(room_id, "transcript_segment", p)

    async def _valid_participant(self, db, booking_id, participant_id) -> Optional[uuid.UUID]:
        from src.api.models.booking import BookingParticipant
        try:
            pid = uuid.UUID(str(participant_id))
        except ValueError:
            return None
        p = await db.get(BookingParticipant, pid)
        return pid if p is not None and p.booking_id == booking_id else None

    async def _broadcast_recording(self, job: TranscriptionJob, status: str, **extra) -> None:
        async with self._session() as db:
            note, booking, _ = await self._load_context(db, job)
            room_id = booking.room_id if booking is not None else (note.room_id if note else None)
        await broadcast(room_id, "recording_status", {
            "booking_id": job.booking_id, "recording_id": job.recording_id, "status": status, **extra,
        })

    async def _finish(self, job: TranscriptionJob, error: Optional[str]) -> None:
        """Perbarui penghitung antrean, flag note.transcript_processing & status rekaman."""
        n = self._pending_note.get(job.note_id, 1) - 1
        if n <= 0:
            self._pending_note.pop(job.note_id, None)
        else:
            self._pending_note[job.note_id] = n
        rec_left = 0
        if job.recording_id:
            rec_left = self._pending_rec.get(job.recording_id, 1) - 1
            if rec_left <= 0:
                self._pending_rec.pop(job.recording_id, None)
                rec_left = 0
            else:
                self._pending_rec[job.recording_id] = rec_left
        new_status = None
        room_id = None
        try:
            async with self._session() as db:
                note, booking, rec = await self._load_context(db, job)
                room_id = booking.room_id if booking is not None else (note.room_id if note else None)
                if note is not None and n <= 0 and note.transcript_processing:
                    note.transcript_processing = False
                if rec is not None:
                    if error:
                        rec.error = error[:2000]
                        # Unggahan gagal = rekaman gagal. Rekaman live tetap berjalan
                        # (audio tetap tersimpan & dicoba ulang), error tampil di status.
                        if job.kind == "file" or rec.status == "processing":
                            rec.status = "failed"
                    elif rec_left == 0 and rec.status == "processing":
                        rec.status = "done"
                    new_status = rec.status
                await db.commit()
        except Exception as e:  # pragma: no cover
            log.warning("STT: gagal memperbarui status: %s", e)
        if job.recording_id:
            self.progress.pop(job.recording_id, None)
        if new_status is not None:
            payload = {"booking_id": job.booking_id, "recording_id": job.recording_id, "status": new_status,
                       "pending_jobs": rec_left}
            if error:
                payload["error"] = error
            await broadcast(room_id, "recording_status", payload)


transcription_service = TranscriptionService()
