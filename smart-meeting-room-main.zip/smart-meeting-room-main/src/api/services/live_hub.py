"""Hub live per ruangan: state AV terakhir (dari MQTT) + WebSocket broadcast.

API publik (dipakai modul lain: notulensi, live meeting, kontrol AV):

    from src.api.services.live_hub import live_hub
    await live_hub.broadcast(room_id, "transcript_segment", {...})
    live_hub.invalidate_room(room_id)      # setelah kursi/kanal/penugasan berubah
    live_hub.room_av_state(room_id, room_code)  # snapshot AV untuk REST

WebSocket: /api/v1/ws/rooms/{room_id}/live?token=  (lihat src/api/routers/live_ws.py)
Format pesan server -> klien: {"event": str, "room_id": str, "data": {...}, "ts": iso}

Sumber data MQTT (lihat docs/architecture/LIVE_MEETING.md §3):
  {root}/devices/{id}/state   -> device_state (+ simpan devices.status/last_seen)
  {root}/agent/{id}/status    -> agent offline => perangkat agent itu offline
  {root}/audio/{room}/levels  -> audio_levels (maks 5 Hz per ruangan)
  {root}/audio/{room}/active  -> active_speakers (kanal -> kursi -> peserta)
  {root}/audio/{room}/mixer   -> mixer_state

Payload audio boleh membawa "key": "mixer_channel" (dikirim agent X-Air): nomor
kanal lalu diterjemahkan ke channel_no memakai audio_channels.mixer_channel.
Tanpa "key" (atau "channel_no") nomor dianggap sudah channel_no (recorder).
"""
from __future__ import annotations

import asyncio
import logging
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Set

from fastapi import WebSocket
from sqlalchemy import select

from src.api.database import async_session

logger = logging.getLogger(__name__)

LEVELS_MIN_INTERVAL = 0.2        # 5 Hz
ROOM_MAP_TTL = 10.0              # detik
ROOM_CODE_TTL = 60.0


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _as_uuid(value: Any) -> Optional[uuid.UUID]:
    try:
        return uuid.UUID(str(value))
    except (ValueError, TypeError):
        return None


class _RoomMap:
    """Pemetaan kanal mic -> kursi -> peserta untuk satu ruangan (cache)."""

    def __init__(self) -> None:
        self.fetched_at = 0.0
        self.booking_id: Optional[str] = None
        self.channel_to_seat: Dict[int, str] = {}
        self.seat_to_participant: Dict[str, str] = {}
        self.mixer_to_channel: Dict[int, int] = {}


class LiveHub:
    def __init__(self) -> None:
        self._subs: Dict[str, Set[WebSocket]] = {}
        self.device_state: Dict[str, Dict[str, Any]] = {}      # device_id -> state
        self.device_room: Dict[str, Optional[str]] = {}        # device_id -> room_id
        self.agent_status: Dict[str, Dict[str, Any]] = {}
        self.mixer: Dict[str, Dict[str, Any]] = {}             # room_code -> mixer state
        self.levels: Dict[str, Dict[str, float]] = {}          # room_code -> {channel_no: dBFS}
        self.active: Dict[str, List[int]] = {}                 # room_code -> [channel_no]
        self._room_maps: Dict[str, _RoomMap] = {}
        self._code_to_room: Dict[str, str] = {}
        self._room_to_code: Dict[str, str] = {}
        self._codes_fetched_at = 0.0
        self._levels_last_emit: Dict[str, float] = {}
        self._levels_flush_scheduled: Set[str] = set()
        self._persist_enabled = True

    # ------------------------------------------------------------------
    # WebSocket
    # ------------------------------------------------------------------
    def connect(self, room_id: str, ws: WebSocket) -> None:
        self._subs.setdefault(str(room_id), set()).add(ws)

    def disconnect(self, room_id: str, ws: WebSocket) -> None:
        subs = self._subs.get(str(room_id))
        if subs is not None:
            subs.discard(ws)
            if not subs:
                self._subs.pop(str(room_id), None)

    def subscriber_count(self, room_id: str) -> int:
        return len(self._subs.get(str(room_id), ()))

    async def broadcast(self, room_id: Any, event: str, data: Any) -> int:
        """Kirim event ke semua subscriber ruangan. Kembalikan jumlah penerima."""
        if room_id is None:
            return 0
        rid = str(room_id)
        subs = list(self._subs.get(rid, ()))
        if not subs:
            return 0
        msg = {"event": event, "room_id": rid, "data": data, "ts": _now_iso()}
        sent = 0
        for ws in subs:
            try:
                await ws.send_json(msg)
                sent += 1
            except Exception:
                self.disconnect(rid, ws)
        return sent

    async def send_initial(self, room_id: str, ws: WebSocket) -> None:
        """State awal untuk klien baru (event yang sama dengan push)."""
        code = await self.room_code(room_id)
        async def _send(event: str, data: Any) -> None:
            await ws.send_json({"event": event, "room_id": room_id, "data": data, "ts": _now_iso()})
        for dev_id, rid in list(self.device_room.items()):
            if rid == room_id and dev_id in self.device_state:
                await _send("device_state", {"device_id": dev_id, "state": self.device_state[dev_id]})
        if code:
            if code in self.mixer:
                await _send("mixer_state", self.mixer[code])
            if code in self.levels:
                await _send("audio_levels", {"levels": self.levels[code]})
            await _send("active_speakers", await self._active_payload(room_id, self.active.get(code, [])))

    # ------------------------------------------------------------------
    # Room lookup
    # ------------------------------------------------------------------
    async def _refresh_codes(self, force: bool = False) -> None:
        if not force and time.monotonic() - self._codes_fetched_at < ROOM_CODE_TTL:
            return
        from src.api.models.room import Room
        try:
            async with async_session() as db:
                rows = (await db.execute(select(Room.id, Room.code))).all()
        except Exception as exc:
            logger.warning("live_hub: gagal memuat kode ruangan: %s", exc)
            return
        self._code_to_room = {str(code): str(rid) for rid, code in rows}
        self._room_to_code = {str(rid): str(code) for rid, code in rows}
        self._codes_fetched_at = time.monotonic()

    def remember_room(self, room_id: str, room_code: str) -> None:
        self._code_to_room[str(room_code)] = str(room_id)
        self._room_to_code[str(room_id)] = str(room_code)

    async def room_id_for_code(self, code: str) -> Optional[str]:
        if code not in self._code_to_room:
            await self._refresh_codes(force=time.monotonic() - self._codes_fetched_at > 5)
        return self._code_to_room.get(code)

    async def room_code(self, room_id: str) -> Optional[str]:
        if str(room_id) not in self._room_to_code:
            await self._refresh_codes(force=time.monotonic() - self._codes_fetched_at > 5)
        return self._room_to_code.get(str(room_id))

    def invalidate_room(self, room_id: Any) -> None:
        """Paksa muat ulang peta kanal/kursi/peserta ruangan pada event berikutnya."""
        self._room_maps.pop(str(room_id), None)

    async def _room_map(self, room_id: str) -> _RoomMap:
        m = self._room_maps.get(room_id)
        if m is not None and time.monotonic() - m.fetched_at < ROOM_MAP_TTL:
            return m
        m = _RoomMap()
        try:
            await self._load_room_map(room_id, m)
        except Exception as exc:
            logger.warning("live_hub: gagal memuat peta kursi ruangan %s: %s", room_id, exc)
        m.fetched_at = time.monotonic()
        self._room_maps[room_id] = m
        return m

    async def _load_room_map(self, room_id: str, m: _RoomMap) -> None:
        from src.api.models.booking import Booking
        from src.api.models.live import AudioChannel, BookingSeatAssignment, RoomSeat

        rid = _as_uuid(room_id)
        if rid is None:
            return
        async with async_session() as db:
            rows = (await db.execute(
                select(AudioChannel.channel_no, AudioChannel.mixer_channel, RoomSeat.id)
                .outerjoin(RoomSeat, RoomSeat.audio_channel_id == AudioChannel.id)
                .where(AudioChannel.room_id == rid)
            )).all()
            for ch_no, mixer_ch, seat_id in rows:
                if seat_id is not None:
                    m.channel_to_seat[int(ch_no)] = str(seat_id)
                if mixer_ch is not None:
                    m.mixer_to_channel[int(mixer_ch)] = int(ch_no)

            booking_id = await self._current_booking_id(db, rid, Booking)
            m.booking_id = str(booking_id) if booking_id else None
            if booking_id:
                arows = (await db.execute(
                    select(BookingSeatAssignment.seat_id, BookingSeatAssignment.participant_id)
                    .where(BookingSeatAssignment.booking_id == booking_id)
                )).all()
                for seat_id, pid in arows:
                    if pid is not None:
                        m.seat_to_participant[str(seat_id)] = str(pid)

    @staticmethod
    async def _current_booking_id(db, rid: uuid.UUID, Booking) -> Optional[uuid.UUID]:
        """Booking 'live' di ruangan; bila tidak ada, booking approved yang sedang berjalan."""
        live = (await db.execute(
            select(Booking.id).where(Booking.room_id == rid, Booking.meeting_status == "live")
            .order_by(Booking.actual_start_at.desc().nullslast()).limit(1)
        )).scalar_one_or_none()
        if live:
            return live
        now = datetime.now()
        rows = (await db.execute(
            select(Booking.id, Booking.start_time, Booking.end_time, Booking.extended_minutes)
            .where(
                Booking.room_id == rid,
                Booking.date == now.date(),
                Booking.status == "approved",
                Booking.meeting_status != "ended",
            )
            .order_by(Booking.start_time.asc())
        )).all()
        for bid, st, et, ext in rows:
            start = datetime.combine(now.date(), st)
            end = datetime.combine(now.date(), et) + timedelta(minutes=int(ext or 0))
            if start <= now <= end:
                return bid
        return None

    async def _active_payload(self, room_id: str, channels: List[int]) -> Dict[str, Any]:
        m = await self._room_map(room_id)
        seats: List[str] = []
        participants: List[str] = []
        for ch in channels:
            seat = m.channel_to_seat.get(int(ch))
            if seat:
                seats.append(seat)
                pid = m.seat_to_participant.get(seat)
                if pid:
                    participants.append(pid)
        return {"channels": list(channels), "seats": seats, "participants": participants,
                "booking_id": m.booking_id}

    async def _to_channel_no(self, room_id: Optional[str], key: Optional[str], nums: Dict[str, Any]) -> Dict[str, Any]:
        """Terjemahkan dict {nomor: nilai} dari kanal mixer ke channel_no bila perlu."""
        if key != "mixer_channel" or room_id is None:
            return {str(k): v for k, v in nums.items()}
        m = await self._room_map(room_id)
        out: Dict[str, Any] = {}
        for k, v in nums.items():
            try:
                mc = int(k)
            except (TypeError, ValueError):
                continue
            ch = m.mixer_to_channel.get(mc)
            if ch is not None:
                out[str(ch)] = v
        return out

    # ------------------------------------------------------------------
    # MQTT -> hub
    # ------------------------------------------------------------------
    async def handle_mqtt(self, topic: str, payload: Dict[str, Any]) -> None:
        parts = topic.split("/")
        try:
            if len(parts) >= 3 and parts[-3] == "audio":
                code, kind = parts[-2], parts[-1]
                if kind == "levels":
                    await self._on_levels(code, payload)
                elif kind == "active":
                    await self._on_active(code, payload)
                elif kind == "mixer":
                    await self._on_mixer(code, payload)
            elif len(parts) >= 3 and parts[-3] == "agent" and parts[-1] == "status":
                await self._on_agent_status(parts[-2], payload)
            elif len(parts) >= 3 and parts[-1] == "state":
                await self._on_device_state(parts[-2], payload)
            elif len(parts) >= 3 and parts[-1] == "ack":
                self._on_ack(parts[-2], payload)
        except Exception:
            logger.exception("live_hub: gagal memproses %s", topic)

    def _on_ack(self, device_id: str, payload: Dict[str, Any]) -> None:
        # Ack sukses = agent mengeksekusi; state resmi tetap dari topic state.
        st = self.device_state.setdefault(device_id, {})
        st["last_ack"] = {k: payload.get(k) for k in ("cmd_id", "ok", "error", "ts")}

    async def _on_device_state(self, device_ref: str, payload: Dict[str, Any]) -> None:
        state = dict(payload)
        room_id, device_id = await self._persist_device_state(device_ref, state)
        key = device_id or device_ref
        prev = self.device_state.get(key, {})
        merged = {**prev, **state}
        self.device_state[key] = merged
        if room_id is not None:
            self.device_room[key] = room_id
        else:
            room_id = self.device_room.get(key)
        await self.broadcast(room_id, "device_state", {"device_id": key, "state": merged})

    async def _persist_device_state(self, device_ref: str, state: Dict[str, Any]):
        """Simpan status online/offline + last_seen. Kembalikan (room_id, device_id)."""
        if not self._persist_enabled:
            return self.device_room.get(device_ref), None
        from src.api.models.device import Device
        try:
            async with async_session() as db:
                dev = await self._find_device(db, Device, device_ref)
                if dev is None:
                    return None, None
                online = state.get("online")
                if online is not None and dev.status != "maintenance":
                    dev.status = "online" if online else "offline"
                if online:
                    dev.last_seen = datetime.now(timezone.utc)
                await db.commit()
                return (str(dev.location_id) if dev.location_id else None), str(dev.id)
        except Exception as exc:
            logger.warning("live_hub: gagal simpan state device %s: %s", device_ref, exc)
            return self.device_room.get(device_ref), None

    @staticmethod
    async def _find_device(db, Device, ref: str):
        uid = _as_uuid(ref)
        cond = Device.id == uid if uid else Device.code == ref
        return (await db.execute(select(Device).where(cond))).scalar_one_or_none()

    async def _on_agent_status(self, agent_id: str, payload: Dict[str, Any]) -> None:
        self.agent_status[agent_id] = {**payload, "agent_id": agent_id}
        if payload.get("online") is not False:
            return
        # Agent offline (LWT): semua perangkat yang dilayani agent ini dianggap offline.
        refs: List[str] = []
        for d in payload.get("devices") or []:
            if isinstance(d, dict):
                # UUID aplikasi bila valid, selain itu device_code
                ref = d.get("id") if _as_uuid(d.get("id")) else d.get("code")
            else:
                ref = d
            if ref:
                refs.append(str(ref))
        for ref in dict.fromkeys(refs):
            await self._on_device_state(ref, {"online": False, "reason": "agent_offline", "ts": payload.get("ts")})

    async def _on_levels(self, code: str, payload: Dict[str, Any]) -> None:
        room_id = await self.room_id_for_code(code)
        raw = payload.get("levels") or {}
        if not isinstance(raw, dict):
            return
        levels = await self._to_channel_no(room_id, payload.get("key"), raw)
        cur = self.levels.setdefault(code, {})
        cur.update({k: float(v) for k, v in levels.items() if isinstance(v, (int, float))})
        if room_id is None:
            return
        now = time.monotonic()
        last = self._levels_last_emit.get(code, 0.0)
        if now - last >= LEVELS_MIN_INTERVAL:
            await self._emit_levels(code, room_id)
        elif code not in self._levels_flush_scheduled:
            self._levels_flush_scheduled.add(code)
            delay = LEVELS_MIN_INTERVAL - (now - last)
            asyncio.get_event_loop().call_later(
                delay, lambda: asyncio.ensure_future(self._emit_levels(code, room_id))
            )

    async def _emit_levels(self, code: str, room_id: str) -> None:
        self._levels_flush_scheduled.discard(code)
        self._levels_last_emit[code] = time.monotonic()
        await self.broadcast(room_id, "audio_levels", {"levels": dict(self.levels.get(code, {}))})

    async def _on_active(self, code: str, payload: Dict[str, Any]) -> None:
        room_id = await self.room_id_for_code(code)
        raw = payload.get("active") or []
        nums: List[int] = []
        for v in raw:
            try:
                nums.append(int(v))
            except (TypeError, ValueError):
                continue
        if payload.get("key") == "mixer_channel" and room_id is not None:
            mapped = await self._to_channel_no(room_id, "mixer_channel", {str(n): True for n in nums})
            nums = [int(k) for k in mapped]
        nums = sorted(set(nums))
        self.active[code] = nums
        if room_id is None:
            return
        await self.broadcast(room_id, "active_speakers", await self._active_payload(room_id, nums))

    async def _on_mixer(self, code: str, payload: Dict[str, Any]) -> None:
        room_id = await self.room_id_for_code(code)
        state = dict(payload)
        chans = state.get("channels") or {}
        if isinstance(chans, dict):
            state["channels"] = await self._to_channel_no(room_id, state.get("key"), chans)
        state.pop("key", None)
        self.mixer[code] = state
        if room_id is not None:
            await self.broadcast(room_id, "mixer_state", state)

    # ------------------------------------------------------------------
    # Snapshot untuk REST
    # ------------------------------------------------------------------
    async def room_av_state(self, room_id: str, room_code: Optional[str]) -> Dict[str, Any]:
        code = room_code or await self.room_code(room_id)
        if room_code:
            self.remember_room(room_id, room_code)
        active = self.active.get(code or "", [])
        return {
            "mixer": self.mixer.get(code or ""),
            "levels": self.levels.get(code or "", {}),
            "active_speakers": await self._active_payload(str(room_id), active),
        }

    def device_live(self, device_id: str, device_code: Optional[str] = None) -> Optional[Dict[str, Any]]:
        return self.device_state.get(device_id) or (self.device_state.get(device_code) if device_code else None)


live_hub = LiveHub()
