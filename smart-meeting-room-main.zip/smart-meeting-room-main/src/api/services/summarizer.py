"""Ringkasan notulensi dengan LLM lokal (Ollama).

- Endpoint: ``POST {OLLAMA_BASE_URL}/api/chat`` (stream=false, temperature 0.2)
  dengan ``format`` = JSON schema (structured outputs Ollama >= 0.5); bila server
  Ollama lama menolak schema, otomatis mencoba ulang dengan ``format: "json"``.
- Transkrip dibentuk sebagai baris ``[mm:ss] Nama: teks``.
- Transkrip panjang: map-reduce per ±6000 token (estimasi 4 karakter/token):
  tiap bagian diringkas, lalu ringkasan bagian digabung menjadi satu.
- Tidak ada ringkasan palsu: bila Ollama tidak bisa dihubungi / model belum
  diunduh, dilempar `SummarizerError` (503) dengan pesan jelas.
"""
from __future__ import annotations

import json
import logging
import re
from datetime import date
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import httpx
from pydantic import BaseModel, Field, field_validator

from src.api.config import settings

log = logging.getLogger("smr.summarizer")

CHUNK_TOKENS = 6000
CHARS_PER_TOKEN = 4
CHUNK_CHARS = CHUNK_TOKENS * CHARS_PER_TOKEN


class SummarizerError(Exception):
    def __init__(self, message: str, status_code: int = 503, code: str = "LLM_UNAVAILABLE"):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.code = code


# ---------------------------------------------------------------------------
# Skema hasil
# ---------------------------------------------------------------------------
def _clean_str(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, (dict, list)):
        v = json.dumps(v, ensure_ascii=False)
    return re.sub(r"[ \t]+", " ", str(v)).strip()


def _as_list(v: Any) -> List[Any]:
    if v is None:
        return []
    if isinstance(v, list):
        return v
    if isinstance(v, str):
        return [v] if v.strip() else []
    return [v]


class PokokBahasan(BaseModel):
    judul: str = ""
    uraian: str = ""


class TindakLanjut(BaseModel):
    tugas: str
    pic: Optional[str] = None
    tenggat: Optional[str] = None  # YYYY-MM-DD

    @field_validator("tenggat", mode="before")
    @classmethod
    def _norm_date(cls, v: Any) -> Optional[str]:
        if v is None:
            return None
        s = str(v).strip()
        m = re.search(r"(\d{4})-(\d{2})-(\d{2})", s)
        if not m:
            return None
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3))).isoformat()
        except ValueError:
            return None

    @field_validator("pic", mode="before")
    @classmethod
    def _norm_pic(cls, v: Any) -> Optional[str]:
        s = _clean_str(v)
        return s if s and s.lower() not in ("-", "null", "none", "tidak ada", "n/a") else None


class SummaryResult(BaseModel):
    ringkasan: str = ""
    pokok_bahasan: List[PokokBahasan] = Field(default_factory=list)
    keputusan: List[str] = Field(default_factory=list)
    tindak_lanjut: List[TindakLanjut] = Field(default_factory=list)
    peserta_aktif: List[str] = Field(default_factory=list)


SUMMARY_JSON_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "ringkasan": {"type": "string"},
        "pokok_bahasan": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {"judul": {"type": "string"}, "uraian": {"type": "string"}},
                "required": ["judul", "uraian"],
            },
        },
        "keputusan": {"type": "array", "items": {"type": "string"}},
        "tindak_lanjut": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "tugas": {"type": "string"},
                    "pic": {"type": ["string", "null"]},
                    "tenggat": {"type": ["string", "null"]},
                },
                "required": ["tugas", "pic", "tenggat"],
            },
        },
        "peserta_aktif": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["ringkasan", "pokok_bahasan", "keputusan", "tindak_lanjut", "peserta_aktif"],
}


def normalize_summary(raw: Any) -> SummaryResult:
    """Validasi & rapikan JSON dari LLM (toleran terhadap variasi bentuk)."""
    if not isinstance(raw, dict):
        raise SummarizerError("Model AI mengembalikan format yang tidak valid (bukan objek JSON).", 502, "LLM_BAD_OUTPUT")
    ringkasan = raw.get("ringkasan") or raw.get("summary") or ""
    if isinstance(ringkasan, list):
        ringkasan = "\n\n".join(_clean_str(p) for p in ringkasan if _clean_str(p))
    pokok = []
    for item in _as_list(raw.get("pokok_bahasan")):
        if isinstance(item, dict):
            j, u = _clean_str(item.get("judul") or item.get("topik")), _clean_str(item.get("uraian") or item.get("isi"))
        else:
            j, u = _clean_str(item), ""
        if j or u:
            pokok.append(PokokBahasan(judul=j or "Pembahasan", uraian=u))
    keputusan = []
    for k in _as_list(raw.get("keputusan")):
        if isinstance(k, dict):
            k = k.get("keputusan") or k.get("isi") or k.get("teks") or " ".join(_clean_str(x) for x in k.values())
        s = _clean_str(k)
        if s:
            keputusan.append(s)
    tl = []
    for t in _as_list(raw.get("tindak_lanjut")):
        if isinstance(t, dict):
            tugas = _clean_str(t.get("tugas") or t.get("task"))
            if tugas:
                tl.append(TindakLanjut(tugas=tugas, pic=t.get("pic") or t.get("penanggung_jawab"),
                                       tenggat=t.get("tenggat") or t.get("deadline")))
        else:
            s = _clean_str(t)
            if s:
                tl.append(TindakLanjut(tugas=s))
    peserta = []
    for p in _as_list(raw.get("peserta_aktif")):
        s = _clean_str(p)
        if s and s not in peserta:
            peserta.append(s)
    return SummaryResult(ringkasan=str(ringkasan).strip(), pokok_bahasan=pokok, keputusan=keputusan,
                         tindak_lanjut=tl, peserta_aktif=peserta)


def parse_llm_json(content: str) -> Any:
    s = (content or "").strip()
    s = re.sub(r"^```(?:json)?\s*|\s*```$", "", s, flags=re.IGNORECASE)
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        a, b = s.find("{"), s.rfind("}")
        if a != -1 and b > a:
            try:
                return json.loads(s[a:b + 1])
            except json.JSONDecodeError:
                pass
    raise SummarizerError("Model AI mengembalikan JSON yang tidak valid. Coba ulangi.", 502, "LLM_BAD_OUTPUT")


# ---------------------------------------------------------------------------
# Transkrip -> teks & potongan
# ---------------------------------------------------------------------------
def fmt_ts(ms: int) -> str:
    s = max(0, int(ms or 0)) // 1000
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    return f"{h:d}:{m:02d}:{sec:02d}" if h else f"{m:02d}:{sec:02d}"


def build_transcript_lines(segments: Iterable[Any]) -> List[str]:
    """segments: objek/dict dengan start_ms, speaker_name, text."""
    lines = []
    for s in segments:
        get = s.get if isinstance(s, dict) else (lambda k, _s=s: getattr(_s, k, None))
        text = _clean_str(get("text"))
        if not text:
            continue
        lines.append(f"[{fmt_ts(get('start_ms') or 0)}] {_clean_str(get('speaker_name')) or 'Peserta'}: {text}")
    return lines


def chunk_lines(lines: Sequence[str], max_chars: int = CHUNK_CHARS) -> List[str]:
    chunks: List[str] = []
    cur: List[str] = []
    size = 0
    for line in lines:
        if len(line) > max_chars:  # baris sangat panjang: pecah paksa
            for i in range(0, len(line), max_chars):
                piece = line[i:i + max_chars]
                if cur:
                    chunks.append("\n".join(cur))
                    cur, size = [], 0
                chunks.append(piece)
            continue
        if size + len(line) + 1 > max_chars and cur:
            chunks.append("\n".join(cur))
            cur, size = [], 0
        cur.append(line)
        size += len(line) + 1
    if cur:
        chunks.append("\n".join(cur))
    return chunks


# ---------------------------------------------------------------------------
# Prompt
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = """Anda adalah notulis rapat profesional di instansi pemerintah/perusahaan Indonesia.
Tugas Anda menyusun notulen dari transkrip rapat dalam Bahasa Indonesia yang baku dan formal.

Aturan:
- Gunakan HANYA informasi yang ada di transkrip. Jangan mengarang nama, angka, tanggal, atau keputusan.
- Transkrip hasil speech-to-text bisa mengandung salah dengar; perbaiki ejaan yang jelas keliru tanpa mengubah makna.
- "ringkasan": 3-6 paragraf naratif (pisahkan paragraf dengan baris kosong) tentang jalannya rapat.
- "pokok_bahasan": daftar topik yang dibahas, masing-masing {"judul", "uraian"}.
- "keputusan": daftar keputusan/kesepakatan yang benar-benar disepakati di rapat (kosongkan bila tidak ada).
- "tindak_lanjut": daftar tugas {"tugas", "pic", "tenggat"}; "pic" = nama penanggung jawab bila disebut (atau null);
  "tenggat" = tanggal format YYYY-MM-DD bila disebut jelas (atau null).
- "peserta_aktif": nama pembicara yang aktif berbicara.
- Jawab HANYA dengan satu objek JSON valid sesuai skema, tanpa teks lain."""


def _meta_block(meta: Dict[str, Any]) -> str:
    parts = []
    for key, label in (("judul", "Judul rapat"), ("tanggal", "Tanggal"), ("waktu", "Waktu"),
                       ("tempat", "Tempat"), ("peserta", "Peserta terdaftar")):
        v = meta.get(key)
        if v:
            parts.append(f"{label}: {', '.join(v) if isinstance(v, list) else v}")
    return "\n".join(parts)


def _user_prompt_full(meta: Dict[str, Any], transcript: str) -> str:
    return f"{_meta_block(meta)}\n\nTRANSKRIP RAPAT:\n{transcript}\n\nSusun notulen dalam format JSON sesuai skema."


def _user_prompt_part(meta: Dict[str, Any], transcript: str, idx: int, total: int) -> str:
    return (f"{_meta_block(meta)}\n\nIni BAGIAN {idx} dari {total} transkrip rapat (bukan keseluruhan).\n"
            f"TRANSKRIP BAGIAN {idx}:\n{transcript}\n\n"
            "Buat ringkasan bagian ini dalam format JSON sesuai skema (ringkasan boleh 1-3 paragraf).")


def _user_prompt_merge(meta: Dict[str, Any], partials: List[SummaryResult]) -> str:
    body = json.dumps([p.model_dump() for p in partials], ensure_ascii=False, indent=1)
    return (f"{_meta_block(meta)}\n\nBerikut ringkasan per bagian dari satu rapat yang sama (urut waktu):\n{body}\n\n"
            "Gabungkan menjadi SATU notulen utuh dalam format JSON sesuai skema: ringkasan 3-6 paragraf, "
            "gabungkan pokok bahasan yang sama, hapus duplikasi keputusan & tindak lanjut.")


# ---------------------------------------------------------------------------
# Klien Ollama
# ---------------------------------------------------------------------------
class OllamaClient:
    def __init__(self, base_url: Optional[str] = None, model: Optional[str] = None,
                 timeout: Optional[float] = None, transport: Optional[httpx.AsyncBaseTransport] = None):
        self.base_url = (base_url or settings.OLLAMA_BASE_URL).rstrip("/")
        self.model = model or settings.OLLAMA_MODEL
        self.timeout = float(timeout or settings.OLLAMA_TIMEOUT_SECONDS)
        self.transport = transport

    def _client(self, timeout: Optional[float] = None) -> httpx.AsyncClient:
        t = httpx.Timeout(timeout or self.timeout, connect=10.0)
        return httpx.AsyncClient(base_url=self.base_url, timeout=t, transport=self.transport)

    def _unreachable(self, e: Exception) -> SummarizerError:
        return SummarizerError(
            f"Layanan AI (Ollama) tidak dapat dihubungi di {self.base_url}. "
            f"Pastikan Ollama berjalan (ollama serve). Detail: {type(e).__name__}", 503, "LLM_UNAVAILABLE")

    def _model_missing(self) -> SummarizerError:
        return SummarizerError(
            f"Model AI '{self.model}' belum diunduh di server Ollama. Jalankan: ollama pull {self.model}",
            503, "LLM_MODEL_MISSING")

    async def tags(self) -> List[str]:
        try:
            async with self._client(timeout=5.0) as c:
                r = await c.get("/api/tags")
                r.raise_for_status()
                return [m.get("name") or m.get("model") for m in r.json().get("models", [])]
        except (httpx.HTTPError, ValueError) as e:
            raise self._unreachable(e) from e

    def model_in(self, names: Iterable[str]) -> bool:
        want = self.model if ":" in self.model else f"{self.model}:latest"
        return any(n == self.model or n == want for n in names if n)

    async def status(self) -> Dict[str, Any]:
        try:
            names = await self.tags()
        except SummarizerError as e:
            return {"reachable": False, "base_url": self.base_url, "model": self.model,
                    "model_available": False, "error": e.message, "models": []}
        return {"reachable": True, "base_url": self.base_url, "model": self.model,
                "model_available": self.model_in(names), "error": None, "models": names}

    async def chat_json(self, system: str, user: str) -> Any:
        payload: Dict[str, Any] = {
            "model": self.model,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "stream": False,
            "format": SUMMARY_JSON_SCHEMA,
            "options": {"temperature": 0.2, "num_ctx": 16384},
        }
        async with self._client() as c:
            for attempt in range(3):
                try:
                    r = await c.post("/api/chat", json=payload)
                except httpx.TimeoutException as e:
                    raise SummarizerError(
                        f"Layanan AI (Ollama) tidak merespons dalam {int(self.timeout)} detik. "
                        "Coba lagi atau gunakan model yang lebih kecil.", 504, "LLM_TIMEOUT") from e
                except httpx.HTTPError as e:
                    raise self._unreachable(e) from e
                body_text = r.text[:500]
                if r.status_code == 404 and "not found" in body_text.lower():
                    raise self._model_missing()
                if r.status_code in (400, 500) and payload["format"] != "json" and "format" in body_text.lower():
                    payload["format"] = "json"  # Ollama lama: belum mendukung JSON schema
                    continue
                if r.status_code >= 400:
                    raise SummarizerError(f"Ollama mengembalikan error {r.status_code}: {body_text}", 502, "LLM_ERROR")
                try:
                    content = r.json().get("message", {}).get("content", "")
                    return parse_llm_json(content)
                except SummarizerError:
                    if attempt >= 1:
                        raise
                    continue  # coba sekali lagi
                except ValueError as e:
                    raise SummarizerError("Respons Ollama bukan JSON.", 502, "LLM_BAD_OUTPUT") from e
        raise SummarizerError("Model AI gagal menghasilkan JSON yang valid.", 502, "LLM_BAD_OUTPUT")


async def summarize_segments(
    segments: Sequence[Any], meta: Dict[str, Any], client: Optional[OllamaClient] = None,
    chunk_chars: int = CHUNK_CHARS,
) -> Tuple[SummaryResult, Dict[str, Any]]:
    """Ringkas transkrip. Mengembalikan (hasil, info {model, chunks})."""
    client = client or OllamaClient()
    lines = build_transcript_lines(segments)
    if not lines:
        raise SummarizerError("Belum ada transkrip untuk diringkas.", 400, "NO_TRANSCRIPT")
    chunks = chunk_lines(lines, chunk_chars)
    if len(chunks) == 1:
        result = normalize_summary(await client.chat_json(SYSTEM_PROMPT, _user_prompt_full(meta, chunks[0])))
        return result, {"model": client.model, "chunks": 1}

    partials: List[SummaryResult] = []
    for i, ch in enumerate(chunks, 1):
        partials.append(normalize_summary(await client.chat_json(SYSTEM_PROMPT, _user_prompt_part(meta, ch, i, len(chunks)))))
    # Reduce bertingkat bila gabungan ringkasan bagian masih terlalu panjang.
    while True:
        groups: List[List[SummaryResult]] = [[]]
        size = 0
        for p in partials:
            n = len(json.dumps(p.model_dump(), ensure_ascii=False))
            if groups[-1] and size + n > chunk_chars:
                groups.append([])
                size = 0
            groups[-1].append(p)
            size += n
        merged = [normalize_summary(await client.chat_json(SYSTEM_PROMPT, _user_prompt_merge(meta, g)))
                  if len(g) > 1 else g[0] for g in groups]
        if len(merged) == 1:
            return merged[0], {"model": client.model, "chunks": len(chunks)}
        if len(merged) >= len(partials):  # tidak menyusut (ringkasan bagian sangat besar)
            result = normalize_summary(await client.chat_json(SYSTEM_PROMPT, _user_prompt_merge(meta, merged)))
            return result, {"model": client.model, "chunks": len(chunks)}
        partials = merged
