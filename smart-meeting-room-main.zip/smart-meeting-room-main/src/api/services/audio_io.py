"""Utilitas audio untuk pipeline notulensi (decode, resample, potong).

Semua fungsi di sini sinkron (blocking) dan dipanggil lewat `asyncio.to_thread`
oleh `transcription.py`. Tidak ada state global selain pencarian `ffmpeg`.

Urutan decoder:
1. soundfile (libsndfile): WAV/FLAC/OGG — dipakai untuk segmen recorder.
2. ffmpeg (subprocess, argumen berupa list — tanpa shell): semua format
   (webm/opus dari browser, mp3, m4a, dst).
3. PyAV (terpasang bersama faster-whisper) bila binary ffmpeg tidak ada.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path
from typing import Optional

import numpy as np

SAMPLE_RATE = 16000

# Ekstensi file audio yang diterima dari unggahan (whitelist).
AUDIO_EXTENSIONS = {
    ".wav", ".flac", ".ogg", ".oga", ".opus", ".webm", ".mp3", ".m4a", ".mp4", ".aac", ".weba",
}
# Content-type yang diterima (selain audio/*).
EXTRA_CONTENT_TYPES = {
    "video/webm", "video/mp4", "video/ogg", "application/ogg", "application/octet-stream", "",
}


class AudioDecodeError(RuntimeError):
    """File audio tidak bisa dibaca/di-decode."""


def ffmpeg_path() -> Optional[str]:
    return shutil.which("ffmpeg")


def is_allowed_audio(filename: str, content_type: Optional[str]) -> bool:
    ext = Path(filename or "").suffix.lower()
    if ext not in AUDIO_EXTENSIONS:
        return False
    ct = (content_type or "").split(";")[0].strip().lower()
    return ct.startswith("audio/") or ct in EXTRA_CONTENT_TYPES


def to_mono(data: np.ndarray) -> np.ndarray:
    if data.ndim == 1:
        return data.astype(np.float32, copy=False)
    return data.mean(axis=1).astype(np.float32)


def resample(x: np.ndarray, sr_in: int, sr_out: int = SAMPLE_RATE) -> np.ndarray:
    """Resample sederhana. Rasio bulat (48k/32k -> 16k): rata-rata blok (low-pass
    kasar + decimate). Selain itu: interpolasi linear. Cukup untuk ucapan."""
    x = np.asarray(x, dtype=np.float32)
    if sr_in == sr_out or x.size == 0:
        return x
    if sr_in > sr_out and sr_in % sr_out == 0:
        f = sr_in // sr_out
        n = (x.size // f) * f
        return x[:n].reshape(-1, f).mean(axis=1).astype(np.float32)
    n_out = int(round(x.size * sr_out / sr_in))
    if n_out <= 0:
        return np.zeros(0, dtype=np.float32)
    t_in = np.arange(x.size, dtype=np.float64) / sr_in
    t_out = np.arange(n_out, dtype=np.float64) / sr_out
    return np.interp(t_out, t_in, x).astype(np.float32)


def _decode_ffmpeg_pipe(path: str) -> np.ndarray:
    exe = ffmpeg_path()
    if not exe:
        raise AudioDecodeError("ffmpeg tidak ditemukan")
    cmd = [exe, "-nostdin", "-hide_banner", "-loglevel", "error", "-i", str(path),
           "-ac", "1", "-ar", str(SAMPLE_RATE), "-f", "s16le", "-"]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=600)
    if proc.returncode != 0:
        raise AudioDecodeError(f"ffmpeg gagal decode audio: {proc.stderr.decode(errors='ignore')[-300:]}")
    return np.frombuffer(proc.stdout, dtype=np.int16).astype(np.float32) / 32768.0


def _decode_pyav(path: str) -> np.ndarray:
    try:
        from faster_whisper.audio import decode_audio  # memakai PyAV
    except Exception as e:  # pragma: no cover - tergantung instalasi
        raise AudioDecodeError(
            "ffmpeg tidak ditemukan di server dan PyAV tidak tersedia. "
            "Pasang ffmpeg (lihat docs/modules/11_NOTULENSI.md)."
        ) from e
    try:
        return np.asarray(decode_audio(str(path), sampling_rate=SAMPLE_RATE), dtype=np.float32)
    except Exception as e:
        raise AudioDecodeError(f"Gagal decode audio: {e}") from e


def read_audio_16k(path: str) -> np.ndarray:
    """Baca file audio pendek -> float32 mono 16 kHz."""
    out = None
    try:
        import soundfile as sf
        data, sr = sf.read(str(path), dtype="float32", always_2d=False)
        out = resample(to_mono(np.asarray(data)), int(sr))
    except Exception:
        out = None
    if out is None:
        out = _decode_ffmpeg_pipe(path) if ffmpeg_path() else _decode_pyav(path)
    if out.size == 0:
        raise AudioDecodeError("audio kosong atau format tidak dikenali")
    return out


def convert_to_wav16k(src: str, dst: str) -> float:
    """Konversi file (panjang) ke WAV PCM16 mono 16 kHz di disk, tanpa memuat
    seluruh file ke memori. Mengembalikan durasi (detik)."""
    dur = _convert_to_wav16k(src, dst)
    if not dur or dur <= 0:
        raise AudioDecodeError("audio kosong atau format tidak dikenali")
    return dur


def _convert_to_wav16k(src: str, dst: str) -> float:
    import soundfile as sf

    Path(dst).parent.mkdir(parents=True, exist_ok=True)
    exe = ffmpeg_path()
    if exe:
        cmd = [exe, "-nostdin", "-hide_banner", "-loglevel", "error", "-y", "-i", str(src),
               "-vn", "-ac", "1", "-ar", str(SAMPLE_RATE), "-c:a", "pcm_s16le", str(dst)]
        proc = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=3600)
        if proc.returncode != 0:
            raise AudioDecodeError(f"ffmpeg gagal konversi audio: {proc.stderr.decode(errors='ignore')[-300:]}")
        return sf.info(str(dst)).duration

    # Tanpa ffmpeg: libsndfile untuk WAV/FLAC/OGG (dibaca per blok) ...
    try:
        info = sf.info(str(src))
    except Exception:
        info = None
    if info is not None:
        with sf.SoundFile(str(dst), "w", samplerate=SAMPLE_RATE, channels=1, subtype="PCM_16") as out:
            block = int(info.samplerate) * 30
            for chunk in sf.blocks(str(src), blocksize=block, dtype="float32", always_2d=True):
                out.write(resample(to_mono(chunk), int(info.samplerate)))
        return sf.info(str(dst)).duration

    # ... lalu PyAV (streaming, resampler bawaan) untuk format lain.
    try:
        import av  # type: ignore
    except Exception as e:
        raise AudioDecodeError(
            "ffmpeg tidak ditemukan di server; format ini butuh ffmpeg. "
            "Pasang ffmpeg lalu ulangi (lihat docs/modules/11_NOTULENSI.md)."
        ) from e
    try:
        with av.open(str(src)) as container, \
                sf.SoundFile(str(dst), "w", samplerate=SAMPLE_RATE, channels=1, subtype="PCM_16") as out:
            resampler = av.audio.resampler.AudioResampler(format="s16", layout="mono", rate=SAMPLE_RATE)
            stream = next((s for s in container.streams if s.type == "audio"), None)
            if stream is None:
                raise AudioDecodeError("File tidak memiliki stream audio")
            for frame in container.decode(stream):
                for rf in resampler.resample(frame) or []:
                    out.write(rf.to_ndarray().reshape(-1).astype(np.int16))
            for rf in resampler.resample(None) or []:
                out.write(rf.to_ndarray().reshape(-1).astype(np.int16))
    except AudioDecodeError:
        raise
    except Exception as e:
        raise AudioDecodeError(f"Gagal decode audio: {e}") from e
    return sf.info(str(dst)).duration


def find_quiet_cut(x: np.ndarray, lo: int, hi: int, frame: int = SAMPLE_RATE // 10) -> int:
    """Cari indeks potong di [lo, hi] pada frame 100 ms dengan energi terendah,
    agar potongan file panjang tidak memotong kata di tengah."""
    lo = max(0, lo)
    hi = min(len(x), hi)
    if hi - lo < frame * 2:
        return hi
    best, best_e = hi, None
    for start in range(lo, hi - frame + 1, frame):
        e = float(np.mean(np.square(x[start:start + frame])))
        if best_e is None or e < best_e:
            best_e, best = e, start + frame // 2
    return best


def read_wav_range(path: str, start: int, frames: int) -> np.ndarray:
    import soundfile as sf
    with sf.SoundFile(str(path)) as f:
        f.seek(start)
        data = f.read(frames, dtype="float32", always_2d=False)
    return to_mono(np.asarray(data))


def wav_frames(path: str) -> int:
    import soundfile as sf
    return int(sf.info(str(path)).frames)


def rms_dbfs(x: np.ndarray) -> float:
    if x.size == 0:
        return -120.0
    rms = float(np.sqrt(np.mean(np.square(x, dtype=np.float64))))
    return 20.0 * np.log10(max(rms, 1e-6))


def safe_unlink(path: Optional[str]) -> None:
    if not path:
        return
    try:
        os.unlink(path)
    except OSError:
        pass
