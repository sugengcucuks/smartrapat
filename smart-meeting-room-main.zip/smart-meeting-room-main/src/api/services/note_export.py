"""Export notulensi: PDF (ReportLab), DOCX (python-docx), TXT, HTML.

Layout mengikuti format notulen rapat formal Indonesia:
kop instansi, judul "NOTULEN RAPAT", tabel identitas rapat (acara, hari/tanggal,
waktu, tempat, pimpinan rapat, notulis, peserta), ringkasan, pokok bahasan,
keputusan, tabel tindak lanjut, blok tanda tangan, dan lampiran transkrip (opsional).

Semua teks pengguna di-escape: `xml.sax.saxutils.escape` untuk Paragraph
ReportLab (mini-markup XML) dan `html.escape` untuk HTML.
"""
from __future__ import annotations

import html as html_lib
import io
import re
import unicodedata
from dataclasses import dataclass, field
from datetime import date, datetime, time
from typing import Any, Dict, List, Optional
from xml.sax.saxutils import escape as xml_escape

HARI = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]
BULAN = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus",
         "September", "Oktober", "November", "Desember"]
STATUS_LABEL = {"open": "Terbuka", "in_progress": "Berjalan", "done": "Selesai", "cancelled": "Dibatalkan"}


def tanggal_indo(d: Optional[date]) -> str:
    if not d:
        return "-"
    return f"{HARI[d.weekday()]}, {d.day} {BULAN[d.month - 1]} {d.year}"


def tanggal_pendek(d: Optional[Any]) -> str:
    if not d:
        return "-"
    if isinstance(d, str):
        try:
            d = date.fromisoformat(d[:10])
        except ValueError:
            return d
    return f"{d.day} {BULAN[d.month - 1]} {d.year}"


def jam(t: Optional[Any]) -> str:
    if t is None:
        return "-"
    if isinstance(t, (time, datetime)):
        return t.strftime("%H:%M")
    return str(t)[:5]


def fmt_ms(ms: int) -> str:
    s = max(0, int(ms or 0)) // 1000
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    return f"{h:d}:{m:02d}:{sec:02d}" if h else f"{m:02d}:{sec:02d}"


def safe_filename(title: str, ext: str) -> str:
    s = unicodedata.normalize("NFKD", title or "notulensi").encode("ascii", "ignore").decode()
    s = re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_").lower()[:50] or "notulensi"
    return f"notulensi_{s}.{ext}"


@dataclass
class ExportContext:
    org_name: str
    org_address: Optional[str]
    title: str
    tanggal: str
    waktu: str
    tempat: str
    pimpinan: Optional[str]
    notulis: Optional[str]
    peserta: List[str]
    ringkasan: str
    pokok_bahasan: List[Dict[str, str]]
    keputusan: List[str]
    tindak_lanjut: List[Dict[str, Any]]
    transcript: List[Dict[str, Any]] = field(default_factory=list)
    status: str = "draft"
    finalized_at: Optional[datetime] = None
    ai_model: Optional[str] = None


# ---------------------------------------------------------------------------
# TXT
# ---------------------------------------------------------------------------
def render_txt(c: ExportContext) -> bytes:
    L: List[str] = [c.org_name.upper()]
    if c.org_address:
        L.append(c.org_address)
    L += ["=" * 70, "NOTULEN RAPAT" + ("" if c.status == "final" else " (DRAFT)"), "=" * 70,
          f"Acara          : {c.title}", f"Hari/Tanggal   : {c.tanggal}", f"Waktu          : {c.waktu}",
          f"Tempat         : {c.tempat}", f"Pimpinan Rapat : {c.pimpinan or '-'}", f"Notulis        : {c.notulis or '-'}",
          f"Peserta Hadir  : {len(c.peserta)} orang"]
    for i, p in enumerate(c.peserta, 1):
        L.append(f"   {i}. {p}")
    L += ["", "I. RINGKASAN", c.ringkasan or "-", ""]
    L.append("II. POKOK BAHASAN")
    for i, p in enumerate(c.pokok_bahasan, 1):
        L.append(f"  {i}. {p.get('judul', '')}")
        if p.get("uraian"):
            L.append(f"     {p['uraian']}")
    if not c.pokok_bahasan:
        L.append("  -")
    L += ["", "III. KEPUTUSAN"]
    L += [f"  {i}. {k}" for i, k in enumerate(c.keputusan, 1)] or ["  -"]
    L += ["", "IV. TINDAK LANJUT"]
    for i, t in enumerate(c.tindak_lanjut, 1):
        L.append(f"  {i}. {t['tugas']} | PIC: {t.get('pic') or '-'} | Tenggat: {tanggal_pendek(t.get('tenggat'))} | {STATUS_LABEL.get(t.get('status'), t.get('status') or '-')}")
    if not c.tindak_lanjut:
        L.append("  -")
    if c.transcript:
        L += ["", "LAMPIRAN: TRANSKRIP"]
        for s in c.transcript:
            L.append(f"[{fmt_ms(s['start_ms'])}] {s.get('speaker_name') or 'Peserta'}: {s['text']}")
    return "\n".join(L).encode("utf-8")


# ---------------------------------------------------------------------------
# HTML
# ---------------------------------------------------------------------------
def render_html(c: ExportContext) -> bytes:
    e = lambda s: html_lib.escape(str(s or ""))  # noqa: E731
    peserta = "".join(f"<li>{e(p)}</li>" for p in c.peserta) or "<li>-</li>"
    pokok = "".join(f"<li><b>{e(p.get('judul'))}</b><br>{e(p.get('uraian'))}</li>" for p in c.pokok_bahasan) or "<li>-</li>"
    kep = "".join(f"<li>{e(k)}</li>" for k in c.keputusan) or "<li>-</li>"
    tl = "".join(
        f"<tr><td>{i}</td><td>{e(t['tugas'])}</td><td>{e(t.get('pic') or '-')}</td>"
        f"<td>{e(tanggal_pendek(t.get('tenggat')))}</td><td>{e(STATUS_LABEL.get(t.get('status'), t.get('status')))}</td></tr>"
        for i, t in enumerate(c.tindak_lanjut, 1)) or "<tr><td colspan=5>-</td></tr>"
    ringkasan = "".join(f"<p>{e(p)}</p>" for p in (c.ringkasan or "-").split("\n\n"))
    trans = ""
    if c.transcript:
        rows = "".join(f"<li><span class=ts>[{e(fmt_ms(s['start_ms']))}]</span> <b>{e(s.get('speaker_name') or 'Peserta')}</b>: {e(s['text'])}</li>" for s in c.transcript)
        trans = f"<h2>Lampiran: Transkrip</h2><ul class=tr>{rows}</ul>"
    doc = f"""<!DOCTYPE html><html lang="id"><head><meta charset="utf-8"><title>Notulen - {e(c.title)}</title>
<style>body{{font-family:'Times New Roman',serif;max-width:800px;margin:32px auto;color:#111;line-height:1.5}}
.kop{{text-align:center;border-bottom:3px double #000;padding-bottom:8px}}h1{{text-align:center;font-size:18px}}
table{{border-collapse:collapse;width:100%}}.id td{{padding:2px 6px;vertical-align:top}}
.tl td,.tl th{{border:1px solid #444;padding:4px 6px}}.ts{{color:#666;font-size:12px}}ul.tr{{list-style:none;padding:0}}</style>
</head><body><div class=kop><b>{e(c.org_name.upper())}</b><br>{e(c.org_address or '')}</div>
<h1>NOTULEN RAPAT{'' if c.status == 'final' else ' (DRAFT)'}</h1>
<table class=id><tr><td>Acara</td><td>:</td><td>{e(c.title)}</td></tr><tr><td>Hari/Tanggal</td><td>:</td><td>{e(c.tanggal)}</td></tr>
<tr><td>Waktu</td><td>:</td><td>{e(c.waktu)}</td></tr><tr><td>Tempat</td><td>:</td><td>{e(c.tempat)}</td></tr>
<tr><td>Pimpinan Rapat</td><td>:</td><td>{e(c.pimpinan or '-')}</td></tr><tr><td>Notulis</td><td>:</td><td>{e(c.notulis or '-')}</td></tr></table>
<h2>Peserta Hadir ({len(c.peserta)})</h2><ol>{peserta}</ol><h2>I. Ringkasan</h2>{ringkasan}
<h2>II. Pokok Bahasan</h2><ol>{pokok}</ol><h2>III. Keputusan</h2><ol>{kep}</ol>
<h2>IV. Tindak Lanjut</h2><table class=tl><tr><th>No</th><th>Tugas</th><th>PIC</th><th>Tenggat</th><th>Status</th></tr>{tl}</table>
{trans}</body></html>"""
    return doc.encode("utf-8")


# ---------------------------------------------------------------------------
# PDF (ReportLab)
# ---------------------------------------------------------------------------
def _p(text: Any) -> str:
    """Escape teks pengguna untuk Paragraph ReportLab; baris baru -> <br/>."""
    return xml_escape(str(text if text is not None else "")).replace("\n", "<br/>")


def render_pdf(c: ExportContext) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import (HRFlowable, KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table,
                                    TableStyle)

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=2.5 * cm, rightMargin=2 * cm, topMargin=2 * cm,
                            bottomMargin=2 * cm, title=f"Notulen - {c.title}", author=c.org_name)
    ss = getSampleStyleSheet()
    base = ParagraphStyle("base", parent=ss["Normal"], fontName="Times-Roman", fontSize=11, leading=15)
    just = ParagraphStyle("just", parent=base, alignment=TA_JUSTIFY)
    kop = ParagraphStyle("kop", parent=base, fontName="Times-Bold", fontSize=14, alignment=TA_CENTER, leading=17)
    kop2 = ParagraphStyle("kop2", parent=base, fontSize=10, alignment=TA_CENTER)
    h1 = ParagraphStyle("h1", parent=base, fontName="Times-Bold", fontSize=13, alignment=TA_CENTER, spaceBefore=8, spaceAfter=8)
    h2 = ParagraphStyle("h2", parent=base, fontName="Times-Bold", fontSize=11.5, spaceBefore=10, spaceAfter=4)
    small = ParagraphStyle("small", parent=base, fontSize=9.5, leading=12)

    story: List[Any] = [Paragraph(_p(c.org_name.upper()), kop)]
    if c.org_address:
        story.append(Paragraph(_p(c.org_address), kop2))
    story += [Spacer(1, 4), HRFlowable(width="100%", thickness=2, color=colors.black), Spacer(1, 2),
              HRFlowable(width="100%", thickness=0.6, color=colors.black),
              Paragraph("NOTULEN RAPAT" + ("" if c.status == "final" else " (DRAFT)"), h1)]

    ident = [["Acara", ":", Paragraph(_p(c.title), base)],
             ["Hari/Tanggal", ":", Paragraph(_p(c.tanggal), base)],
             ["Waktu", ":", Paragraph(_p(c.waktu), base)],
             ["Tempat", ":", Paragraph(_p(c.tempat), base)],
             ["Pimpinan Rapat", ":", Paragraph(_p(c.pimpinan or "-"), base)],
             ["Notulis", ":", Paragraph(_p(c.notulis or "-"), base)],
             ["Peserta Hadir", ":", Paragraph(_p(f"{len(c.peserta)} orang (daftar terlampir di bawah)" if c.peserta else "-"), base)]]
    t = Table(ident, colWidths=[3.5 * cm, 0.4 * cm, None])
    t.setStyle(TableStyle([("FONT", (0, 0), (1, -1), "Times-Roman", 11), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 1), ("TOPPADDING", (0, 0), (-1, -1), 1)]))
    story.append(t)

    if c.peserta:
        story.append(Paragraph("Daftar Peserta Hadir", h2))
        half = (len(c.peserta) + 1) // 2
        rows = []
        for i in range(half):
            left = f"{i + 1}. {c.peserta[i]}"
            j = i + half
            right = f"{j + 1}. {c.peserta[j]}" if j < len(c.peserta) else ""
            rows.append([Paragraph(_p(left), base), Paragraph(_p(right), base)])
        pt = Table(rows, colWidths=["50%", "50%"])
        pt.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("TOPPADDING", (0, 0), (-1, -1), 0),
                                ("BOTTOMPADDING", (0, 0), (-1, -1), 1)]))
        story.append(pt)

    story.append(Paragraph("I. Ringkasan", h2))
    for para in (c.ringkasan or "-").split("\n\n"):
        if para.strip():
            story.append(Paragraph(_p(para.strip()), just))
            story.append(Spacer(1, 4))

    story.append(Paragraph("II. Pokok Bahasan", h2))
    if c.pokok_bahasan:
        for i, pb in enumerate(c.pokok_bahasan, 1):
            story.append(Paragraph(f"{i}. <b>{_p(pb.get('judul'))}</b>", base))
            if pb.get("uraian"):
                story.append(Paragraph(_p(pb["uraian"]), ParagraphStyle("ind", parent=just, leftIndent=14)))
            story.append(Spacer(1, 3))
    else:
        story.append(Paragraph("-", base))

    story.append(Paragraph("III. Keputusan", h2))
    for i, k in enumerate(c.keputusan, 1):
        story.append(Paragraph(f"{i}. {_p(k)}", ParagraphStyle("kl", parent=just, leftIndent=14, firstLineIndent=-14)))
    if not c.keputusan:
        story.append(Paragraph("-", base))

    story.append(Paragraph("IV. Tindak Lanjut", h2))
    rows = [[Paragraph("<b>No</b>", small), Paragraph("<b>Tugas</b>", small), Paragraph("<b>PIC</b>", small),
             Paragraph("<b>Tenggat</b>", small), Paragraph("<b>Status</b>", small)]]
    for i, tl in enumerate(c.tindak_lanjut, 1):
        rows.append([Paragraph(str(i), small), Paragraph(_p(tl["tugas"]), small), Paragraph(_p(tl.get("pic") or "-"), small),
                     Paragraph(_p(tanggal_pendek(tl.get("tenggat"))), small),
                     Paragraph(_p(STATUS_LABEL.get(tl.get("status"), tl.get("status") or "-")), small)])
    if len(rows) == 1:
        rows.append([Paragraph("-", small), Paragraph("Tidak ada tindak lanjut", small), "", "", ""])
    tt = Table(rows, colWidths=[1 * cm, 7.2 * cm, 3.3 * cm, 2.6 * cm, 2.2 * cm], repeatRows=1)
    tt.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.black), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e5e7eb")),
                            ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story.append(tt)

    sign = Table([
        [Paragraph("Pimpinan Rapat,", ParagraphStyle("c", parent=base, alignment=TA_CENTER)),
         Paragraph("Notulis,", ParagraphStyle("c2", parent=base, alignment=TA_CENTER))],
        [Spacer(1, 50), Spacer(1, 50)],
        [Paragraph(f"<u>{_p(c.pimpinan or '....................')}</u>", ParagraphStyle("c3", parent=base, alignment=TA_CENTER)),
         Paragraph(f"<u>{_p(c.notulis or '....................')}</u>", ParagraphStyle("c4", parent=base, alignment=TA_CENTER))],
    ], colWidths=["50%", "50%"])
    story += [Spacer(1, 18), KeepTogether(sign)]

    if c.transcript:
        story += [Spacer(1, 16), HRFlowable(width="100%", thickness=0.5, color=colors.grey),
                  Paragraph("Lampiran: Transkrip Rapat", h2)]
        for s in c.transcript:
            story.append(Paragraph(
                f"<font color='#555555'>[{_p(fmt_ms(s['start_ms']))}]</font> <b>{_p(s.get('speaker_name') or 'Peserta')}</b>: {_p(s['text'])}",
                small))

    def _footer(canvas, d):
        canvas.saveState()
        canvas.setFont("Times-Italic", 8)
        foot = f"Notulen: {c.title[:80]} — halaman {d.page}"
        if c.status != "final":
            foot += " — DRAFT"
        canvas.drawRightString(A4[0] - 2 * cm, 1.2 * cm, foot)
        canvas.restoreState()

    doc.build(story, onFirstPage=_footer, onLaterPages=_footer)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# DOCX (python-docx)
# ---------------------------------------------------------------------------
def render_docx(c: ExportContext) -> bytes:
    from docx import Document
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Cm, Pt

    d = Document()
    for s in d.sections:
        s.left_margin, s.right_margin, s.top_margin, s.bottom_margin = Cm(2.5), Cm(2), Cm(2), Cm(2)
    st = d.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(11)

    def center(text: str, bold=False, size=11):
        p = d.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(text)
        r.bold = bold
        r.font.size = Pt(size)
        return p

    center(c.org_name.upper(), bold=True, size=14)
    if c.org_address:
        center(c.org_address, size=10)
    center("_" * 78)
    center("NOTULEN RAPAT" + ("" if c.status == "final" else " (DRAFT)"), bold=True, size=13)

    ident = [("Acara", c.title), ("Hari/Tanggal", c.tanggal), ("Waktu", c.waktu), ("Tempat", c.tempat),
             ("Pimpinan Rapat", c.pimpinan or "-"), ("Notulis", c.notulis or "-"),
             ("Peserta Hadir", f"{len(c.peserta)} orang" if c.peserta else "-")]
    t = d.add_table(rows=0, cols=3)
    for k, v in ident:
        row = t.add_row().cells
        row[0].text, row[1].text, row[2].text = k, ":", v
    for row in t.rows:
        row.cells[0].width, row.cells[1].width, row.cells[2].width = Cm(3.8), Cm(0.5), Cm(12)

    if c.peserta:
        d.add_heading("Daftar Peserta Hadir", level=2)
        for p in c.peserta:
            d.add_paragraph(p, style="List Number")

    d.add_heading("I. Ringkasan", level=2)
    for para in (c.ringkasan or "-").split("\n\n"):
        if para.strip():
            p = d.add_paragraph(para.strip())
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    d.add_heading("II. Pokok Bahasan", level=2)
    for pb in c.pokok_bahasan:
        p = d.add_paragraph(style="List Number 2")
        p.add_run(pb.get("judul") or "").bold = True
        if pb.get("uraian"):
            p.add_run("\n" + pb["uraian"])
    if not c.pokok_bahasan:
        d.add_paragraph("-")

    d.add_heading("III. Keputusan", level=2)
    for k in c.keputusan:
        d.add_paragraph(k, style="List Number 3")
    if not c.keputusan:
        d.add_paragraph("-")

    d.add_heading("IV. Tindak Lanjut", level=2)
    tt = d.add_table(rows=1, cols=5)
    tt.style = "Table Grid"
    tt.alignment = WD_TABLE_ALIGNMENT.CENTER
    for cell, h in zip(tt.rows[0].cells, ["No", "Tugas", "PIC", "Tenggat", "Status"]):
        cell.text = ""
        cell.paragraphs[0].add_run(h).bold = True
    for i, tl in enumerate(c.tindak_lanjut, 1):
        r = tt.add_row().cells
        r[0].text, r[1].text, r[2].text = str(i), tl["tugas"], tl.get("pic") or "-"
        r[3].text = tanggal_pendek(tl.get("tenggat"))
        r[4].text = STATUS_LABEL.get(tl.get("status"), tl.get("status") or "-")
    if not c.tindak_lanjut:
        r = tt.add_row().cells
        r[0].text, r[1].text = "-", "Tidak ada tindak lanjut"

    d.add_paragraph()
    sig = d.add_table(rows=3, cols=2)
    sig.alignment = WD_TABLE_ALIGNMENT.CENTER
    sig.cell(0, 0).text, sig.cell(0, 1).text = "Pimpinan Rapat,", "Notulis,"
    sig.cell(1, 0).text = sig.cell(1, 1).text = "\n\n\n"
    sig.cell(2, 0).text = c.pimpinan or "...................."
    sig.cell(2, 1).text = c.notulis or "...................."
    for row in sig.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    if c.transcript:
        d.add_page_break()
        d.add_heading("Lampiran: Transkrip Rapat", level=2)
        for s in c.transcript:
            p = d.add_paragraph()
            ts = p.add_run(f"[{fmt_ms(s['start_ms'])}] ")
            ts.font.size = Pt(9)
            p.add_run(f"{s.get('speaker_name') or 'Peserta'}: ").bold = True
            p.add_run(s["text"])

    buf = io.BytesIO()
    d.save(buf)
    return buf.getvalue()


RENDERERS = {
    "pdf": (render_pdf, "application/pdf"),
    "docx": (render_docx, "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    "txt": (render_txt, "text/plain; charset=utf-8"),
    "html": (render_html, "text/html; charset=utf-8"),
}
