from pydantic import BaseModel, Field
from typing import Optional, List
from uuid import UUID
from datetime import date, datetime, time

from src.api.schemas.user import SuccessResponse


class DoorDisplayCurrentMeeting(BaseModel):
    booking_id: UUID
    title: str
    participants_count: int
    start_time: time
    end_time: time
    minutes_remaining: int
    host_name: str
    status: str


class DoorDisplayUpcomingMeeting(BaseModel):
    booking_id: UUID
    title: str
    start_time: time
    end_time: time
    host_name: str


class DoorDisplayRoomStatus(BaseModel):
    room_id: UUID
    room_name: str
    room_code: str
    capacity: int
    room_status: str
    current_meeting: Optional[DoorDisplayCurrentMeeting] = None
    next_upcoming: List[DoorDisplayUpcomingMeeting] = Field(default_factory=list)


class DoorDisplayBookingItem(BaseModel):
    booking_id: UUID
    title: str
    start_time: time
    end_time: time
    host_name: str
    status: str
    participants_count: int


class DoorDisplayTodayBookingsResponse(BaseModel):
    room_id: UUID
    room_name: str
    date: date
    bookings: List[DoorDisplayBookingItem]


class DoorDisplayCheckInResponse(BaseModel):
    participant_id: UUID
    name: str
    attended: bool
    checked_in_at: datetime


class DoorDisplayExtendResponse(BaseModel):
    booking_id: UUID
    title: str
    old_end_time: time
    new_end_time: time
    extended_minutes: int
