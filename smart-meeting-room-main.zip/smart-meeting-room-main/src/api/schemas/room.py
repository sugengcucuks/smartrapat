from pydantic import BaseModel, Field
from typing import Optional, List, Any
from uuid import UUID
from datetime import datetime

from src.api.schemas.user import SuccessResponse


class BuildingBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    code: str = Field(..., min_length=1, max_length=20)
    floors: int = Field(1, ge=1)
    address: Optional[str] = None


class BuildingCreate(BuildingBase):
    pass


class BuildingUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    code: Optional[str] = Field(None, min_length=1, max_length=20)
    floors: Optional[int] = Field(None, ge=1)
    address: Optional[str] = None


class BuildingResponse(BaseModel):
    id: UUID
    name: str
    code: str
    floors: Optional[int] = None
    address: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class RoomBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    code: str = Field(..., min_length=1, max_length=20)
    building_id: Optional[UUID] = None
    floor: int = Field(1, ge=1)
    capacity: int = Field(10, ge=1)
    room_type: str = Field("meeting", pattern="^(meeting|training|aula|office)$")
    description: Optional[str] = None
    amenities: Optional[List[str]] = Field(default_factory=list)
    layout_url: Optional[str] = Field(None, max_length=500)
    status: str = Field("available", pattern="^(available|maintenance|disabled)$")


class RoomCreate(RoomBase):
    pass


class RoomUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    code: Optional[str] = Field(None, min_length=1, max_length=20)
    building_id: Optional[UUID] = None
    floor: Optional[int] = Field(None, ge=1)
    capacity: Optional[int] = Field(None, ge=1)
    room_type: Optional[str] = Field(None, pattern="^(meeting|training|aula|office)$")
    description: Optional[str] = None
    amenities: Optional[List[str]] = None
    layout_url: Optional[str] = Field(None, max_length=500)
    status: Optional[str] = Field(None, pattern="^(available|maintenance|disabled)$")


class RoomResponse(BaseModel):
    id: UUID
    name: str
    code: str
    building_id: Optional[UUID] = None
    building_name: Optional[str] = None
    floor: Optional[int] = None
    capacity: int
    room_type: str
    description: Optional[str] = None
    amenities: List[str] = Field(default_factory=list)
    layout_url: Optional[str] = None
    status: str
    pairing_key: Optional[str] = None
    has_master_pin: bool = False
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ============================================
# Kiosk Security (ADM-03 / ADM-04 / DSP-07 / DSP-09)
# ============================================

class PairingKeyResponse(BaseModel):
    room_id: UUID
    room_code: str
    pairing_key: str


class MasterPinSetRequest(BaseModel):
    # PIN baru minimal 6 digit (PIN lama 4-5 digit tetap bisa dipakai sampai diganti).
    pin: str = Field(..., min_length=6, max_length=8, pattern="^[0-9]{6,8}$")


class MasterPinResponse(BaseModel):
    room_id: UUID
    room_code: str
    has_master_pin: bool
    message: str


class KioskPairRequest(BaseModel):
    room_code: str = Field(..., min_length=1, max_length=20)
    pairing_key: str = Field(..., min_length=4, max_length=20)


class EarlyReleaseRequest(BaseModel):
    pin: str = Field(..., min_length=4, max_length=8, pattern="^[0-9]{4,8}$")


class PaginatedRoomsResponse(BaseModel):
    items: List[RoomResponse]
    total: int
    page: int
    per_page: int
    total_pages: int
