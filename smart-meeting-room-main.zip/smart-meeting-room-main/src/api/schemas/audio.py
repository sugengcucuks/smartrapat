from pydantic import BaseModel, Field
from typing import Optional, List, Any
from uuid import UUID
from datetime import datetime

from src.api.schemas.user import SuccessResponse


class AudioZoneBase(BaseModel):
    room_id: UUID
    device_id: Optional[UUID] = None
    zone_name: str = Field(..., min_length=1, max_length=100)
    volume: int = Field(60, ge=0, le=100)
    is_muted: bool = False
    input_source: str = Field("mic1", pattern="^(mic1|mic2|line1|bluetooth|hdmi|usb)$")


class AudioZoneCreate(AudioZoneBase):
    pass


class AudioZoneUpdate(BaseModel):
    room_id: Optional[UUID] = None
    device_id: Optional[UUID] = None
    zone_name: Optional[str] = Field(None, min_length=1, max_length=100)
    volume: Optional[int] = Field(None, ge=0, le=100)
    is_muted: Optional[bool] = None
    input_source: Optional[str] = Field(None, pattern="^(mic1|mic2|line1|bluetooth|hdmi|usb)$")


class AudioZoneResponse(BaseModel):
    id: UUID
    room_id: UUID
    room_name: Optional[str] = None
    device_id: Optional[UUID] = None
    device_name: Optional[str] = None
    zone_name: str
    volume: int
    is_muted: bool
    input_source: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
