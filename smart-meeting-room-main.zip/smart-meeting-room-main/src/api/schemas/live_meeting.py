"""Skema request denah kursi, penugasan kursi, dan state live meeting."""
from typing import Any, Dict, List, Literal, Optional
from uuid import UUID

from pydantic import BaseModel, Field, field_validator

SeatType = Literal["chair", "delegate", "secretary", "guest", "operator"]
LayoutType = Literal["u_shape", "boardroom", "classroom", "circle"]


class SeatItem(BaseModel):
    id: Optional[UUID] = None
    seat_no: int = Field(..., ge=1, le=999)
    label: str = Field(..., min_length=1, max_length=50)
    seat_type: SeatType = "delegate"
    pos_x: float = Field(50, ge=0, le=100)
    pos_y: float = Field(50, ge=0, le=100)
    rotation: int = Field(0, ge=-360, le=360)
    audio_channel_id: Optional[UUID] = None

    @field_validator("label")
    @classmethod
    def _strip_label(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Label kursi wajib diisi")
        return v


class SeatLayoutTable(BaseModel):
    shape: Literal["rect", "ellipse", "u"]
    x: float = Field(..., ge=0, le=100)
    y: float = Field(..., ge=0, le=100)
    w: float = Field(..., ge=0, le=100)
    h: float = Field(..., ge=0, le=100)
    tx: Optional[float] = Field(None, ge=0, le=100)  # tebal lengan meja U (sumbu x)
    ty: Optional[float] = Field(None, ge=0, le=100)  # tebal alas meja U (sumbu y)
    label: Optional[str] = Field(None, max_length=50)


class SeatLayout(BaseModel):
    type: Literal["u_shape", "boardroom", "classroom", "circle", "custom"] = "custom"
    tables: List[SeatLayoutTable] = Field(default_factory=list, max_length=100)


class SeatBatchUpdate(BaseModel):
    items: List[SeatItem] = Field(default_factory=list, max_length=200)
    # None = bentuk meja tidak diubah.
    layout: Optional[SeatLayout] = None


class SeatGenerateRequest(BaseModel):
    layout: LayoutType = "u_shape"
    count: int = Field(16, ge=1, le=64)
    chair_count: int = Field(1, ge=0, le=4)
    link_channels: bool = True


class SeatAssignmentItem(BaseModel):
    seat_id: UUID
    participant_id: Optional[UUID] = None
    display_name: Optional[str] = Field(None, max_length=200)
    role_label: Optional[str] = Field(None, max_length=50)


class SeatAssignmentBatch(BaseModel):
    items: List[SeatAssignmentItem] = Field(default_factory=list, max_length=200)
    # True: kursi yang tidak disebut di `items` dikosongkan.
    replace: bool = False


class SeatAutoAssignRequest(BaseModel):
    strategy: Literal["attended_first", "all"] = "attended_first"


class MeetingExtendRequest(BaseModel):
    minutes: int = Field(..., ge=5, le=120)


Json = Dict[str, Any]
