from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from uuid import UUID
from datetime import date, datetime, time

from src.api.schemas.user import SuccessResponse


class DashboardSummaryResponse(BaseModel):
    total_rooms: int
    total_users: int
    today_bookings: int
    ongoing_meetings: int
    online_devices: int
    pending_approvals: int
    room_utilization_percent: float
    avg_meeting_duration_minutes: float


class BookingPerStatusItem(BaseModel):
    status: str
    count: int


class BookingPerRoomItem(BaseModel):
    room_id: UUID
    room_name: str
    count: int


class BookingPerDayItem(BaseModel):
    date: date
    count: int


class BookingsReportResponse(BaseModel):
    total_bookings: int
    per_status: List[BookingPerStatusItem]
    per_room: List[BookingPerRoomItem]
    per_day: List[BookingPerDayItem]
    from_date: Optional[date] = None
    to_date: Optional[date] = None


class BookingsReportDownloadResponse(BaseModel):
    format: str
    download_url: str
    expires_at: datetime


class RoomUtilizationItem(BaseModel):
    room_id: UUID
    room_name: str
    total_hours_available: float
    total_hours_booked: float
    utilization_percent: float
    booking_count: int


class AttendanceParticipantItem(BaseModel):
    participant_id: UUID
    user_id: Optional[UUID] = None
    name: str
    email: Optional[str] = None
    is_guest: bool
    attended: bool
    checked_in_at: Optional[datetime] = None


class AttendanceReportResponse(BaseModel):
    booking_id: UUID
    booking_title: str
    date: date
    start_time: time
    end_time: time
    total_participants: int
    attended_count: int
    absent_count: int
    participants: List[AttendanceParticipantItem]


class EquipmentInventoryItem(BaseModel):
    category: str
    total: int
    active: int
    maintenance: int
    broken: int
    disposed: int


class EquipmentInventoryResponse(BaseModel):
    items: List[EquipmentInventoryItem]
    grand_total: int


class ExportAllResponse(BaseModel):
    format: str
    download_url: str
    expires_at: datetime
    size_bytes: int
