"""Skema Pencarian Lintas Rapat (FTS Postgres)."""
from pydantic import BaseModel
from typing import Any, Dict, List, Optional
from uuid import UUID
from datetime import date as Date

# Catatan: alias `Date` dipakai agar tidak bentrok dengan field bernama `date`;
# assignment default `= None` pada field `date` akan menimpa nama `date` di
# scope class body dan merusak anotasi field berikutnya (gotcha pydantic).


class SearchNoteItem(BaseModel):
    id: UUID
    note_id: UUID
    booking_id: Optional[UUID] = None
    title: str
    booking_title: Optional[str] = None
    date: Optional[Date] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    snippet: str = ""
    rank: float = 0.0


class SearchTranscriptItem(BaseModel):
    id: UUID
    note_id: UUID
    booking_id: Optional[UUID] = None
    note_title: Optional[str] = None
    booking_title: Optional[str] = None
    date: Optional[Date] = None
    speaker_name: Optional[str] = None
    start_ms: int = 0
    snippet: str = ""
    rank: float = 0.0


class SearchActionItem(BaseModel):
    id: UUID
    note_id: UUID
    booking_id: Optional[UUID] = None
    note_title: Optional[str] = None
    booking_title: Optional[str] = None
    date: Optional[Date] = None
    task: str
    owner: Optional[str] = None
    due_date: Optional[Date] = None
    status: str = "open"
    source: str = "manual"


class SearchCounts(BaseModel):
    notes: int = 0
    transcripts: int = 0
    actions: int = 0
    total: int = 0


class SearchResponse(BaseModel):
    query: str
    counts: SearchCounts
    results: Dict[str, List[Any]]
