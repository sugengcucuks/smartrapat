from pydantic import BaseModel, Field
from typing import Optional, List, Any, Dict
from uuid import UUID
from datetime import datetime

from src.api.schemas.user import SuccessResponse


class NotificationCreate(BaseModel):
    user_id: UUID
    type: str = Field("info", pattern="^(info|success|warning|error|booking_request|booking_approved|booking_rejected|booking_cancelled|meeting_started|action_item_due)$")
    title: str = Field(..., min_length=1, max_length=200)
    message: Optional[str] = None
    data: Optional[Dict[str, Any]] = Field(default_factory=dict)


class NotificationSendMany(BaseModel):
    user_ids: List[UUID]
    type: str = Field("info", pattern="^(info|success|warning|error|booking_request|booking_approved|booking_rejected|booking_cancelled|meeting_started|action_item_due)$")
    title: str = Field(..., min_length=1, max_length=200)
    message: Optional[str] = None
    data: Optional[Dict[str, Any]] = Field(default_factory=dict)


class NotificationBroadcast(BaseModel):
    type: str = Field("info", pattern="^(info|success|warning|error|booking_request|booking_approved|booking_rejected|booking_cancelled|meeting_started|action_item_due)$")
    title: str = Field(..., min_length=1, max_length=200)
    message: Optional[str] = None
    data: Optional[Dict[str, Any]] = Field(default_factory=dict)


class NotificationResponse(BaseModel):
    id: UUID
    user_id: UUID
    type: str
    title: str
    message: Optional[str] = None
    data: Optional[Dict[str, Any]] = None
    is_read: bool
    read_at: Optional[datetime] = None
    created_at: datetime

    class Config:
        from_attributes = True


class PaginatedNotificationsResponse(BaseModel):
    items: List[NotificationResponse]
    total: int
    page: int
    per_page: int
    total_pages: int
    unread_count: int
