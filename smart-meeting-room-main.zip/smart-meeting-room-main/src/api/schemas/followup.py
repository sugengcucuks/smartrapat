"""Skema Dashboard Tindak Lanjut lintas rapat."""
from pydantic import BaseModel, Field, model_validator
from typing import Any, Dict, List, Optional
from uuid import UUID
from datetime import date, datetime


class FollowupItemResponse(BaseModel):
    id: UUID
    note_id: UUID
    booking_id: Optional[UUID] = None
    note_title: Optional[str] = None
    booking_title: Optional[str] = None
    meeting_date: Optional[date] = None
    room_name: Optional[str] = None
    task: str
    owner: Optional[str] = None
    assignee: Optional[str] = None  # alias owner (kompatibilitas FE)
    due_date: Optional[date] = None
    status: str = "open"
    source: str = "manual"
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class FollowupItemUpdate(BaseModel):
    task: Optional[str] = Field(None, min_length=1)
    owner: Optional[str] = Field(None, max_length=100)
    due_date: Optional[date] = None
    status: Optional[str] = Field(None, pattern="^(open|in_progress|done|cancelled)$")

    @model_validator(mode="before")
    @classmethod
    def _compat(cls, v: Any) -> Any:
        # Kompatibilitas FE: `assignee` -> owner.
        if isinstance(v, dict):
            v = dict(v)
            if not v.get("owner") and v.get("assignee"):
                v["owner"] = v.get("assignee")
            if v.get("due_date") == "":
                v["due_date"] = None
        return v


class FollowupOwnerStat(BaseModel):
    owner: str
    total: int


class FollowupSummary(BaseModel):
    total: int = 0
    open: int = 0
    in_progress: int = 0
    done: int = 0
    cancelled: int = 0
    overdue: int = 0
    due_today: int = 0
    due_this_week: int = 0
    by_owner: List[FollowupOwnerStat] = []


class FollowupItemsResponse(BaseModel):
    items: List[FollowupItemResponse]
    total: int
    page: int
    per_page: int
    total_pages: int
