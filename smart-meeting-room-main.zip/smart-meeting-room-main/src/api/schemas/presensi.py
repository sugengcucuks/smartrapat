from pydantic import BaseModel, Field
from typing import Optional, List
from uuid import UUID
from datetime import date, datetime, time

from src.api.schemas.user import SuccessResponse


class PresensiScanRequest(BaseModel):
    """Isi pemindaian QR atau kode tiket yang diketik manual."""

    code: str = Field(..., min_length=4, max_length=200)
    room_code: Optional[str] = None


class TicketItem(BaseModel):
    """Satu tiket presensi milik peserta."""

    participant_id: UUID
    booking_id: UUID
    ticket_code: str
    booking_title: str
    room_name: Optional[str] = None
    room_code: Optional[str] = None
    date: date
    start_time: time
    end_time: time
    booking_status: str
    attended: bool = False
    checked_in_at: Optional[datetime] = None
    attended_count: int = 0
    total_participants: int = 0


class MyTicketsResponse(BaseModel):
    items: List[TicketItem] = Field(default_factory=list)
    total: int = 0


class PresensiSeatInfo(BaseModel):
    """Kursi peserta pada denah ruangan (diisi otomatis saat presensi)."""

    seat_id: Optional[UUID] = None
    seat_no: int
    label: str


class PresensiScanResponse(BaseModel):
    """Hasil validasi scan tiket di kiosk presensi."""

    success: bool
    message: str
    participant_id: UUID
    participant_name: str
    booking_id: UUID
    booking_title: str
    room_name: Optional[str] = None
    attended: bool = True
    already_checked_in: bool = False
    checked_in_at: Optional[datetime] = None
    attended_count: int = 0
    total_participants: int = 0
    seat: Optional[PresensiSeatInfo] = None


class AttendanceParticipantItem(BaseModel):
    participant_id: UUID
    name: str
    is_guest: bool = False
    attended: bool = False
    checked_in_at: Optional[datetime] = None


class BookingAttendanceResponse(BaseModel):
    booking_id: UUID
    booking_title: str
    room_name: Optional[str] = None
    attended_count: int = 0
    total_participants: int = 0
    participants: List[AttendanceParticipantItem] = Field(default_factory=list)
