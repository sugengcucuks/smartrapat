from pydantic import BaseModel, Field, model_validator
from typing import Optional, List, Dict, Any
from uuid import UUID
from datetime import datetime, date, time

from src.api.schemas.user import SuccessResponse


_LEGACY_STATUS = {"pending": "open", "completed": "done"}


class ActionItemBase(BaseModel):
    id: Optional[UUID] = None
    task: str = Field(..., min_length=1)
    owner: Optional[str] = Field(None, max_length=100)
    due_date: Optional[date] = None
    status: str = Field("open", pattern="^(open|in_progress|done|cancelled)$")

    @model_validator(mode="before")
    @classmethod
    def _compat(cls, v: Any) -> Any:
        # Kompatibilitas FE lama: `assignee` -> owner, status pending/completed.
        if isinstance(v, dict):
            v = dict(v)
            if not v.get("owner") and v.get("assignee"):
                v["owner"] = v.get("assignee")
            st = v.get("status")
            if st in _LEGACY_STATUS:
                v["status"] = _LEGACY_STATUS[st]
            if v.get("due_date") == "":
                v["due_date"] = None
        return v


class ActionItemUpdate(BaseModel):
    task: Optional[str] = Field(None, min_length=1)
    owner: Optional[str] = Field(None, max_length=100)
    due_date: Optional[date] = None
    status: Optional[str] = Field(None, pattern="^(open|in_progress|done|cancelled)$")

    @model_validator(mode="before")
    @classmethod
    def _compat(cls, v: Any) -> Any:
        return ActionItemBase._compat(v)


class ActionItemResponse(BaseModel):
    id: UUID
    note_id: UUID
    task: str
    owner: Optional[str] = None
    assignee: Optional[str] = None  # alias owner (kompatibilitas FE)
    due_date: Optional[date] = None
    status: str
    source: str = "manual"
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class TranscriptLine(BaseModel):
    speaker: Optional[str] = None
    text: str
    timestamp: Optional[str] = None


class TranscriptSegment(BaseModel):
    id: Optional[str] = None
    speaker: Optional[str] = None
    speaker_id: Optional[str] = None
    text: str
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    confidence: Optional[float] = None
    language: Optional[str] = None
    is_edited: bool = False


class DecisionBase(BaseModel):
    id: Optional[UUID] = None
    decision: str
    made_by: Optional[str] = None
    timestamp: Optional[datetime] = None


class DecisionResponse(BaseModel):
    id: UUID
    note_id: UUID
    decision: str
    made_by: Optional[str] = None
    timestamp: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class RecordingStartRequest(BaseModel):
    booking_id: UUID
    room_id: UUID
    title: str
    use_ai_diarization: bool = True
    languages: Optional[List[str]] = Field(default_factory=lambda: ["id"])


class RecordingStatusResponse(BaseModel):
    recording_id: Optional[UUID] = None
    booking_id: Optional[UUID] = None
    status: str  # idle | recording | paused | completed
    started_at: Optional[datetime] = None
    stopped_at: Optional[datetime] = None
    duration_seconds: int = 0
    audio_level: Optional[float] = None
    current_speaker: Optional[str] = None
    segment_count: int = 0
    transcript_url: Optional[str] = None


class SummaryResponse(BaseModel):
    id: Optional[UUID] = None
    booking_id: Optional[UUID] = None
    summary: Optional[str] = None
    key_points: List[str] = Field(default_factory=list)
    decisions: List[str] = Field(default_factory=list)
    action_items: List[ActionItemBase] = Field(default_factory=list)
    participants: List[Dict[str, Any]] = Field(default_factory=list)
    language: str = "id"
    generated_by: Optional[str] = None
    generated_at: Optional[datetime] = None
    status: str = "idle"  # idle | processing | completed | failed


class SummarizeTriggerResponse(BaseModel):
    status: str
    estimated_time: int = 30
    message: str


class MeetingSummaryMeta(BaseModel):
    total_segments: int = 0
    total_duration: int = 0
    speakers: List[Dict[str, Any]] = Field(default_factory=list)


class MeetingNoteBase(BaseModel):
    booking_id: Optional[UUID] = None
    room_id: Optional[UUID] = None
    title: str = Field(..., min_length=1, max_length=200)
    date: date
    start_time: time
    end_time: time
    participants: Optional[List[str]] = Field(default_factory=list)
    summary: Optional[str] = None
    decisions: Optional[List[str]] = Field(default_factory=list)
    action_items: Optional[List[ActionItemBase]] = Field(default_factory=list)
    transcript: Optional[List[TranscriptLine]] = Field(default_factory=list)
    transcript_processing: bool = False
    ai_model: Optional[str] = None
    generated_at: Optional[datetime] = None


class MeetingNoteCreate(MeetingNoteBase):
    pass


class MeetingNoteUpdate(BaseModel):
    booking_id: Optional[UUID] = None
    room_id: Optional[UUID] = None
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    date: Optional[date] = None
    start_time: Optional[time] = None
    end_time: Optional[time] = None
    participants: Optional[List[str]] = None
    summary: Optional[str] = None
    decisions: Optional[List[str]] = None
    action_items: Optional[List[ActionItemBase]] = None
    transcript: Optional[List[TranscriptLine]] = None
    transcript_processing: Optional[bool] = None
    ai_model: Optional[str] = None
    generated_at: Optional[datetime] = None
    summary_json: Optional[Dict[str, Any]] = None


class MeetingNoteResponse(BaseModel):
    id: UUID
    booking_id: Optional[UUID] = None
    room_id: Optional[UUID] = None
    room_name: Optional[str] = None
    title: str
    date: date
    start_time: time
    end_time: time
    participants: List[str] = Field(default_factory=list)
    summary: Optional[str] = None
    decisions: List[str] = Field(default_factory=list)
    action_items: List[ActionItemResponse] = Field(default_factory=list)
    transcript: List[TranscriptLine] = Field(default_factory=list)
    transcript_processing: bool = False
    ai_model: Optional[str] = None
    generated_at: Optional[datetime] = None
    created_by: Optional[UUID] = None
    created_by_name: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    # migration 015/016
    status: str = "draft"
    summary_json: Optional[Dict[str, Any]] = None
    finalized_at: Optional[datetime] = None
    finalized_by: Optional[UUID] = None
    finalized_by_name: Optional[str] = None
    segment_count: int = 0
    booking_title: Optional[str] = None

    class Config:
        from_attributes = True


class SegmentCreate(BaseModel):
    text: str = Field(..., min_length=1)
    speaker_name: Optional[str] = Field(None, max_length=200)
    participant_id: Optional[UUID] = None
    start_ms: int = Field(0, ge=0)
    end_ms: Optional[int] = Field(None, ge=0)


class SegmentUpdate(BaseModel):
    text: Optional[str] = Field(None, min_length=1)
    speaker_name: Optional[str] = Field(None, max_length=200)
    participant_id: Optional[UUID] = None
    clear_participant: bool = False


class RecordingStartBody(BaseModel):
    source: str = Field("multichannel", pattern="^(multichannel|mix|browser)$")


class LegacyRecordingStart(BaseModel):
    booking_id: UUID
    source: str = Field("multichannel", pattern="^(multichannel|mix|browser)$")

    class Config:
        extra = "ignore"


class PaginatedNotesResponse(BaseModel):
    items: List[MeetingNoteResponse]
    total: int
    page: int
    per_page: int
    total_pages: int


class ExportResponse(BaseModel):
    download_url: str
    format: str
    filename: str


class QuickBookingRequest(BaseModel):
    title: str
    start_time: str
    duration_minutes: int = Field(30, ge=5, le=180)
    booked_by: Optional[str] = "Walk-in Guest"


class QuickBookingResponse(BaseModel):
    booking_id: UUID
    title: str
    room_id: UUID
    room_name: str
    start_time: time
    end_time: time
    status: str


class TimeSlot(BaseModel):
    start: str
    end: str
    available: bool
    booking_id: Optional[UUID] = None


class DoorAvailableSlotsResponse(BaseModel):
    room_id: UUID
    date: date
    slots: List[TimeSlot] = Field(default_factory=list)


class DoorCancelBookingResponse(BaseModel):
    booking_id: UUID
    title: str
    cancelled: bool
    message: str


class WelcomeMessageResponse(BaseModel):
    room_id: UUID
    title: str = "Selamat Datang"
    subtitle: Optional[str] = None
    custom_message: Optional[str] = None
    show_weather: bool = False
    show_clock: bool = True
