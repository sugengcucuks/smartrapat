from pydantic import BaseModel, Field
from typing import Optional, List

from src.api.schemas.user import SuccessResponse


class LicenseActivateRequest(BaseModel):
    """Isi berkas lisensi (satu baris teks) yang ditempel pengguna."""

    license_key: str = Field(..., min_length=20)


class LicenseInfo(BaseModel):
    license_id: str
    customer: str
    fingerprint: str = ""
    edition: str = "standard"
    issued_at: str = ""
    expires_at: Optional[str] = None
    max_rooms: int = 0
    max_users: int = 0
    features: List[str] = []
    notes: str = ""


class LicenseStatusResponse(BaseModel):
    enforced: bool
    activated: bool
    reason: str
    fingerprint: str
    license_file: str
    days_remaining: Optional[int] = None
    license: Optional[LicenseInfo] = None


__all__ = [
    "SuccessResponse",
    "LicenseActivateRequest",
    "LicenseInfo",
    "LicenseStatusResponse",
]
