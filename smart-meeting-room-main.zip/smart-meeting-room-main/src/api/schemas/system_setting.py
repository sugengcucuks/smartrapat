from pydantic import BaseModel, Field, model_validator
from typing import Optional, List, Dict, Any, Union
from uuid import UUID
from datetime import datetime

from src.api.schemas.user import SuccessResponse


class SystemSettingResponse(BaseModel):
    id: UUID
    setting_key: str
    setting_value: Optional[str] = None
    value_type: str
    description: Optional[str] = None
    group_name: Optional[str] = None
    is_public: bool
    updated_at: datetime
    updated_by: Optional[UUID] = None
    updated_by_name: Optional[str] = None

    class Config:
        from_attributes = True


class SystemSettingUpdate(BaseModel):
    """Terima `setting_value` atau `value` (dipakai frontend)."""
    setting_value: Optional[str] = None
    value: Optional[str] = None

    @model_validator(mode="after")
    def _one_value(self):
        if self.setting_value is None and self.value is None:
            raise ValueError("setting_value atau value wajib diisi")
        return self

    def resolved_value(self) -> str:
        return self.setting_value if self.setting_value is not None else (self.value or "")


class SettingKeyValue(BaseModel):
    key: str = Field(..., min_length=1, max_length=100)
    value: Optional[Any] = None


class SystemSettingsBatchUpdate(BaseModel):
    """Batch update. `settings` boleh berupa {"key": "value"} atau
    [{"key": ..., "value": ...}] (format halaman Pengaturan)."""
    settings: Union[Dict[str, Optional[Any]], List[SettingKeyValue]]

    def as_dict(self) -> Dict[str, Optional[str]]:
        if isinstance(self.settings, dict):
            items = self.settings.items()
        else:
            items = ((i.key, i.value) for i in self.settings)
        out: Dict[str, Optional[str]] = {}
        for k, v in items:
            if isinstance(v, bool):
                v = "true" if v else "false"
            out[k] = None if v is None else str(v)
        return out
