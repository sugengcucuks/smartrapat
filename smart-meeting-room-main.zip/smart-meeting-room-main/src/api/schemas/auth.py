from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from uuid import UUID


# Auth Schemas
class LoginRequest(BaseModel):
    username: str = Field(..., min_length=1, max_length=50)
    password: str = Field(..., min_length=1)


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "Bearer"
    expires_in: int


class UserResponse(BaseModel):
    id: UUID
    username: str
    name: str
    email: str
    role: str
    permissions: List[str]
    avatar_url: Optional[str] = None
    department: Optional[str] = None
    rank: Optional[str] = None
    position: Optional[str] = None
    must_change_password: bool = False

    class Config:
        from_attributes = True


class LoginResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "Bearer"
    expires_in: int
    user: UserResponse


class RefreshTokenRequest(BaseModel):
    refresh_token: str


class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str = Field(..., min_length=8, max_length=128)


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str = Field(..., min_length=8, max_length=128)


class MenuItemResponse(BaseModel):
    id: str
    name: str
    icon: str
    path: str
    children: Optional[List["MenuItemResponse"]] = None


class MenuResponse(BaseModel):
    menu: List[MenuItemResponse]


class MessageResponse(BaseModel):
    message: str


class ErrorDetail(BaseModel):
    code: str
    message: str
    details: Optional[dict] = None


class ApiErrorResponse(BaseModel):
    success: bool = False
    error: ErrorDetail
