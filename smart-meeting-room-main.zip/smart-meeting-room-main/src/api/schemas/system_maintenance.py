from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from uuid import UUID
from datetime import datetime

from src.api.schemas.user import SuccessResponse


class SystemHealthResponse(BaseModel):
    db_status: str
    total_users: int
    total_rooms: int
    total_bookings: int
    pending_backup: bool
    storage_used_pct: float
    uptime_seconds: int
    started_at: datetime


class MigrationFileItem(BaseModel):
    filename: str
    status: str
    applied_at: Optional[datetime] = None


class MigrationsListResponse(BaseModel):
    migrations: List[MigrationFileItem]
    total_applied: int
    total_pending: int


class MigrationsRunResponse(BaseModel):
    files_run: List[str]
    errors: List[Dict[str, str]]


class BackupDBResponse(BaseModel):
    download_url: str
    size_bytes: int
    created_at: datetime
    filename: str


class RestoreDBResponse(BaseModel):
    success: bool
    filename: str
    restored_at: datetime
    message: str


class CacheClearResponse(BaseModel):
    success: bool
    cleared_caches: List[str]
    message: str


class SeedDemoResponse(BaseModel):
    success: bool
    users_created: int
    bookings_created: int
    message: str
