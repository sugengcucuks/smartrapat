from pydantic import BaseModel, Field, EmailStr
from typing import Optional, List
from uuid import UUID
from datetime import datetime, date, time

from src.api.schemas.user import SuccessResponse


class BookingParticipantBase(BaseModel):
    user_id: Optional[UUID] = None
    guest_name: Optional[str] = Field(None, max_length=100)
    guest_email: Optional[EmailStr] = None
    is_guest: bool = False


class BookingParticipantCreate(BookingParticipantBase):
    pass


class BookingParticipantResponse(BaseModel):
    id: UUID
    booking_id: UUID
    user_id: Optional[UUID] = None
    user_name: Optional[str] = None
    guest_name: Optional[str] = None
    guest_email: Optional[str] = None
    is_guest: bool
    ticket_code: Optional[str] = None
    attended: bool = False
    checked_in_at: Optional[datetime] = None
    created_at: datetime

    class Config:
        from_attributes = True


class BookingBase(BaseModel):
    room_id: UUID
    title: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    date: date
    start_time: time
    end_time: time
    attendees: int = Field(1, ge=1)
    # Ditentukan server (lihat bookings._resolve_create_status); klien hanya boleh minta "draft".
    status: Optional[str] = Field(None, pattern="^(draft|pending|approved|rejected|cancelled|completed)$")


class BookingCreate(BookingBase):
    participants: Optional[List[BookingParticipantCreate]] = Field(default_factory=list)


class BookingUpdate(BaseModel):
    room_id: Optional[UUID] = None
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = None
    date: Optional[date] = None
    start_time: Optional[time] = None
    end_time: Optional[time] = None
    attendees: Optional[int] = Field(None, ge=1)
    status: Optional[str] = Field(None, pattern="^(draft|pending|approved|rejected|cancelled|completed)$")
    participants: Optional[List[BookingParticipantCreate]] = None


class BookingApprove(BaseModel):
    approval_notes: Optional[str] = None


class BookingResponse(BaseModel):
    id: UUID
    user_id: UUID
    user_name: Optional[str] = None
    room_id: UUID
    room_name: Optional[str] = None
    building_id: Optional[UUID] = None
    building_name: Optional[str] = None
    title: str
    description: Optional[str] = None
    date: date
    start_time: time
    end_time: time
    attendees: int
    status: str
    approval_notes: Optional[str] = None
    created_by: Optional[UUID] = None
    organizer_id: Optional[UUID] = None
    organizer_name: Optional[str] = None
    approved_by: Optional[UUID] = None
    approved_by_name: Optional[str] = None
    approved_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    participants: List[BookingParticipantResponse] = Field(default_factory=list)
    participant_count: int = 0

    class Config:
        from_attributes = True


class PaginatedBookingsResponse(BaseModel):
    items: List[BookingResponse]
    total: int
    page: int
    per_page: int
    total_pages: int

