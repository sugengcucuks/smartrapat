"""Skema Setup Wizard ala WordPress."""
from pydantic import BaseModel, Field
from typing import List, Optional


class SetupStep(BaseModel):
    key: str
    label: str
    done: bool
    detail: str = ""


class SetupStatusResponse(BaseModel):
    completed: bool
    steps: List[SetupStep]


class SetupProfileRequest(BaseModel):
    org_name: str = Field(..., min_length=1, max_length=200)
    org_address: Optional[str] = Field(None, max_length=500)
    org_phone: Optional[str] = Field(None, max_length=50)
    org_email: Optional[str] = Field(None, max_length=200)


class SetupCompleteResponse(BaseModel):
    completed: bool
    message: str
