from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from uuid import UUID
from datetime import datetime

from src.api.schemas.user import SuccessResponse


class AuditLogCreate(BaseModel):
    user_id: Optional[UUID] = None
    action: str = Field(..., pattern="^(login|logout|create|update|delete|approve|reject|cancel|export|import|settings_change|control)$")
    module: str = Field(..., pattern="^(auth|users|roles|rooms|equipment|devices|bookings|notes|settings|system)$")
    target_type: Optional[str] = None
    target_id: Optional[str] = None
    old_value: Optional[Dict[str, Any]] = None
    new_value: Optional[Dict[str, Any]] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None


class AuditLogResponse(BaseModel):
    id: UUID
    user_id: Optional[UUID] = None
    user_name: Optional[str] = None
    action: str
    module: str
    target_type: Optional[str] = None
    target_id: Optional[str] = None
    old_value: Optional[Dict[str, Any]] = None
    new_value: Optional[Dict[str, Any]] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    timestamp: datetime

    class Config:
        from_attributes = True


class PaginatedAuditLogsResponse(BaseModel):
    items: List[AuditLogResponse]
    total: int
    page: int
    per_page: int
    total_pages: int


class AuditLogPerModuleItem(BaseModel):
    module: str
    count: int


class AuditLogPerActionItem(BaseModel):
    action: str
    count: int


class AuditLogTopUserItem(BaseModel):
    user_id: UUID
    user_name: str
    count: int


class AuditStatsSummaryResponse(BaseModel):
    total_logs_30d: int
    per_module: List[AuditLogPerModuleItem]
    per_action: List[AuditLogPerActionItem]
    top_users: List[AuditLogTopUserItem]
