from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from uuid import UUID
from datetime import datetime

from src.api.schemas.user import SuccessResponse


class VideowallInput(BaseModel):
    """Satu sumber pada jendela layout. `input` = id sumber dari capabilities (mis. "hdmi1")."""
    input: str = Field(..., min_length=1, max_length=50)
    label: Optional[str] = None
    window: Optional[int] = Field(None, ge=1, le=16)


class VideowallBase(BaseModel):
    room_id: UUID
    device_id: Optional[UUID] = None
    config_name: str = Field(..., min_length=1, max_length=100)
    # id preset dari GET /rooms/{room_id}/av/capabilities (divalidasi saat simpan)
    layout_mode: str = Field("fullscreen", min_length=1, max_length=20)
    inputs: Optional[List[VideowallInput]] = Field(default_factory=list)


class VideowallCreate(VideowallBase):
    pass


class VideowallUpdate(BaseModel):
    room_id: Optional[UUID] = None
    device_id: Optional[UUID] = None
    config_name: Optional[str] = Field(None, min_length=1, max_length=100)
    layout_mode: Optional[str] = Field(None, min_length=1, max_length=20)
    inputs: Optional[List[VideowallInput]] = None


class VideowallSource(BaseModel):
    """id sumber dari capabilities ruangan (mis. "hdmi1")."""
    source: str = Field(..., min_length=1, max_length=50)
    window: int = Field(1, ge=1, le=16)


class VideowallLayoutRequest(BaseModel):
    preset: str = Field(..., min_length=1, max_length=50)


class VideowallResponse(BaseModel):
    id: UUID
    room_id: UUID
    room_name: Optional[str] = None
    device_id: Optional[UUID] = None
    device_name: Optional[str] = None
    config_name: str
    layout_mode: str
    inputs: List[VideowallInput] = Field(default_factory=list)
    last_action: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
