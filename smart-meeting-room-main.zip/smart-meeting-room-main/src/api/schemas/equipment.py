from pydantic import BaseModel, Field
from typing import Optional, List, Any
from uuid import UUID
from datetime import datetime, date

from src.api.schemas.user import SuccessResponse


class EquipmentBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=150)
    code: str = Field(..., min_length=1, max_length=30)
    category: str = Field("other", pattern="^(display|audio|input|network|camera|other)$")
    brand: Optional[str] = Field(None, max_length=100)
    model: Optional[str] = Field(None, max_length=100)
    serial_number: Optional[str] = Field(None, max_length=100)
    purchase_date: Optional[date] = None
    warranty_until: Optional[date] = None
    status: str = Field("active", pattern="^(active|maintenance|broken|disposed)$")
    notes: Optional[str] = None
    location_id: Optional[UUID] = None


class EquipmentCreate(EquipmentBase):
    pass


class EquipmentUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=150)
    code: Optional[str] = Field(None, min_length=1, max_length=30)
    category: Optional[str] = Field(None, pattern="^(display|audio|input|network|camera|other)$")
    brand: Optional[str] = Field(None, max_length=100)
    model: Optional[str] = Field(None, max_length=100)
    serial_number: Optional[str] = Field(None, max_length=100)
    purchase_date: Optional[date] = None
    warranty_until: Optional[date] = None
    status: Optional[str] = Field(None, pattern="^(active|maintenance|broken|disposed)$")
    notes: Optional[str] = None
    location_id: Optional[UUID] = None


class EquipmentAssignRoom(BaseModel):
    location_id: Optional[UUID] = None


class EquipmentResponse(BaseModel):
    id: UUID
    name: str
    code: str
    category: str
    brand: Optional[str] = None
    model: Optional[str] = None
    serial_number: Optional[str] = None
    purchase_date: Optional[date] = None
    warranty_until: Optional[date] = None
    status: str
    notes: Optional[str] = None
    location_id: Optional[UUID] = None
    room_name: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class PaginatedEquipmentResponse(BaseModel):
    items: List[EquipmentResponse]
    total: int
    page: int
    per_page: int
    total_pages: int
