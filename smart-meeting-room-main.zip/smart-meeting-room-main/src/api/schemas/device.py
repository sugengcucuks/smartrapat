from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from uuid import UUID
from datetime import datetime

from src.api.schemas.user import SuccessResponse


class DeviceBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=150)
    device_type: str = Field(..., pattern="^(tv|display|projector|ac|cctv|lights|curtain|sensor_temp|sensor_humidity|door_lock|videowall_controller|audio_mixer|audio_processor|tablet)$")
    code: str = Field(..., min_length=1, max_length=30)
    location_id: Optional[UUID] = None
    ip_address: Optional[str] = Field(None, max_length=45)
    mac_address: Optional[str] = Field(None, max_length=20)
    firmware_version: Optional[str] = Field(None, max_length=50)
    status: str = Field("offline", pattern="^(online|offline|error|maintenance)$")
    last_seen: Optional[datetime] = None
    config: Optional[Dict[str, Any]] = Field(default_factory=dict)


class DeviceCreate(DeviceBase):
    pass


class DeviceUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=150)
    device_type: Optional[str] = Field(None, pattern="^(tv|display|projector|ac|cctv|lights|curtain|sensor_temp|sensor_humidity|door_lock|videowall_controller|audio_mixer|audio_processor|tablet)$")
    code: Optional[str] = Field(None, min_length=1, max_length=30)
    location_id: Optional[UUID] = None
    ip_address: Optional[str] = Field(None, max_length=45)
    mac_address: Optional[str] = Field(None, max_length=20)
    firmware_version: Optional[str] = Field(None, max_length=50)
    status: Optional[str] = Field(None, pattern="^(online|offline|error|maintenance)$")
    last_seen: Optional[datetime] = None
    config: Optional[Dict[str, Any]] = None


class DeviceResponse(BaseModel):
    id: UUID
    name: str
    device_type: str
    code: str
    location_id: Optional[UUID] = None
    room_name: Optional[str] = None
    ip_address: Optional[str] = None
    mac_address: Optional[str] = None
    firmware_version: Optional[str] = None
    status: str
    last_seen: Optional[datetime] = None
    config: Dict[str, Any] = Field(default_factory=dict)
    last_action: Optional[str] = None
    live: Optional[Dict[str, Any]] = None   # state terakhir dari agent (MQTT), bila ada
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class DeviceStatusResponse(BaseModel):
    id: UUID
    name: str
    code: str
    status: str
    last_seen: Optional[datetime] = None
    uptime_suggestion: Optional[str] = None
    is_healthy: bool


class DeviceHealthSummary(BaseModel):
    count_total: int
    count_online: int
    count_offline: int
    count_error: int
    count_maintenance: int
    list_per_room: List[Dict[str, Any]]


class PaginatedDevicesResponse(BaseModel):
    items: List[DeviceResponse]
    total: int
    page: int
    per_page: int
    total_pages: int
