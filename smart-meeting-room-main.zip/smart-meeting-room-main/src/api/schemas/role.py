from pydantic import BaseModel, Field
from typing import Optional, List
from uuid import UUID
from datetime import datetime

from src.api.schemas.user import SuccessResponse


class _PermissionInput(BaseModel):
    """Izin boleh dikirim sebagai `permissions` (kode, mis. "users.view") atau
    `permission_ids` (id katalog, mis. "perm_users_view"). Keduanya digabung."""
    permissions: Optional[List[str]] = None
    permission_ids: Optional[List[str]] = None

    def all_permissions(self) -> Optional[List[str]]:
        if self.permissions is None and self.permission_ids is None:
            return None
        return list(self.permissions or []) + list(self.permission_ids or [])


class RoleBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=50)
    description: Optional[str] = None
    is_active: Optional[bool] = True


class RoleCreate(RoleBase, _PermissionInput):
    pass


class RoleUpdate(_PermissionInput):
    name: Optional[str] = Field(None, min_length=1, max_length=50)
    description: Optional[str] = None
    is_active: Optional[bool] = None


class RoleResponse(BaseModel):
    id: UUID
    name: str
    description: Optional[str] = None
    permissions: List[str] = Field(default_factory=list)
    is_active: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class PermissionList(BaseModel):
    permissions: List[str]


class RolePermissionSync(_PermissionInput):
    pass
