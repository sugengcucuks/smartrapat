from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Any
from uuid import UUID
from datetime import datetime


# ============================================
# Standard Response Wrappers
# ============================================

class SuccessResponse(BaseModel):
    success: bool = True
    data: Any


class ErrorResponse(BaseModel):
    success: bool = False
    detail: Any


# ============================================
# Department Schemas
# ============================================

class DepartmentBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    code: str = Field(..., min_length=1, max_length=20)
    head_id: Optional[UUID] = None


class DepartmentCreate(DepartmentBase):
    pass


class DepartmentUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    code: Optional[str] = Field(None, min_length=1, max_length=20)
    head_id: Optional[UUID] = None


class DepartmentResponse(BaseModel):
    id: UUID
    name: str
    code: str
    head_id: Optional[UUID] = None
    head_name: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ============================================
# User Schemas
# ============================================

class UserBase(BaseModel):
    username: str = Field(..., min_length=1, max_length=50)
    name: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    nik: Optional[str] = Field(None, max_length=20)
    rank: Optional[str] = Field(None, max_length=50)
    position: Optional[str] = Field(None, max_length=100)
    role_id: Optional[UUID] = None
    department_id: Optional[UUID] = None
    avatar_url: Optional[str] = Field(None, max_length=500)
    phone: Optional[str] = Field(None, max_length=20)
    status: Optional[str] = "ACTIVE"


class UserCreate(UserBase):
    password: str = Field(..., min_length=8, max_length=128)


class UserUpdate(BaseModel):
    username: Optional[str] = Field(None, min_length=1, max_length=50)
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    email: Optional[EmailStr] = None
    nik: Optional[str] = Field(None, max_length=20)
    rank: Optional[str] = Field(None, max_length=50)
    position: Optional[str] = Field(None, max_length=100)
    role_id: Optional[UUID] = None
    department_id: Optional[UUID] = None
    avatar_url: Optional[str] = Field(None, max_length=500)
    phone: Optional[str] = Field(None, max_length=20)
    status: Optional[str] = None


class UserMeUpdate(BaseModel):
    """Profil yang boleh diubah sendiri. NIK/pangkat/jabatan/role/status via admin."""
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    email: Optional[EmailStr] = None
    avatar_url: Optional[str] = Field(None, max_length=500)
    phone: Optional[str] = Field(None, max_length=20)


class PasswordUpdate(BaseModel):
    new_password: str = Field(..., min_length=8, max_length=128)


class UserResponse(BaseModel):
    id: UUID
    username: str
    name: str
    email: str
    nik: Optional[str] = None
    rank: Optional[str] = None
    position: Optional[str] = None
    role_id: Optional[UUID] = None
    role_name: Optional[str] = None
    department_id: Optional[UUID] = None
    department_name: Optional[str] = None
    avatar_url: Optional[str] = None
    phone: Optional[str] = None
    status: str
    last_login: Optional[datetime] = None
    login_attempts: int = 0
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class PaginatedUsersResponse(BaseModel):
    items: List[UserResponse]
    total: int
    page: int
    per_page: int
    total_pages: int
