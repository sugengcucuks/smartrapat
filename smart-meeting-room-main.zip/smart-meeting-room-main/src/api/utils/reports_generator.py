import io
import datetime as dt
from typing import Any, Dict, List, Optional
from xml.sax.saxutils import escape as _xml_escape


# ---------------------------------------------------------------------------
# Output escaping
# ---------------------------------------------------------------------------
FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def safe_cell(value: Any) -> Any:
    """Cegah formula injection di Excel/CSV: teks yang diawali = + - @ diberi
    awalan tanda kutip tunggal sehingga dibaca sebagai teks biasa."""
    if isinstance(value, str) and value.startswith(FORMULA_PREFIXES):
        return "'" + value
    return value


def esc(value: Any) -> str:
    """Escape teks pengguna sebelum dimasukkan ke ReportLab Paragraph (markup XML)."""
    return _xml_escape("" if value is None else str(value))

# ---------------------------------------------------------------------------
# Excel generation — openpyxl
# ---------------------------------------------------------------------------
try:
    from openpyxl import Workbook  # type: ignore
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side  # type: ignore
    HAS_XLSX = True
except ImportError:  # pragma: no cover
    HAS_XLSX = False

# ---------------------------------------------------------------------------
# PDF generation — reportlab
# ---------------------------------------------------------------------------
try:
    from reportlab.lib import colors  # type: ignore
    from reportlab.lib.pagesizes import A4, landscape  # type: ignore
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle  # type: ignore
    from reportlab.lib.units import mm  # type: ignore
    from reportlab.platypus import (  # type: ignore
        SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, HRFlowable,
    )
    HAS_PDF = True
except ImportError:  # pragma: no cover
    HAS_PDF = False


# =======================================================================
# BOOKINGS REPORT
# =======================================================================

def _write_table_xlsx(ws, headers: List[str], rows: List[List[Any]], title: Optional[str] = None) -> None:
    if not HAS_XLSX:
        return

    bold = Font(bold=True, color="FFFFFF", size=12)
    title_font = Font(bold=True, size=16, color="1e1b4b")
    header_fill = PatternFill(start_color="6366f1", end_color="6366f1", fill_type="solid")
    alt_fill = PatternFill(start_color="f5f3ff", end_color="f5f3ff", fill_type="solid")
    thin = Side(border_style="thin", color="d1d5db")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    center = Alignment(horizontal="center", vertical="center")
    left = Alignment(horizontal="left", vertical="center", wrap_text=True)

    current_row = 1
    if title:
        ws.cell(row=current_row, column=1, value=safe_cell(title)).font = title_font
        ws.merge_cells(start_row=current_row, start_column=1, end_row=current_row, end_column=len(headers))
        ws.cell(row=current_row, column=1).alignment = Alignment(horizontal="left", vertical="center")
        current_row += 2

    for col_idx, name in enumerate(headers, start=1):
        cell = ws.cell(row=current_row, column=col_idx, value=name)
        cell.font = bold
        cell.fill = header_fill
        cell.alignment = center
        cell.border = border

    current_row += 1
    for r_idx, row in enumerate(rows):
        for c_idx, val in enumerate(row, start=1):
            cell = ws.cell(row=current_row, column=c_idx, value=safe_cell(val))
            cell.alignment = left if c_idx in (2, 3, 4) else center
            cell.border = border
            if r_idx % 2 == 1:
                cell.fill = alt_fill
        current_row += 1

    for col_idx in range(1, len(headers) + 1):
        ws.column_dimensions[chr(64 + col_idx) if col_idx <= 26 else "A" + chr(64 + col_idx - 26)].width = 22


def generate_bookings_xlsx(
    bookings: List[Dict[str, Any]],
    summary: Dict[str, Any],
    from_date: Optional[dt.date] = None,
    to_date: Optional[dt.date] = None,
) -> io.BytesIO:
    if not HAS_XLSX:
        raise RuntimeError("openpyxl belum terinstall. Jalankan pip install openpyxl.")

    wb = Workbook()
    ws = wb.active
    ws.title = "Bookings"
    ws.sheet_view.showGridLines = False

    period = f"Periode: {from_date.isoformat() if from_date else 'Semua tanggal'} s/d {to_date.isoformat() if to_date else 'Semua tanggal'}"
    _write_table_xlsx(ws, title=f"Laporan Pemesanan Ruangan — {period}", headers=[
        "No", "Tanggal", "Judul Rapat", "Ruangan", "Gedung",
        "Penyelenggara", "Waktu Mulai", "Waktu Selesai", "Durasi (mnt)", "Peserta", "Status",
    ], rows=[
        [
            i + 1,
            str(b.get("date", "")),
            b.get("title", ""),
            b.get("room_name", ""),
            b.get("building_name", ""),
            b.get("organizer_name", ""),
            str(b.get("start_time", "")),
            str(b.get("end_time", "")),
            b.get("duration_minutes", 0),
            b.get("participant_count", 0),
            _status_label(str(b.get("status", ""))),
        ]
        for i, b in enumerate(bookings)
    ])

    # Summary sheet
    ws2 = wb.create_sheet(title="Ringkasan")
    ws2.sheet_view.showGridLines = False
    summary_rows = [
        ["Total Pemesanan", summary.get("total_bookings", 0)],
        ["Total Durasi (menit)", summary.get("total_duration_minutes", 0)],
        ["Total Peserta", summary.get("total_participants", 0)],
    ]
    by_status = _status_pairs(summary.get("by_status"))
    for k, v in by_status:
        summary_rows.append([f"Status: {_status_label(str(k))}", v])
    _write_table_xlsx(ws2, title="Ringkasan Data", headers=["Keterangan", "Nilai"], rows=summary_rows)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def generate_equipment_xlsx(items: List[Dict[str, Any]], summary: List[Dict[str, Any]]) -> io.BytesIO:
    if not HAS_XLSX:
        raise RuntimeError("openpyxl belum terinstall. Jalankan pip install openpyxl.")

    wb = Workbook()
    ws = wb.active
    ws.title = "Inventory"
    ws.sheet_view.showGridLines = False

    _write_table_xlsx(ws, title="Laporan Inventaris Perangkat AV", headers=[
        "No", "Kode", "Nama Perangkat", "Kategori", "Merek", "Model",
        "Ruangan", "Status", "Tanggal Beli",
    ], rows=[
        [
            i + 1,
            it.get("code", ""),
            it.get("name", ""),
            it.get("category", ""),
            it.get("brand", ""),
            it.get("model", ""),
            it.get("room_name", ""),
            it.get("status", ""),
            str(it.get("purchase_date", "")),
        ]
        for i, it in enumerate(items)
    ])

    ws2 = wb.create_sheet(title="Ringkasan Kategori")
    ws2.sheet_view.showGridLines = False
    _write_table_xlsx(ws2, title="Ringkasan Berdasarkan Kategori", headers=[
        "Kategori", "Total", "Aktif", "Maintenance", "Rusak", "Hilang",
    ], rows=[
        [
            s.get("category", ""),
            s.get("total", 0),
            s.get("active", 0),
            s.get("maintenance", 0),
            s.get("damaged", 0),
            s.get("disposed", 0),
        ]
        for s in summary
    ])

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


# =======================================================================
# PDF GENERATION (ReportLab)
# =======================================================================

def _build_pdf_doc(buf: io.BytesIO, title: str, subtitle: str) -> tuple:
    if not HAS_PDF:
        raise RuntimeError("reportlab belum terinstall. Jalankan pip install reportlab.")

    doc = SimpleDocTemplate(
        buf, pagesize=landscape(A4),
        leftMargin=15 * mm, rightMargin=15 * mm,
        topMargin=15 * mm, bottomMargin=15 * mm,
        title=title, author="Smart Meeting Room",
    )
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="SMRTitle", parent=styles["Title"], fontSize=22, textColor=colors.HexColor("#4f46e5"), spaceAfter=2))
    styles.add(ParagraphStyle(name="SMRSubtitle", parent=styles["Normal"], fontSize=10, textColor=colors.HexColor("#6b7280"), spaceAfter=8))
    return doc, styles


def generate_bookings_pdf(
    bookings: List[Dict[str, Any]],
    summary: Dict[str, Any],
    from_date: Optional[dt.date] = None,
    to_date: Optional[dt.date] = None,
) -> io.BytesIO:
    if not HAS_PDF:
        raise RuntimeError("reportlab belum terinstall. Jalankan pip install reportlab.")

    buf = io.BytesIO()
    period = f"Periode: {from_date.isoformat() if from_date else 'Semua tanggal'} s/d {to_date.isoformat() if to_date else 'Semua tanggal'}"
    doc, styles = _build_pdf_doc(buf, "Laporan Pemesanan Ruangan", period)

    story = [
        Paragraph("LAPORAN PEMESANAN RUANGAN", styles["SMRTitle"]),
        Paragraph(f"{esc(period)} &nbsp;|&nbsp; Dicetak: {dt.datetime.now().strftime('%Y-%m-%d %H:%M')}", styles["SMRSubtitle"]),
        HRFlowable(width="100%", thickness=1, color=colors.HexColor("#e5e7eb"), spaceAfter=10),
    ]

    # Summary box
    sum_items = [
        ("Total Pemesanan", summary.get("total_bookings", 0)),
        ("Total Durasi", f"{summary.get('total_duration_minutes', 0)} menit"),
        ("Total Peserta", summary.get("total_participants", 0)),
    ]
    by_status = _status_pairs(summary.get("by_status"))
    for k, v in by_status:
        sum_items.append((f"Status {_status_label(str(k))}", str(v)))
    sum_table_data = [[Paragraph(f"<b>{esc(k)}</b>", styles["Normal"]) for k, _ in sum_items],
                      [str(v) for _, v in sum_items]]
    sum_table = Table(sum_table_data, hAlign="LEFT")
    sum_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eef2ff")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#4338ca")),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#e5e7eb")),
    ]))
    story.append(sum_table)
    story.append(Spacer(1, 10))

    # Bookings table
    story.append(Paragraph("<b>Daftar Pemesanan</b>", styles["Heading3"]))
    story.append(Spacer(1, 4))

    headers = ["No", "Tanggal", "Judul", "Ruangan", "Penyelenggara", "Waktu", "Dur", "Peserta", "Status"]
    rows = [headers]
    for i, b in enumerate(bookings):
        rows.append([
            str(i + 1),
            str(b.get("date", "")),
            Paragraph(esc(b.get("title", "")), styles["Normal"]),
            f"{b.get('room_name', '')}\n{b.get('building_name', '')}".strip(),
            str(b.get("organizer_name", "")),
            f"{b.get('start_time', '')} - {b.get('end_time', '')}",
            str(b.get("duration_minutes", 0)),
            str(b.get("participant_count", 0)),
            _status_label(str(b.get("status", ""))),
        ])

    table = Table(rows, repeatRows=1, hAlign="LEFT",
                  colWidths=[12 * mm, 26 * mm, 60 * mm, 36 * mm, 38 * mm, 36 * mm, 18 * mm, 20 * mm, 26 * mm])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#6366f1")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("ALIGN", (0, 0), (-1, 0), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#e5e7eb")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#faf5ff")]),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(table)
    doc.build(story)
    buf.seek(0)
    return buf


def generate_equipment_pdf(items: List[Dict[str, Any]], summary: List[Dict[str, Any]]) -> io.BytesIO:
    if not HAS_PDF:
        raise RuntimeError("reportlab belum terinstall. Jalankan pip install reportlab.")

    buf = io.BytesIO()
    doc, styles = _build_pdf_doc(buf, "Laporan Inventaris Perangkat", "Inventory Perangkat Audio Visual")

    story = [
        Paragraph("LAPORAN INVENTARIS PERANGKAT AV", styles["SMRTitle"]),
        Paragraph(f"Dicetak: {dt.datetime.now().strftime('%Y-%m-%d %H:%M')}", styles["SMRSubtitle"]),
        HRFlowable(width="100%", thickness=1, color=colors.HexColor("#e5e7eb"), spaceAfter=10),
    ]

    sum_header = ["Kategori", "Total", "Aktif", "Maintenance", "Rusak", "Hilang"]
    sum_rows = [sum_header] + [[
        str(s.get("category", "")), str(s.get("total", 0)), str(s.get("active", 0)),
        str(s.get("maintenance", 0)), str(s.get("damaged", 0)), str(s.get("disposed", 0)),
    ] for s in summary]
    sum_table = Table(sum_rows, hAlign="LEFT", colWidths=[40 * mm, 24 * mm, 24 * mm, 32 * mm, 24 * mm, 24 * mm])
    sum_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#6366f1")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#e5e7eb")),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#faf5ff")]),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(Paragraph("<b>Ringkasan Kategori</b>", styles["Heading3"]))
    story.append(sum_table)
    story.append(Spacer(1, 12))

    headers = ["No", "Kode", "Nama", "Kategori", "Merek/Model", "Ruangan", "Status"]
    rows = [headers]
    for i, it in enumerate(items):
        rows.append([
            str(i + 1),
            it.get("code", ""),
            Paragraph(esc(it.get("name", "")), styles["Normal"]),
            str(it.get("category", "")),
            f"{it.get('brand','')} {it.get('model','')}".strip(),
            str(it.get("room_name", "") or "-"),
            str(it.get("status", "")),
        ])

    table = Table(rows, repeatRows=1, hAlign="LEFT",
                  colWidths=[14 * mm, 28 * mm, 60 * mm, 36 * mm, 50 * mm, 44 * mm, 30 * mm])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#6366f1")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#e5e7eb")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#faf5ff")]),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story.append(Paragraph("<b>Daftar Perangkat</b>", styles["Heading3"]))
    story.append(table)
    doc.build(story)
    buf.seek(0)
    return buf


# =======================================================================
# Helpers
# =======================================================================
_STATUS_LABEL = {
    "draft": "Draf",
    "pending": "Menunggu",
    "approved": "Disetujui",
    "rejected": "Ditolak",
    "cancelled": "Dibatalkan",
    "completed": "Selesai",
}


def _status_pairs(by_status: Any) -> List[tuple]:
    if isinstance(by_status, dict):
        return list(by_status.items())
    if isinstance(by_status, list):
        return [(x.get("status_raw") or x.get("status"), x.get("count", 0)) for x in by_status if isinstance(x, dict)]
    return []


def _status_label(s: str) -> str:
    return _STATUS_LABEL.get(s or "", s or "-")
