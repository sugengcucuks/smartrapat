"""Pencatatan audit log dari sisi server.

Semua field identitas (user, IP, user-agent) diisi server, tidak pernah dari
body request klien.
"""
import ipaddress
import logging
from typing import Any, Optional

from fastapi import Request
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.models.audit_log import AuditLog

logger = logging.getLogger("smr.audit")


def client_ip(request: Optional[Request]) -> Optional[str]:
    """IP klien (tervalidasi agar aman untuk kolom INET)."""
    if request is None or request.client is None:
        return None
    host = request.client.host
    try:
        return str(ipaddress.ip_address(host))
    except (ValueError, TypeError):
        return None


def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(v) for v in value]
    return str(value)


async def record_audit(
    db: AsyncSession,
    user: Any,
    action: str,
    module: str,
    target_type: Optional[str] = None,
    target_id: Any = None,
    details: Optional[dict] = None,
    request: Optional[Request] = None,
    old_value: Optional[dict] = None,
    commit: bool = False,
) -> None:
    """Tambahkan entri audit ke session.

    Default hanya `db.add` sehingga ikut ter-commit bersama perubahan utama.
    Pakai `commit=True` bila dipanggil setelah commit utama. Kegagalan audit
    dicatat ke log dan tidak menggagalkan aksi utama bila `commit=True`.
    """
    user_agent = request.headers.get("user-agent") if request is not None else None
    entry = AuditLog(
        user_id=getattr(user, "id", None),
        action=(action or "")[:30],
        module=(module or "")[:30],
        target_type=(target_type or None) and str(target_type)[:50],
        target_id=None if target_id is None else str(target_id)[:100],
        old_value=_json_safe(old_value) if old_value is not None else None,
        new_value=_json_safe(details) if details is not None else None,
        ip_address=client_ip(request),
        user_agent=(user_agent or None) and user_agent[:500],
    )
    db.add(entry)
    if commit:
        try:
            await db.commit()
        except Exception:  # noqa: BLE001
            logger.exception("Gagal menyimpan audit log %s/%s", module, action)
            await db.rollback()
