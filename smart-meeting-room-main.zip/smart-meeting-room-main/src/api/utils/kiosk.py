"""Autentikasi kiosk / display depan pintu.

Alur:
1. Admin melihat pairing key ruangan (GET /rooms/{id}/pairing-key).
2. Kiosk memanggil POST /door-display/pair {room_code, pairing_key} dan menerima
   token kiosk (JWT type "kiosk") yang berlaku KIOSK_SESSION_MINUTES.
3. Semua endpoint door-display & WebSocket kiosk wajib membawa token tersebut
   (header `X-Kiosk-Token`, atau `?kiosk_token=` untuk WebSocket).

Token memuat `kv` = prefix hash pairing key saat ini, sehingga regenerate pairing
key langsung mencabut semua kiosk yang sudah dipasangkan.
"""
import hashlib
import time
from datetime import datetime, timedelta, timezone
from threading import Lock
from typing import Dict, Optional, Tuple
from uuid import UUID

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.config import settings
from src.api.database import get_db
from src.api.models.room import Room
from src.api.models.user import User
from src.api.utils.auth import decode_token, get_user_from_payload

KIOSK_HEADER = "X-Kiosk-Token"
_optional_bearer = HTTPBearer(auto_error=False)


def _unauthorized(message: str = "Kiosk belum dipasangkan atau sesi kiosk berakhir") -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail={"code": "KIOSK_UNPAIRED", "message": message},
    )


def pairing_key_version(room: Room) -> str:
    return hashlib.sha256((room.pairing_key or "").encode("utf-8")).hexdigest()[:12]


def create_kiosk_token(room: Room) -> Tuple[str, datetime]:
    expires = datetime.now(timezone.utc) + timedelta(minutes=settings.KIOSK_SESSION_MINUTES)
    claims = {
        "type": "kiosk",
        "room_code": room.code,
        "room_id": str(room.id),
        "kv": pairing_key_version(room),
        "exp": expires,
    }
    return jwt.encode(claims, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM), expires


async def verify_kiosk_token(db: AsyncSession, token: Optional[str], room_code: Optional[str] = None) -> Room:
    """Validasi token kiosk; kembalikan Room-nya. `room_code` (bila ada) harus cocok."""
    if not token:
        raise _unauthorized()
    try:
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])
    except JWTError:
        raise _unauthorized()
    if payload.get("type") != "kiosk":
        raise _unauthorized()
    try:
        room_id = UUID(str(payload.get("room_id")))
    except (TypeError, ValueError):
        raise _unauthorized()
    room = (await db.execute(select(Room).where(Room.id == room_id))).scalar_one_or_none()
    if room is None or room.code != payload.get("room_code"):
        raise _unauthorized()
    if room_code is not None and room_code != room.code:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "KIOSK_ROOM_MISMATCH", "message": "Token kiosk tidak berlaku untuk ruangan ini"},
        )
    if not room.pairing_key or payload.get("kv") != pairing_key_version(room):
        raise _unauthorized("Pairing key ruangan sudah diganti. Pasangkan ulang kiosk.")
    return room


def kiosk_token_from_request(request: Request) -> Optional[str]:
    return request.headers.get(KIOSK_HEADER) or request.query_params.get("kiosk_token")


async def optional_user(
    request: Request,
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(_optional_bearer),
    db: AsyncSession = Depends(get_db),
) -> Optional[User]:
    """User login bila ada Bearer token valid; None bila tidak ada / tidak valid."""
    if credentials is None:
        return None
    try:
        payload = decode_token(credentials.credentials, expected_type="access")
        user = await get_user_from_payload(payload, db)
    except HTTPException:
        return None
    if user.must_change_password:
        return None
    return user


# ---------------------------------------------------------------------------
# Lockout Master PIN per ruangan (in-memory, single process)
# ---------------------------------------------------------------------------
PIN_MAX_ATTEMPTS = 5
PIN_LOCK_SECONDS = 15 * 60


class PinLockout:
    def __init__(self) -> None:
        self._state: Dict[str, Tuple[int, float]] = {}
        self._lock = Lock()

    def check(self, key: str) -> None:
        with self._lock:
            count, until = self._state.get(key, (0, 0.0))
        if until and until > time.monotonic():
            remaining = int(until - time.monotonic()) + 1
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail={
                    "code": "PIN_LOCKED",
                    "message": f"Terlalu banyak PIN salah. Kiosk terkunci {remaining // 60 + 1} menit.",
                },
                headers={"Retry-After": str(remaining)},
            )

    def fail(self, key: str) -> int:
        with self._lock:
            count, until = self._state.get(key, (0, 0.0))
            if until and until <= time.monotonic():
                count = 0
            count += 1
            until = time.monotonic() + PIN_LOCK_SECONDS if count >= PIN_MAX_ATTEMPTS else 0.0
            self._state[key] = (count, until)
            return max(0, PIN_MAX_ATTEMPTS - count)

    def success(self, key: str) -> None:
        with self._lock:
            self._state.pop(key, None)


pin_lockout = PinLockout()
