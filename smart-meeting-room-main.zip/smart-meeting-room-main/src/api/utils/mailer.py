"""Pengiriman email via SMTP.

Konfigurasi dibaca dari tabel system_settings (diisi lewat halaman Pengaturan):
smtp_host, smtp_port, smtp_user, smtp_pass, smtp_tls, smtp_from.
Bila smtp_host kosong, email tidak dikirim dan fungsi mengembalikan False.
"""
import asyncio
import logging
import smtplib
import ssl
from email.message import EmailMessage
from typing import Dict

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.models.system_setting import SystemSetting

logger = logging.getLogger("smr.mailer")

SMTP_KEYS = ("smtp_host", "smtp_port", "smtp_user", "smtp_pass", "smtp_tls", "smtp_from")


async def load_smtp_config(db: AsyncSession) -> Dict[str, str]:
    result = await db.execute(
        select(SystemSetting.setting_key, SystemSetting.setting_value).where(
            SystemSetting.setting_key.in_(SMTP_KEYS)
        )
    )
    return {k: (v or "") for k, v in result.all()}


def _send_sync(cfg: Dict[str, str], to: str, subject: str, body: str) -> None:
    host = cfg.get("smtp_host", "").strip()
    port = int(cfg.get("smtp_port") or 587)
    user = cfg.get("smtp_user", "").strip()
    password = cfg.get("smtp_pass", "")
    use_tls = str(cfg.get("smtp_tls", "true")).lower() in ("1", "true", "yes")
    sender = cfg.get("smtp_from") or user or "no-reply@localhost"

    msg = EmailMessage()
    msg["From"] = sender
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(body)

    ctx = ssl.create_default_context()
    if port == 465:
        with smtplib.SMTP_SSL(host, port, context=ctx, timeout=15) as s:
            if user:
                s.login(user, password)
            s.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=15) as s:
            if use_tls:
                s.starttls(context=ctx)
            if user:
                s.login(user, password)
            s.send_message(msg)


async def send_email(db: AsyncSession, to: str, subject: str, body: str) -> bool:
    cfg = await load_smtp_config(db)
    if not cfg.get("smtp_host"):
        logger.warning("SMTP belum dikonfigurasi; email ke %s tidak dikirim", to)
        return False
    try:
        await asyncio.to_thread(_send_sync, cfg, to, subject, body)
        return True
    except Exception as exc:  # jaringan / kredensial
        logger.error("Gagal kirim email ke %s: %s", to, exc)
        return False
