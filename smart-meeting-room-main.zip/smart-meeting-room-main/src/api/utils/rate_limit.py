"""Rate limiter in-memory sederhana (sliding window) untuk endpoint sensitif.

Cukup untuk deployment single-process (uvicorn 1 worker di PC server ruang rapat).
Bila memakai banyak worker, ganti backend ke Redis.
"""
import threading
import time
from collections import defaultdict, deque
from typing import Deque, Dict

from fastapi import HTTPException, status


class RateLimiter:
    def __init__(self) -> None:
        self._hits: Dict[str, Deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def hit(self, key: str, limit: int, window_seconds: int) -> None:
        """Catat satu percobaan; lempar 429 bila melewati `limit` dalam `window_seconds`."""
        now = time.monotonic()
        with self._lock:
            q = self._hits[key]
            while q and now - q[0] > window_seconds:
                q.popleft()
            if len(q) >= limit:
                retry = int(window_seconds - (now - q[0])) + 1
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail={"code": "RATE_LIMITED", "message": f"Terlalu banyak percobaan. Coba lagi dalam {retry} detik."},
                    headers={"Retry-After": str(retry)},
                )
            q.append(now)
            if len(self._hits) > 10000:
                self._gc(now)

    def reset(self, key: str) -> None:
        with self._lock:
            self._hits.pop(key, None)

    def _gc(self, now: float) -> None:
        for k in [k for k, q in self._hits.items() if not q or now - q[-1] > 3600]:
            self._hits.pop(k, None)


rate_limiter = RateLimiter()
