"""Generator & normalizer kode tiket presensi QR.

Format tiket: ``TC-XXXXXX`` (6 karakter acak dari alfabet aman).

Alfabet membuang karakter yang paling sering salah baca: digit ``0``,
digit ``1``, dan huruf ``L``. Huruf ``O`` dan ``I`` tetap dipakai karena
di dalam alfabet ini keduanya tidak lagi ambigu. Saat normalisasi,
input ``0`` dipetakan ke ``O``, dan input ``1`` / ``L`` dipetakan ke ``I``.
"""

import re
import secrets
from typing import Optional

TICKET_PREFIX = "TC-"
TICKET_LENGTH = 6

# Tanpa 0, 1, L -> mengurangi salah baca OCR / input manual.
TICKET_ALPHABET = "23456789ABCDEFGHIJKMNOPQRSTUVWXYZ"

_TICKET_PATTERN = re.compile(r"^TC-[%s]{%d}$" % (TICKET_ALPHABET, TICKET_LENGTH))

# Mencari pola "TC" + 6 karakter (dengan/tanpa pemisah) di dalam teks apa pun.
# Dipakai agar QR yang berisi URL atau prefix tambahan tetap terbaca.
_SEARCH_PATTERN = re.compile(r"TC[^0-9A-Z]{0,2}([0-9A-Z]{%d})" % TICKET_LENGTH)

_AMBIGUOUS_MAP = str.maketrans({"0": "O", "1": "I", "L": "I"})


def _canonical(body: str) -> Optional[str]:
    """Ubah 6 karakter mentah menjadi kode tiket kanonik, atau ``None``."""
    fixed = body.translate(_AMBIGUOUS_MAP)
    if len(fixed) != TICKET_LENGTH:
        return None
    if any(ch not in TICKET_ALPHABET for ch in fixed):
        return None
    return f"{TICKET_PREFIX}{fixed}"


def generate_ticket_code() -> str:
    """Buat kode tiket baru, contoh: ``TC-7KQ4MZ``."""
    body = "".join(secrets.choice(TICKET_ALPHABET) for _ in range(TICKET_LENGTH))
    return f"{TICKET_PREFIX}{body}"


def normalize_ticket_code(raw: Optional[str]) -> Optional[str]:
    """Normalisasi input tiket dari hasil scan QR / ketikan manual.

    Menerima berbagai bentuk (huruf kecil, ada spasi, tanpa prefix, atau
    berupa URL) lalu mengembalikan bentuk kanonik ``TC-XXXXXX``.

    Returns:
        Kode tiket kanonik, atau ``None`` bila input kosong / tidak valid.
    """
    if not raw:
        return None

    text = str(raw).strip().upper()

    # Coba 1: cari pola "TC" + 6 karakter di mana pun dalam teks.
    match = _SEARCH_PATTERN.search(text)
    if match:
        found = _canonical(match.group(1))
        if found:
            return found

    # Coba 2: bersihkan seluruh teks, buang prefix, lalu validasi.
    cleaned = re.sub(r"[^0-9A-Z]", "", text)
    if cleaned.startswith("TC"):
        cleaned = cleaned[2:]
    return _canonical(cleaned)


def is_valid_ticket_code(raw: Optional[str]) -> bool:
    """Cek apakah ``raw`` sudah berbentuk kode tiket kanonik yang valid."""
    if not raw:
        return False
    return bool(_TICKET_PATTERN.match(str(raw).strip().upper()))
