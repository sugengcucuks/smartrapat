"""Klien MQTT backend (paho-mqtt 1.6) untuk perintah perangkat IoT/AV.

Kontrak topic & payload: docs/architecture/LIVE_MEETING.md §3.

- Perintah   : {root}/devices/{device_id}/command/{action}   (QoS 1)
               payload {"cmd_id", "device_code", "action", ...params, "ts"}
- Ack        : {root}/devices/{device_id}/ack  -> menyelesaikan `wait_ack(cmd_id)`
- State/audio: diteruskan ke listener (src/api/services/live_hub.py)

Tidak ada lagi "mock mode": bila broker tidak dikonfigurasi, `publish_command`
melempar `MqttNotConfigured` dan endpoint mengembalikan 503 MQTT_NOT_CONFIGURED.

Env:
  MQTT_BROKER_URL   host broker (kosong = tidak dikonfigurasi)
  MQTT_PORT         default 1883 (8883 bila TLS)
  MQTT_USERNAME / MQTT_PASSWORD
  MQTT_TLS=true     aktifkan TLS; MQTT_CA_CERT = path CA (opsional)
  MQTT_TOPIC_PREFIX prefix topic perangkat, default "smr/devices"
                    (root "smr" diturunkan dari prefix ini)
  MQTT_SIMULATE=true  KHUSUS DEV LOKAL: tanpa broker, perintah di-ack otomatis
                    (ok=true, response="simulated"). Default false. JANGAN dipakai
                    di produksi — status sukses tidak mencerminkan perangkat nyata.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import ssl
import threading
import uuid
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

try:  # pragma: no cover - import guard
    import paho.mqtt.client as paho_mqtt  # type: ignore
except ImportError:  # pragma: no cover
    paho_mqtt = None  # type: ignore


class MqttError(RuntimeError):
    code = "MQTT_ERROR"


class MqttNotConfigured(MqttError):
    code = "MQTT_NOT_CONFIGURED"


class MqttNotConnected(MqttError):
    code = "MQTT_NOT_CONNECTED"


def _env_bool(name: str, default: bool = False) -> bool:
    val = os.getenv(name)
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "on")


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# Listener menerima (topic, payload_dict) dan dipanggil DI THREAD EVENT LOOP asyncio.
Listener = Callable[[str, Dict[str, Any]], Any]


class MqttManager:
    """Satu koneksi MQTT per proses backend."""

    def __init__(self) -> None:
        self.client = None
        self._connected = False
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._pending: Dict[str, asyncio.Future] = {}
        self._listeners: List[Listener] = []
        self._lock = threading.Lock()
        self.last_error: Optional[str] = None
        self.load_env()

    # ------------------------------------------------------------------
    # Konfigurasi
    # ------------------------------------------------------------------
    def load_env(self) -> None:
        self.broker_url = os.getenv("MQTT_BROKER_URL", "").strip()
        self.use_tls = _env_bool("MQTT_TLS")
        try:
            self.broker_port = int(os.getenv("MQTT_PORT", "8883" if self.use_tls else "1883"))
        except (TypeError, ValueError):
            self.broker_port = 1883
        self.username = os.getenv("MQTT_USERNAME", "").strip()
        self.password = os.getenv("MQTT_PASSWORD", "")
        self.ca_cert = os.getenv("MQTT_CA_CERT", "").strip()
        prefix = os.getenv("MQTT_TOPIC_PREFIX", "smr/devices").strip().rstrip("/") or "smr/devices"
        self.topic_prefix = prefix
        # "smr/devices" -> root "smr"; prefix tanpa '/' dianggap root itu sendiri.
        self.root = prefix.rsplit("/", 1)[0] if "/" in prefix else prefix
        self.simulate = _env_bool("MQTT_SIMULATE")
        self.client_id = os.getenv("MQTT_CLIENT_ID", "").strip() or f"smr-backend-{os.getpid()}"

    @property
    def configured(self) -> bool:
        return bool(self.broker_url) and paho_mqtt is not None

    @property
    def is_connected(self) -> bool:
        if self.simulate and not self.configured:
            return True
        return bool(self.client is not None and self._connected)

    def status(self) -> Dict[str, Any]:
        return {
            "configured": self.configured,
            "connected": self.is_connected,
            "simulate": self.simulate,
            "broker": f"{self.broker_url}:{self.broker_port}" if self.broker_url else None,
            "tls": self.use_tls,
            "last_error": self.last_error,
        }

    # ------------------------------------------------------------------
    # Lifecycle (dipanggil dari lifespan FastAPI)
    # ------------------------------------------------------------------
    def start(self, loop: Optional[asyncio.AbstractEventLoop] = None) -> None:
        self._loop = loop or asyncio.get_event_loop()
        if self.client is None:
            self.load_env()
        if not self.configured:
            if self.simulate:
                logger.warning("MQTT_SIMULATE=true: perintah perangkat di-ack otomatis (DEV SAJA)")
            else:
                logger.warning("MQTT broker tidak dikonfigurasi (MQTT_BROKER_URL kosong): kontrol perangkat nonaktif")
            return
        if self.client is not None:
            return
        client = paho_mqtt.Client(client_id=self.client_id, clean_session=True)
        if self.username:
            client.username_pw_set(self.username, self.password or None)
        if self.use_tls:
            ctx = ssl.create_default_context(cafile=self.ca_cert or None)
            client.tls_set_context(ctx)
        client.on_connect = self._on_connect
        client.on_disconnect = self._on_disconnect
        client.on_message = self._on_message
        client.reconnect_delay_set(1, 30)
        try:
            client.connect_async(self.broker_url, port=self.broker_port, keepalive=30)
            client.loop_start()
        except Exception as exc:  # pragma: no cover - network dependent
            self.last_error = str(exc)
            logger.error("MQTT gagal start: %s", exc)
            return
        self.client = client
        logger.info("MQTT menghubungkan ke %s:%s (tls=%s)", self.broker_url, self.broker_port, self.use_tls)

    def stop(self) -> None:
        client, self.client = self.client, None
        self._connected = False
        if client is not None:
            try:
                client.disconnect()
                client.loop_stop()
            except Exception:
                pass
        for fut in list(self._pending.values()):
            if not fut.done():
                fut.cancel()
        self._pending.clear()

    # Kompatibilitas nama lama
    disconnect = stop

    def add_listener(self, fn: Listener) -> None:
        if fn not in self._listeners:
            self._listeners.append(fn)

    def remove_listener(self, fn: Listener) -> None:
        if fn in self._listeners:
            self._listeners.remove(fn)

    def subscriptions(self) -> List[str]:
        r = self.root
        return [
            f"{self.topic_prefix}/+/ack",
            f"{self.topic_prefix}/+/state",
            f"{r}/agent/+/status",
            f"{r}/audio/+/levels",
            f"{r}/audio/+/active",
            f"{r}/audio/+/mixer",
        ]

    # ------------------------------------------------------------------
    # Callback paho (thread jaringan paho)
    # ------------------------------------------------------------------
    def _on_connect(self, client, _userdata, _flags, rc, *_args) -> None:
        if rc != 0:
            self._connected = False
            self.last_error = f"CONNACK rc={rc} ({paho_mqtt.connack_string(rc) if paho_mqtt else rc})"
            logger.error("MQTT connect ditolak: %s", self.last_error)
            return
        self._connected = True
        self.last_error = None
        for topic in self.subscriptions():
            client.subscribe(topic, qos=1)
        logger.info("MQTT terhubung; subscribe %d topic", len(self.subscriptions()))

    def _on_disconnect(self, _client, _userdata, rc, *_args) -> None:
        self._connected = False
        if rc != 0:
            self.last_error = f"terputus rc={rc}"
            logger.warning("MQTT terputus (rc=%s), paho akan reconnect otomatis", rc)

    def _on_message(self, _client, _userdata, msg) -> None:
        try:
            payload = json.loads(msg.payload.decode("utf-8")) if msg.payload else {}
            if not isinstance(payload, dict):
                payload = {"value": payload}
        except (ValueError, UnicodeDecodeError):
            logger.warning("MQTT payload bukan JSON di %s", msg.topic)
            return
        self.dispatch_threadsafe(msg.topic, payload)

    def dispatch_threadsafe(self, topic: str, payload: Dict[str, Any]) -> None:
        """Serahkan pesan ke event loop (aman dipanggil dari thread mana pun)."""
        loop = self._loop
        if loop is None or loop.is_closed():
            return
        loop.call_soon_threadsafe(self._dispatch, topic, payload)

    def _dispatch(self, topic: str, payload: Dict[str, Any]) -> None:
        """Dijalankan di thread event loop."""
        if topic.endswith("/ack"):
            cmd_id = payload.get("cmd_id")
            fut = self._pending.get(str(cmd_id)) if cmd_id else None
            if fut is not None and not fut.done():
                fut.set_result(payload)
        for fn in list(self._listeners):
            try:
                res = fn(topic, payload)
                if asyncio.iscoroutine(res):
                    asyncio.ensure_future(res)
            except Exception:  # pragma: no cover
                logger.exception("Listener MQTT gagal untuk %s", topic)

    # ------------------------------------------------------------------
    # Perintah
    # ------------------------------------------------------------------
    def build_topic(self, device_id: str, action: str) -> str:
        return f"{self.topic_prefix}/{device_id}/command/{action}"

    def ensure_ready(self) -> None:
        if self.simulate and not self.configured:
            return
        if not self.configured:
            raise MqttNotConfigured(
                "Broker MQTT belum dikonfigurasi (MQTT_BROKER_URL). Kontrol perangkat tidak tersedia."
            )
        if not self.is_connected:
            raise MqttNotConnected(
                f"Backend belum terhubung ke broker MQTT {self.broker_url}:{self.broker_port}"
                + (f" ({self.last_error})" if self.last_error else "")
            )

    def publish_command(
        self,
        device_id: str,
        action: str,
        payload: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Publish perintah (QoS 1) dan kembalikan cmd_id.

        Harus dipanggil dari event loop (future ack didaftarkan SEBELUM publish
        agar ack cepat tidak terlewat). Lempar MqttNotConfigured/MqttNotConnected.
        """
        self.ensure_ready()
        if self._loop is None:
            self._loop = asyncio.get_event_loop()
        cmd_id = uuid.uuid4().hex
        body = {**(payload or {}), "cmd_id": cmd_id, "action": action, "ts": utc_now_iso()}
        self._pending[cmd_id] = self._loop.create_future()

        if self.simulate and not self.configured:
            ack = {"cmd_id": cmd_id, "ok": True, "error": None, "response": "simulated", "ts": utc_now_iso()}
            self._loop.call_later(0.05, self._dispatch, f"{self.topic_prefix}/{device_id}/ack", ack)
            return cmd_id

        assert self.client is not None
        info = self.client.publish(self.build_topic(device_id, action), json.dumps(body, default=str), qos=1)
        if info.rc != 0:
            self._pending.pop(cmd_id, None)
            raise MqttNotConnected(f"Publish MQTT gagal (rc={info.rc})")
        return cmd_id

    async def wait_ack(self, cmd_id: str, timeout: float = 3.0) -> Optional[Dict[str, Any]]:
        """Tunggu ack agent. None bila timeout."""
        fut = self._pending.get(cmd_id)
        if fut is None:
            return None
        try:
            return await asyncio.wait_for(asyncio.shield(fut), timeout=timeout)
        except asyncio.TimeoutError:
            return None
        finally:
            self._pending.pop(cmd_id, None)

    def publish_raw(self, topic: str, payload: Dict[str, Any], retain: bool = False) -> None:
        """Publish bebas (dipakai tes/alat bantu). Tidak dipakai jalur perintah."""
        self.ensure_ready()
        if self.client is not None:
            self.client.publish(topic, json.dumps(payload, default=str), qos=1, retain=retain)


mqtt_manager = MqttManager()
