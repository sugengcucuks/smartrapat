"""Role-based access control (RBAC).

Sumber kebenaran izin ada di backend. Frontend hanya menyembunyikan menu/tombol
untuk UX; setiap endpoint yang mengubah data WAJIB memakai `require_permission`.

Aturan:
- Role bernama "Super Admin" atau yang memiliki izin "*" -> semua izin.
- Selain itu, izin diambil dari kolom `roles.permissions` (JSON list kode izin).
- Kode lama bergaya "users:write" (seed awal) dipetakan ke kode baru via LEGACY_MAP.
"""
from typing import Iterable, Set

from fastapi import Depends, HTTPException, status

from src.api.models.user import User
from src.api.utils.auth import get_current_user

# Katalog izin resmi. `code` dipakai di roles.permissions dan di require_permission.
PERMISSIONS = [
    {"id": "perm_users_view", "code": "users.view", "name": "Lihat Data Pengguna", "group": "users"},
    {"id": "perm_users_create", "code": "users.create", "name": "Tambah Pengguna", "group": "users"},
    {"id": "perm_users_edit", "code": "users.edit", "name": "Ubah Pengguna", "group": "users"},
    {"id": "perm_users_delete", "code": "users.delete", "name": "Hapus Pengguna", "group": "users"},
    {"id": "perm_roles_view", "code": "roles.view", "name": "Lihat Peran & Izin", "group": "users"},
    {"id": "perm_roles_write", "code": "roles.write", "name": "Kelola Peran & Izin", "group": "users"},
    {"id": "perm_rooms_view", "code": "rooms.view", "name": "Lihat Ruangan & Gedung", "group": "rooms"},
    {"id": "perm_rooms_write", "code": "rooms.write", "name": "Kelola Ruangan, Gedung & Denah Kursi", "group": "rooms"},
    {"id": "perm_bookings_view", "code": "bookings.view", "name": "Lihat Pemesanan", "group": "bookings"},
    {"id": "perm_bookings_create", "code": "bookings.create", "name": "Buat Pemesanan", "group": "bookings"},
    {"id": "perm_bookings_approve", "code": "bookings.approve", "name": "Setujui/Kelola Semua Pemesanan", "group": "bookings"},
    {"id": "perm_bookings_delete", "code": "bookings.delete", "name": "Hapus Pemesanan", "group": "bookings"},
    {"id": "perm_notes_view", "code": "notes.view", "name": "Lihat Notulensi", "group": "notes"},
    {"id": "perm_notes_write", "code": "notes.write", "name": "Kelola Notulensi & Rekaman", "group": "notes"},
    {"id": "perm_devices_view", "code": "devices.view", "name": "Lihat Perangkat", "group": "devices"},
    {"id": "perm_devices_write", "code": "devices.write", "name": "Kelola Perangkat IoT/AV", "group": "devices"},
    {"id": "perm_devices_control", "code": "devices.control", "name": "Kontrol Perangkat (Power/Lock)", "group": "devices"},
    {"id": "perm_audio_control", "code": "audio.control", "name": "Kontrol Audio & Mic", "group": "devices"},
    {"id": "perm_videowall_control", "code": "videowall.control", "name": "Kontrol Videowall", "group": "devices"},
    {"id": "perm_reports_view", "code": "reports.view", "name": "Lihat Laporan", "group": "reports"},
    {"id": "perm_reports_export", "code": "reports.export", "name": "Export Laporan PDF/Excel", "group": "reports"},
    {"id": "perm_notifications_send", "code": "notifications.send", "name": "Broadcast Pemberitahuan", "group": "settings"},
    {"id": "perm_settings_view", "code": "settings.view", "name": "Lihat Pengaturan Sistem", "group": "settings"},
    {"id": "perm_settings_write", "code": "settings.write", "name": "Ubah Pengaturan Sistem", "group": "settings"},
    {"id": "perm_audit_read", "code": "audit.read", "name": "Lihat Log Audit", "group": "audit"},
    {"id": "perm_maintenance", "code": "system.maintenance", "name": "Akses Pemeliharaan Sistem", "group": "settings"},
    {"id": "perm_display_manage", "code": "door_display.manage", "name": "Kelola Display Depan Pintu", "group": "rooms"},
]

PERMISSION_CODES: Set[str] = {p["code"] for p in PERMISSIONS}
PERMISSION_ID_TO_CODE = {p["id"]: p["code"] for p in PERMISSIONS}

# Pemetaan kode seed lama (001_initial_schema.sql) ke kode baru.
LEGACY_MAP = {
    "users:read": {"users.view", "roles.view"},
    "users:write": {"users.view", "users.create", "users.edit", "users.delete"},
    "rooms:read": {"rooms.view"},
    "rooms:write": {"rooms.view", "rooms.write", "door_display.manage"},
    "bookings:read": {"bookings.view"},
    "bookings:write": {"bookings.view", "bookings.create"},
    "reports:read": {"reports.view", "reports.export"},
    "settings:read": {"settings.view"},
    "settings:write": {"settings.view", "settings.write"},
    "devices:read": {"devices.view"},
    "devices:write": {"devices.view", "devices.control", "audio.control", "videowall.control"},
    "system.admin": {"system.maintenance"},
}


def normalize_permissions(raw: Iterable[str]) -> Set[str]:
    """Terima kode baru, kode lama, atau id `perm_*`; kembalikan set kode baru."""
    out: Set[str] = set()
    for item in raw or []:
        if not isinstance(item, str):
            continue
        if item == "*":
            out.add("*")
        elif item in PERMISSION_CODES:
            out.add(item)
        elif item in PERMISSION_ID_TO_CODE:
            out.add(PERMISSION_ID_TO_CODE[item])
        elif item in LEGACY_MAP:
            out |= LEGACY_MAP[item]
    return out


def is_super_admin_role_name(name: str | None) -> bool:
    rn = (name or "").strip().lower().replace(" ", "_")
    return rn == "super_admin"


def user_permissions(user: User) -> Set[str]:
    role = getattr(user, "role", None)
    if role is None or not getattr(role, "is_active", True):
        return set()
    perms = normalize_permissions(role.permissions or [])
    if is_super_admin_role_name(role.name) or "*" in perms:
        return {"*"}
    return perms


def has_permission(user: User, *codes: str) -> bool:
    """True bila user memiliki SALAH SATU dari `codes`."""
    perms = user_permissions(user)
    if "*" in perms:
        return True
    return any(c in perms for c in codes)


def is_super_admin(user: User) -> bool:
    return "*" in user_permissions(user)


def require_permission(*codes: str):
    """Dependency FastAPI: izinkan bila user punya salah satu `codes`."""
    for c in codes:
        if c not in PERMISSION_CODES:
            raise ValueError(f"Kode izin tidak dikenal: {c}")

    async def _dep(current_user: User = Depends(get_current_user)) -> User:
        if not has_permission(current_user, *codes):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={"code": "FORBIDDEN", "message": "Anda tidak memiliki izin untuk aksi ini"},
            )
        return current_user

    return _dep


def require_super_admin():
    async def _dep(current_user: User = Depends(get_current_user)) -> User:
        if not is_super_admin(current_user):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={"code": "FORBIDDEN", "message": "Hanya Super Admin"},
            )
        return current_user

    return _dep
