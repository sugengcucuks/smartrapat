from sqlalchemy import Column, String, DateTime, ForeignKey, JSON, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid

from src.api.database import Base


class Device(Base):
    __tablename__ = "devices"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(150), nullable=False)
    device_type = Column(String(30), nullable=False)
    code = Column(String(30), unique=True, nullable=False)
    location_id = Column(UUID(as_uuid=True), ForeignKey("rooms.id"))
    ip_address = Column(String(45))
    mac_address = Column(String(20))
    firmware_version = Column(String(50))
    status = Column(String(20), nullable=False, default="offline")
    last_seen = Column(DateTime(timezone=True))
    config = Column(JSON, default=dict)
    last_action = Column(String(200))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    room = relationship("Room")
