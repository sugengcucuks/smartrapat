"""Model live meeting: kanal mic, denah kursi, penugasan kursi, rekaman & transkrip.

Skema: src/api/db/migrations/015_live_meeting_audio.sql
Alur: docs/architecture/LIVE_MEETING.md
"""
from sqlalchemy import (
    BigInteger, Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid

from src.api.database import Base


class AudioChannel(Base):
    """Satu kanal mic fisik di ruangan (mis. receiver Ashley M118-A, CH-3)."""
    __tablename__ = "audio_channels"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    room_id = Column(UUID(as_uuid=True), ForeignKey("rooms.id", ondelete="CASCADE"), nullable=False, index=True)
    channel_no = Column(Integer, nullable=False)          # nomor mic logis 1..N di ruangan
    label = Column(String(100), nullable=False)           # "Mic 3"
    receiver_label = Column(String(100))                  # "M118-A CH-3"
    mixer_channel = Column(Integer)                       # kanal di digital mixer (X-Air), bila ada
    capture_channel = Column(Integer)                     # indeks kanal di audio interface USB (1-based)
    device_id = Column(UUID(as_uuid=True), ForeignKey("devices.id", ondelete="SET NULL"))  # mixer/interface
    is_enabled = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    seat = relationship("RoomSeat", back_populates="audio_channel", uselist=False)


class RoomSeat(Base):
    """Kursi pada denah ruangan. Posisi dalam persen (0-100) agar responsif."""
    __tablename__ = "room_seats"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    room_id = Column(UUID(as_uuid=True), ForeignKey("rooms.id", ondelete="CASCADE"), nullable=False, index=True)
    seat_no = Column(Integer, nullable=False)
    label = Column(String(50), nullable=False)
    seat_type = Column(String(20), nullable=False, default="delegate")  # chair|delegate|secretary|guest|operator
    pos_x = Column(Float, nullable=False, default=50)
    pos_y = Column(Float, nullable=False, default=50)
    rotation = Column(Integer, nullable=False, default=0)
    audio_channel_id = Column(UUID(as_uuid=True), ForeignKey("audio_channels.id", ondelete="SET NULL"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    audio_channel = relationship("AudioChannel", back_populates="seat")


class BookingSeatAssignment(Base):
    """Per rapat: kursi -> peserta (manual oleh operator atau otomatis saat presensi)."""
    __tablename__ = "booking_seat_assignments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    booking_id = Column(UUID(as_uuid=True), ForeignKey("bookings.id", ondelete="CASCADE"), nullable=False, index=True)
    seat_id = Column(UUID(as_uuid=True), ForeignKey("room_seats.id", ondelete="CASCADE"), nullable=False)
    participant_id = Column(UUID(as_uuid=True), ForeignKey("booking_participants.id", ondelete="SET NULL"))
    display_name = Column(String(200))
    role_label = Column(String(50))                       # "Pimpinan Rapat", "Notulis", "Peserta"
    assigned_via = Column(String(20), nullable=False, default="manual")  # manual|checkin|auto
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    seat = relationship("RoomSeat")
    participant = relationship("BookingParticipant")


class MeetingRecording(Base):
    __tablename__ = "meeting_recordings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    booking_id = Column(UUID(as_uuid=True), ForeignKey("bookings.id", ondelete="CASCADE"), nullable=False, index=True)
    note_id = Column(UUID(as_uuid=True), ForeignKey("meeting_notes.id", ondelete="SET NULL"))
    source = Column(String(20), nullable=False, default="multichannel")  # multichannel|mix|browser|upload
    status = Column(String(20), nullable=False, default="recording")     # recording|paused|stopped|processing|done|failed
    channel_count = Column(Integer, nullable=False, default=1)
    started_at = Column(DateTime(timezone=True), server_default=func.now())
    paused_at = Column(DateTime(timezone=True))
    paused_ms = Column(BigInteger, nullable=False, default=0, server_default="0")  # migration 017
    ended_at = Column(DateTime(timezone=True))
    file_path = Column(String(500))
    error = Column(Text)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class TranscriptSegment(Base):
    __tablename__ = "meeting_transcript_segments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    note_id = Column(UUID(as_uuid=True), ForeignKey("meeting_notes.id", ondelete="CASCADE"), nullable=False, index=True)
    booking_id = Column(UUID(as_uuid=True), ForeignKey("bookings.id", ondelete="CASCADE"))
    recording_id = Column(UUID(as_uuid=True), ForeignKey("meeting_recordings.id", ondelete="SET NULL"))
    start_ms = Column(BigInteger, nullable=False, default=0)   # relatif terhadap awal rapat/rekaman
    end_ms = Column(BigInteger, nullable=False, default=0)
    audio_channel_no = Column(Integer)
    seat_id = Column(UUID(as_uuid=True), ForeignKey("room_seats.id", ondelete="SET NULL"))
    participant_id = Column(UUID(as_uuid=True), ForeignKey("booking_participants.id", ondelete="SET NULL"))
    speaker_name = Column(String(200))
    text = Column(Text, nullable=False)
    confidence = Column(Float)
    language = Column(String(10))
    is_edited = Column(Boolean, nullable=False, default=False)
    audio_path = Column(String(500))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
