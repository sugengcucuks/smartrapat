from sqlalchemy import Column, String, DateTime, ForeignKey, Date, Time, Text, Boolean, JSON
from sqlalchemy.dialects.postgresql import UUID, ARRAY, JSONB
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid

from src.api.database import Base


class MeetingNote(Base):
    __tablename__ = "meeting_notes"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    booking_id = Column(UUID(as_uuid=True), ForeignKey("bookings.id"))
    room_id = Column(UUID(as_uuid=True), ForeignKey("rooms.id"))
    title = Column(String(200), nullable=False)
    date = Column(Date, nullable=False)
    start_time = Column(Time, nullable=False)
    end_time = Column(Time, nullable=False)
    participants = Column(ARRAY(Text), default=list)
    summary = Column(Text)
    decisions = Column(ARRAY(Text), default=list)
    transcript = Column(JSON, default=list)
    transcript_processing = Column(Boolean, nullable=False, default=False)
    ai_model = Column(String(50))
    generated_at = Column(DateTime(timezone=True))
    # migration 015: draft | final, ringkasan terstruktur hasil LLM
    status = Column(String(20), nullable=False, default="draft", server_default="draft")
    summary_json = Column(JSONB)
    finalized_at = Column(DateTime(timezone=True))
    finalized_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    booking = relationship("Booking")
    room = relationship("Room")
    creator = relationship("User", foreign_keys=[created_by])
    action_items = relationship("MeetingNoteActionItem", back_populates="note", cascade="all, delete-orphan")


class MeetingNoteActionItem(Base):
    __tablename__ = "meeting_note_action_items"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    note_id = Column(UUID(as_uuid=True), ForeignKey("meeting_notes.id", ondelete="CASCADE"), nullable=False)
    task = Column(Text, nullable=False)
    owner = Column(String(100))
    due_date = Column(Date)
    status = Column(String(20), nullable=False, default="open")
    # migration 017: manual | ai (item hasil ringkasan AI diganti saat ringkasan dibuat ulang)
    source = Column(String(10), nullable=False, default="manual", server_default="manual")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    note = relationship("MeetingNote", back_populates="action_items")
