from sqlalchemy import Column, String, DateTime, ForeignKey, Date, Text, Enum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid

from src.api.database import Base


class Equipment(Base):
    __tablename__ = "equipment"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(150), nullable=False)
    code = Column(String(30), unique=True, nullable=False)
    category = Column(String(20), nullable=False, default="other")
    brand = Column(String(100))
    model = Column(String(100))
    serial_number = Column(String(100))
    purchase_date = Column(Date)
    warranty_until = Column(Date)
    status = Column(String(20), nullable=False, default="active")
    notes = Column(Text)
    location_id = Column(UUID(as_uuid=True), ForeignKey("rooms.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    room = relationship("Room")
