from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey, Enum, Integer, Text, Float, JSON
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid

from src.api.database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username = Column(String(50), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    name = Column(String(100), nullable=False)
    email = Column(String(255), unique=True, nullable=False, index=True)
    nik = Column(String(20), unique=True)
    rank = Column(String(50))
    position = Column(String(100))
    role_id = Column(UUID(as_uuid=True), ForeignKey("roles.id"))
    department_id = Column(UUID(as_uuid=True), ForeignKey("departments.id"))
    avatar_url = Column(String(500))
    phone = Column(String(20))
    # Kolom di PostgreSQL bertipe enum user_status, bukan varchar. Tanpa deklarasi
    # ini, filter seperti User.status == "ACTIVE" gagal dengan UndefinedFunctionError.
    status = Column(
        Enum("ACTIVE", "INACTIVE", "SUSPENDED", name="user_status", create_type=False),
        default="ACTIVE",
    )
    last_login = Column(DateTime(timezone=True))
    login_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime(timezone=True))
    # Naik setiap logout/ganti password -> semua token lama otomatis tidak berlaku.
    token_version = Column(Integer, nullable=False, default=0, server_default="0")
    must_change_password = Column(Boolean, nullable=False, default=False, server_default="false")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    role = relationship("Role", back_populates="users")
    department = relationship("Department", back_populates="users", foreign_keys=[department_id])


class Role(Base):
    __tablename__ = "roles"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(50), unique=True, nullable=False)
    description = Column(Text)
    permissions = Column(JSON, default=list)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    users = relationship("User", back_populates="role")


class Department(Base):
    __tablename__ = "departments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    code = Column(String(20), unique=True, nullable=False)
    name = Column(String(100), nullable=False)
    head_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    users = relationship("User", back_populates="department", foreign_keys="[User.department_id]")
    head = relationship("User", foreign_keys=[head_id])
