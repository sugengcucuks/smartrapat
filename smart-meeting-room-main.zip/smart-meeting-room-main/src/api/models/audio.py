from sqlalchemy import Column, String, DateTime, ForeignKey, Integer, Boolean, Enum as SAEnum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid

from src.api.database import Base


class AudioZone(Base):
    __tablename__ = "audio_zones"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    room_id = Column(UUID(as_uuid=True), ForeignKey("rooms.id"), nullable=False)
    device_id = Column(UUID(as_uuid=True), ForeignKey("devices.id"))
    zone_name = Column(String(100), nullable=False)
    volume = Column(Integer, nullable=False, default=60)
    is_muted = Column(Boolean, nullable=False, default=False)
    input_source = Column(
        SAEnum(
            "mic1", "mic2", "line1", "bluetooth", "hdmi", "usb",
            name="audio_source",
            values_callable=lambda e: [m.name for m in e],
            create_type=False,
        ),
        nullable=False,
        default="mic1",
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    room = relationship("Room")
    device = relationship("Device")
