from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey, Integer, Text, JSON
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid

from src.api.database import Base


class Building(Base):
    __tablename__ = "buildings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(100), nullable=False)
    code = Column(String(20), unique=True, nullable=False)
    floors = Column(Integer, nullable=False, default=1)
    address = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    rooms = relationship("Room", back_populates="building")


class Room(Base):
    __tablename__ = "rooms"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(100), nullable=False)
    code = Column(String(20), unique=True, nullable=False)
    building_id = Column(UUID(as_uuid=True), ForeignKey("buildings.id"))
    floor = Column(Integer, nullable=False, default=1)
    capacity = Column(Integer, nullable=False, default=10)
    room_type = Column(String(20), nullable=False, default="meeting")
    description = Column(Text)
    amenities = Column(JSON, default=list)
    layout_url = Column(String(500))
    status = Column(String(20), nullable=False, default="available")
    pairing_key = Column(String(20), unique=True, index=True)
    master_pin_hash = Column(String(255))
    # Bentuk meja denah kursi (migration 018), lihat routers/live_meeting.py
    seat_layout = Column(JSONB)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    building = relationship("Building", back_populates="rooms")
    bookings = relationship("Booking", back_populates="room")
