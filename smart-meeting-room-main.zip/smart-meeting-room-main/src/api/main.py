from pathlib import Path
from dotenv import load_dotenv

# Load .env dari project root (sebelum settings & service lain membaca env)
load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from contextlib import asynccontextmanager
from uuid import UUID
from datetime import datetime
from typing import Optional
from sqlalchemy import select

from src.api.config import settings, validate_security_settings
from src.api.database import async_session
from src.api.models.room import Room
from src.api.routers import auth
from src.api.routers import users
from src.api.routers import roles
from src.api.routers import rooms
from src.api.routers import bookings
from src.api.routers import calendar
from src.api.routers import equipment
from src.api.routers import devices
from src.api.routers import videowall
from src.api.routers import audio
from src.api.routers import notes
from src.api.routers import notifications as notifications_router
from src.api.routers import reports as reports_router
from src.api.routers import settings as settings_router
from src.api.routers import door_display as door_display_router
from src.api.routers import audit as audit_router
from src.api.routers import system_maintenance as system_maintenance_router
from src.api.routers import presensi as presensi_router
from src.api.routers import license as license_router
from src.api.routers import av_control as av_control_router
from src.api.routers import live_ws as live_ws_router
from src.api.routers import live_meeting as live_meeting_router
from src.api.routers import search as search_router
from src.api.routers import followups as followups_router
from src.api.routers import setup as setup_router
from src.api.routers.notifications import ws_manager
from src.api.routers.door_display import door_ws_manager, _get_status_payload
from src.api.services.status_scheduler import status_scheduler
from src.api.services.transcription import transcription_service
from src.api.services.live_hub import live_hub
from src.api.utils.mqtt_client import mqtt_manager
from src.api.middleware.license_gate import LicenseGateMiddleware
from src.api.utils.auth import decode_token, get_user_from_payload
from src.api.utils.kiosk import verify_kiosk_token


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    validate_security_settings(settings)
    print(f"Starting {settings.APP_NAME} v{settings.APP_VERSION}")
    status_scheduler.start()
    await transcription_service.start()
    # MQTT: perintah perangkat + subscriber ack/state/audio -> hub WS live
    import asyncio
    mqtt_manager.add_listener(live_hub.handle_mqtt)
    mqtt_manager.start(asyncio.get_running_loop())
    yield
    # Shutdown
    mqtt_manager.stop()
    await transcription_service.stop()
    await status_scheduler.stop()
    print("Shutting down...")


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Smart Meeting Room API",
    docs_url="/docs" if settings.ENABLE_API_DOCS else None,
    redoc_url="/redoc" if settings.ENABLE_API_DOCS else None,
    openapi_url="/openapi.json" if settings.ENABLE_API_DOCS else None,
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Gating lisensi: blokir seluruh API bila lisensi belum aktif.
app.add_middleware(LicenseGateMiddleware)

# Include routers
app.include_router(license_router.router, prefix="/api/v1")
app.include_router(auth.router, prefix="/api/v1")
app.include_router(users.router, prefix="/api/v1")
app.include_router(roles.router, prefix="/api/v1")
app.include_router(rooms.router, prefix="/api/v1")
app.include_router(bookings.router, prefix="/api/v1")
app.include_router(calendar.router, prefix="/api/v1")
app.include_router(equipment.router, prefix="/api/v1")
app.include_router(devices.router, prefix="/api/v1")
app.include_router(videowall.router, prefix="/api/v1")
app.include_router(audio.router, prefix="/api/v1")
app.include_router(notes.router, prefix="/api/v1")
app.include_router(notifications_router.router, prefix="/api/v1")
app.include_router(reports_router.router, prefix="/api/v1")
app.include_router(settings_router.router, prefix="/api/v1")
app.include_router(door_display_router.router, prefix="/api/v1")
app.include_router(audit_router.router, prefix="/api/v1")
app.include_router(presensi_router.router, prefix="/api/v1")
app.include_router(av_control_router.router, prefix="/api/v1")
app.include_router(live_ws_router.router, prefix="/api/v1")
app.include_router(live_meeting_router.router, prefix="/api/v1")
app.include_router(search_router.router, prefix="/api/v1")
app.include_router(followups_router.router, prefix="/api/v1")
app.include_router(setup_router.router, prefix="/api/v1")
app.include_router(system_maintenance_router.router, prefix="/api/v1/system")
app.include_router(system_maintenance_router.router, prefix="/api/v1/maintenance")


# ---------------------------------------------------------------------------
# SERVE FRONTEND PRODUKSI (single port)
# Bila folder dist/ (hasil `npx vite build`) ada, backend juga menyajikan
# frontend sehingga cukup 1 port untuk semuanya. Fallback SPA: semua path
# non-API dikembalikan index.html agar React Router bekerja.
# ---------------------------------------------------------------------------
DIST_DIR = Path(__file__).resolve().parents[2] / "dist"
HAS_DIST = (DIST_DIR / "index.html").exists()


@app.get("/")
async def root():
    if HAS_DIST:
        return FileResponse(DIST_DIR / "index.html")
    return {"message": "Smart Meeting Room API", "version": settings.APP_VERSION}


@app.get("/health")
async def health_check():
    return {"status": "healthy"}


@app.websocket("/api/v1/ws/notifications")
async def ws_notifications_v2(
    websocket: WebSocket,
    token: Optional[str] = Query(None, description="JWT access token (query param)"),
):
    """WebSocket endpoint for real-time notifications with JWT auth via ?token=.

    Frontend connects to: ws://host:8000/api/v1/ws/notifications?token=<access_token>
    """
    user_id: Optional[UUID] = None
    if token:
        try:
            payload = decode_token(token, expected_type="access")
            async with async_session() as db:
                ws_user = await get_user_from_payload(payload, db)
            user_id = ws_user.id
        except Exception:
            user_id = None

    if not user_id:
        await websocket.accept()
        await websocket.send_json({"event": "error", "type": "auth_error", "message": "Invalid or missing token"})
        try:
            await websocket.close(code=1008, reason="Auth failed")
        except Exception:
            pass
        return

    await ws_manager.connect(user_id, websocket)
    try:
        await websocket.send_json({
            "event": "connected",
            "type": "connected",
            "message": "Realtime notification WebSocket connected",
            "user_id": str(user_id),
            "timestamp": datetime.now().isoformat(),
        })
        while True:
            try:
                data = await websocket.receive_text()
                try:
                    msg = __import__("json").loads(data) if isinstance(data, str) else {}
                    if isinstance(msg, dict) and msg.get("type") == "ping":
                        await websocket.send_json({"type": "pong", "timestamp": datetime.now().isoformat()})
                except Exception:
                    pass
            except WebSocketDisconnect:
                break
    finally:
        ws_manager.disconnect(user_id, websocket)


@app.websocket("/api/v1/ws/door-display/{room_code}")
async def ws_door_display(
    websocket: WebSocket,
    room_code: str,
    kiosk_token: Optional[str] = Query(None, description="Token kiosk dari POST /door-display/pair"),
):
    """WebSocket realtime untuk kiosk display depan pintu.

    Wajib token kiosk yang valid untuk ruangan ini:
      ws://host:8000/api/v1/ws/door-display/<ROOM_CODE>?kiosk_token=<token>
    Events pushed from server:
      - connected: initial payload with current status on first connect
      - status_changed: full room status payload recomputed after any booking change
      - booking_created / booking_extended / booking_cancelled: event notifications
    """
    room = None
    try:
        async with async_session() as db:
            room = await verify_kiosk_token(db, kiosk_token, room_code)
    except HTTPException:
        room = None
    if room is None:
        await websocket.accept()
        await websocket.send_json({
            "event": "error",
            "type": "auth_error",
            "code": "KIOSK_UNPAIRED",
            "message": "Kiosk belum dipasangkan atau sesi kiosk berakhir",
            "room_code": room_code,
            "timestamp": datetime.now().isoformat(),
        })
        try:
            await websocket.close(code=4401, reason="Kiosk unauthorized")
        except Exception:
            pass
        return

    await door_ws_manager.connect(room_code, websocket)
    try:
        async with async_session() as db:

            initial_payload = await _get_status_payload(db, room)
            await websocket.send_json({
                "event": "connected",
                "message": "Door display WebSocket terhubung",
                "room_code": room_code,
                "room_id": str(room.id),
                "timestamp": datetime.now().isoformat(),
            })
            await websocket.send_json({
                "event": "status_changed",
                "data": initial_payload,
                "room_code": room_code,
                "timestamp": datetime.now().isoformat(),
            })

        while True:
            try:
                data = await websocket.receive_text()
                try:
                    msg = __import__("json").loads(data) if isinstance(data, str) else {}
                    if isinstance(msg, dict) and msg.get("type") == "ping":
                        await websocket.send_json({
                            "type": "pong",
                            "room_code": room_code,
                            "timestamp": datetime.now().isoformat(),
                        })
                except Exception:
                    pass
            except WebSocketDisconnect:
                break
    finally:
        door_ws_manager.disconnect(room_code, websocket)


# ---------------------------------------------------------------------------
# SPA FALLBACK (harus paling akhir)
# ---------------------------------------------------------------------------
if HAS_DIST:
    if (DIST_DIR / "assets").exists():
        app.mount("/assets", StaticFiles(directory=DIST_DIR / "assets"), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def spa_fallback(full_path: str):
        # API/WS yang tidak terdaftar tetap 404 JSON, bukan index.html.
        if full_path.startswith(("api/", "ws/")):
            raise HTTPException(status_code=404, detail="Not found")
        candidate = (DIST_DIR / full_path).resolve()
        try:
            candidate.relative_to(DIST_DIR)
        except ValueError:
            raise HTTPException(status_code=404, detail="Not found")
        if full_path and candidate.is_file():
            return FileResponse(candidate)
        return FileResponse(DIST_DIR / "index.html")
