"""Middleware gating lisensi: blokir total bila lisensi tidak aktif."""
from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from src.api.licensing.service import evaluate, is_enforced

# Endpoint yang tetap boleh diakses walau lisensi belum aktif.
ALLOWED_PREFIXES = (
    "/api/v1/license",
    "/api/v1/auth/login",
    "/api/v1/auth/refresh",
    "/api/v1/setup",
    "/docs",
    "/redoc",
    "/openapi.json",
    "/health",
)

# Halaman publik yang tidak boleh diblokir (kiosk pintu + aset statis).
ALLOWED_EXACT = ("/",)


def _is_allowed(path: str) -> bool:
    if path in ALLOWED_EXACT:
        return True
    return path.startswith(ALLOWED_PREFIXES)


class LicenseGateMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if not is_enforced():
            return await call_next(request)

        path = request.url.path

        # Gating hanya untuk API & WebSocket. Frontend/aset statis selalu
        # terbuka agar halaman aktivasi lisensi tetap dapat diakses.
        is_api_call = path.startswith("/api") or path.startswith("/ws")
        if request.method == "OPTIONS" or not is_api_call:
            return await call_next(request)

        if _is_allowed(path):
            return await call_next(request)

        status_now = evaluate()
        if status_now.activated:
            return await call_next(request)

        return JSONResponse(
            status_code=402,
            content={
                "success": False,
                "detail": {
                    "code": "LICENSE_REQUIRED",
                    "message": status_now.reason or "Lisensi belum aktif",
                },
                "license": status_now.to_dict(),
            },
        )
