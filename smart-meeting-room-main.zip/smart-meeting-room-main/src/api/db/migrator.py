"""Runner migrasi SQL (dipakai scripts/migrate.py dan endpoint /system/migrations/run).

- Riwayat disimpan di tabel `schema_migrations(filename, applied_at)`.
- Berkas *.sql di src/api/db/migrations diterapkan berurutan, masing-masing
  dalam satu transaksi.
- Berkas lama 001-010 diketahui "kotor" (sebagian statement gagal pada DB baru
  karena skemanya ditulis ulang oleh 006/007). Berkas tersebut dijalankan dalam
  mode toleran: per statement dengan SAVEPOINT, error dicatat lalu dilanjutkan.
- Berkas 011 ke atas dijalankan mode ketat: satu error -> rollback & berhenti.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, List, Optional

import asyncpg

logger = logging.getLogger("smr.migrate")

MIGRATIONS_DIR = Path(__file__).resolve().parent / "migrations"
# Nomor berkas <= batas ini dijalankan mode toleran.
LEGACY_MAX_NUMBER = 10

CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS schema_migrations (
    filename VARCHAR(255) PRIMARY KEY,
    applied_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
)
"""


@dataclass
class FileResult:
    filename: str
    mode: str
    ok: bool = True
    statements: int = 0
    failed_statements: List[str] = field(default_factory=list)
    error: Optional[str] = None


def list_migration_files(directory: Path = MIGRATIONS_DIR) -> List[str]:
    if not directory.exists():
        return []
    return sorted(p.name for p in directory.glob("*.sql"))


def is_legacy(filename: str) -> bool:
    m = re.match(r"^(\d+)", filename)
    return bool(m) and int(m.group(1)) <= LEGACY_MAX_NUMBER


def split_sql(sql: str) -> List[str]:
    """Pecah skrip SQL menjadi statement, memperhatikan string, komentar & $tag$."""
    out: List[str] = []
    buf: List[str] = []
    i, n = 0, len(sql)
    while i < n:
        ch = sql[i]
        nxt = sql[i + 1] if i + 1 < n else ""
        if ch == "-" and nxt == "-":
            j = sql.find("\n", i)
            j = n if j == -1 else j
            buf.append(sql[i:j])
            i = j
            continue
        if ch == "/" and nxt == "*":
            j = sql.find("*/", i + 2)
            j = n if j == -1 else j + 2
            buf.append(sql[i:j])
            i = j
            continue
        if ch in ("'", '"'):
            j = i + 1
            while j < n:
                if sql[j] == ch:
                    if j + 1 < n and sql[j + 1] == ch:
                        j += 2
                        continue
                    break
                j += 1
            buf.append(sql[i:j + 1])
            i = j + 1
            continue
        if ch == "$":
            m = re.match(r"\$([A-Za-z_][A-Za-z0-9_]*)?\$", sql[i:])
            if m:
                tag = m.group(0)
                j = sql.find(tag, i + len(tag))
                j = n if j == -1 else j + len(tag)
                buf.append(sql[i:j])
                i = j
                continue
        if ch == ";":
            stmt = "".join(buf).strip()
            if _has_code(stmt):
                out.append(stmt)
            buf = []
            i += 1
            continue
        buf.append(ch)
        i += 1
    stmt = "".join(buf).strip()
    if _has_code(stmt):
        out.append(stmt)
    return out


def _has_code(stmt: str) -> bool:
    no_comments = re.sub(r"--[^\n]*", "", stmt)
    no_comments = re.sub(r"/\*.*?\*/", "", no_comments, flags=re.S)
    return bool(no_comments.strip())


def _head(stmt: str) -> str:
    lines = [ln for ln in stmt.splitlines() if ln.strip() and not ln.strip().startswith("--")]
    return (" ".join(lines))[:100]


async def applied_migrations(conn: asyncpg.Connection) -> dict:
    await conn.execute(CREATE_TABLE_SQL)
    rows = await conn.fetch("SELECT filename, applied_at FROM schema_migrations")
    return {r["filename"]: r["applied_at"] for r in rows}


async def _apply_file(conn: asyncpg.Connection, path: Path, log: Callable[[str], None]) -> FileResult:
    sql = path.read_text(encoding="utf-8")
    legacy = is_legacy(path.name)
    res = FileResult(filename=path.name, mode="toleran" if legacy else "ketat")
    tr = conn.transaction()
    await tr.start()
    try:
        if legacy:
            for idx, stmt in enumerate(split_sql(sql), start=1):
                res.statements += 1
                sp = conn.transaction()  # nested -> SAVEPOINT
                await sp.start()
                try:
                    await conn.execute(stmt)
                    await sp.commit()
                except Exception as e:  # noqa: BLE001 - mode toleran
                    await sp.rollback()
                    msg = f"#{idx} {_head(stmt)} => {type(e).__name__}: {e}"
                    res.failed_statements.append(msg)
                    log(f"    [lewati] {msg}")
        else:
            res.statements = len(split_sql(sql))
            await conn.execute(sql)
        await conn.execute(
            "INSERT INTO schema_migrations (filename, applied_at) VALUES ($1, NOW()) "
            "ON CONFLICT (filename) DO NOTHING",
            path.name,
        )
        await tr.commit()
    except Exception as e:  # noqa: BLE001
        await tr.rollback()
        res.ok = False
        res.error = f"{type(e).__name__}: {e}"
    return res


async def run_pending(
    dsn: str,
    directory: Path = MIGRATIONS_DIR,
    log: Callable[[str], None] = logger.info,
    dry_run: bool = False,
) -> List[FileResult]:
    """Terapkan semua migrasi yang belum tercatat. Berhenti pada error mode ketat."""
    conn = await asyncpg.connect(dsn)
    results: List[FileResult] = []
    try:
        done = await applied_migrations(conn)
        if not done and await conn.fetchval("SELECT to_regclass('public.users') IS NOT NULL"):
            # DB lama yang dibuat manual (tanpa riwayat). Berkas legacy 007 men-DROP
            # tabel bookings, jadi JANGAN dijalankan ulang: tandai 001-010 sebagai
            # sudah diterapkan, lalu lanjutkan migrasi 011+.
            legacy = [f for f in list_migration_files(directory) if is_legacy(f)]
            log(f"DB sudah berisi skema tanpa riwayat migrasi -> baseline {len(legacy)} berkas legacy.")
            if not dry_run:
                for f in legacy:
                    await conn.execute(
                        "INSERT INTO schema_migrations (filename) VALUES ($1) ON CONFLICT DO NOTHING", f
                    )
                done = await applied_migrations(conn)
            else:
                done = {f: None for f in legacy}
        pending = [f for f in list_migration_files(directory) if f not in done]
        if not pending:
            log("Tidak ada migrasi tertunda.")
            return results
        for fname in pending:
            if dry_run:
                log(f"[pending] {fname}")
                continue
            log(f"-> {fname} ({'toleran' if is_legacy(fname) else 'ketat'})")
            res = await _apply_file(conn, directory / fname, log)
            results.append(res)
            if not res.ok:
                log(f"[GAGAL] {fname}: {res.error}")
                break
            extra = f", {len(res.failed_statements)} statement dilewati" if res.failed_statements else ""
            log(f"[OK] {fname} ({res.statements} statement{extra})")
    finally:
        await conn.close()
    return results
