-- ============================================================
-- 009 - Presensi QR: kode tiket unik per peserta rapat
-- ============================================================
-- Kolom ticket_code menyimpan kode tiket presensi (format TC-XXXXXX)
-- yang di-generate otomatis saat booking dibuat, lalu di-encode
-- menjadi QR di sisi frontend.
--
-- Migrasi ini idempotent: aman dijalankan berulang di database
-- yang kolomnya sudah pernah ditambahkan.
-- ============================================================

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'booking_participants' AND column_name = 'ticket_code'
    ) THEN
        ALTER TABLE booking_participants ADD COLUMN ticket_code VARCHAR(20);
    END IF;
END $$;

-- Satu tiket hanya boleh dipakai satu peserta.
-- Partial index: peserta lama yang belum punya tiket tidak ikut terbentur.
CREATE UNIQUE INDEX IF NOT EXISTS idx_bp_ticket_code
    ON booking_participants (ticket_code)
    WHERE ticket_code IS NOT NULL;

-- Mempercepat lookup scan tiket (tiket + booking sekaligus).
CREATE INDEX IF NOT EXISTS idx_bp_ticket_lookup
    ON booking_participants (ticket_code, booking_id);

-- Backfill peserta lama yang belum punya tiket.
-- Alfabet sama dengan src/api/utils/ticket.py (tanpa 0, 1, L).
DO $$
DECLARE
    rec RECORD;
    alphabet TEXT := '23456789ABCDEFGHIJKMNOPQRSTUVWXYZ';
    candidate TEXT;
    i INT;
    attempt INT;
BEGIN
    FOR rec IN SELECT id FROM booking_participants WHERE ticket_code IS NULL LOOP
        attempt := 0;
        LOOP
            candidate := 'TC-';
            FOR i IN 1..6 LOOP
                candidate := candidate || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1);
            END LOOP;
            attempt := attempt + 1;
            EXIT WHEN NOT EXISTS (
                SELECT 1 FROM booking_participants WHERE ticket_code = candidate
            );
            IF attempt > 50 THEN
                RAISE EXCEPTION 'Gagal membuat tiket unik untuk participant %', rec.id;
            END IF;
        END LOOP;
        UPDATE booking_participants SET ticket_code = candidate WHERE id = rec.id;
    END LOOP;
END $$;
