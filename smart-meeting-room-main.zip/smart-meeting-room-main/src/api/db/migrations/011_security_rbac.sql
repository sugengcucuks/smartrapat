-- ============================================================
-- MIGRATION 011: Security hardening & RBAC
-- - users.token_version        : revoke token saat logout / ganti password
-- - users.must_change_password : paksa ganti password default
-- - roles.permissions          : normalisasi ke kode izin baru (users.view, ...)
-- Idempotent: aman dijalankan berulang kali.
-- ============================================================

ALTER TABLE users ADD COLUMN IF NOT EXISTS token_version INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN NOT NULL DEFAULT FALSE;

-- Akun admin seed (password "admin123") wajib ganti password saat login pertama.
UPDATE users
   SET must_change_password = TRUE
 WHERE password_hash = '$2b$12$m2GDQU9XhUGoHB7MzDyituL3t5BQrx6rzXPQuK936FUGE78wwIi5q';

-- Normalisasi izin role bawaan ke katalog izin baru (src/api/utils/permissions.py).
-- Hanya role bawaan yang masih memakai kode lama ("xxx:yyy") yang diubah.
UPDATE roles SET permissions = '["*"]'::jsonb
 WHERE lower(replace(name, ' ', '_')) = 'super_admin';

UPDATE roles SET permissions = '[
    "users.view","users.create","users.edit","users.delete","roles.view",
    "rooms.view","rooms.write","door_display.manage",
    "bookings.view","bookings.create","bookings.approve","bookings.delete",
    "notes.view","notes.write",
    "devices.view","devices.write","devices.control","audio.control","videowall.control",
    "reports.view","reports.export","notifications.send",
    "settings.view","settings.write","audit.read"
]'::jsonb
 WHERE lower(name) = 'admin'
   AND (permissions IS NULL OR permissions::text LIKE '%:%' OR jsonb_array_length(permissions::jsonb) = 0);

UPDATE roles SET permissions = '[
    "rooms.view","bookings.view","bookings.create","bookings.approve",
    "notes.view","notes.write",
    "devices.view","devices.control","audio.control","videowall.control"
]'::jsonb
 WHERE lower(name) = 'operator'
   AND (permissions IS NULL OR permissions::text LIKE '%:%' OR jsonb_array_length(permissions::jsonb) = 0);

UPDATE roles SET permissions = '["rooms.view","bookings.view","bookings.create","notes.view"]'::jsonb
 WHERE lower(name) IN ('user', 'staff')
   AND (permissions IS NULL OR permissions::text LIKE '%:%' OR jsonb_array_length(permissions::jsonb) = 0);
