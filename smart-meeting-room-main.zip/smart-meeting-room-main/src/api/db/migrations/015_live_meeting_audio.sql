-- ============================================================
-- MIGRATION 015: Live meeting, mic/kursi, rekaman & transkrip
-- Lihat docs/architecture/LIVE_MEETING.md untuk alur lengkap.
--
-- audio_channels              : kanal mic fisik per ruangan (mis. Ashley M118-A CH-3)
-- room_seats                  : denah kursi per ruangan, kursi -> kanal mic
-- booking_seat_assignments    : per rapat, kursi -> peserta
-- bookings.meeting_status ... : state rapat di server (scheduled/live/ended)
-- meeting_recordings          : sesi rekaman audio
-- meeting_transcript_segments : segmen transkrip per pembicara
-- meeting_notes.status ...    : draft/final notulensi + ringkasan terstruktur
-- Idempotent: aman dijalankan berulang kali.
-- ============================================================

CREATE TABLE IF NOT EXISTS audio_channels (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id UUID NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
    channel_no INTEGER NOT NULL CHECK (channel_no BETWEEN 1 AND 64),
    label VARCHAR(100) NOT NULL,
    receiver_label VARCHAR(100),
    mixer_channel INTEGER,
    capture_channel INTEGER,
    device_id UUID REFERENCES devices(id) ON DELETE SET NULL,
    is_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_audio_channels_room_channel UNIQUE (room_id, channel_no)
);
CREATE INDEX IF NOT EXISTS idx_audio_channels_room ON audio_channels(room_id);

CREATE TABLE IF NOT EXISTS room_seats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id UUID NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
    seat_no INTEGER NOT NULL CHECK (seat_no >= 1),
    label VARCHAR(50) NOT NULL,
    seat_type VARCHAR(20) NOT NULL DEFAULT 'delegate'
        CHECK (seat_type IN ('chair', 'delegate', 'secretary', 'guest', 'operator')),
    pos_x REAL NOT NULL DEFAULT 50 CHECK (pos_x BETWEEN 0 AND 100),
    pos_y REAL NOT NULL DEFAULT 50 CHECK (pos_y BETWEEN 0 AND 100),
    rotation INTEGER NOT NULL DEFAULT 0,
    audio_channel_id UUID REFERENCES audio_channels(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_room_seats_room_seat UNIQUE (room_id, seat_no)
);
CREATE INDEX IF NOT EXISTS idx_room_seats_room ON room_seats(room_id);
-- Satu kanal mic hanya boleh terpasang di satu kursi.
CREATE UNIQUE INDEX IF NOT EXISTS uq_room_seats_channel
    ON room_seats(audio_channel_id) WHERE audio_channel_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS booking_seat_assignments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    seat_id UUID NOT NULL REFERENCES room_seats(id) ON DELETE CASCADE,
    participant_id UUID REFERENCES booking_participants(id) ON DELETE SET NULL,
    display_name VARCHAR(200),
    role_label VARCHAR(50),
    assigned_via VARCHAR(20) NOT NULL DEFAULT 'manual'
        CHECK (assigned_via IN ('manual', 'checkin', 'auto')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_seat_assign_booking_seat UNIQUE (booking_id, seat_id)
);
CREATE INDEX IF NOT EXISTS idx_seat_assign_booking ON booking_seat_assignments(booking_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_seat_assign_booking_participant
    ON booking_seat_assignments(booking_id, participant_id) WHERE participant_id IS NOT NULL;

ALTER TABLE bookings ADD COLUMN IF NOT EXISTS meeting_status VARCHAR(20) NOT NULL DEFAULT 'scheduled';
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS actual_start_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS actual_end_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS extended_minutes INTEGER NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS meeting_recordings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    note_id UUID REFERENCES meeting_notes(id) ON DELETE SET NULL,
    source VARCHAR(20) NOT NULL DEFAULT 'multichannel'
        CHECK (source IN ('multichannel', 'mix', 'browser', 'upload')),
    status VARCHAR(20) NOT NULL DEFAULT 'recording'
        CHECK (status IN ('recording', 'paused', 'stopped', 'processing', 'done', 'failed')),
    channel_count INTEGER NOT NULL DEFAULT 1,
    started_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    paused_at TIMESTAMP WITH TIME ZONE,
    ended_at TIMESTAMP WITH TIME ZONE,
    file_path VARCHAR(500),
    error TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_meeting_recordings_booking ON meeting_recordings(booking_id);

CREATE TABLE IF NOT EXISTS meeting_transcript_segments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    note_id UUID NOT NULL REFERENCES meeting_notes(id) ON DELETE CASCADE,
    booking_id UUID REFERENCES bookings(id) ON DELETE CASCADE,
    recording_id UUID REFERENCES meeting_recordings(id) ON DELETE SET NULL,
    start_ms BIGINT NOT NULL DEFAULT 0,
    end_ms BIGINT NOT NULL DEFAULT 0,
    audio_channel_no INTEGER,
    seat_id UUID REFERENCES room_seats(id) ON DELETE SET NULL,
    participant_id UUID REFERENCES booking_participants(id) ON DELETE SET NULL,
    speaker_name VARCHAR(200),
    text TEXT NOT NULL,
    confidence REAL,
    language VARCHAR(10),
    is_edited BOOLEAN NOT NULL DEFAULT FALSE,
    audio_path VARCHAR(500),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_transcript_segments_note ON meeting_transcript_segments(note_id, start_ms);

ALTER TABLE meeting_notes ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'draft';
ALTER TABLE meeting_notes ADD COLUMN IF NOT EXISTS summary_json JSONB;
ALTER TABLE meeting_notes ADD COLUMN IF NOT EXISTS finalized_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE meeting_notes ADD COLUMN IF NOT EXISTS finalized_by UUID REFERENCES users(id);

-- Tabel lama tanpa migrasi (tidak pernah dibuat); digantikan booking_seat_assignments.
DROP TABLE IF EXISTS booking_microphone_assignments;
