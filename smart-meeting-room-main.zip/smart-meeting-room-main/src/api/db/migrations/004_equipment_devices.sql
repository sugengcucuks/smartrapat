-- Smart Meeting Room Database Migration 004
-- Equipment, Devices, Videowall Configs, Audio Zones, Meeting Notes
-- PostgreSQL 15+
-- Idempotent: Aman dijalankan berkali-kali

-- ============================================
-- ENUM TYPES (jika belum ada)
-- ============================================

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'equipment_category') THEN
        CREATE TYPE equipment_category AS ENUM ('display', 'audio', 'input', 'network', 'camera', 'other');
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'equipment_status') THEN
        CREATE TYPE equipment_status AS ENUM ('active', 'maintenance', 'broken', 'disposed');
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'device_type') THEN
        CREATE TYPE device_type AS ENUM ('tv', 'projector', 'ac', 'cctv', 'lights', 'curtain', 'sensor_temp', 'sensor_humidity', 'door_lock', 'videowall_controller', 'audio_processor', 'tablet');
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'device_status') THEN
        CREATE TYPE device_status AS ENUM ('online', 'offline', 'error', 'maintenance');
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'videowall_layout') THEN
        CREATE TYPE videowall_layout AS ENUM ('fullscreen', '2x2', '3x3', '1x4', '4x1', 'custom');
    END IF;
END $$;

-- ============================================
-- TABLE: equipment
-- ============================================

CREATE TABLE IF NOT EXISTS equipment (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(150) NOT NULL,
    code VARCHAR(30) UNIQUE NOT NULL,
    category equipment_category NOT NULL DEFAULT 'other',
    brand VARCHAR(100),
    model VARCHAR(100),
    serial_number VARCHAR(100),
    purchase_date DATE,
    warranty_until DATE,
    status equipment_status NOT NULL DEFAULT 'active',
    notes TEXT,
    location_id UUID REFERENCES rooms(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_equipment_code ON equipment(code);
CREATE INDEX IF NOT EXISTS idx_equipment_category ON equipment(category);
CREATE INDEX IF NOT EXISTS idx_equipment_status ON equipment(status);
CREATE INDEX IF NOT EXISTS idx_equipment_location ON equipment(location_id);
CREATE INDEX IF NOT EXISTS idx_equipment_name ON equipment(name);

-- ============================================
-- TABLE: devices
-- ============================================

CREATE TABLE IF NOT EXISTS devices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(150) NOT NULL,
    device_type device_type NOT NULL,
    code VARCHAR(30) UNIQUE NOT NULL,
    location_id UUID REFERENCES rooms(id),
    ip_address VARCHAR(45),
    mac_address VARCHAR(20),
    firmware_version VARCHAR(50),
    status device_status NOT NULL DEFAULT 'offline',
    last_seen TIMESTAMP WITH TIME ZONE,
    config JSONB DEFAULT '{}'::jsonb,
    last_action VARCHAR(200),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_devices_code ON devices(code);
CREATE INDEX IF NOT EXISTS idx_devices_type ON devices(device_type);
CREATE INDEX IF NOT EXISTS idx_devices_status ON devices(status);
CREATE INDEX IF NOT EXISTS idx_devices_location ON devices(location_id);
CREATE INDEX IF NOT EXISTS idx_devices_ip ON devices(ip_address);

-- ============================================
-- TABLE: videowall_configs
-- ============================================

CREATE TABLE IF NOT EXISTS videowall_configs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id UUID REFERENCES rooms(id) NOT NULL,
    device_id UUID REFERENCES devices(id),
    config_name VARCHAR(100) NOT NULL,
    layout_mode videowall_layout NOT NULL DEFAULT 'fullscreen',
    inputs JSONB DEFAULT '[]'::jsonb,
    last_action VARCHAR(200),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_videowall_room ON videowall_configs(room_id);
CREATE INDEX IF NOT EXISTS idx_videowall_device ON videowall_configs(device_id);
CREATE INDEX IF NOT EXISTS idx_videowall_layout ON videowall_configs(layout_mode);

-- ============================================
-- TABLE: audio_zones
-- ============================================

CREATE TABLE IF NOT EXISTS audio_zones (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id UUID REFERENCES rooms(id) NOT NULL,
    device_id UUID REFERENCES devices(id),
    zone_name VARCHAR(100) NOT NULL,
    volume INTEGER NOT NULL DEFAULT 60 CHECK (volume >= 0 AND volume <= 100),
    is_muted BOOLEAN NOT NULL DEFAULT FALSE,
    input_source VARCHAR(30) NOT NULL DEFAULT 'mic1',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_audio_zone_room ON audio_zones(room_id);
CREATE INDEX IF NOT EXISTS idx_audio_zone_device ON audio_zones(device_id);
CREATE INDEX IF NOT EXISTS idx_audio_zone_source ON audio_zones(input_source);

-- ============================================
-- TABLE: meeting_notes
-- ============================================

CREATE TABLE IF NOT EXISTS meeting_notes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID REFERENCES bookings(id),
    room_id UUID REFERENCES rooms(id),
    title VARCHAR(200) NOT NULL,
    date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    participants TEXT[] DEFAULT '{}',
    summary TEXT,
    decisions TEXT[] DEFAULT '{}',
    transcript JSONB DEFAULT '[]'::jsonb,
    transcript_processing BOOLEAN NOT NULL DEFAULT FALSE,
    ai_model VARCHAR(50),
    generated_at TIMESTAMP WITH TIME ZONE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notes_booking ON meeting_notes(booking_id);
CREATE INDEX IF NOT EXISTS idx_notes_room ON meeting_notes(room_id);
CREATE INDEX IF NOT EXISTS idx_notes_date ON meeting_notes(date);
CREATE INDEX IF NOT EXISTS idx_notes_creator ON meeting_notes(created_by);
CREATE INDEX IF NOT EXISTS idx_notes_room_date ON meeting_notes(room_id, date);

-- ============================================
-- TABLE: meeting_note_action_items
-- ============================================

CREATE TABLE IF NOT EXISTS meeting_note_action_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    note_id UUID REFERENCES meeting_notes(id) ON DELETE CASCADE NOT NULL,
    task TEXT NOT NULL,
    owner VARCHAR(100),
    due_date DATE,
    status VARCHAR(20) NOT NULL DEFAULT 'open',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_action_items_note ON meeting_note_action_items(note_id);
CREATE INDEX IF NOT EXISTS idx_action_items_status ON meeting_note_action_items(status);
CREATE INDEX IF NOT EXISTS idx_action_items_due ON meeting_note_action_items(due_date);

-- ============================================
-- CONSTRAINT: Waktu valid meeting notes
-- ============================================

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints
        WHERE constraint_name = 'meeting_notes_time_check'
    ) THEN
        ALTER TABLE meeting_notes ADD CONSTRAINT meeting_notes_time_check CHECK (start_time < end_time);
    END IF;
END $$;

-- ============================================
-- SEED DATA: Sample Equipment (8+ items)
-- ============================================

WITH r101 AS (SELECT id FROM rooms WHERE code = 'R-101' LIMIT 1),
     r102 AS (SELECT id FROM rooms WHERE code = 'R-102' LIMIT 1),
     r201 AS (SELECT id FROM rooms WHERE code = 'R-201' LIMIT 1),
     r301 AS (SELECT id FROM rooms WHERE code = 'R-301' LIMIT 1),
     rb201 AS (SELECT id FROM rooms WHERE code = 'R-B201' LIMIT 1)
INSERT INTO equipment (name, code, category, brand, model, serial_number, purchase_date, warranty_until, status, notes, location_id) VALUES
    ('Smart TV 65 Inch', 'EQ-TV-001', 'display', 'Samsung', 'QN65Q70C', 'SN-TV-2024-001', '2024-01-15', '2026-01-15', 'active', '4K QLED TV dengan HDMI 2.1', (SELECT id FROM r101)),
    ('Projector 4K Laser', 'EQ-PROJ-001', 'display', 'Epson', 'EB-L775U', 'SN-PRJ-2024-001', '2024-02-01', '2027-02-01', 'active', 'Laser projector 5000 lumens', (SELECT id FROM r201)),
    ('Mic Wireless System', 'EQ-MIC-001', 'audio', 'Shure', 'BLX288/SM58', 'SN-MIC-2024-001', '2024-01-20', '2026-01-20', 'active', 'Dual handheld wireless mic', (SELECT id FROM r201)),
    ('Bluetooth Speaker', 'EQ-SPK-001', 'audio', 'JBL', 'Charge 5', 'SN-SPK-2024-001', '2024-03-01', '2025-03-01', 'active', 'Portable bluetooth speaker', (SELECT id FROM r102)),
    ('PTZ Conference Camera', 'EQ-CAM-001', 'camera', 'Logitech', 'Rally Plus', 'SN-CAM-2024-001', '2024-01-10', '2026-01-10', 'active', '4K PTZ camera 15x zoom', (SELECT id FROM r102)),
    ('Laptop Presentasi 1', 'EQ-LAP-001', 'input', 'Dell', 'Latitude 7440', 'SN-LAP-2024-001', '2024-02-15', '2027-02-15', 'active', 'Laptop untuk presentasi meeting', (SELECT id FROM r301)),
    ('HDMI Matrix Switcher 4x4', 'EQ-SW-001', 'network', 'Blackmagic', 'ATEM Mini Pro ISO', 'SN-SW-2024-001', '2024-03-10', '2026-03-10', 'active', 'Switcher HDMI 4 input 4 output', (SELECT id FROM rb201)),
    ('Soundbar Dolby Atmos', 'EQ-SB-001', 'audio', 'Sony', 'HT-A7000', 'SN-SB-2024-001', '2024-04-01', '2026-04-01', 'active', 'Soundbar premium untuk ruang VIP', (SELECT id FROM rb201)),
    ('Projector Short Throw', 'EQ-PROJ-002', 'display', 'ViewSonic', 'LS831WU', 'SN-PRJ-2024-002', '2024-05-01', '2027-05-01', 'active', 'Short throw projector untuk ruang training', (SELECT id FROM r301)),
    ('Tablet Control Room', 'EQ-TAB-001', 'input', 'Apple', 'iPad Pro 12.9', 'SN-TAB-2024-001', '2024-06-01', '2026-06-01', 'active', 'Tablet untuk kontrol ruangan', (SELECT id FROM rb201))
ON CONFLICT (code) DO NOTHING;

-- ============================================
-- SEED DATA: Sample Devices (15+ items)
-- ============================================

WITH r101 AS (SELECT id FROM rooms WHERE code = 'R-101' LIMIT 1),
     r102 AS (SELECT id FROM rooms WHERE code = 'R-102' LIMIT 1),
     r201 AS (SELECT id FROM rooms WHERE code = 'R-201' LIMIT 1),
     r301 AS (SELECT id FROM rooms WHERE code = 'R-301' LIMIT 1),
     rb101 AS (SELECT id FROM rooms WHERE code = 'R-B101' LIMIT 1),
     rb201 AS (SELECT id FROM rooms WHERE code = 'R-B201' LIMIT 1)
INSERT INTO devices (name, device_type, code, location_id, ip_address, mac_address, firmware_version, status, last_seen, config) VALUES
    ('TV Kenari Room', 'tv', 'DEV-TV-001', (SELECT id FROM r101), '192.168.1.101', 'AA:BB:CC:00:01:01', 'v1.2.3', 'online', CURRENT_TIMESTAMP, '{"hdmi_ports": 3, "cec_enabled": true}'::jsonb),
    ('TV Garuda Room', 'tv', 'DEV-TV-002', (SELECT id FROM r102), '192.168.1.102', 'AA:BB:CC:00:01:02', 'v1.2.3', 'online', CURRENT_TIMESTAMP, '{"hdmi_ports": 4, "cec_enabled": true}'::jsonb),
    ('Projector Aula', 'projector', 'DEV-PROJ-001', (SELECT id FROM r201), '192.168.1.201', 'AA:BB:CC:00:02:01', 'v2.0.1', 'online', CURRENT_TIMESTAMP, '{"lamp_hours": 120, "max_resolution": "3840x2160"}'::jsonb),
    ('Projector Training', 'projector', 'DEV-PROJ-002', (SELECT id FROM r301), '192.168.1.202', 'AA:BB:CC:00:02:02', 'v2.0.1', 'offline', CURRENT_TIMESTAMP - INTERVAL '2 hours', '{"lamp_hours": 45, "max_resolution": "1920x1200"}'::jsonb),
    ('AC Aula Serbaguna', 'ac', 'DEV-AC-001', (SELECT id FROM r201), '192.168.1.301', 'AA:BB:CC:00:03:01', 'v3.1.0', 'online', CURRENT_TIMESTAMP, '{"brand": "Daikin", "btu": 24000, "current_temp": 24}'::jsonb),
    ('CCTV Aula Depan', 'cctv', 'DEV-CCTV-001', (SELECT id FROM r201), '192.168.1.401', 'AA:BB:CC:00:04:01', 'v4.0.2', 'online', CURRENT_TIMESTAMP, '{"resolution": "4MP", "night_vision": true}'::jsonb),
    ('Lights Kenari', 'lights', 'DEV-LGT-001', (SELECT id FROM r101), '192.168.1.501', 'AA:BB:CC:00:05:01', 'v1.0.5', 'online', CURRENT_TIMESTAMP, '{"zones": ["main", "spotlight"], "dimmable": true}'::jsonb),
    ('Lights Garuda', 'lights', 'DEV-LGT-002', (SELECT id FROM r102), '192.168.1.502', 'AA:BB:CC:00:05:02', 'v1.0.5', 'online', CURRENT_TIMESTAMP, '{"zones": ["main", "spotlight"], "dimmable": true}'::jsonb),
    ('Curtain Aula', 'curtain', 'DEV-CUR-001', (SELECT id FROM r201), '192.168.1.601', 'AA:BB:CC:00:06:01', 'v1.0.0', 'error', CURRENT_TIMESTAMP - INTERVAL '15 minutes', '{"motors": 2, "position_percent": 50}'::jsonb),
    ('Sensor Suhu Kenari', 'sensor_temp', 'DEV-ST-001', (SELECT id FROM r101), '192.168.1.701', 'AA:BB:CC:00:07:01', 'v2.1.0', 'online', CURRENT_TIMESTAMP, '{"min_temp": 16, "max_temp": 32, "unit": "C"}'::jsonb),
    ('Sensor Kelembapan Garuda', 'sensor_humidity', 'DEV-SH-001', (SELECT id FROM r102), '192.168.1.702', 'AA:BB:CC:00:07:02', 'v2.1.0', 'online', CURRENT_TIMESTAMP, '{"min_humidity": 30, "max_humidity": 80, "unit": "%"}'::jsonb),
    ('Door Lock VIP Cendana', 'door_lock', 'DEV-DL-001', (SELECT id FROM rb201), '192.168.1.801', 'AA:BB:CC:00:08:01', 'v3.0.0', 'online', CURRENT_TIMESTAMP, '{"access_methods": ["rfid", "pin", "app"], "auto_lock": true}'::jsonb),
    ('Videowall Controller Aula', 'videowall_controller', 'DEV-VWC-001', (SELECT id FROM r201), '192.168.1.901', 'AA:BB:CC:00:09:01', 'v5.2.1', 'online', CURRENT_TIMESTAMP, '{"inputs": 4, "outputs": 4, "bezel_correction": true}'::jsonb),
    ('Audio Processor Aula', 'audio_processor', 'DEV-AP-001', (SELECT id FROM r201), '192.168.1.902', 'AA:BB:CC:00:09:02', 'v4.1.0', 'online', CURRENT_TIMESTAMP, '{"inputs": 8, "outputs": 6, "dsp": true, "feedback_suppression": true}'::jsonb),
    ('Audio Processor VIP', 'audio_processor', 'DEV-AP-002', (SELECT id FROM rb201), '192.168.1.903', 'AA:BB:CC:00:09:03', 'v4.1.0', 'maintenance', CURRENT_TIMESTAMP - INTERVAL '1 day', '{"inputs": 4, "outputs": 4, "dsp": true}'::jsonb),
    ('Tablet Control Cendana', 'tablet', 'DEV-TAB-001', (SELECT id FROM rb201), '192.168.1.904', 'AA:BB:CC:00:09:04', 'iOS 17.5', 'online', CURRENT_TIMESTAMP, '{"os": "iOS", "app_version": "2.3.0"}'::jsonb),
    ('Sensor Suhu Training', 'sensor_temp', 'DEV-ST-002', (SELECT id FROM r301), '192.168.1.703', 'AA:BB:CC:00:07:03', 'v2.1.0', 'online', CURRENT_TIMESTAMP, '{"min_temp": 16, "max_temp": 32, "unit": "C"}'::jsonb),
    ('Door Lock Office 1', 'door_lock', 'DEV-DL-002', (SELECT id FROM rb101), '192.168.1.802', 'AA:BB:CC:00:08:02', 'v3.0.0', 'offline', CURRENT_TIMESTAMP - INTERVAL '3 hours', '{"access_methods": ["rfid", "pin"], "auto_lock": true}'::jsonb)
ON CONFLICT (code) DO NOTHING;

-- ============================================
-- SEED DATA: Sample Videowall Configs
-- ============================================

WITH r201 AS (SELECT id FROM rooms WHERE code = 'R-201' LIMIT 1),
     vwc01 AS (SELECT id FROM devices WHERE code = 'DEV-VWC-001' LIMIT 1)
INSERT INTO videowall_configs (room_id, device_id, config_name, layout_mode, inputs) VALUES
    ((SELECT id FROM r201), (SELECT id FROM vwc01), 'Presentasi Penuh', 'fullscreen',
     '[{"input": "hdmi1", "label": "Laptop Presenter"}, {"input": "hdmi2", "label": "CCTV Depan"}]'::jsonb),
    ((SELECT id FROM r201), (SELECT id FROM vwc01), 'Meeting 4 Sumber', '2x2',
     '[{"input": "hdmi1", "label": "Laptop Presenter"}, {"input": "hdmi2", "label": "CCTV"}, {"input": "hdmi3", "label": "Whiteboard"}, {"input": "wireless", "label": "Screen Share"}]'::jsonb),
    ((SELECT id FROM r201), (SELECT id FROM vwc01), 'Banner Horizontal', '1x4',
     '[{"input": "dp", "label": "Banner 1"}, {"input": "hdmi1", "label": "Banner 2"}, {"input": "hdmi2", "label": "Banner 3"}, {"input": "hdmi3", "label": "Banner 4"}]'::jsonb)
ON CONFLICT DO NOTHING;

-- ============================================
-- SEED DATA: Sample Audio Zones
-- ============================================

WITH r101 AS (SELECT id FROM rooms WHERE code = 'R-101' LIMIT 1),
     r102 AS (SELECT id FROM rooms WHERE code = 'R-102' LIMIT 1),
     r201 AS (SELECT id FROM rooms WHERE code = 'R-201' LIMIT 1),
     r301 AS (SELECT id FROM rooms WHERE code = 'R-301' LIMIT 1),
     rb201 AS (SELECT id FROM rooms WHERE code = 'R-B201' LIMIT 1),
     ap01 AS (SELECT id FROM devices WHERE code = 'DEV-AP-001' LIMIT 1),
     ap02 AS (SELECT id FROM devices WHERE code = 'DEV-AP-002' LIMIT 1)
INSERT INTO audio_zones (room_id, device_id, zone_name, volume, is_muted, input_source) VALUES
    ((SELECT id FROM r201), (SELECT id FROM ap01), 'Zone Utama Aula', 65, FALSE, 'mic1'),
    ((SELECT id FROM r201), (SELECT id FROM ap01), 'Zone Panggung', 80, FALSE, 'mic2'),
    ((SELECT id FROM r201), (SELECT id FROM ap01), 'Zone Belakang', 55, FALSE, 'line1'),
    ((SELECT id FROM rb201), (SELECT id FROM ap02), 'Zone VIP Utama', 60, FALSE, 'bluetooth'),
    ((SELECT id FROM r101), NULL, 'Zone Kenari Speaker', 60, FALSE, 'hdmi'),
    ((SELECT id FROM r102), NULL, 'Zone Garuda Mic', 70, FALSE, 'mic1'),
    ((SELECT id FROM r301), NULL, 'Zone Training', 65, TRUE, 'usb')
ON CONFLICT DO NOTHING;

-- ============================================
-- SEED DATA: Sample Meeting Notes (3+)
-- ============================================

WITH admin_user AS (SELECT id FROM users WHERE username = 'admin' LIMIT 1),
     r201 AS (SELECT id FROM rooms WHERE code = 'R-201' LIMIT 1),
     r102 AS (SELECT id FROM rooms WHERE code = 'R-102' LIMIT 1),
     rb201 AS (SELECT id FROM rooms WHERE code = 'R-B201' LIMIT 1)
INSERT INTO meeting_notes (booking_id, room_id, title, date, start_time, end_time, participants, summary, decisions, transcript, ai_model, generated_at, created_by) VALUES
    (NULL, (SELECT id FROM r201), 'Rapat Q3 Review Performa', '2024-09-15', '09:00:00', '11:30:00',
     ARRAY['Budi Santoso', 'Siti Rahayu', 'Ahmad Wijaya', 'Dewi Lestari', 'Rudi Hartono'],
     'Rapat tinjauan performa kuartal ketiga membahas capaian target penjualan, efisiensi operasional, dan rencana strategis Q4. Hasil penjualan mencapai 92% dari target dengan peningkatan signifikan di divisi korporat. Operasional mengalami efisiensi biaya sebesar 12% berkat implementasi sistem baru.',
     ARRAY['Meningkatkan target Q4 sebesar 15%', 'Launch produk baru November 2024', 'Rekrutmen 5 anggota tim baru', 'Upgrade infrastruktur IT bulan depan'],
     '[{"speaker": "Budi Santoso", "text": "Selamat datang semua, mari kita mulai rapat Q3 hari ini.", "timestamp": "09:01:00"},
       {"speaker": "Siti Rahayu", "text": "Untuk penjualan, kita sudah mencapai 92% dari target.", "timestamp": "09:15:00"},
       {"speaker": "Ahmad Wijaya", "text": "Divisi korporat tumbuh 22% YoY, ini hasil yang sangat bagus.", "timestamp": "09:45:00"},
       {"speaker": "Dewi Lestari", "text": "Efisiensi biaya 12% sudah di atas ekspektasi kita.", "timestamp": "10:30:00"},
       {"speaker": "Rudi Hartono", "text": "Saya setuju target Q4 dinaikkan 15%, kita bisa capai.", "timestamp": "11:00:00"}]'::jsonb,
     'mock-llama3-8b', CURRENT_TIMESTAMP, (SELECT id FROM admin_user)),
    (NULL, (SELECT id FROM r102), 'Sprint Planning - Sprint 23', '2024-09-18', '13:00:00', '15:00:00',
     ARRAY['Andi Pratama', 'Rina Marlina', 'Fajar Nugroho'],
     'Sprint planning untuk Sprint 23 dengan tema "Performa dan Stabilitas". Total 18 story points diambil meliputi optimasi database, perbaikan bug kritikal, dan peningkatan UI dashboard. Daily standup tetap setiap jam 9 pagi.',
     ARRAY['Prioritaskan optimasi query booking', 'Bug payment gateway ditangani minggu ini', 'UI dashboard selesai pertengahan sprint'],
     '[{"speaker": "Andi Pratama", "text": "Mari kita bahas backlog untuk sprint ini.", "timestamp": "13:05:00"},
       {"speaker": "Rina Marlina", "text": "Saya bisa ambil ticket optimasi database.", "timestamp": "13:20:00"},
       {"speaker": "Fajar Nugroho", "text": "Saya tangani payment gateway bug.", "timestamp": "14:10:00"}]'::jsonb,
     'mock-llama3-8b', CURRENT_TIMESTAMP, (SELECT id FROM admin_user)),
    (NULL, (SELECT id FROM rb201), 'Rapat Strategi Kemitraan', '2024-09-20', '10:00:00', '12:00:00',
     ARRAY['Direktur Utama', 'Direktur Keuangan', 'Komisaris'],
     'Rapat eksekutif membahas peluang kemitraan strategis dengan 3 vendor besar. Pembahasan mencakup due diligence, struktur deal, dan timeline implementasi. Keputusan bulat untuk lanjut ke tahap MoU dengan Vendor A dan Vendor B.',
     ARRAY['MoU dengan Vendor A ditandatangani Oktober 2024', 'Due diligence Vendor B selesai November 2024', 'Vendor C ditunda evaluasi tahun depan'],
     '[{"speaker": "Direktur Utama", "text": "Kita punya 3 kandidat vendor untuk kemitraan ini.", "timestamp": "10:10:00"},
       {"speaker": "Direktur Keuangan", "text": "Secara finansial Vendor A dan B paling menguntungkan.", "timestamp": "10:45:00"},
       {"speaker": "Komisaris", "text": "Setuju lanjut MoU dengan A dan B, C ditunda dulu.", "timestamp": "11:30:00"}]'::jsonb,
     'mock-llama3-8b', CURRENT_TIMESTAMP, (SELECT id FROM admin_user))
ON CONFLICT DO NOTHING;

-- ============================================
-- SEED DATA: Sample Action Items
-- ============================================

WITH note1 AS (SELECT id FROM meeting_notes WHERE title = 'Rapat Q3 Review Performa' LIMIT 1),
     note2 AS (SELECT id FROM meeting_notes WHERE title = 'Sprint Planning - Sprint 23' LIMIT 1)
INSERT INTO meeting_note_action_items (note_id, task, owner, due_date, status) VALUES
    ((SELECT id FROM note1), 'Finalisasi dokumen target Q4 15%', 'Budi Santoso', '2024-09-25', 'open'),
    ((SELECT id FROM note1), 'Buat timeline launch produk baru', 'Siti Rahayu', '2024-10-01', 'open'),
    ((SELECT id FROM note1), 'Buka lowongan rekrutmen 5 orang', 'HR Department', '2024-09-30', 'in_progress'),
    ((SELECT id FROM note1), 'Ajukan budget upgrade IT', 'Ahmad Wijaya', '2024-10-05', 'open'),
    ((SELECT id FROM note2), 'Optimasi query booking (TOP 5 slow)', 'Rina Marlina', '2024-09-25', 'in_progress'),
    ((SELECT id FROM note2), 'Fix bug payment gateway timeout', 'Fajar Nugroho', '2024-09-22', 'open'),
    ((SELECT id FROM note2), 'Design wireframe dashboard baru', 'Andi Pratama', '2024-09-27', 'done')
ON CONFLICT DO NOTHING;
