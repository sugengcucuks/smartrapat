-- 008 Patch seed data: perbaiki ARRAY cast ke jsonb + setting_value_type enum

-- ===== ROOMS (4): gunakan to_jsonb(ARRAY[...]) =====
DO $$
DECLARE
    gidA UUID; gidB UUID; gidC UUID;
BEGIN
    SELECT id INTO gidA FROM buildings WHERE code = 'GED-A' LIMIT 1;
    SELECT id INTO gidB FROM buildings WHERE code = 'GED-B' LIMIT 1;
    SELECT id INTO gidC FROM buildings WHERE code = 'GED-C' LIMIT 1;

    INSERT INTO rooms (id, code, name, building_id, floor, capacity, room_type, description, amenities, status, created_at, updated_at)
    VALUES
        (uuid_generate_v4(), 'R-A101', 'Ruang Rapat Utama A101', gidA, 1, 30, 'meeting', 'Ruang rapat besar untuk rapat pleno', to_jsonb(ARRAY['projector','whiteboard','video_conference','wifi']), 'available', NOW(), NOW()),
        (uuid_generate_v4(), 'R-A203', 'Ruang Diskusi A203', gidA, 2, 10, 'meeting', 'Ruang diskusi kecil', to_jsonb(ARRAY['tv_led','whiteboard','wifi']), 'available', NOW(), NOW()),
        (uuid_generate_v4(), 'R-B102', 'Ruang Meeting B102', gidB, 1, 15, 'meeting', 'Ruang meeting middle size', to_jsonb(ARRAY['projector','speaker','wifi']), 'available', NOW(), NOW()),
        (uuid_generate_v4(), 'R-C301', 'Training Room C301', gidC, 3, 50, 'training', 'Ruang training kapasitas besar', to_jsonb(ARRAY['projector','sound_system','mic_wireless','wifi','air_conditioner']), 'available', NOW(), NOW())
    ON CONFLICT (code) DO NOTHING;
END $$;

-- ===== EQUIPMENT (5) =====
DO $$
DECLARE
    room1 UUID; room2 UUID; room3 UUID; room4 UUID;
BEGIN
    SELECT id INTO room1 FROM rooms WHERE code = 'R-A101' LIMIT 1;
    SELECT id INTO room2 FROM rooms WHERE code = 'R-A203' LIMIT 1;
    SELECT id INTO room3 FROM rooms WHERE code = 'R-B102' LIMIT 1;
    SELECT id INTO room4 FROM rooms WHERE code = 'R-C301' LIMIT 1;

    INSERT INTO equipment (id, code, name, category, brand, model, serial_number, purchase_date, warranty_until, status, location_id, notes, created_at, updated_at)
    VALUES
        (uuid_generate_v4(), 'EQ-PROJ-001', 'Proyektor Epson 4K', 'display', 'Epson', 'EB-L730U', 'SN-EPS-2024-0001', '2024-01-15', '2026-01-15', 'active', room1, 'Laser projector 7000 lumens', NOW(), NOW()),
        (uuid_generate_v4(), 'EQ-TV-001', 'Smart TV LED 65 Inch', 'display', 'Samsung', 'Q65C QLED', 'SN-SMS-2024-0101', '2024-02-10', '2026-02-10', 'active', room2, '4K Smart TV dengan screen mirroring', NOW(), NOW()),
        (uuid_generate_v4(), 'EQ-SPK-001', 'Speaker Wireless Portable', 'audio', 'JBL', 'Charge 5', 'SN-JBL-2024-0303', '2024-03-05', '2025-03-05', 'active', room3, 'Bluetooth speaker 40W waterproof', NOW(), NOW()),
        (uuid_generate_v4(), 'EQ-MIC-001', 'Microphone Wireless Set', 'audio', 'Shure', 'BLX24/SM58', 'SN-SHR-2024-0415', '2024-04-01', '2026-04-01', 'active', room4, 'Dual handheld wireless mic system', NOW(), NOW()),
        (uuid_generate_v4(), 'EQ-CAM-001', 'Webcam 4K PTZ', 'camera', 'Logitech', 'Rally', 'SN-LOG-2024-0520', '2024-05-10', '2026-05-10', 'maintenance', room1, 'Sedang perawatan sensor auto-focus', NOW(), NOW())
    ON CONFLICT (code) DO NOTHING;
END $$;

-- ===== DEVICES (4) =====
DO $$
DECLARE
    room1 UUID; room2 UUID; room3 UUID; room4 UUID;
BEGIN
    SELECT id INTO room1 FROM rooms WHERE code = 'R-A101' LIMIT 1;
    SELECT id INTO room2 FROM rooms WHERE code = 'R-A203' LIMIT 1;
    SELECT id INTO room3 FROM rooms WHERE code = 'R-B102' LIMIT 1;
    SELECT id INTO room4 FROM rooms WHERE code = 'R-C301' LIMIT 1;

    INSERT INTO devices (id, code, name, device_type, location_id, ip_address, mac_address, firmware_version, status, last_seen, config, created_at, updated_at)
    VALUES
        (uuid_generate_v4(), 'DEV-DC-001', 'Door Controller A101', 'door_access', room1, '192.168.1.101', 'AA:BB:CC:01:01:01', 'v2.3.1', 'online', NOW(), jsonb_build_object('protocol','Wiegand-26','relay_count',2), NOW(), NOW()),
        (uuid_generate_v4(), 'DEV-CAM-001', 'CCTV Camera A203', 'cctv', room2, '192.168.1.110', 'AA:BB:CC:02:02:02', 'v1.8.0', 'online', NOW()-INTERVAL '2 minutes', jsonb_build_object('resolution','4K','night_vision',true), NOW(), NOW()),
        (uuid_generate_v4(), 'DEV-MRP-001', 'Meeting Room Panel B102', 'room_panel', room3, '192.168.1.125', 'AA:BB:CC:03:03:03', 'v3.0.2', 'online', NOW()-INTERVAL '1 minute', jsonb_build_object('screen_size',10.1,'os','Android 13'), NOW(), NOW()),
        (uuid_generate_v4(), 'DEV-VWC-001', 'Videowall Controller C301', 'videowall', room4, '192.168.1.150', 'AA:BB:CC:04:04:04', 'v1.2.0', 'error', NOW()-INTERVAL '3 hours', jsonb_build_object('input_count',4,'output_count',4), NOW(), NOW())
    ON CONFLICT (code) DO NOTHING;
END $$;

-- ===== AUDIT LOGS (5) =====
DO $$
DECLARE
    uid UUID;
BEGIN
    SELECT id INTO uid FROM users WHERE username = 'admin' LIMIT 1;

    INSERT INTO audit_logs (id, user_id, action, module, target_type, target_id, old_value, new_value, ip_address, user_agent, timestamp)
    VALUES
        (uuid_generate_v4(), uid, 'LOGIN', 'auth', 'session', NULL, NULL, NULL, '127.0.0.1'::INET, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120', NOW()-INTERVAL '1 day 2 hours'),
        (uuid_generate_v4(), uid, 'CREATE', 'rooms', 'room', (SELECT id::text FROM rooms WHERE code='R-A101' LIMIT 1), NULL, jsonb_build_object('code','R-A101','name','Ruang Rapat Utama A101'), '127.0.0.1'::INET, 'Mozilla/5.0 Chrome/120', NOW()-INTERVAL '20 hours'),
        (uuid_generate_v4(), uid, 'UPDATE', 'users', 'user', uid::text, jsonb_build_object('position','NULL'), jsonb_build_object('position','System Administrator'), '127.0.0.1'::INET, 'Mozilla/5.0 Chrome/120', NOW()-INTERVAL '10 hours'),
        (uuid_generate_v4(), uid, 'CREATE', 'equipment', 'equipment', (SELECT id::text FROM equipment WHERE code='EQ-PROJ-001' LIMIT 1), NULL, jsonb_build_object('code','EQ-PROJ-001','name','Proyektor Epson 4K'), '127.0.0.1'::INET, 'Mozilla/5.0 Chrome/120', NOW()-INTERVAL '5 hours'),
        (uuid_generate_v4(), uid, 'UPDATE', 'settings', 'system_setting', 'app_title', jsonb_build_object('setting_value','SMR Lama'), jsonb_build_object('setting_value','Smart Meeting Room'), '127.0.0.1'::INET, 'Mozilla/5.0 Chrome/120', NOW()-INTERVAL '1 hour')
    ON CONFLICT DO NOTHING;
END $$;

-- ===== NOTIFICATIONS (4) =====
DO $$
DECLARE
    uid UUID;
BEGIN
    SELECT id INTO uid FROM users WHERE username = 'admin' LIMIT 1;

    INSERT INTO notifications (id, user_id, type, title, message, data, is_read, read_at, created_at)
    VALUES
        (uuid_generate_v4(), uid, 'system', 'Selamat Datang di Smart Meeting Room', 'Sistem Smart Meeting Room berhasil diinisiasi. Silakan konfigurasi pengaturan terlebih dahulu.', jsonb_build_object('from','system_init'), false, NULL, NOW()-INTERVAL '2 days'),
        (uuid_generate_v4(), uid, 'maintenance', 'Pemeliharaan Perangkat', 'Proyektor Epson 4K (EQ-PROJ-001) memasuki jadwal maintenance bulanan.', jsonb_build_object('equipment_code','EQ-PROJ-001'), false, NULL, NOW()-INTERVAL '1 day'),
        (uuid_generate_v4(), uid, 'alert', 'Device Error Terdeteksi', 'Videowall Controller C301 (DEV-VWC-001) melaporkan status ERROR. Periksa segera.', jsonb_build_object('device_code','DEV-VWC-001','status','error'), false, NULL, NOW()-INTERVAL '3 hours'),
        (uuid_generate_v4(), uid, 'info', 'Pembaruan Sistem', 'Versi aplikasi akan diperbarui pada malam ini pukul 23.00 - 00.00 WIB.', jsonb_build_object('version','1.0.1'), true, NOW()-INTERVAL '1 hour', NOW()-INTERVAL '6 hours')
    ON CONFLICT DO NOTHING;
END $$;

-- ===== BOOKINGS (5) =====
DO $$
DECLARE
    uid UUID;
    r1 UUID; r2 UUID; r3 UUID; r4 UUID;
    today DATE := CURRENT_DATE;
BEGIN
    SELECT id INTO uid FROM users WHERE username = 'admin' LIMIT 1;
    SELECT id INTO r1 FROM rooms WHERE code = 'R-A101' LIMIT 1;
    SELECT id INTO r2 FROM rooms WHERE code = 'R-A203' LIMIT 1;
    SELECT id INTO r3 FROM rooms WHERE code = 'R-B102' LIMIT 1;
    SELECT id INTO r4 FROM rooms WHERE code = 'R-C301' LIMIT 1;

    INSERT INTO bookings (id, user_id, room_id, title, description, date, start_time, end_time, attendees, status, approval_notes, created_by, approved_by, approved_at, created_at, updated_at)
    VALUES
        (uuid_generate_v4(), uid, r1, 'Rapat Koordinasi Proyek Q4', 'Rapat evaluasi capaian target Q4 antar tim', today, '09:00'::TIME, '11:00'::TIME, 20, 'approved', NULL, uid, uid, NOW()-INTERVAL '1 day', NOW()-INTERVAL '3 days', NOW()-INTERVAL '1 day'),
        (uuid_generate_v4(), uid, r2, 'Design Review Sprint 3', 'Review desain UI/UX untuk sprint 3 product team', today, '13:00'::TIME, '14:30'::TIME, 8, 'approved', NULL, uid, uid, NOW()-INTERVAL '18 hours', NOW()-INTERVAL '2 days', NOW()-INTERVAL '18 hours'),
        (uuid_generate_v4(), uid, r3, 'Client Meeting - Konsorsium ABC', 'Presentasi proposal kerjasama dengan perwakilan Konsorsium ABC', today+1, '10:00'::TIME, '12:00'::TIME, 15, 'pending', 'Menunggu approval pimpinan', uid, NULL, NULL, NOW()-INTERVAL '5 hours', NOW()-INTERVAL '5 hours'),
        (uuid_generate_v4(), uid, r4, 'Onboarding & Training Karyawan Baru', 'Sesi training penggunaan sistem untuk 12 karyawan baru', today+2, '08:00'::TIME, '16:00'::TIME, 40, 'approved', 'Full-day training session', uid, uid, NOW()-INTERVAL '2 hours', NOW()-INTERVAL '4 days', NOW()-INTERVAL '2 hours'),
        (uuid_generate_v4(), uid, r1, 'Executive Briefing Bulanan', 'Laporan bulanan CEO kepada dewan direksi', today+5, '14:00'::TIME, '16:00'::TIME, 12, 'draft', NULL, uid, NULL, NULL, NOW()-INTERVAL '30 minutes', NOW()-INTERVAL '30 minutes')
    ON CONFLICT DO NOTHING;
END $$;

-- ===== SYSTEM SETTINGS (6) — value_type pakai enum valid: {string,number,boolean,json} =====
DO $$
DECLARE
    uid UUID;
BEGIN
    SELECT id INTO uid FROM users WHERE username = 'admin' LIMIT 1;

    INSERT INTO system_settings (id, setting_key, setting_value, value_type, description, group_name, is_public, updated_by, updated_at)
    VALUES
        (uuid_generate_v4(), 'app_title', 'Smart Meeting Room', 'string', 'Nama aplikasi yang ditampilkan di header dan login', 'general', true, uid, NOW()),
        (uuid_generate_v4(), 'app_theme_default', 'light', 'string', 'Default tema aplikasi (light/dark)', 'general', true, uid, NOW()),
        (uuid_generate_v4(), 'booking_max_days_ahead', '30', 'number', 'Maksimal hari ke depan untuk pemesanan ruangan', 'booking', true, uid, NOW()),
        (uuid_generate_v4(), 'booking_default_status', 'pending', 'string', 'Status default pemesanan baru (draft/pending/approved)', 'booking', false, uid, NOW()),
        (uuid_generate_v4(), 'notification_booking_approve', 'true', 'boolean', 'Kirim notifikasi ketika pemesanan disetujui', 'notifications', false, uid, NOW()),
        (uuid_generate_v4(), 'maintenance_weekly_check_day', 'sunday', 'string', 'Hari penjadwalan pemeriksaan perangkat mingguan', 'maintenance', false, uid, NOW())
    ON CONFLICT (setting_key) DO NOTHING;
END $$;
