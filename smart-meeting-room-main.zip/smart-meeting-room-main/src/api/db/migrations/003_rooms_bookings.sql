-- Smart Meeting Room Database Migration 003
-- Rooms, Buildings, Bookings, BookingParticipants
-- PostgreSQL 15+
-- Idempotent: Aman dijalankan berkali-kali

-- ============================================
-- TABLE: buildings
-- ============================================

CREATE TABLE IF NOT EXISTS buildings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    code VARCHAR(20) UNIQUE NOT NULL,
    floors INTEGER NOT NULL DEFAULT 1,
    address TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_buildings_code ON buildings(code);

-- ============================================
-- TABLE: rooms
-- ============================================

CREATE TABLE IF NOT EXISTS rooms (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    code VARCHAR(20) UNIQUE NOT NULL,
    building_id UUID REFERENCES buildings(id),
    floor INTEGER NOT NULL DEFAULT 1,
    capacity INTEGER NOT NULL DEFAULT 10,
    room_type VARCHAR(20) NOT NULL DEFAULT 'meeting',
    description TEXT,
    amenities JSONB DEFAULT '[]'::jsonb,
    layout_url VARCHAR(500),
    status VARCHAR(20) NOT NULL DEFAULT 'available',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_rooms_code ON rooms(code);
CREATE INDEX IF NOT EXISTS idx_rooms_building ON rooms(building_id);
CREATE INDEX IF NOT EXISTS idx_rooms_status ON rooms(status);
CREATE INDEX IF NOT EXISTS idx_rooms_type ON rooms(room_type);
CREATE INDEX IF NOT EXISTS idx_rooms_capacity ON rooms(capacity);

-- ============================================
-- TABLE: bookings
-- ============================================

CREATE TABLE IF NOT EXISTS bookings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) NOT NULL,
    room_id UUID REFERENCES rooms(id) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    attendees INTEGER NOT NULL DEFAULT 1,
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    approval_notes TEXT,
    created_by UUID REFERENCES users(id),
    approved_by UUID REFERENCES users(id),
    approved_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_bookings_user ON bookings(user_id);
CREATE INDEX IF NOT EXISTS idx_bookings_room ON bookings(room_id);
CREATE INDEX IF NOT EXISTS idx_bookings_date ON bookings(date);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_room_date ON bookings(room_id, date);
CREATE INDEX IF NOT EXISTS idx_bookings_user_date ON bookings(user_id, date);

-- ============================================
-- TABLE: booking_participants
-- ============================================

CREATE TABLE IF NOT EXISTS booking_participants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID REFERENCES bookings(id) ON DELETE CASCADE NOT NULL,
    user_id UUID REFERENCES users(id),
    guest_name VARCHAR(100),
    guest_email VARCHAR(255),
    is_guest BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_booking_participants_booking ON booking_participants(booking_id);
CREATE INDEX IF NOT EXISTS idx_booking_participants_user ON booking_participants(user_id);

-- ============================================
-- CONSTRAINT: Cek waktu valid (start_time < end_time)
-- ============================================

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints
        WHERE constraint_name = 'bookings_time_check'
    ) THEN
        ALTER TABLE bookings ADD CONSTRAINT bookings_time_check CHECK (start_time < end_time);
    END IF;
END $$;

-- ============================================
-- SEED DATA: Sample Buildings
-- ============================================

INSERT INTO buildings (code, name, floors, address) VALUES
    ('BLD-A', 'Gedung Utama A', 5, 'Jl. Contoh No. 1, Jakarta'),
    ('BLD-B', 'Gedung Annex B', 3, 'Jl. Contoh No. 3, Jakarta')
ON CONFLICT (code) DO NOTHING;

-- ============================================
-- SEED DATA: Sample Rooms
-- ============================================

WITH bld_a AS (SELECT id FROM buildings WHERE code = 'BLD-A' LIMIT 1),
     bld_b AS (SELECT id FROM buildings WHERE code = 'BLD-B' LIMIT 1)
INSERT INTO rooms (code, name, building_id, floor, capacity, room_type, description, amenities, status) VALUES
    ('R-101', 'Ruang Rapat Kenari', (SELECT id FROM bld_a), 1, 8, 'meeting',
     'Ruang rapat kecil untuk 8 orang',
     '["projector", "whiteboard", "wifi"]'::jsonb,
     'available'),
    ('R-102', 'Ruang Rapat Garuda', (SELECT id FROM bld_a), 1, 12, 'meeting',
     'Ruang rapat menengah dengan projector 4K',
     '["projector", "whiteboard", "wifi", "video-conference"]'::jsonb,
     'available'),
    ('R-201', 'Aula Serbaguna', (SELECT id FROM bld_a), 2, 100, 'aula',
     'Aula besar untuk acara perusahaan',
     '["projector", "sound-system", "stage", "wifi"]'::jsonb,
     'available'),
    ('R-301', 'Ruang Training', (SELECT id FROM bld_a), 3, 30, 'training',
     'Ruang training dengan 30 kursi',
     '["projector", "whiteboard", "wifi", "tv-screen"]'::jsonb,
     'available'),
    ('R-B101', 'Office Suite 1', (SELECT id FROM bld_b), 1, 4, 'office',
     'Kantor pribadi untuk 4 orang',
     '["wifi", "phone"]'::jsonb,
     'available'),
    ('R-B201', 'Ruang Rapat Cendana', (SELECT id FROM bld_b), 2, 20, 'meeting',
     'Ruang rapat VIP',
     '["projector", "whiteboard", "wifi", "video-conference", "coffee-machine"]'::jsonb,
     'available')
ON CONFLICT (code) DO NOTHING;
