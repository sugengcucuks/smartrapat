-- Smart Meeting Room Database Migration 002
-- Users & Departments: Tambah department_id FK, CREATE/ALTER departments
-- PostgreSQL 15+
-- Idempotent: Aman dijalankan berkali-kali

-- ============================================
-- TABLE: departments (CREATE jika belum ada, ALTER jika sudah ada)
-- ============================================

CREATE TABLE IF NOT EXISTS departments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    head_id UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Jika kolom parent_id ada (dari migrasi 001), hapus karena diganti head_id
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'departments' AND column_name = 'parent_id'
    ) THEN
        ALTER TABLE departments DROP COLUMN parent_id;
    END IF;
END $$;

-- Jika kolom is_active ada (dari migrasi 001), hapus karena tidak diperlukan
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'departments' AND column_name = 'is_active'
    ) THEN
        ALTER TABLE departments DROP COLUMN is_active;
    END IF;
END $$;

-- Tambah head_id jika belum ada
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'departments' AND column_name = 'head_id'
    ) THEN
        ALTER TABLE departments ADD COLUMN head_id UUID REFERENCES users(id);
    END IF;
END $$;

-- ============================================
-- TABLE: users - Tambah department_id FK jika belum ada
-- ============================================

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'users' AND column_name = 'department_id'
    ) THEN
        ALTER TABLE users ADD COLUMN department_id UUID REFERENCES departments(id);
    END IF;
END $$;

-- Index untuk department_id jika belum ada
CREATE INDEX IF NOT EXISTS idx_users_department ON users(department_id);

-- ============================================
-- SEED DATA: Sample Departments
-- ============================================

INSERT INTO departments (code, name) VALUES
    ('IT', 'Information Technology'),
    ('HRD', 'Human Resources Development'),
    ('FIN', 'Finance'),
    ('GA', 'General Affairs'),
    ('MRK', 'Marketing'),
    ('OPS', 'Operations')
ON CONFLICT (code) DO NOTHING;
