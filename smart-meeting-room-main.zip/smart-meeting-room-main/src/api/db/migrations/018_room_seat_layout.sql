-- ============================================================
-- MIGRATION 018: Bentuk meja pada denah kursi ruangan
-- rooms.seat_layout (JSONB) : {"type": "u_shape"|"boardroom"|"classroom"|"circle"|"custom",
--                              "tables": [{"shape": "rect"|"ellipse"|"u", "x", "y", "w", "h", ...}]}
-- Semua koordinat dalam persen (0-100) terhadap kanvas denah 16:10.
-- Diisi oleh POST /rooms/{id}/seats/generate dan PUT /rooms/{id}/seats.
-- Idempotent: aman dijalankan berulang kali.
-- ============================================================

ALTER TABLE rooms ADD COLUMN IF NOT EXISTS seat_layout JSONB;
