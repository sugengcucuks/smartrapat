-- ============================================================
-- MIGRATION 017: Asal action item notulensi (manual / ai)
-- Action item hasil ringkasan AI ditandai source='ai' agar bisa
-- diganti saat ringkasan dibuat ulang tanpa menghapus item manual.
-- Idempotent.
-- ============================================================
ALTER TABLE meeting_note_action_items
    ADD COLUMN IF NOT EXISTS source VARCHAR(10) NOT NULL DEFAULT 'manual';

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'ck_mnai_source'
    ) THEN
        ALTER TABLE meeting_note_action_items
            ADD CONSTRAINT ck_mnai_source CHECK (source IN ('manual', 'ai'));
    END IF;
END$$;

CREATE INDEX IF NOT EXISTS idx_transcript_segments_note_updated
    ON meeting_transcript_segments(note_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_meeting_recordings_booking_status
    ON meeting_recordings(booking_id, status);

-- Total durasi jeda rekaman (ms) agar offset segmen = waktu rekam efektif.
ALTER TABLE meeting_recordings ADD COLUMN IF NOT EXISTS paused_ms BIGINT NOT NULL DEFAULT 0;
