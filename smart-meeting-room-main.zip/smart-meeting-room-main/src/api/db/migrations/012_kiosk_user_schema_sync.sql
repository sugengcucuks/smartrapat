-- ============================================================
-- MIGRATION 012: Akun sistem kiosk + sinkronisasi skema dengan model ORM
-- - users 'kiosk'  : pemilik booking walk-in dari display depan pintu
--                    (password tidak bisa dipakai login, tanpa role/izin)
-- - rooms.layout_url                  : dipakai model Room (sebelumnya hilang)
-- - booking_microphone_assignments    : dipakai endpoint mic-assignments
-- Idempotent: aman dijalankan berulang kali.
-- ============================================================

ALTER TABLE rooms ADD COLUMN IF NOT EXISTS layout_url VARCHAR(500);

CREATE TABLE IF NOT EXISTS booking_microphone_assignments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    mic_id VARCHAR(100) NOT NULL,
    mic_label VARCHAR(200) NOT NULL,
    participant_id UUID REFERENCES booking_participants(id) ON DELETE SET NULL,
    participant_name VARCHAR(200),
    is_guest BOOLEAN NOT NULL DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_bma_booking ON booking_microphone_assignments(booking_id);

-- Hash '!' + acak bukan hash bcrypt valid -> verify_password selalu False.
INSERT INTO users (username, password_hash, name, email, status, position)
SELECT 'kiosk',
       '!' || md5(random()::text || clock_timestamp()::text),
       'Kiosk Display',
       'kiosk@system.local',
       'ACTIVE',
       'Akun sistem (booking walk-in)'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'kiosk');
