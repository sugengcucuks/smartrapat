-- ============================================================
-- MIGRATION 016: Kontrol AV per ruangan
-- videowall_configs.layout_mode: enum lama videowall_layout -> VARCHAR(20).
-- Nilai valid kini = id preset dari GET /rooms/{id}/av/capabilities
-- (config perangkat videowall_controller; default fullscreen/split2/main_side/quad/panels6).
-- Idempotent.
-- ============================================================
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'videowall_configs' AND column_name = 'layout_mode' AND data_type = 'USER-DEFINED'
    ) THEN
        ALTER TABLE videowall_configs ALTER COLUMN layout_mode DROP DEFAULT;
        ALTER TABLE videowall_configs ALTER COLUMN layout_mode TYPE VARCHAR(20) USING (
            CASE layout_mode::text
                WHEN '2x2' THEN 'quad'
                WHEN '3x3' THEN 'panels6'
                WHEN '1x4' THEN 'split2'
                WHEN '4x1' THEN 'split2'
                WHEN 'custom' THEN 'fullscreen'
                ELSE layout_mode::text
            END
        );
        ALTER TABLE videowall_configs ALTER COLUMN layout_mode SET DEFAULT 'fullscreen';
    END IF;
END $$;
