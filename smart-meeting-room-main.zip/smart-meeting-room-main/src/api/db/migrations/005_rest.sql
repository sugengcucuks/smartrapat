-- Smart Meeting Room Database Migration 005
-- Notifications, System Settings, Audit Logs + Participant Attendance
-- PostgreSQL 15+
-- Idempotent: Aman dijalankan berkali-kali

-- ============================================
-- EXTENSION: Pastikan uuid-ossp aktif
-- ============================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- ENUM TYPES (jika belum ada)
-- ============================================

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'notification_type') THEN
        CREATE TYPE notification_type AS ENUM (
            'info', 'success', 'warning', 'error',
            'booking_request', 'booking_approved', 'booking_rejected',
            'booking_cancelled', 'meeting_started', 'action_item_due'
        );
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'setting_value_type') THEN
        CREATE TYPE setting_value_type AS ENUM ('string', 'number', 'boolean', 'json');
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'audit_action') THEN
        CREATE TYPE audit_action AS ENUM (
            'login', 'logout', 'create', 'update', 'delete',
            'approve', 'reject', 'cancel', 'export', 'import', 'settings_change'
        );
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'audit_module') THEN
        CREATE TYPE audit_module AS ENUM (
            'auth', 'users', 'roles', 'rooms', 'equipment',
            'devices', 'bookings', 'notes', 'settings', 'system'
        );
    END IF;
END $$;

-- ============================================
-- ALTER TABLE booking_participants: Tambah kolom attendance
-- ============================================

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'booking_participants' AND column_name = 'attended'
    ) THEN
        ALTER TABLE booking_participants
            ADD COLUMN attended BOOLEAN NOT NULL DEFAULT FALSE;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'booking_participants' AND column_name = 'checked_in_at'
    ) THEN
        ALTER TABLE booking_participants
            ADD COLUMN checked_in_at TIMESTAMP WITH TIME ZONE;
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_booking_participants_attended ON booking_participants(attended);

-- ============================================
-- TABLE: notifications
-- ============================================

CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type notification_type NOT NULL DEFAULT 'info',
    title VARCHAR(200) NOT NULL,
    message TEXT,
    data JSONB DEFAULT '{}'::jsonb,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    read_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_user_created ON notifications(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_type ON notifications(type);
CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(user_id, is_read)
    WHERE is_read = FALSE;

-- ============================================
-- TABLE: system_settings
-- ============================================

CREATE TABLE IF NOT EXISTS system_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    value_type setting_value_type NOT NULL DEFAULT 'string',
    description TEXT,
    group_name VARCHAR(50),
    is_public BOOLEAN NOT NULL DEFAULT FALSE,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_by UUID REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_settings_key ON system_settings(setting_key);
CREATE INDEX IF NOT EXISTS idx_settings_group ON system_settings(group_name);
CREATE INDEX IF NOT EXISTS idx_settings_is_public ON system_settings(is_public);

-- ============================================
-- TABLE: audit_logs
-- ============================================

CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    action audit_action NOT NULL,
    module audit_module NOT NULL,
    target_type VARCHAR(50),
    target_id VARCHAR(100),
    old_value JSONB,
    new_value JSONB,
    ip_address INET,
    user_agent TEXT,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_module ON audit_logs(module);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_target ON audit_logs(target_type, target_id);
CREATE INDEX IF NOT EXISTS idx_audit_module_timestamp ON audit_logs(module, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_user_timestamp ON audit_logs(user_id, timestamp DESC);

-- ============================================
-- CONSTRAINT: Cek setting_key unik (case-insensitive)
-- ============================================

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints
        WHERE constraint_name = 'system_settings_key_unique_lower'
    ) THEN
        CREATE UNIQUE INDEX IF NOT EXISTS system_settings_key_unique_lower
            ON system_settings(LOWER(setting_key));
    END IF;
END $$;

-- ============================================
-- SEED DATA: System Settings - Authentication Group
-- ============================================

WITH admin_user AS (SELECT id FROM users WHERE username = 'admin' LIMIT 1)
INSERT INTO system_settings (setting_key, setting_value, value_type, description, group_name, is_public, updated_by) VALUES
    ('auth_session_timeout', '480', 'number', 'Durasi timeout session dalam menit', 'Authentication', FALSE, (SELECT id FROM admin_user)),
    ('auth_password_min_length', '8', 'number', 'Panjang minimum password', 'Authentication', TRUE, (SELECT id FROM admin_user)),
    ('auth_password_require_special', 'true', 'boolean', 'Password harus mengandung karakter special', 'Authentication', TRUE, (SELECT id FROM admin_user)),
    ('auth_max_failed_login', '5', 'number', 'Jumlah maksimum login gagal sebelum lock', 'Authentication', FALSE, (SELECT id FROM admin_user))
ON CONFLICT (setting_key) DO NOTHING;

-- ============================================
-- SEED DATA: System Settings - Email Group
-- ============================================

WITH admin_user AS (SELECT id FROM users WHERE username = 'admin' LIMIT 1)
INSERT INTO system_settings (setting_key, setting_value, value_type, description, group_name, is_public, updated_by) VALUES
    ('email_host', 'smtp.example.com', 'string', 'SMTP host', 'Email', FALSE, (SELECT id FROM admin_user)),
    ('email_port', '587', 'number', 'SMTP port', 'Email', FALSE, (SELECT id FROM admin_user)),
    ('email_user', 'no-reply@company.com', 'string', 'SMTP username', 'Email', FALSE, (SELECT id FROM admin_user)),
    ('email_pass', '', 'string', 'SMTP password', 'Email', FALSE, (SELECT id FROM admin_user)),
    ('email_tls', 'true', 'boolean', 'Gunakan TLS untuk email', 'Email', FALSE, (SELECT id FROM admin_user)),
    ('email_from', 'Smart Meeting Room <no-reply@company.com>', 'string', 'Alamat pengirim email', 'Email', FALSE, (SELECT id FROM admin_user))
ON CONFLICT (setting_key) DO NOTHING;

-- ============================================
-- SEED DATA: System Settings - Company Group
-- ============================================

WITH admin_user AS (SELECT id FROM users WHERE username = 'admin' LIMIT 1)
INSERT INTO system_settings (setting_key, setting_value, value_type, description, group_name, is_public, updated_by) VALUES
    ('company_name', 'PT. Smart Meeting Room Indonesia', 'string', 'Nama perusahaan', 'Company', TRUE, (SELECT id FROM admin_user)),
    ('company_logo_url', '/assets/logo.png', 'string', 'URL logo perusahaan', 'Company', TRUE, (SELECT id FROM admin_user)),
    ('company_address', 'Jl. Sudirman No. 1, Jakarta Pusat', 'string', 'Alamat kantor', 'Company', TRUE, (SELECT id FROM admin_user)),
    ('company_phone', '+62 21 1234 5678', 'string', 'Nomor telepon kantor', 'Company', TRUE, (SELECT id FROM admin_user))
ON CONFLICT (setting_key) DO NOTHING;

-- ============================================
-- SEED DATA: System Settings - Booking Group
-- ============================================

WITH admin_user AS (SELECT id FROM users WHERE username = 'admin' LIMIT 1)
INSERT INTO system_settings (setting_key, setting_value, value_type, description, group_name, is_public, updated_by) VALUES
    ('booking_auto_approve_staff', 'false', 'boolean', 'Otomatis approve booking untuk staff', 'Booking', TRUE, (SELECT id FROM admin_user)),
    ('booking_default_advance_days', '30', 'number', 'Maksimum hari advance booking', 'Booking', TRUE, (SELECT id FROM admin_user)),
    ('booking_min_minutes', '15', 'number', 'Durasi minimum booking (menit)', 'Booking', TRUE, (SELECT id FROM admin_user)),
    ('booking_max_hours', '8', 'number', 'Durasi maksimum booking (jam)', 'Booking', TRUE, (SELECT id FROM admin_user)),
    ('booking_allowed_extra_time', '30', 'number', 'Waktu tambahan yang diizinkan (menit)', 'Booking', TRUE, (SELECT id FROM admin_user))
ON CONFLICT (setting_key) DO NOTHING;

-- ============================================
-- SEED DATA: System Settings - Notifications Group
-- ============================================

WITH admin_user AS (SELECT id FROM users WHERE username = 'admin' LIMIT 1)
INSERT INTO system_settings (setting_key, setting_value, value_type, description, group_name, is_public, updated_by) VALUES
    ('notify_email_enabled', 'false', 'boolean', 'Aktifkan notifikasi via email', 'Notifications', TRUE, (SELECT id FROM admin_user)),
    ('notify_push_enabled', 'true', 'boolean', 'Aktifkan notifikasi push/web', 'Notifications', TRUE, (SELECT id FROM admin_user))
ON CONFLICT (setting_key) DO NOTHING;

-- ============================================
-- SEED DATA: System Settings - Maintenance Group
-- ============================================

WITH admin_user AS (SELECT id FROM users WHERE username = 'admin' LIMIT 1)
INSERT INTO system_settings (setting_key, setting_value, value_type, description, group_name, is_public, updated_by) VALUES
    ('maintenance_mode', 'false', 'boolean', 'Mode maintenance aktif', 'Maintenance', TRUE, (SELECT id FROM admin_user)),
    ('maintenance_message', '', 'string', 'Pesan maintenance mode', 'Maintenance', TRUE, (SELECT id FROM admin_user)),
    ('maintenance_last_backup_at', '', 'string', 'Waktu backup terakhir (ISO timestamp)', 'Maintenance', FALSE, (SELECT id FROM admin_user))
ON CONFLICT (setting_key) DO NOTHING;

-- ============================================
-- SEED DATA: Sample Notifications (5 untuk admin)
-- ============================================

WITH admin_user AS (SELECT id FROM users WHERE username = 'admin' LIMIT 1)
INSERT INTO notifications (user_id, type, title, message, data, is_read, created_at) VALUES
    ((SELECT id FROM admin_user), 'success', 'Selamat Datang di Smart Meeting Room', 'Akun admin Anda telah berhasil diaktifkan. Silakan jelajahi fitur-fitur kami.',
     '{"welcome_tour": true}'::jsonb, FALSE, CURRENT_TIMESTAMP - INTERVAL '3 days'),

    ((SELECT id FROM admin_user), 'booking_request', 'Permintaan Booking Baru', 'Ada 1 permintaan booking baru yang menunggu persetujuan Anda.',
     '{"booking_count": 1, "action_url": "/bookings/pending"}'::jsonb, FALSE, CURRENT_TIMESTAMP - INTERVAL '1 day'),

    ((SELECT id FROM admin_user), 'info', 'Backup Otomatis Berhasil', 'Backup database mingguan telah berhasil dijalankan pada pukul 02:00 WIB.',
     '{"backup_size": "8.5 MB", "backup_file": "smr_backup_20240915.sql"}'::jsonb, TRUE, CURRENT_TIMESTAMP - INTERVAL '20 hours'),

    ((SELECT id FROM admin_user), 'warning', 'Peringatan Kapasitas Storage', 'Penggunaan storage server telah mencapai 78%. Pertimbangkan untuk melakukan cleanup.',
     '{"storage_used_pct": 78, "threshold": 80}'::jsonb, FALSE, CURRENT_TIMESTAMP - INTERVAL '6 hours'),

    ((SELECT id FROM admin_user), 'action_item_due', 'Action Item Jatuh Tempo', 'Terdapat 2 action item yang jatuh tempo hari ini dari rapat Q3 Review.',
     '{"action_items": ["Finalisasi dokumen target Q4", "Ajukan budget upgrade IT"], "note_id": "auto-1"}'::jsonb, FALSE, CURRENT_TIMESTAMP - INTERVAL '2 hours')
ON CONFLICT DO NOTHING;

-- ============================================
-- SEED DATA: Sample Audit Logs (10)
-- ============================================

WITH admin_user AS (SELECT id FROM users WHERE username = 'admin' LIMIT 1)
INSERT INTO audit_logs (user_id, action, module, target_type, target_id, old_value, new_value, ip_address, user_agent, timestamp) VALUES
    ((SELECT id FROM admin_user), 'login', 'auth', 'user', 'admin', NULL,
     '{"status": "success", "method": "password"}'::jsonb,
     '192.168.1.10'::inet, 'Mozilla/5.0 Chrome/120.0', CURRENT_TIMESTAMP - INTERVAL '7 days'),

    ((SELECT id FROM admin_user), 'create', 'rooms', 'room', 'R-301', NULL,
     '{"name": "Training Room", "capacity": 30, "floor": 3}'::jsonb,
     '192.168.1.10'::inet, 'Mozilla/5.0 Chrome/120.0', CURRENT_TIMESTAMP - INTERVAL '6 days'),

    ((SELECT id FROM admin_user), 'update', 'users', 'user', 'staff1',
     '{"position": "Staff"}'::jsonb, '{"position": "Senior Staff"}'::jsonb,
     '192.168.1.10'::inet, 'Mozilla/5.0 Chrome/120.0', CURRENT_TIMESTAMP - INTERVAL '5 days'),

    ((SELECT id FROM admin_user), 'approve', 'bookings', 'booking', 'BK-001',
     '{"status": "pending"}'::jsonb, '{"status": "approved", "approved_by": "admin"}'::jsonb,
     '192.168.1.10'::inet, 'Mozilla/5.0 Chrome/120.0', CURRENT_TIMESTAMP - INTERVAL '4 days'),

    ((SELECT id FROM admin_user), 'create', 'equipment', 'equipment', 'EQ-TAB-001', NULL,
     '{"name": "Tablet Control Room", "category": "input", "location": "R-B201"}'::jsonb,
     '192.168.1.10'::inet, 'Mozilla/5.0 Chrome/120.0', CURRENT_TIMESTAMP - INTERVAL '3 days'),

    ((SELECT id FROM admin_user), 'export', 'bookings', 'report', 'bookings-sep-2024', NULL,
     '{"format": "xlsx", "records": 156}'::jsonb,
     '192.168.1.10'::inet, 'Mozilla/5.0 Chrome/120.0', CURRENT_TIMESTAMP - INTERVAL '2 days 10 hours'),

    ((SELECT id FROM admin_user), 'settings_change', 'settings', 'setting', 'booking_allowed_extra_time',
     '{"setting_value": "15"}'::jsonb, '{"setting_value": "30"}'::jsonb,
     '192.168.1.10'::inet, 'Mozilla/5.0 Chrome/120.0', CURRENT_TIMESTAMP - INTERVAL '2 days'),

    ((SELECT id FROM admin_user), 'login', 'auth', 'user', 'admin', NULL,
     '{"status": "success", "method": "password"}'::jsonb,
     '192.168.1.22'::inet, 'Mozilla/5.0 Safari/17.0 Mac', CURRENT_TIMESTAMP - INTERVAL '1 day 8 hours'),

    ((SELECT id FROM admin_user), 'delete', 'devices', 'device', 'DEV-OLD-001',
     '{"name": "Old Projector", "status": "broken"}'::jsonb, NULL,
     '192.168.1.10'::inet, 'Mozilla/5.0 Chrome/120.0', CURRENT_TIMESTAMP - INTERVAL '18 hours'),

    ((SELECT id FROM admin_user), 'logout', 'auth', 'user', 'admin', NULL,
     '{"session_duration_minutes": 145}'::jsonb,
     '192.168.1.10'::inet, 'Mozilla/5.0 Chrome/120.0', CURRENT_TIMESTAMP - INTERVAL '6 hours')
ON CONFLICT DO NOTHING;

-- ============================================
-- FUNCTION: Trigger update updated_at untuk system_settings
-- ============================================

CREATE OR REPLACE FUNCTION update_settings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_system_settings_updated_at ON system_settings;
CREATE TRIGGER trg_system_settings_updated_at
    BEFORE UPDATE ON system_settings
    FOR EACH ROW
    EXECUTE FUNCTION update_settings_updated_at();
