CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- FIX 1: Tambah kolom is_active ke users (model pake is_active)
-- ============================================
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name='users' AND column_name='is_active'
    ) THEN
        ALTER TABLE users ADD COLUMN is_active BOOLEAN NOT NULL DEFAULT TRUE;
    END IF;
END $$;

-- Sync dari status enum ke is_active
UPDATE users SET is_active = (status = 'active');

-- ============================================
-- FIX 2: Booking participants (Modul 10 & 16 Door Display)
-- ============================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'bp_status') THEN
        CREATE TYPE bp_status AS ENUM ('invited', 'confirmed', 'declined');
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS booking_participants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    guest_name VARCHAR(150),
    guest_email VARCHAR(200),
    is_guest BOOLEAN NOT NULL DEFAULT FALSE,
    status bp_status NOT NULL DEFAULT 'invited',
    attended BOOLEAN NOT NULL DEFAULT FALSE,
    checked_in_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_bp_booking ON booking_participants(booking_id);
CREATE INDEX IF NOT EXISTS idx_bp_user ON booking_participants(user_id);
CREATE INDEX IF NOT EXISTS idx_bp_attended ON booking_participants(attended);

-- ============================================
-- FIX 3: ENUM Equipment (Modul 06) & Device (Modul 07)
-- ============================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'equipment_category') THEN
        CREATE TYPE equipment_category AS ENUM (
            'display', 'audio', 'input', 'network', 'camera', 'other'
        );
    END IF;
END $$;
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'equipment_status') THEN
        CREATE TYPE equipment_status AS ENUM (
            'active', 'maintenance', 'broken', 'disposed'
        );
    END IF;
END $$;
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'device_type') THEN
        CREATE TYPE device_type AS ENUM (
            'tv', 'projector', 'ac', 'cctv', 'lights', 'curtain',
            'sensor_temp', 'sensor_humidity', 'door_lock',
            'videowall_controller', 'audio_processor', 'tablet'
        );
    END IF;
END $$;
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'device_status') THEN
        CREATE TYPE device_status AS ENUM (
            'online', 'offline', 'error', 'maintenance'
        );
    END IF;
END $$;

-- Kolom untuk equipment
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='equipment' AND column_name='category') THEN
        ALTER TABLE equipment ADD COLUMN category equipment_category;
    END IF;
END $$;
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='equipment' AND column_name='status') THEN
        ALTER TABLE equipment ADD COLUMN status equipment_status;
    END IF;
END $$;

-- Kolom untuk devices
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='devices' AND column_name='device_type') THEN
        ALTER TABLE devices ADD COLUMN device_type device_type;
    END IF;
END $$;
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='devices' AND column_name='status') THEN
        ALTER TABLE devices ADD COLUMN status device_status;
    END IF;
END $$;

-- ============================================
-- FIX 4: Videowall Configs (Modul 08)
-- ============================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'videowall_layout') THEN
        CREATE TYPE videowall_layout AS ENUM (
            'fullscreen', '2x2', '3x3', '1x4', '4x1', 'custom'
        );
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS videowall_configs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id UUID REFERENCES rooms(id) ON DELETE SET NULL,
    device_id UUID REFERENCES devices(id) ON DELETE SET NULL,
    config_name VARCHAR(100) NOT NULL,
    layout_mode videowall_layout NOT NULL DEFAULT 'fullscreen',
    inputs JSONB DEFAULT '[]'::jsonb,
    last_action VARCHAR(200),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_videowall_room ON videowall_configs(room_id);
CREATE INDEX IF NOT EXISTS idx_videowall_device ON videowall_configs(device_id);

-- ============================================
-- FIX 5: Audio Zones (Modul 09)
-- ============================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'audio_source') THEN
        CREATE TYPE audio_source AS ENUM (
            'mic1', 'mic2', 'line1', 'bluetooth', 'hdmi', 'usb'
        );
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS audio_zones (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id UUID REFERENCES rooms(id) ON DELETE SET NULL,
    device_id UUID REFERENCES devices(id) ON DELETE SET NULL,
    zone_name VARCHAR(100) NOT NULL,
    volume INTEGER NOT NULL DEFAULT 60 CHECK (volume BETWEEN 0 AND 100),
    is_muted BOOLEAN NOT NULL DEFAULT FALSE,
    input_source audio_source DEFAULT 'mic1',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_audio_zone_room ON audio_zones(room_id);
CREATE INDEX IF NOT EXISTS idx_audio_zone_device ON audio_zones(device_id);

-- ============================================
-- FIX 6: Meeting Notes + Action Items (Modul 11)
-- ============================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'action_status') THEN
        CREATE TYPE action_status AS ENUM ('open', 'in_progress', 'done', 'cancelled');
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS meeting_notes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID REFERENCES bookings(id) ON DELETE SET NULL,
    room_id UUID REFERENCES rooms(id) ON DELETE SET NULL,
    title VARCHAR(250) NOT NULL,
    date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    participants TEXT[] DEFAULT '{}'::TEXT[],
    summary TEXT,
    decisions TEXT[] DEFAULT '{}'::TEXT[],
    transcript JSONB DEFAULT '[]'::jsonb,
    transcript_processing BOOLEAN NOT NULL DEFAULT FALSE,
    ai_model VARCHAR(100),
    generated_at TIMESTAMP WITH TIME ZONE,
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_notes_room ON meeting_notes(room_id);
CREATE INDEX IF NOT EXISTS idx_notes_booking ON meeting_notes(booking_id);
CREATE INDEX IF NOT EXISTS idx_notes_date ON meeting_notes(date DESC);
CREATE INDEX IF NOT EXISTS idx_notes_created_by ON meeting_notes(created_by);

CREATE TABLE IF NOT EXISTS meeting_note_action_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    note_id UUID NOT NULL REFERENCES meeting_notes(id) ON DELETE CASCADE,
    task TEXT NOT NULL,
    owner VARCHAR(200),
    due_date DATE,
    status action_status NOT NULL DEFAULT 'open',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_mnai_note ON meeting_note_action_items(note_id);
CREATE INDEX IF NOT EXISTS idx_mnai_status ON meeting_note_action_items(status);
CREATE INDEX IF NOT EXISTS idx_mnai_due ON meeting_note_action_items(due_date);

-- ============================================
-- FIX 7: ENUM notifications (Modul 13) & system settings & audit logs
-- ============================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'notification_type') THEN
        CREATE TYPE notification_type AS ENUM (
            'info', 'warning', 'error',
            'booking_request', 'booking_approved', 'booking_rejected',
            'booking_cancelled', 'meeting_started', 'action_item_due'
        );
    END IF;
END $$;
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'setting_value_type') THEN
        CREATE TYPE setting_value_type AS ENUM ('string', 'number', 'boolean', 'json');
    END IF;
END $$;
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'audit_action') THEN
        CREATE TYPE audit_action AS ENUM (
            'login', 'logout', 'create', 'update', 'delete',
            'approve', 'reject', 'cancel', 'export', 'import', 'settings_change'
        );
    END IF;
END $$;
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'audit_module') THEN
        CREATE TYPE audit_module AS ENUM (
            'auth', 'users', 'roles', 'rooms', 'equipment',
            'devices', 'bookings', 'notes', 'settings', 'system'
        );
    END IF;
END $$;

-- Tambah kolom type di notifications jika belum ada
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='notifications' AND column_name='type') THEN
        ALTER TABLE notifications ADD COLUMN type notification_type DEFAULT 'info';
    END IF;
END $$;

-- Tambah kolom di system_settings jika belum
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='system_settings' AND column_name='setting_key') THEN
        ALTER TABLE system_settings ADD COLUMN setting_key VARCHAR(100) UNIQUE;
    END IF;
END $$;
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='system_settings' AND column_name='setting_value') THEN
        ALTER TABLE system_settings ADD COLUMN setting_value TEXT;
    END IF;
END $$;
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='system_settings' AND column_name='value_type') THEN
        ALTER TABLE system_settings ADD COLUMN value_type setting_value_type DEFAULT 'string';
    END IF;
END $$;
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='system_settings' AND column_name='group_name') THEN
        ALTER TABLE system_settings ADD COLUMN group_name VARCHAR(50);
    END IF;
END $$;
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='system_settings' AND column_name='is_public') THEN
        ALTER TABLE system_settings ADD COLUMN is_public BOOLEAN NOT NULL DEFAULT FALSE;
    END IF;
END $$;

-- Tambah kolom di audit_logs jika kurang
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='audit_logs' AND column_name='module') THEN
        ALTER TABLE audit_logs ADD COLUMN module audit_module;
    END IF;
END $$;
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='audit_logs' AND column_name='action') THEN
        ALTER TABLE audit_logs ADD COLUMN action audit_action;
    END IF;
END $$;
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='audit_logs' AND column_name='timestamp') THEN
        ALTER TABLE audit_logs ADD COLUMN timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;
    END IF;
END $$;

-- ============================================
-- SEED AKHIR: 2 sample videowall config, 3 audio zones, 3 meeting notes, 7 action items
-- ============================================
WITH r1 AS (SELECT id FROM rooms LIMIT 1),
     d1 AS (SELECT id FROM devices WHERE device_type = 'videowall_controller' LIMIT 1)
INSERT INTO videowall_configs (room_id, device_id, config_name, layout_mode, inputs)
SELECT (SELECT id FROM r1), (SELECT id FROM d1), 'Presentasi Utama', 'fullscreen',
       '[{"label":"Laptop CEO","port":"HDMI1"},{"label":"Tablet Control","port":"HDMI2"}]'::jsonb
WHERE EXISTS (SELECT 1 FROM r1)
ON CONFLICT DO NOTHING;

INSERT INTO videowall_configs (room_id, device_id, config_name, layout_mode, inputs)
SELECT (SELECT id FROM r1), (SELECT id FROM d1), 'Grid 2x2 4 Sumber', '2x2',
       '[{"label":"HDMI1"},{"label":"HDMI2"},{"label":"DP"},{"label":"USB-C"}]'::jsonb
WHERE EXISTS (SELECT 1 FROM r1)
ON CONFLICT DO NOTHING;

-- Audio zones
WITH r1 AS (SELECT id FROM rooms LIMIT 1),
     d2 AS (SELECT id FROM devices WHERE device_type = 'audio_processor' LIMIT 1)
INSERT INTO audio_zones (room_id, device_id, zone_name, volume, input_source) VALUES
    ((SELECT id FROM r1), (SELECT id FROM d2), 'Zone Utama Ruang Rapat', 65, 'mic1'),
    ((SELECT id FROM r1), (SELECT id FROM d2), 'Zone Meja Peserta', 55, 'mic2'),
    ((SELECT id FROM r1), (SELECT id FROM d2), 'Zone Podium', 70, 'line1')
ON CONFLICT DO NOTHING;

-- Notes sample
WITH admin_user AS (SELECT id FROM users WHERE username = 'admin' LIMIT 1),
     rb1 AS (SELECT id FROM bookings LIMIT 1),
     rr1 AS (SELECT id FROM rooms LIMIT 1)
INSERT INTO meeting_notes (booking_id, room_id, title, date, start_time, end_time, participants, summary, decisions, transcript, ai_model, generated_at, created_by)
SELECT
    (SELECT id FROM rb1), (SELECT id FROM rr1), 'Rapat Tinjauan Q3', CURRENT_DATE - INTERVAL '5 days',
    '09:00', '11:30',
    ARRAY['Budi Santoso', 'Siti Rahayu', 'Ahmad Wijaya', 'Dewi Lestari'],
    E'Rapat tinjauan kuartal ketiga membahas pencapaian target bisnis. Total pendapatan mencapai 85% dari target Q3, dengan peningkatan signifikan di divisi teknologi. Keputusan utama adalah meningkatkan anggaran marketing sebesar 15% untuk Q4 dan membuka lowongan 5 posisi baru engineering.',
    ARRAY['Anggaran marketing Q4 naik 15%', 'Rekrutmen 5 engineer baru', 'Produk baru launch pertengahan November', 'Target Q4 dinaikkan 10%'],
    ('[{"speaker":"Budi Santoso","text":"Mari kita mulai tinjauan performa Q3.","timestamp":"09:05:00"},' ||
    '{"speaker":"Siti Rahayu","text":"Pendapatan mencapai 85% target, bagian teknologi paling berkontribusi.","timestamp":"09:20:00"},' ||
    '{"speaker":"Ahmad Wijaya","text":"Usulkan anggaran marketing naik 15%.","timestamp":"10:15:00"},' ||
    '{"speaker":"Dewi Lestari","text":"Setuju, dan kita butuh rekrutmen tambahan.","timestamp":"10:45:00"}]')::jsonb,
    'mock-gemma-2b', CURRENT_TIMESTAMP - INTERVAL '5 hours', (SELECT id FROM admin_user)
WHERE EXISTS (SELECT 1 FROM admin_user)
ON CONFLICT DO NOTHING;

WITH n1 AS (SELECT id FROM meeting_notes WHERE title='Rapat Tinjauan Q3' LIMIT 1)
INSERT INTO meeting_note_action_items (note_id, task, owner, due_date, status) VALUES
    ((SELECT id FROM n1), 'Finalisasi anggaran marketing Q4', 'Siti Rahayu', CURRENT_DATE + INTERVAL '3 days', 'in_progress'),
    ((SELECT id FROM n1), 'Buka lowongan 5 engineer', 'Tim HRD', CURRENT_DATE + INTERVAL '7 days', 'open'),
    ((SELECT id FROM n1), 'Rilis roadmap produk Q4', 'Ahmad Wijaya', CURRENT_DATE + INTERVAL '10 days', 'open'),
    ((SELECT id FROM n1), 'Presentasi ke stakeholder', 'Budi Santoso', CURRENT_DATE + INTERVAL '5 days', 'done')
ON CONFLICT DO NOTHING;

WITH admin_user AS (SELECT id FROM users WHERE username = 'admin' LIMIT 1),
     rr1 AS (SELECT id FROM rooms LIMIT 1)
INSERT INTO meeting_notes (booking_id, room_id, title, date, start_time, end_time, participants, summary, decisions, transcript, ai_model, generated_at, created_by)
SELECT
    NULL, (SELECT id FROM rr1), 'Sprint Planning Sprint 24', CURRENT_DATE - INTERVAL '2 days',
    '13:00', '15:00',
    ARRAY['Andi Pratama', 'Rina Marlina', 'Fajar Nugroho', 'Sari Dewi'],
    'Sprint planning untuk sprint 24. Total 21 story point diambil mencakup fitur payment integrasi, perbaikan booking conflict, 2 UI improvement, dan upgrade dependency security. Target delivery 2 minggu dengan release candidate di hari Jumat minggu kedua.',
    ARRAY['Payment gateway midtrans integration selesai sprint ini', 'Bug booking ruang bentrok fix dalam 3 hari pertama'],
    ('[{"speaker":"Andi Pratama","text":"Halo semua, mari mulai planning sprint 24.","timestamp":"13:05:00"},' ||
    '{"speaker":"Rina Marlina","text":"Saya handle payment gateway, estimasi 8 SP.","timestamp":"13:30:00"},' ||
    '{"speaker":"Fajar Nugroho","text":"Saya handle booking conflict.","timestamp":"14:00:00"}]')::jsonb,
    'mock-llama', CURRENT_TIMESTAMP - INTERVAL '2 days', (SELECT id FROM admin_user)
WHERE EXISTS (SELECT 1 FROM admin_user)
ON CONFLICT DO NOTHING;

WITH n2 AS (SELECT id FROM meeting_notes WHERE title='Sprint Planning Sprint 24' LIMIT 1)
INSERT INTO meeting_note_action_items (note_id, task, owner, due_date, status) VALUES
    ((SELECT id FROM n2), 'Integrasi payment gateway', 'Rina Marlina', CURRENT_DATE + INTERVAL '10 days', 'open'),
    ((SELECT id FROM n2), 'Fix booking ruang bentrok', 'Fajar Nugroho', CURRENT_DATE + INTERVAL '3 days', 'in_progress'),
    ((SELECT id FROM n2), 'Upgrade dependencies critical', 'Sari Dewi', CURRENT_DATE + INTERVAL '1 day', 'done')
ON CONFLICT DO NOTHING;
