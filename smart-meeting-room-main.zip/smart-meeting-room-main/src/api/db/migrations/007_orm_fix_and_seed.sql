-- ============================================================
-- 007 ORM Schema Sync & Seed Data
-- Sinkronkan DB actual dengan ORM Python models
-- ============================================================

-- 1. BUILDINGS: Tambah kolom floors (ORM Building butuh floors INT)
ALTER TABLE buildings ADD COLUMN IF NOT EXISTS floors INTEGER NOT NULL DEFAULT 1;

-- 2. ROOMS: Rename facilities -> amenities; ubah status ke VARCHAR lowercase
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'rooms' AND column_name = 'facilities'
    ) THEN
        ALTER TABLE rooms RENAME COLUMN facilities TO amenities;
    END IF;
END $$;

ALTER TABLE rooms ALTER COLUMN status TYPE VARCHAR(20);
ALTER TABLE rooms ALTER COLUMN status SET DEFAULT 'available';
UPDATE rooms SET status = LOWER(status);

-- 3. BOOKINGS: DROP & RECREATE (schema total berbeda — organizer_id vs user_id, date+time vs timestamptz)
DROP TABLE IF EXISTS booking_participants CASCADE;
DROP TABLE IF EXISTS meetings CASCADE;
DROP TABLE IF EXISTS transcript_segments CASCADE;
DROP TABLE IF EXISTS bookings CASCADE;

CREATE TABLE bookings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id),
    room_id UUID NOT NULL REFERENCES rooms(id),
    title VARCHAR(200) NOT NULL,
    description TEXT,
    date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    attendees INTEGER NOT NULL DEFAULT 1,
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    approval_notes TEXT,
    created_by UUID REFERENCES users(id),
    approved_by UUID REFERENCES users(id),
    approved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE booking_participants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id),
    guest_name VARCHAR(100),
    guest_email VARCHAR(255),
    is_guest BOOLEAN NOT NULL DEFAULT FALSE,
    attended BOOLEAN NOT NULL DEFAULT FALSE,
    checked_in_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_bookings_user ON bookings(user_id);
CREATE INDEX IF NOT EXISTS idx_bookings_room ON bookings(room_id);
CREATE INDEX IF NOT EXISTS idx_bookings_date ON bookings(date);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_booking_participants_booking ON booking_participants(booking_id);

-- 4. EQUIPMENT: Sinkronisasi dengan ORM
ALTER TABLE equipment DROP COLUMN IF EXISTS category;  -- drop enum category dulu (konflik nama)
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'equipment' AND column_name = 'equipment_type'
    ) THEN
        ALTER TABLE equipment RENAME COLUMN equipment_type TO category;
    END IF;
END $$;

DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'equipment' AND column_name = 'room_id'
    ) THEN
        ALTER TABLE equipment RENAME COLUMN room_id TO location_id;
    END IF;
END $$;

ALTER TABLE equipment ALTER COLUMN category TYPE VARCHAR(20);
ALTER TABLE equipment ALTER COLUMN category SET DEFAULT 'other';
ALTER TABLE equipment ALTER COLUMN status TYPE VARCHAR(20);
ALTER TABLE equipment ALTER COLUMN status SET DEFAULT 'active';
UPDATE equipment SET status = LOWER(status) WHERE status != LOWER(status);
ALTER TABLE equipment ADD COLUMN IF NOT EXISTS purchase_date DATE;
ALTER TABLE equipment ADD COLUMN IF NOT EXISTS warranty_until DATE;
ALTER TABLE equipment ADD COLUMN IF NOT EXISTS notes TEXT;

-- 5. DEVICES: Sinkronisasi dengan ORM
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'devices' AND column_name = 'room_id'
    ) THEN
        ALTER TABLE devices RENAME COLUMN room_id TO location_id;
    END IF;
END $$;

ALTER TABLE devices ALTER COLUMN device_type TYPE VARCHAR(30);
ALTER TABLE devices ALTER COLUMN status TYPE VARCHAR(20);
ALTER TABLE devices ALTER COLUMN status SET DEFAULT 'offline';
UPDATE devices SET status = LOWER(status) WHERE status != LOWER(status);
ALTER TABLE devices ADD COLUMN IF NOT EXISTS firmware_version VARCHAR(50);
ALTER TABLE devices ADD COLUMN IF NOT EXISTS last_action VARCHAR(200);

-- 6. AUDIT_LOGS: DROP & RECREATE (kolom beda total: entity_type vs target_type, old_data vs old_value)
DROP TABLE IF EXISTS audit_logs CASCADE;
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    action VARCHAR(30) NOT NULL,
    module VARCHAR(30) NOT NULL,
    target_type VARCHAR(50),
    target_id VARCHAR(100),
    old_value JSONB,
    new_value JSONB,
    ip_address INET,
    user_agent TEXT,
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_module ON audit_logs(module);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_target ON audit_logs(target_type, target_id);

-- 7. NOTIFICATIONS: Sinkron type enum → VARCHAR
ALTER TABLE notifications ALTER COLUMN type TYPE VARCHAR(30);
ALTER TABLE notifications ALTER COLUMN type SET DEFAULT 'info';

-- 8. SYSTEM_SETTINGS: Drop duplicate `key`/`value`; pastikan ORM-expected columns lengkap
ALTER TABLE system_settings DROP COLUMN IF EXISTS value;
ALTER TABLE system_settings DROP COLUMN IF EXISTS key;
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'system_settings' AND column_name = 'setting_key'
    ) THEN
        ALTER TABLE system_settings ADD COLUMN setting_key VARCHAR(100) UNIQUE;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'system_settings' AND column_name = 'setting_value'
    ) THEN
        ALTER TABLE system_settings ADD COLUMN setting_value TEXT;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'system_settings' AND column_name = 'value_type'
    ) THEN
        ALTER TABLE system_settings ADD COLUMN value_type VARCHAR(20) NOT NULL DEFAULT 'string';
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'system_settings' AND column_name = 'group_name'
    ) THEN
        ALTER TABLE system_settings ADD COLUMN group_name VARCHAR(50);
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'system_settings' AND column_name = 'is_public'
    ) THEN
        ALTER TABLE system_settings ADD COLUMN is_public BOOLEAN NOT NULL DEFAULT FALSE;
    END IF;
END $$;

-- ============================================================
-- SEED DATA: Buildings, Rooms, Equipment, Devices,
-- Audit Logs, Notifications, Bookings Demo, System Settings
-- ============================================================

-- ===== BUILDINGS (3) =====
INSERT INTO buildings (id, code, name, address, floors, created_at, updated_at)
VALUES
    (uuid_generate_v4(), 'GED-A', 'Gedung A - Utama', 'Jl. Merdeka No. 1, Jakarta Pusat', 5, NOW(), NOW()),
    (uuid_generate_v4(), 'GED-B', 'Gedung B - Operasional', 'Jl. Merdeka No. 2, Jakarta Pusat', 4, NOW(), NOW()),
    (uuid_generate_v4(), 'GED-C', 'Gedung C - Rapat & Training', 'Jl. Merdeka No. 3, Jakarta Pusat', 3, NOW(), NOW())
ON CONFLICT (code) DO NOTHING;

-- ===== ROOMS (4 - satu gedung minimal 1 ruangan) =====
DO $$
DECLARE
    gidA UUID; gidB UUID; gidC UUID;
    uid_admin UUID;
BEGIN
    SELECT id INTO gidA FROM buildings WHERE code = 'GED-A' LIMIT 1;
    SELECT id INTO gidB FROM buildings WHERE code = 'GED-B' LIMIT 1;
    SELECT id INTO gidC FROM buildings WHERE code = 'GED-C' LIMIT 1;

    INSERT INTO rooms (id, code, name, building_id, floor, capacity, room_type, description, amenities, status, created_at, updated_at)
    VALUES
        (uuid_generate_v4(), 'R-A101', 'Ruang Rapat Utama A101', gidA, 1, 30, 'meeting', 'Ruang rapat besar untuk rapat pleno', ARRAY['projector','whiteboard','video_conference','wifi']::jsonb, 'available', NOW(), NOW()),
        (uuid_generate_v4(), 'R-A203', 'Ruang Diskusi A203', gidA, 2, 10, 'meeting', 'Ruang diskusi kecil', ARRAY['tv_led','whiteboard','wifi']::jsonb, 'available', NOW(), NOW()),
        (uuid_generate_v4(), 'R-B102', 'Ruang Meeting B102', gidB, 1, 15, 'meeting', 'Ruang meeting middle size', ARRAY['projector','speaker','wifi']::jsonb, 'available', NOW(), NOW()),
        (uuid_generate_v4(), 'R-C301', 'Training Room C301', gidC, 3, 50, 'training', 'Ruang training kapasitas besar', ARRAY['projector','sound_system','mic_wireless','wifi','air_conditioner']::jsonb, 'available', NOW(), NOW())
    ON CONFLICT (code) DO NOTHING;
END $$;

-- ===== EQUIPMENT (Perangkat AV) (5) =====
DO $$
DECLARE
    room1 UUID; room2 UUID; room3 UUID; room4 UUID;
BEGIN
    SELECT id INTO room1 FROM rooms WHERE code = 'R-A101' LIMIT 1;
    SELECT id INTO room2 FROM rooms WHERE code = 'R-A203' LIMIT 1;
    SELECT id INTO room3 FROM rooms WHERE code = 'R-B102' LIMIT 1;
    SELECT id INTO room4 FROM rooms WHERE code = 'R-C301' LIMIT 1;

    INSERT INTO equipment (id, code, name, category, brand, model, serial_number, purchase_date, warranty_until, status, location_id, notes, created_at, updated_at)
    VALUES
        (uuid_generate_v4(), 'EQ-PROJ-001', 'Proyektor Epson 4K', 'display', 'Epson', 'EB-L730U', 'SN-EPS-2024-0001', '2024-01-15', '2026-01-15', 'active', room1, 'Laser projector 7000 lumens', NOW(), NOW()),
        (uuid_generate_v4(), 'EQ-TV-001', 'Smart TV LED 65 Inch', 'display', 'Samsung', 'Q65C QLED', 'SN-SMS-2024-0101', '2024-02-10', '2026-02-10', 'active', room2, '4K Smart TV dengan screen mirroring', NOW(), NOW()),
        (uuid_generate_v4(), 'EQ-SPK-001', 'Speaker Wireless Portable', 'audio', 'JBL', 'Charge 5', 'SN-JBL-2024-0303', '2024-03-05', '2025-03-05', 'active', room3, 'Bluetooth speaker 40W waterproof', NOW(), NOW()),
        (uuid_generate_v4(), 'EQ-MIC-001', 'Microphone Wireless Set', 'audio', 'Shure', 'BLX24/SM58', 'SN-SHR-2024-0415', '2024-04-01', '2026-04-01', 'active', room4, 'Dual handheld wireless mic system', NOW(), NOW()),
        (uuid_generate_v4(), 'EQ-CAM-001', 'Webcam 4K PTZ', 'camera', 'Logitech', 'Rally', 'SN-LOG-2024-0520', '2024-05-10', '2026-05-10', 'maintenance', room1, 'Sedang perawatan sensor auto-focus', NOW(), NOW())
    ON CONFLICT (code) DO NOTHING;
END $$;

-- ===== DEVICES (Perangkat IoT) (4) =====
DO $$
DECLARE
    room1 UUID; room2 UUID; room3 UUID; room4 UUID;
BEGIN
    SELECT id INTO room1 FROM rooms WHERE code = 'R-A101' LIMIT 1;
    SELECT id INTO room2 FROM rooms WHERE code = 'R-A203' LIMIT 1;
    SELECT id INTO room3 FROM rooms WHERE code = 'R-B102' LIMIT 1;
    SELECT id INTO room4 FROM rooms WHERE code = 'R-C301' LIMIT 1;

    INSERT INTO devices (id, code, name, device_type, location_id, ip_address, mac_address, firmware_version, status, last_seen, config, created_at, updated_at)
    VALUES
        (uuid_generate_v4(), 'DEV-DC-001', 'Door Controller A101', 'door_access', room1, '192.168.1.101', 'AA:BB:CC:01:01:01', 'v2.3.1', 'online', NOW(), jsonb_build_object('protocol','Wiegand-26','relay_count',2), NOW(), NOW()),
        (uuid_generate_v4(), 'DEV-CAM-001', 'CCTV Camera A203', 'cctv', room2, '192.168.1.110', 'AA:BB:CC:02:02:02', 'v1.8.0', 'online', NOW()-INTERVAL '2 minutes', jsonb_build_object('resolution','4K','night_vision',true), NOW(), NOW()),
        (uuid_generate_v4(), 'DEV-MRP-001', 'Meeting Room Panel B102', 'room_panel', room3, '192.168.1.125', 'AA:BB:CC:03:03:03', 'v3.0.2', 'online', NOW()-INTERVAL '1 minute', jsonb_build_object('screen_size',10.1,'os','Android 13'), NOW(), NOW()),
        (uuid_generate_v4(), 'DEV-VWC-001', 'Videowall Controller C301', 'videowall', room4, '192.168.1.150', 'AA:BB:CC:04:04:04', 'v1.2.0', 'error', NOW()-INTERVAL '3 hours', jsonb_build_object('input_count',4,'output_count',4), NOW(), NOW())
    ON CONFLICT (code) DO NOTHING;
END $$;

-- ===== AUDIT LOGS (5 contoh) =====
DO $$
DECLARE
    uid UUID;
BEGIN
    SELECT id INTO uid FROM users WHERE username = 'admin' LIMIT 1;

    INSERT INTO audit_logs (id, user_id, action, module, target_type, target_id, old_value, new_value, ip_address, user_agent, timestamp)
    VALUES
        (uuid_generate_v4(), uid, 'LOGIN', 'auth', 'session', NULL, NULL, NULL, '127.0.0.1'::INET, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120', NOW()-INTERVAL '1 day 2 hours'),
        (uuid_generate_v4(), uid, 'CREATE', 'rooms', 'room', (SELECT id::text FROM rooms WHERE code='R-A101' LIMIT 1), NULL, jsonb_build_object('code','R-A101','name','Ruang Rapat Utama A101'), '127.0.0.1'::INET, 'Mozilla/5.0 Chrome/120', NOW()-INTERVAL '20 hours'),
        (uuid_generate_v4(), uid, 'UPDATE', 'users', 'user', uid::text, jsonb_build_object('position','NULL'), jsonb_build_object('position','System Administrator'), '127.0.0.1'::INET, 'Mozilla/5.0 Chrome/120', NOW()-INTERVAL '10 hours'),
        (uuid_generate_v4(), uid, 'CREATE', 'equipment', 'equipment', (SELECT id::text FROM equipment WHERE code='EQ-PROJ-001' LIMIT 1), NULL, jsonb_build_object('code','EQ-PROJ-001','name','Proyektor Epson 4K'), '127.0.0.1'::INET, 'Mozilla/5.0 Chrome/120', NOW()-INTERVAL '5 hours'),
        (uuid_generate_v4(), uid, 'UPDATE', 'settings', 'system_setting', 'app_title', jsonb_build_object('setting_value','SMR Lama'), jsonb_build_object('setting_value','Smart Meeting Room'), '127.0.0.1'::INET, 'Mozilla/5.0 Chrome/120', NOW()-INTERVAL '1 hour')
    ON CONFLICT DO NOTHING;
END $$;

-- ===== NOTIFICATIONS (4 contoh buat admin) =====
DO $$
DECLARE
    uid UUID;
BEGIN
    SELECT id INTO uid FROM users WHERE username = 'admin' LIMIT 1;

    INSERT INTO notifications (id, user_id, type, title, message, data, is_read, read_at, created_at)
    VALUES
        (uuid_generate_v4(), uid, 'system', 'Selamat Datang di Smart Meeting Room', 'Sistem Smart Meeting Room berhasil diinisiasi. Silakan konfigurasi pengaturan terlebih dahulu.', jsonb_build_object('from','system_init'), false, NULL, NOW()-INTERVAL '2 days'),
        (uuid_generate_v4(), uid, 'maintenance', 'Pemeliharaan Perangkat', 'Proyektor Epson 4K (EQ-PROJ-001) memasuki jadwal maintenance bulanan.', jsonb_build_object('equipment_code','EQ-PROJ-001'), false, NULL, NOW()-INTERVAL '1 day'),
        (uuid_generate_v4(), uid, 'alert', 'Device Error Terdeteksi', 'Videowall Controller C301 (DEV-VWC-001) melaporkan status ERROR. Periksa segera.', jsonb_build_object('device_code','DEV-VWC-001','status','error'), false, NULL, NOW()-INTERVAL '3 hours'),
        (uuid_generate_v4(), uid, 'info', 'Pembaruan Sistem', 'Versi aplikasi akan diperbarui pada malam ini pukul 23.00 - 00.00 WIB.', jsonb_build_object('version','1.0.1'), true, NOW()-INTERVAL '1 hour', NOW()-INTERVAL '6 hours')
    ON CONFLICT DO NOTHING;
END $$;

-- ===== BOOKINGS DEMO (5 contoh) =====
DO $$
DECLARE
    uid UUID;
    r1 UUID; r2 UUID; r3 UUID; r4 UUID;
    today DATE := CURRENT_DATE;
BEGIN
    SELECT id INTO uid FROM users WHERE username = 'admin' LIMIT 1;
    SELECT id INTO r1 FROM rooms WHERE code = 'R-A101' LIMIT 1;
    SELECT id INTO r2 FROM rooms WHERE code = 'R-A203' LIMIT 1;
    SELECT id INTO r3 FROM rooms WHERE code = 'R-B102' LIMIT 1;
    SELECT id INTO r4 FROM rooms WHERE code = 'R-C301' LIMIT 1;

    INSERT INTO bookings (id, user_id, room_id, title, description, date, start_time, end_time, attendees, status, approval_notes, created_by, approved_by, approved_at, created_at, updated_at)
    VALUES
        (uuid_generate_v4(), uid, r1, 'Rapat Koordinasi Proyek Q4', 'Rapat evaluasi capaian target Q4 antar tim', today, '09:00'::TIME, '11:00'::TIME, 20, 'approved', NULL, uid, uid, NOW()-INTERVAL '1 day', NOW()-INTERVAL '3 days', NOW()-INTERVAL '1 day'),
        (uuid_generate_v4(), uid, r2, 'Design Review Sprint 3', 'Review desain UI/UX untuk sprint 3 product team', today, '13:00'::TIME, '14:30'::TIME, 8, 'approved', NULL, uid, uid, NOW()-INTERVAL '18 hours', NOW()-INTERVAL '2 days', NOW()-INTERVAL '18 hours'),
        (uuid_generate_v4(), uid, r3, 'Client Meeting - Konsorsium ABC', 'Presentasi proposal kerjasama dengan perwakilan Konsorsium ABC', today+1, '10:00'::TIME, '12:00'::TIME, 15, 'pending', 'Menunggu approval pimpinan', uid, NULL, NULL, NOW()-INTERVAL '5 hours', NOW()-INTERVAL '5 hours'),
        (uuid_generate_v4(), uid, r4, 'Onboarding & Training Karyawan Baru', 'Sesi training penggunaan sistem untuk 12 karyawan baru', today+2, '08:00'::TIME, '16:00'::TIME, 40, 'approved', 'Full-day training session', uid, uid, NOW()-INTERVAL '2 hours', NOW()-INTERVAL '4 days', NOW()-INTERVAL '2 hours'),
        (uuid_generate_v4(), uid, r1, 'Executive Briefing Bulanan', 'Laporan bulanan CEO kepada dewan direksi', today+5, '14:00'::TIME, '16:00'::TIME, 12, 'draft', NULL, uid, NULL, NULL, NOW()-INTERVAL '30 minutes', NOW()-INTERVAL '30 minutes')
    ON CONFLICT DO NOTHING;
END $$;

-- ===== SYSTEM_SETTINGS (6 default konfigurasi) =====
DO $$
DECLARE
    uid UUID;
BEGIN
    SELECT id INTO uid FROM users WHERE username = 'admin' LIMIT 1;

    INSERT INTO system_settings (id, setting_key, setting_value, value_type, description, group_name, is_public, updated_by, updated_at)
    VALUES
        (uuid_generate_v4(), 'app_title', 'Smart Meeting Room', 'string', 'Nama aplikasi yang ditampilkan di header dan login', 'general', true, uid, NOW()),
        (uuid_generate_v4(), 'app_theme_default', 'light', 'string', 'Default tema aplikasi (light/dark)', 'general', true, uid, NOW()),
        (uuid_generate_v4(), 'booking_max_days_ahead', '30', 'integer', 'Maksimal hari ke depan untuk pemesanan ruangan', 'booking', true, uid, NOW()),
        (uuid_generate_v4(), 'booking_default_status', 'pending', 'string', 'Status default pemesanan baru (draft/pending/approved)', 'booking', false, uid, NOW()),
        (uuid_generate_v4(), 'notification_booking_approve', 'true', 'boolean', 'Kirim notifikasi ketika pemesanan disetujui', 'notifications', false, uid, NOW()),
        (uuid_generate_v4(), 'maintenance_weekly_check_day', 'sunday', 'string', 'Hari penjadwalan pemeriksaan perangkat mingguan', 'maintenance', false, uid, NOW())
    ON CONFLICT (setting_key) DO NOTHING;
END $$;
