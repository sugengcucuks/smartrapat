-- ============================================================
-- MIGRATION 019: Pencarian lintas rapat (Full-Text Search)
-- Kolom generated tsvector + indeks GIN untuk:
--   - meeting_transcript_segments (speaker_name + text)
--   - meeting_notes              (title + summary)
--   - meeting_note_action_items  (task, indeks ekspresi)
-- Dipakai endpoint GET /api/v1/search (routers/search.py).
-- Config 'simple' dipakai agar kata Indonesia tidak distem; cocok
-- untuk pencarian frasa persis ala Ctrl+F lintas rapat.
-- Idempotent: aman dijalankan berulang kali.
-- ============================================================

ALTER TABLE meeting_transcript_segments
    ADD COLUMN IF NOT EXISTS search_vector tsvector
    GENERATED ALWAYS AS (
        to_tsvector('simple', coalesce(speaker_name, '') || ' ' || text)
    ) STORED;

CREATE INDEX IF NOT EXISTS idx_transcript_segments_fts
    ON meeting_transcript_segments USING GIN (search_vector);

ALTER TABLE meeting_notes
    ADD COLUMN IF NOT EXISTS search_vector tsvector
    GENERATED ALWAYS AS (
        to_tsvector('simple', coalesce(title, '') || ' ' || coalesce(summary, ''))
    ) STORED;

CREATE INDEX IF NOT EXISTS idx_meeting_notes_fts
    ON meeting_notes USING GIN (search_vector);

-- Ekspresi immutable sehingga boleh jadi indeks parsial GIN.
CREATE INDEX IF NOT EXISTS idx_mnai_task_fts
    ON meeting_note_action_items USING GIN (to_tsvector('simple', coalesce(task, '')));
