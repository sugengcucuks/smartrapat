-- ============================================================
-- MIGRATION 010: Kiosk Security (ADM-03/ADM-04, DSP-07/DSP-09)
-- - rooms.pairing_key     : kunci pairing kiosk pintu (RM-XXXXXX)
-- - rooms.master_pin_hash : hash bcrypt Master PIN kiosk (nullable)
-- Idempotent: aman dijalankan berulang kali.
-- ============================================================

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'rooms' AND column_name = 'pairing_key'
    ) THEN
        ALTER TABLE rooms ADD COLUMN pairing_key VARCHAR(20);
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'rooms' AND column_name = 'master_pin_hash'
    ) THEN
        ALTER TABLE rooms ADD COLUMN master_pin_hash VARCHAR(255);
    END IF;
END $$;

-- Unique index untuk pairing key (partial agar NULL boleh berulang).
CREATE UNIQUE INDEX IF NOT EXISTS idx_rooms_pairing_key
    ON rooms (pairing_key)
    WHERE pairing_key IS NOT NULL;

-- Backfill pairing key untuk ruangan yang belum punya.
DO $$
DECLARE
    r RECORD;
    new_key TEXT;
    alphabet TEXT := '23456789ABCDEFGHIJKMNOPQRSTUVWXYZ';
    i INT;
BEGIN
    FOR r IN SELECT id FROM rooms WHERE pairing_key IS NULL LOOP
        LOOP
            new_key := 'RM-';
            FOR i IN 1..6 LOOP
                new_key := new_key || substr(alphabet, floor(random() * length(alphabet) + 1)::int, 1);
            END LOOP;
            EXIT WHEN NOT EXISTS (SELECT 1 FROM rooms WHERE pairing_key = new_key);
        END LOOP;
        UPDATE rooms SET pairing_key = new_key WHERE id = r.id;
    END LOOP;
END $$;
