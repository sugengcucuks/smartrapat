# Live Meeting, Mic/Kursi & Notulensi Otomatis — Arsitektur

Dokumen ini adalah kontrak antar modul (backend, device agent, recorder, frontend)
untuk fitur live meeting, pemetaan kursi–mic–peserta, kontrol AV, dan notulensi
otomatis (rekam → transkrip → ringkasan).

---

## 1. Hardware terpasang (hasil survei foto)

| Perangkat | Keterangan | Bisa dikontrol software? |
|---|---|---|
| 2× **Ashley M118** (UHF 8CH wireless microphone receiver) | 16 kanal mic total (A: CH1–8, B: CH1–8). Panel depan: knob volume analog per kanal, IR sync, GROUP. | **Tidak.** Tidak ada port kontrol (RS232/LAN) yang terlihat; semua analog. |
| 16× **Ashley wireless conference gooseneck mic** (UHF) | Unit meja bertenaga baterai dengan tombol bicara (talk). Tiap unit dipasangkan ke 1 kanal receiver. | Tidak (tanpa data). Status bicara hanya bisa dideteksi dari **level audio** kanalnya. |
| **FirstClass BBE FC-A5400** (echo mixing amplifier, karaoke) | 4 input mic 6.35 mm; saat ini MIC1/MIC2 diisi output mix receiver A & B. Ada Bluetooth/USB/DVD in. | Tidak (analog). |
| **Videowall processor** 4×HDMI in (+4 slot), 8×HDMI out, RS232, NET, PV (Digibird DB-VWC2-B-4H8H-PV) | Mengontrol wall LG 55VL5PJ 3×2 (6 output terpakai). | **Ya** — UDP/TCP (NET) atau RS232. Sudah didukung agent. |

### Konsekuensi untuk "siapa bicara" (speaker attribution)

Karena mic Ashley sepenuhnya analog, **satu-satunya cara andal** mengetahui mic mana
yang sedang bicara adalah menangkap **audio per kanal** lalu mengukur level
(VAD/RMS) per kanal. Mic konferensi hanya mengirim suara saat tombol talk aktif,
sehingga kanal yang "hidup" = kursi yang sedang bicara. Ini jauh lebih akurat dan
ringan daripada diarization AI.

Syaratnya: receiver M118 harus punya **output individual per kanal**.

**Status: terkonfirmasi dari foto panel belakang (katalog M118).** Tiap receiver punya
**8× XLR balanced out (satu per kanal)** + 1× jack 6.35 mm (mix out) + konektor BNC
antena. Total 16 XLR dari dua receiver, pas untuk 16 input mic XR18/MR18, jadi
**Mode A bisa dipakai**. Cocokkan dengan unit terpasang saat instalasi (model
harus sama; lihat urutan label CH1..CH8 pada XLR).

Pengkabelan Mode A:
- XLR CH1..CH8 receiver A → input XR18 1..8; receiver B → input 9..16
  (sesuai default aplikasi: `mixer_channel = capture_channel = channel_no`).
- Main L/R XR18 → input LINE/DVD FC-A5400. Kabel mix out 6.35 mm yang sekarang
  masuk MIC1/MIC2 amplifier **dicabut**. Kalau tidak, mute per kursi dari
  aplikasi tidak berpengaruh ke speaker.
- Preamp XR18: gain untuk level line (output receiver umumnya line/mic
  switchable; set receiver ke LINE bila ada), phantom power **OFF**.
- Knob volume di depan M118 dibiarkan tetap (mis. 3/4). Level diatur dari mixer/aplikasi.

**Mode A — Multichannel (direkomendasikan, 16 kanal terpisah)**

```
16 gooseneck ─UHF─► 2× M118 ──16× individual out──► Behringer XR18 / Midas MR18 (digital mixer)
                                                        │  USB 18×18 ──► PC Monitoring (recorder, 16 kanal)
                                                        │  LAN (OSC) ──► device agent (mute/gain/meter per mic)
                                                        └─ Main L/R ──► FC-A5400 (input DVD/LINE) ──► speaker ruangan
```

- XR18 (±Rp 10–12 jt) memberi 16 preamp mic, audio interface USB 18 kanal, dan
  kontrol jaringan OSC (mute, fader, gain, **meter level per kanal**).
- Hasil: mute/unmute per kursi dari aplikasi, indikator "sedang bicara" di denah,
  dan transkrip otomatis berlabel nama peserta.
- Alternatif lebih murah tanpa kontrol mute: audio interface USB 16 kanal (mis.
  Behringer UMC1820 + ADA8200). Deteksi pembicara & transkrip per kursi tetap jalan;
  mute per kursi tidak.

**Mode B — Mix (tanpa hardware tambahan)**

Bila M118 hanya punya output mix: rekam 2 kanal (mix receiver A, mix receiver B)
lewat audio interface USB 2 kanal (atau line-in PC). Transkrip tetap jalan, tapi
pembicara hanya diketahui per grup (A: kursi 1–8, B: kursi 9–16); notulis dapat
mengoreksi nama pembicara per segmen di UI.

**Mode C — Browser**: operator merekam dari laptop/iPad (mikrofon perangkat) di
halaman Live Meeting. Untuk ruangan tanpa perangkat rekam.

Semua mode memakai pipeline software yang sama; hanya sumber audio yang berbeda.

---

## 2. Model data (migration 015)

```
rooms 1─* audio_channels (channel_no, label, receiver_label, mixer_channel, capture_channel, device_id)
rooms 1─* room_seats (seat_no, label, seat_type, pos_x, pos_y, rotation, audio_channel_id → audio_channels, unik)
bookings 1─* booking_seat_assignments (seat_id, participant_id → booking_participants, display_name, role_label, assigned_via)
bookings: meeting_status (scheduled|live|ended), actual_start_at, actual_end_at, extended_minutes
bookings 1─* meeting_recordings (source multichannel|mix|browser|upload, status, channel_count)
meeting_notes 1─* meeting_transcript_segments (start_ms, end_ms, audio_channel_no, seat_id, participant_id, speaker_name, text, confidence)
meeting_notes: status (draft|final), summary_json, finalized_at, finalized_by
```

Rantai atribusi pembicara:
`kanal audio (capture_channel) → audio_channels.channel_no → room_seats (audio_channel_id) → booking_seat_assignments (booking) → participant → nama`.

`start_ms` segmen dihitung relatif terhadap `meeting_recordings.started_at`
(dikurangi durasi jeda).

---

## 3. MQTT (broker Mosquitto, auth + ACL wajib)

Prefix default `smr` (env `MQTT_TOPIC_PREFIX` untuk device = `smr/devices`).

| Topic | Arah | Payload (JSON) |
|---|---|---|
| `smr/devices/{device_id}/command/{action}` | backend → agent | `{"cmd_id": "<uuid>", "device_code": "...", "action": "...", ...params, "ts": "<iso>"}` |
| `smr/devices/{device_id}/ack` | agent → backend | `{"cmd_id", "ok": bool, "error": str|null, "response": str|null, "ts"}` |
| `smr/devices/{device_id}/state` | agent → backend (retained) | `{"online": bool, "power": "on"|"off"|null, "source": str|null, "layout": str|null, "ts"}` |
| `smr/agent/{agent_id}/status` | agent → backend (retained, LWT = offline) | `{"online": bool, "version", "devices": [...], "ts"}` |
| `smr/audio/{room_code}/levels` | agent/recorder → backend | `{"levels": {"1": -42.1, "2": -60.0, ...} (dBFS per channel_no), "ts"}` — maks 5 Hz |
| `smr/audio/{room_code}/active` | agent/recorder → backend | `{"active": [3], "ts"}` — kanal yang sedang bicara (level > ambang, hold 800 ms) |
| `smr/audio/{room_code}/mixer` | agent → backend (retained) | `{"channels": {"3": {"muted": false, "fader": 0.75, "gain": 32.0}}, "main": {"muted": false, "fader": 0.8}, "ts"}` |

Perintah audio mixer (action pada device mixer): `mute` `{channel_no}`, `unmute`
`{channel_no}`, `mute_all`, `unmute_all`, `set_fader` `{channel_no|"main", value 0..1}`,
`set_gain` `{channel_no, db}`.

Catatan implementasi (kontrol AV):
- Backend menyertakan `mixer_channel` (dari `audio_channels`) pada perintah mixer;
  `mute`/`unmute`/`set_fader` menerima `{"target": "main"}` untuk main L/R;
  `mute_all`/`unmute_all` membawa `mixer_channels: [...]`.
- Payload `levels`/`active`/`mixer` boleh membawa `"key": "mixer_channel"` (agent X-Air):
  nomor = kanal mixer, backend memetakan ke `channel_no`. Tanpa `key` = `channel_no`.
- Ack juga memuat `action` & `device_code`; topic ack/state memakai UUID perangkat bila
  diisi di `devices.yaml`, selain itu `device_code` (backend menerima keduanya).

---

## 4. REST API (prefix `/api/v1`)

### Ruangan: kanal mic & denah (izin `rooms.write` untuk tulis, `rooms.view` baca)
- `GET/PUT /rooms/{room_id}/audio-channels` — daftar & simpan batch kanal mic.
- `GET/PUT /rooms/{room_id}/seats` — daftar & simpan batch denah kursi (termasuk `audio_channel_id`).
- `POST /rooms/{room_id}/seats/generate` — buat denah awal otomatis (`{"layout": "u_shape"|"boardroom"|"classroom"|"circle", "count": 16, "chair_count": 1, "link_channels": true}`); panduan: `docs/modules/19_LIVE_MEETING.md`.

### Live meeting (pemilik booking atau `bookings.approve`)
- `GET /bookings/{id}/live` — snapshot: booking, meeting_status, waktu efektif, peserta + kehadiran, kursi + penugasan, kanal mic, rekaman aktif.
- `POST /bookings/{id}/meeting/start` | `/meeting/end` | `/meeting/extend {minutes}` (cek bentrok jadwal).
- `GET/PUT /bookings/{id}/seat-assignments` — batch; `POST /bookings/{id}/seat-assignments/auto` — isi otomatis dari peserta hadir.
- Presensi `/presensi/scan`: bila peserta belum punya kursi, sistem menugaskan kursi kosong (prioritas `delegate`) dan mengembalikan `seat: {seat_no, label}` pada respons & event `attendance_changed`.

### Kontrol AV per ruangan
- `POST /rooms/{room_id}/av/videowall/{power-on|power-off}`, `POST /rooms/{room_id}/av/videowall/layout {preset}`, `POST /rooms/{room_id}/av/videowall/source {source, window?}`
- `POST /rooms/{room_id}/av/audio/mic/{channel_no}/{mute|unmute}`, `POST /rooms/{room_id}/av/audio/mute-all|unmute-all`, `POST /rooms/{room_id}/av/audio/fader {target, value}`
- `GET /rooms/{room_id}/av/state` — state perangkat & mixer terakhir (dari MQTT state/ack).
- Respons perintah: `{"cmd_id", "status": "sent"|"acked"|"failed"|"timeout", "error"}` — backend menunggu ack maks 3 detik.
  Ditambah `results: [...]` per perangkat (power videowall = fan-out ke semua panel + controller).
  HTTP 200 untuk acked/failed/timeout; 503 `MQTT_NOT_CONFIGURED|MQTT_NOT_CONNECTED`; 409 `MIXER_NOT_INSTALLED`.
- Tambahan: `POST /rooms/{room_id}/av/audio/gain {channel_no, db}`, `GET /rooms/{room_id}/av/capabilities`
  (preset/sumber videowall dari `devices.config` controller, mode audio `xair|none`, kanal mic).
- `GET/PUT /rooms/{room_id}/audio-channels` diimplementasikan di `av_control.py` (bukan rooms.py).

### Notulensi (`notes.view` baca, `notes.write` tulis)
- `POST /notes/recording/{booking_id}/start {source}` | `/pause` | `/resume` | `/stop`; `GET /notes/recording/{booking_id}/status`.
- `POST /notes/recording/{booking_id}/segments` — **dipanggil recorder** (header `X-Agent-Key`), multipart: `audio` (WAV/FLAC 16 kHz mono), `channel_no`, `start_ms`, `end_ms`, `recording_id`. Backend menaruh ke antrean STT.
- `POST /notes/recording/{booking_id}/chunks` — dipanggil browser (mode C), JWT, multipart `audio` (webm/ogg) + `start_ms`.
- `POST /notes/{note_id}/transcribe-audio` — unggah file rekaman penuh (mode upload).
- `GET /notes/{note_id}/segments`, `PATCH /notes/{note_id}/segments/{segment_id}` (koreksi teks/pembicara), `DELETE ...`.
- `POST /notes/{note_id}/summarize` — ringkasan LLM (Ollama) → `summary`, `summary_json`, `decisions`, action items.
- `POST /notes/{note_id}/finalize`; `GET /notes/{note_id}/export/{pdf|docx|txt}`.

---

## 5. WebSocket

`/api/v1/ws/rooms/{room_id}/live?token=<access_token>` (JWT; izin baca booking/ruangan).
Event dari server:

| event | data |
|---|---|
| `snapshot` | sama dengan `GET /bookings/{id}/live` untuk rapat berjalan |
| `meeting_status` | `{booking_id, meeting_status, end_time_effective}` |
| `attendance_changed` | `{booking_id, participant_id, attended, seat?}` |
| `seats_changed` | `{booking_id, assignments: [...]}` |
| `audio_levels` | `{levels: {channel_no: dBFS}}` (maks 5 Hz) |
| `active_speakers` | `{channels: [3], seats: [seat_id], participants: [participant_id]}` |
| `mixer_state` | payload `smr/audio/{room}/mixer` |
| `device_state` | `{device_id, state}` |
| `transcript_segment` | segmen baru/terkoreksi (bentuk sama dengan `GET /notes/{id}/segments` item) |
| `recording_status` | `{booking_id, recording_id, status}` |

---

## 6. Komponen & kepemilikan kode

| Komponen | Lokasi |
|---|---|
| MQTT client + subscriber ack/state/audio, hub WS live | `src/api/utils/mqtt_client.py`, `src/api/services/live_hub.py` |
| Kontrol AV per ruangan, kanal mic | `src/api/routers/av_control.py`, `src/api/routers/rooms.py` |
| Denah kursi, live meeting, penugasan | `src/api/routers/live_meeting.py` |
| Pipeline notulensi (antrean STT, faster-whisper, Ollama) | `src/api/services/transcription.py`, `src/api/services/summarizer.py`, `src/api/routers/notes.py` |
| Device agent (videowall, TV LG, mixer X-Air OSC) | `agent/device_agent.py`, `agent/drivers/*` |
| Recorder multikanal (PC Monitoring) | `agent/recorder.py` |
| UI | `src/web/pages/bookings/MeetingLivePage.tsx`, `src/web/components/live/*`, `src/web/pages/rooms/RoomLayoutPage.tsx` |
