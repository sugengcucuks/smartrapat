# Module 16: Door Display

## Overview

Modul Door Display menangani Antarmuka door display di luar ruangan untuk menampilkan status ruangan, jadwal, dan quick booking.

## Sub-Modules

```
16_DOOR_DISPLAY
├── 16_01_STATUS        # Room status display
├── 16_02_BOOKING      # Quick booking from door
└── 16_03_CONTENT      # Welcome message, idle content
```

---

## 16_01_STATUS - Status Display

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/door-display/{room_id}/status` | Get room status | Door Display |
| GET | `/api/v1/door-display/{room_id}/current-meeting` | Get current meeting | Door Display |
| GET | `/api/v1/door-display/{room_id}/next-meeting` | Get next meeting | Door Display |

### Door Display UI States

```
┌─────────────────────────────────────────────────────────┐
│                                                         │
│  ┌───────────────────────────────────────────────────┐ │
│  │                                                   │ │
│  │              RUANG RAPAT 1                       │ │
│  │              ─────────────                       │ │
│  │                                                   │ │
│  │                                                   │ │
│  │                                                   │ │
│  │              ● TERSEDIA                           │ │
│  │                                                   │ │
│  │                                                   │ │
│  │  ──────────────────────────────────────────────  │ │
│  │                                                   │ │
│  │  NEXT: 14:00                                     │ │
│  │  "Rapat板门"                                     │ │
│  │                                                   │ │
│  │  [Booking >]                                     │ │
│  │                                                   │ │
│  └───────────────────────────────────────────────────┘ │
│                                                         │
│  🟢 HIJAU = Available    🔴 MERAH = Occupied          │
│                                                         │
└─────────────────────────────────────────────────────────┘


OCCUPIED STATE:
┌─────────────────────────────────────────────────────────┐
│                                                         │
│  ┌───────────────────────────────────────────────────┐ │
│  │                                                   │ │
│  │              RUANG RAPAT 1                       │ │
│  │              ─────────────                       │ │
│  │                                                   │ │
│  │                                                   │ │
│  │              ● SEDANG DIGUNAKAN                   │ │
│  │                                                   │ │
│  │  ──────────────────────────────────────────────  │ │
│  │                                                   │ │
│  │  CURRENT: 10:00 - 12:00                         │ │
│  │  "Rapat Evaluasi Kinerja"                       │ │
│  │                                                   │ │
│  │  NEXT: 13:00                                    │ │
│  │  "Interview Kandidat"                            │ │
│  │                                                   │ │
│  └───────────────────────────────────────────────────┘ │
│                                                         │
│  🟢 HIJAU = Available    🔴 MERAH = Occupied          │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Request/Response Examples

**GET /api/v1/door-display/{room_id}/status**

```json
{
  "success": true,
  "data": {
    "room": {
      "id": "room-xxx",
      "name": "Ruang Rapat 1",
      "code": "RR01"
    },
    "status": "AVAILABLE",
    "status_display": "Tersedia",
    "status_color": "green",
    "current_meeting": null,
    "next_meeting": {
      "id": "booking-xxx",
      "title": "Rapat板门",
      "start_time": "14:00",
      "organizer": "Budi Santoso"
    },
    "available_slots_today": 5,
    "last_updated": "2026-09-18T10:30:00Z"
  }
}
```

**GET /api/v1/door-display/{room_id}/current-meeting**

```json
{
  "success": true,
  "data": {
    "booking_id": "booking-001",
    "title": "Rapat Evaluasi Kinerja",
    "description": "Evaluasi bulanan divisi",
    "start_time": "10:00",
    "end_time": "12:00",
    "organizer": {
      "name": "Budi Santoso"
    },
    "participants": [
      { "name": "Budi Santoso" },
      { "name": "Ani Wijaya" },
      { "name": "Dewi Lestari" }
    ],
    "progress_percent": 45,
    "time_remaining_minutes": 65
  }
}
```

---

## 16_02_BOOKING - Quick Booking

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| POST | `/api/v1/door-display/{room_id}/book` | Quick book | Door Display |
| POST | `/api/v1/door-display/{room_id}/cancel/{booking_id}` | Cancel booking | Door Display |
| POST | `/api/v1/door-display/{room_id}/extend/{booking_id}` | Extend booking | Door Display |
| GET | `/api/v1/door-display/{room_id}/available-slots` | Get available slots | Door Display |

### Request/Response Examples

**GET /api/v1/door-display/{room_id}/available-slots**

```json
{
  "success": true,
  "data": {
    "room_id": "room-xxx",
    "date": "2026-09-18",
    "slots": [
      { "start": "08:00", "end": "09:00", "available": true },
      { "start": "09:00", "end": "10:00", "available": true },
      { "start": "10:00", "end": "11:00", "available": false, "booking_id": "booking-001" },
      { "start": "11:00", "end": "12:00", "available": false, "booking_id": "booking-001" },
      { "start": "12:00", "end": "13:00", "available": true },
      { "start": "13:00", "end": "14:00", "available": false, "booking_id": "booking-002" },
      { "start": "14:00", "end": "15:00", "available": true },
      { "start": "15:00", "end": "16:00", "available": true }
    ]
  }
}
```

**POST /api/v1/door-display/{room_id}/book**

```json
// Request
{
  "title": "Meeting Cepat",
  "start_time": "15:00",
  "duration_minutes": 30,
  "booked_by": "Anonymous"  // or user_id if authenticated
}

// Response
{
  "success": true,
  "data": {
    "booking_id": "booking-new",
    "title": "Meeting Cepat",
    "room": {
      "id": "room-xxx",
      "name": "Ruang Rapat 1"
    },
    "start_time": "15:00",
    "end_time": "15:30",
    "status": "SCHEDULED",
    "qr_code": "/api/v1/bookings/booking-new/qr"
  }
}
```

**POST /api/v1/door-display/{room_id}/extend/{booking_id}**

```json
// Request
{
  "extend_minutes": 15
}

// Response
{
  "success": true,
  "data": {
    "booking_id": "booking-001",
    "original_end_time": "12:00",
    "new_end_time": "12:15",
    "conflict_check": {
      "has_conflict": false,
      "conflicting_booking": null
    }
  }
}
```

---

## 16_03_CONTENT - Display Content

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/door-display/{room_id}/welcome-message` | Get welcome message | Door Display |
| PUT | `/api/v1/door-display/{room_id}/welcome-message` | Set welcome message | Admin |
| GET | `/api/v1/door-display/{room_id}/idle-content` | Get idle content | Door Display |
| PUT | `/api/v1/door-display/{room_id}/idle-content` | Set idle content | Admin |

### Request/Response Examples

**GET /api/v1/door-display/{room_id}/welcome-message**

```json
{
  "success": true,
  "data": {
    "room_id": "room-xxx",
    "title": "Selamat Datang di Ruang Rapat 1",
    "subtitle": "Gedung A, Lantai 3",
    "custom_message": "Untuk booking, silakan gunakan aplikasi atau hubungi admin",
    "show_weather": true,
    "show_clock": true
  }
}
```

**GET /api/v1/door-display/{room_id}/idle-content**

```json
{
  "success": true,
  "data": {
    "room_id": "room-xxx",
    "type": "slideshow",
    "content": [
      {
        "type": "image",
        "url": "/uploads/slides/slide1.jpg",
        "duration_seconds": 10
      },
      {
        "type": "text",
        "content": "Ruang Rapat 1\nKapasitas: 30 orang\nFasilitas: Video Wall, Audio Conference, Notulensi",
        "duration_seconds": 15
      },
      {
        "type": "image",
        "url": "/uploads/slides/slide2.jpg",
        "duration_seconds": 10
      }
    ],
    "schedule": [
      { "start": "09:00", "end": "18:00", "days": ["mon", "tue", "wed", "thu", "fri"] }
    ]
  }
}
```

---

## Door Display - LED Indicator

The door display supports hardware LED indicators:

| Status | LED Color | State |
|--------|-----------|-------|
| `AVAILABLE` | Green | Solid |
| `OCCUPIED` | Red | Solid |
| `BOOKING_SOON` | Yellow/Orange | Blinking |
| `MAINTENANCE` | Blue | Blinking |

---

## Data Models

```typescript
interface DoorDisplayStatus {
  room: RoomInfo;
  status: RoomStatus;
  status_display: string;
  status_color: string;
  current_meeting: MeetingInfo | null;
  next_meeting: NextMeetingInfo | null;
  available_slots_today: number;
  last_updated: DateTime;
}

interface RoomInfo {
  id: string;
  name: string;
  code: string;
}

interface MeetingInfo {
  booking_id: string;
  title: string;
  description?: string;
  start_time: string;
  end_time: string;
  organizer: { name: string };
  participants: { name: string }[];
  progress_percent: number;
  time_remaining_minutes: number;
}

interface NextMeetingInfo {
  id: string;
  title: string;
  start_time: string;
  organizer: string;
}

interface TimeSlot {
  start: string;
  end: string;
  available: boolean;
  booking_id?: string;
}

interface WelcomeMessage {
  room_id: string;
  title: string;
  subtitle?: string;
  custom_message?: string;
  show_weather: boolean;
  show_clock: boolean;
}

interface IdleContent {
  room_id: string;
  type: 'slideshow' | 'static' | 'video';
  content: ContentItem[];
  schedule: Schedule[];
}

interface ContentItem {
  type: 'image' | 'text' | 'video';
  url?: string;
  content?: string;
  duration_seconds: number;
}

interface Schedule {
  start: string;
  end: string;
  days: string[];
}
```

---

## Polling vs WebSocket

Door display dapat mengambil data dengan dua cara:

### Option 1: Polling (Recommended for simplicity)
- Poll `/api/v1/door-display/{room_id}/status` setiap 5 detik
- Tidak perlu WebSocket infrastructure

### Option 2: WebSocket (More efficient)
```javascript
ws://server:8000/ws/door-display/{room_id}

{
  "event": "status_changed",
  "data": {
    "status": "OCCUPIED",
    "current_meeting": { ... }
  }
}
```

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `ROOM_NOT_FOUND` | 404 | Ruang tidak ditemukan |
| `BOOKING_NOT_FOUND` | 404 | Booking tidak ditemukan |
| `SLOT_NOT_AVAILABLE` | 400 | Slot waktu tidak tersedia |
| `BOOKING_CONFLICT` | 409 | Booking bentrok |
| `UNAUTHORIZED_BOOKING` | 401 | Harus login untuk booking |
