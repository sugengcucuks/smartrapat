# Module 12: Calendar

## Overview

Modul Calendar menyediakan berbagai tampilan kalendar dan navigasi jadwal untuk semua ruang rapat.

## Sub-Modules

```
12_CALENDAR
├── 12_01_VIEWS        # Daily, weekly, monthly, agenda views
├── 12_02_DISPLAY      # Room schedule display
└── 12_03_NAVIGATION  # Date navigation
```

---

## 12_01_VIEWS - Calendar Views

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/calendar/daily` | Daily view | All |
| GET | `/api/v1/calendar/weekly` | Weekly view | All |
| GET | `/api/v1/calendar/monthly` | Monthly view | All |
| GET | `/api/v1/calendar/agenda` | Agenda view | All |

### Query Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `date` | string | Reference date (ISO format) |
| `room_id` | string | Filter by room (optional) |
| `user_id` | string | Filter by organizer (optional) |

### Request/Response Examples

**GET /api/v1/calendar/weekly**

```json
{
  "success": true,
  "data": {
    "week_start": "2026-09-14",
    "week_end": "2026-09-20",
    "rooms": [
      {
        "room_id": "room-xxx",
        "room_name": "Ruang Rapat 1",
        "bookings": [
          {
            "date": "2026-09-14",
            "items": [
              {
                "id": "booking-001",
                "title": "Rapat板门",
                "start_time": "09:00",
                "end_time": "11:00",
                "status": "completed"
              },
              {
                "id": "booking-002",
                "title": "Interview Kandidat",
                "start_time": "13:00",
                "end_time": "14:00",
                "status": "completed"
              }
            ]
          },
          {
            "date": "2026-09-15",
            "items": [
              {
                "id": "booking-003",
                "title": "Evaluasi Bulanan",
                "start_time": "09:00",
                "end_time": "12:00",
                "status": "scheduled"
              }
            ]
          }
        ]
      }
    ]
  }
}
```

**GET /api/v1/calendar/monthly**

```json
{
  "success": true,
  "data": {
    "year": 2026,
    "month": 9,
    "weeks": [
      {
        "week_number": 37,
        "days": [
          {
            "date": "2026-09-14",
            "day": 14,
            "is_today": false,
            "bookings_count": 2,
            "rooms": [
              { "room_id": "room-xxx", "bookings": 1 },
              { "room_id": "room-yyy", "bookings": 1 }
            ]
          },
          {
            "date": "2026-09-15",
            "day": 15,
            "is_today": false,
            "bookings_count": 3,
            "rooms": [
              { "room_id": "room-xxx", "bookings": 2 },
              { "room_id": "room-yyy", "bookings": 1 }
            ]
          }
        ]
      }
    ]
  }
}
```

**GET /api/v1/calendar/agenda**

```json
{
  "success": true,
  "data": {
    "date_from": "2026-09-18",
    "date_to": "2026-09-24",
    "items": [
      {
        "id": "booking-001",
        "date": "2026-09-18",
        "start_time": "09:00",
        "end_time": "11:00",
        "title": "Rapat板门",
        "room": { "id": "room-xxx", "name": "Ruang Rapat 1" },
        "organizer": { "id": "user-xxx", "name": "Budi Santoso" },
        "status": "scheduled"
      },
      {
        "id": "booking-002",
        "date": "2026-09-18",
        "start_time": "14:00",
        "end_time": "15:00",
        "title": "Interview",
        "room": { "id": "room-yyy", "name": "Ruang Rapat 2" },
        "organizer": { "id": "user-yyy", "name": "Ani Wijaya" },
        "status": "scheduled"
      },
      {
        "id": "booking-003",
        "date": "2026-09-19",
        "start_time": "10:00",
        "end_time": "12:00",
        "title": "Training",
        "room": { "id": "room-xxx", "name": "Ruang Rapat 1" },
        "organizer": { "id": "user-xxx", "name": "Budi Santoso" },
        "status": "scheduled"
      }
    ],
    "meta": {
      "total_items": 12,
      "date_from": "2026-09-18",
      "date_to": "2026-09-24"
    }
  }
}
```

---

## 12_02_DISPLAY - Room Schedule Display

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/calendar/room/{id}` | Room calendar | All |
| GET | `/api/v1/calendar/user/{id}` | User's calendar | All |
| GET | `/api/v1/calendar/date/{date}` | Specific date | All |
| GET | `/api/v1/calendar/range` | Date range | All |
| POST | `/api/v1/calendar/sync` | Sync external calendar | Admin |

### Request/Response Examples

**GET /api/v1/calendar/room/{id}**

```json
{
  "success": true,
  "data": {
    "room": {
      "id": "room-xxx",
      "name": "Ruang Rapat 1",
      "code": "RR01"
    },
    "date": "2026-09-18",
    "schedule": [
      {
        "id": "booking-001",
        "title": "Rapat板门",
        "start_time": "09:00",
        "end_time": "11:00",
        "organizer": "Budi Santoso",
        "status": "completed"
      },
      {
        "id": "booking-002",
        "title": "Interview Kandidat",
        "start_time": "13:00",
        "end_time": "14:00",
        "organizer": "Ani Wijaya",
        "status": "ongoing"
      },
      {
        "id": "booking-003",
        "title": "Evaluasi Bulanan",
        "start_time": "14:30",
        "end_time": "16:30",
        "organizer": "Dewi Lestari",
        "status": "scheduled"
      }
    ],
    "availability": [
      { "start": "08:00", "end": "09:00", "available": true },
      { "start": "11:00", "end": "13:00", "available": true },
      { "start": "14:00", "end": "14:30", "available": false },
      { "start": "16:30", "end": "18:00", "available": true }
    ]
  }
}
```

---

## 12_03_NAVIGATION - Date Navigation

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/calendar/navigate` | Navigate to date | All |
| GET | `/api/v1/calendar/today` | Get today's bookings | All |

### Query Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `direction` | string | 'prev' or 'next' |
| `amount` | int | Number of units |
| `unit` | string | 'day', 'week', 'month' |
| `current_date` | string | Current reference date |

### Request/Response Examples

**GET /api/v1/calendar/navigate?direction=next&amount=1&unit=week&current_date=2026-09-18**

```json
{
  "success": true,
  "data": {
    "direction": "next",
    "unit": "week",
    "previous_date": "2026-09-14",
    "new_date": "2026-09-21",
    "week_start": "2026-09-21",
    "week_end": "2026-09-27"
  }
}
```

**GET /api/v1/calendar/today**

```json
{
  "success": true,
  "data": {
    "date": "2026-09-18",
    "is_today": true,
    "bookings_today": [
      {
        "id": "booking-001",
        "title": "Rapat板门",
        "room": { "id": "room-xxx", "name": "Ruang Rapat 1" },
        "start_time": "09:00",
        "end_time": "11:00",
        "status": "completed"
      }
    ],
    "upcoming_count": 2,
    "next_meeting": {
      "id": "booking-002",
      "title": "Interview Kandidat",
      "room": { "id": "room-yyy", "name": "Ruang Rapat 2" },
      "start_time": "13:00",
      "starts_in_minutes": 120
    }
  }
}
```

---

## Data Models

```typescript
interface CalendarView {
  type: 'daily' | 'weekly' | 'monthly' | 'agenda';
  date_from: Date;
  date_to: Date;
  rooms: RoomSchedule[];
}

interface RoomSchedule {
  room_id: string;
  room_name: string;
  bookings: DailyBooking[];
}

interface DailyBooking {
  id: string;
  date: string;
  title: string;
  start_time: string;
  end_time: string;
  status: BookingStatus;
  organizer?: UserSummary;
}

interface BookingStatus = 
  | 'scheduled'
  | 'ongoing'
  | 'completed'
  | 'cancelled';

interface TimeSlot {
  start: string;
  end: string;
  available: boolean;
}
```

---

## Calendar View States

### Daily View
```
┌─────────────────────────────────────────────────────┐
│       📅 18 September 2026 (Kamis)                  │
├─────────────────────────────────────────────────────┤
│                                                     │
│  08:00 │                                          │
│  09:00 │ ████████████████  Rapat板门              │
│        │  Ruang Rapat 1                           │
│  10:00 │                                          │
│  11:00 │                                          │
│  12:00 │                                          │
│  13:00 │ ██████████  Interview Kandidat           │
│        │  Ruang Rapat 2                           │
│  14:00 │                                          │
│  15:00 │                                          │
│                                                     │
└─────────────────────────────────────────────────────┘
```

### Weekly View
```
┌─────────────────────────────────────────────────────┐
│       ◀  Minggu, 14 Sep 2026  ▶                    │
├─────────────────────────────────────────────────────┤
│       │ Sen 14 │ Sel 15 │ Rab 16 │ Kam 17 │ ...  │
├───────┼────────┼────────┼────────┼────────┼──────┤
│ R.R.1 │ ███    │        │ ███    │        │      │
│       │ 09-11  │        │ 10-12  │        │      │
├───────┼────────┼────────┼────────┼────────┼──────┤
│ R.R.2 │        │ ███    │        │ ███    │      │
│       │        │ 14-15  │        │ 09-10  │      │
└───────┴────────┴────────┴────────┴────────┴──────┘
```

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `INVALID_DATE` | 400 | Format tanggal tidak valid |
| `INVALID_VIEW` | 400 | Tipe view tidak valid |
| `ROOM_NOT_FOUND` | 404 | Ruang tidak ditemukan |
| `USER_NOT_FOUND` | 404 | User tidak ditemukan |
