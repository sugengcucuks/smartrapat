# Module 13: Notifications

## Overview

Modul Notifications menangani pengiriman dan management semua jenis notifikasi kepada user.

## Sub-Modules

```
13_NOTIFICATIONS
├── 13_01_MANAGEMENT    # CRUD notifications
└── 13_02_PREFERENCES  # User notification preferences
```

---

## 13_01_MANAGEMENT - Notification Management

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/notifications` | List notifications | All |
| GET | `/api/v1/notifications/{id}` | Get notification | All |
| PUT | `/api/v1/notifications/{id}/read` | Mark as read | All |
| PUT | `/api/v1/notifications/read-all` | Mark all as read | All |
| DELETE | `/api/v1/notifications/{id}` | Delete notification | All |

### Notification Types

| Type | Description | Channel |
|------|-------------|---------|
| `booking_created` | Booking berhasil dibuat | In-app, Email |
| `booking_updated` | Booking diupdate | In-app, Email |
| `booking_cancelled` | Booking dibatalkan | In-app, Email |
| `booking_reminder` | Reminder 15 menit sebelum | In-app, Push |
| `booking_conflict` | Conflict dengan booking lain | In-app |
| `booking_approved` | Booking disetujui | In-app, Email |
| `booking_rejected` | Booking ditolak | In-app, Email |
| `meeting_started` | Meeting akan dimulai | In-app, Push |
| `meeting_ended` | Meeting selesai | In-app |
| `recording_started` | Notulensi dimulai | In-app |
| `recording_completed` | Notulensi selesai | In-app |
| `summary_ready` | Summary AI tersedia | In-app |
| `system_alert` | Alert sistem | In-app, Email |

### Request/Response Examples

**GET /api/v1/notifications**

**Query Parameters:**
- `is_read` (boolean): Filter by read status
- `type` (string): Filter by notification type
- `page` (int): Page number
- `limit` (int): Items per page

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": "notif-001",
      "type": "booking_reminder",
      "title": "Rapat板门 akan dimulai",
      "message": "Rapat板门 akan dimulai dalam 15 menit di Ruang Rapat 1",
      "is_read": false,
      "data": {
        "booking_id": "booking-xxx",
        "room_id": "room-xxx",
        "room_name": "Ruang Rapat 1",
        "start_time": "2026-09-18T10:00:00Z"
      },
      "created_at": "2026-09-18T09:45:00Z"
    },
    {
      "id": "notif-002",
      "type": "booking_created",
      "title": "Booking berhasil dibuat",
      "message": "Booking 'Evaluasi Bulanan' telah berhasil dibuat untuk 20 September 2026",
      "is_read": true,
      "data": {
        "booking_id": "booking-yyy",
        "title": "Evaluasi Bulanan"
      },
      "created_at": "2026-09-18T08:00:00Z"
    },
    {
      "id": "notif-003",
      "type": "summary_ready",
      "title": "Notulensi siap di-export",
      "message": "Summary rapat 'Rapat板门' telah tersedia",
      "is_read": false,
      "data": {
        "meeting_id": "meeting-xxx",
        "booking_id": "booking-xxx"
      },
      "created_at": "2026-09-18T07:30:00Z"
    }
  ],
  "meta": {
    "page": 1,
    "limit": 20,
    "total": 5,
    "total_unread": 2
  }
}
```

**PUT /api/v1/notifications/{id}/read**

```json
// Response
{
  "success": true,
  "data": {
    "id": "notif-001",
    "is_read": true,
    "read_at": "2026-09-18T10:00:00Z"
  }
}
```

### Notification Templates

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| POST | `/api/v1/notifications/templates` | Create template | Admin |
| GET | `/api/v1/notifications/templates` | List templates | Admin |
| PUT | `/api/v1/notifications/templates/{id}` | Update template | Admin |

**POST /api/v1/notifications/templates**

```json
{
  "type": "booking_reminder",
  "title": "{{room_name}} - {{meeting_title}}",
  "message": "{{meeting_title}} akan dimulai dalam {{minutes}} menit di {{room_name}}",
  "channels": ["in_app", "push", "email"],
  "variables": ["room_name", "meeting_title", "minutes", "start_time"]
}
```

---

## 13_02_PREFERENCES - User Preferences

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/notifications/preferences` | Get preferences | All |
| PUT | `/api/v1/notifications/preferences` | Update preferences | All |

### Request/Response Examples

**GET /api/v1/notifications/preferences**

```json
{
  "success": true,
  "data": {
    "user_id": "user-xxx",
    "channels": {
      "in_app": true,
      "email": true,
      "push": true,
      "sms": false
    },
    "types": {
      "booking_created": { "enabled": true, "channels": ["in_app", "email"] },
      "booking_updated": { "enabled": true, "channels": ["in_app"] },
      "booking_cancelled": { "enabled": true, "channels": ["in_app", "email"] },
      "booking_reminder": { "enabled": true, "channels": ["in_app", "push"], "timing_minutes": [15, 5] },
      "booking_conflict": { "enabled": true, "channels": ["in_app", "email"] },
      "booking_approved": { "enabled": true, "channels": ["in_app", "email"] },
      "booking_rejected": { "enabled": true, "channels": ["in_app", "email"] },
      "meeting_started": { "enabled": true, "channels": ["in_app"] },
      "meeting_ended": { "enabled": false },
      "recording_started": { "enabled": true, "channels": ["in_app"] },
      "recording_completed": { "enabled": true, "channels": ["in_app"] },
      "summary_ready": { "enabled": true, "channels": ["in_app", "email"] },
      "system_alert": { "enabled": true, "channels": ["in_app", "email"] }
    },
    "quiet_hours": {
      "enabled": true,
      "start": "22:00",
      "end": "07:00",
      "timezone": "Asia/Jakarta"
    },
    "do_not_disturb": false
  }
}
```

**PUT /api/v1/notifications/preferences**

```json
{
  "channels": {
    "in_app": true,
    "email": true,
    "push": true,
    "sms": false
  },
  "types": {
    "booking_reminder": {
      "enabled": true,
      "channels": ["in_app", "push", "email"],
      "timing_minutes": [30, 15, 5]
    }
  },
  "quiet_hours": {
    "enabled": true,
    "start": "23:00",
    "end": "06:00"
  }
}
```

---

## Data Models

```typescript
interface Notification {
  id: string;
  user_id: string;
  type: NotificationType;
  title: string;
  message: string;
  is_read: boolean;
  read_at?: DateTime;
  data?: Record<string, any>;
  created_at: DateTime;
}

type NotificationType = 
  | 'booking_created'
  | 'booking_updated'
  | 'booking_cancelled'
  | 'booking_reminder'
  | 'booking_conflict'
  | 'booking_approved'
  | 'booking_rejected'
  | 'meeting_started'
  | 'meeting_ended'
  | 'recording_started'
  | 'recording_completed'
  | 'summary_ready'
  | 'system_alert';

interface NotificationPreferences {
  user_id: string;
  channels: NotificationChannels;
  types: Record<NotificationType, TypePreference>;
  quiet_hours?: QuietHours;
  do_not_disturb: boolean;
}

interface NotificationChannels {
  in_app: boolean;
  email: boolean;
  push: boolean;
  sms: boolean;
}

interface TypePreference {
  enabled: boolean;
  channels?: NotificationChannels;
  timing_minutes?: number[];
}

interface QuietHours {
  enabled: boolean;
  start: string;      // HH:mm
  end: string;        // HH:mm
  timezone: string;
}
```

---

## Real-time Notification (WebSocket)

```javascript
// Subscribe to notifications
ws://server:8000/ws/notifications

// Receive notification
{
  "event": "new_notification",
  "data": {
    "id": "notif-xxx",
    "type": "booking_reminder",
    "title": "Rapat板门 akan dimulai",
    "message": "Rapat板门 akan dimulai dalam 15 menit",
    "data": { "booking_id": "booking-xxx" }
  }
}
```

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `NOTIFICATION_NOT_FOUND` | 404 | Notifikasi tidak ditemukan |
| `INVALID_TYPE` | 400 | Tipe notifikasi tidak valid |
| `INVALID_CHANNEL` | 400 | Channel notifikasi tidak valid |
| `TEMPLATE_NOT_FOUND` | 404 | Template tidak ditemukan |
