# Module 05: Room Management

## Overview

Modul Room Management menangani CRUD ruang rapat, equipment mapping, dan room facilities.

## API Endpoints

### 05.01 Room CRUD

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/rooms` | List all rooms | All (filtered by role) |
| POST | `/api/v1/rooms` | Create new room | Web Admin |
| GET | `/api/v1/rooms/{id}` | Get room detail | All |
| PUT | `/api/v1/rooms/{id}` | Update room | Web Admin |
| DELETE | `/api/v1/rooms/{id}` | Delete room | Web Admin |

### 05.02 Room Status

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/rooms/{id}/status` | Get room status (live) | All |
| PUT | `/api/v1/rooms/{id}/status` | Update room status | Web/Operator |

### 05.03 Room Equipment

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/rooms/{id}/equipment` | List room equipment | All |
| POST | `/api/v1/rooms/{id}/equipment` | Add equipment to room | Web Admin |
| PUT | `/api/v1/rooms/{id}/equipment/{eid}` | Update equipment | Web Admin |
| DELETE | `/api/v1/rooms/{id}/equipment/{eid}` | Remove equipment | Web Admin |

### 05.04 Room Schedule

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/rooms/{id}/schedule` | Get room schedule | All |

### 05.05 Availability & Facilities

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/rooms/available` | Check room availability | All |
| GET | `/api/v1/rooms/facilities` | List facility options | Web Admin |
| POST | `/api/v1/rooms/facilities` | Add facility option | Web Admin |

---

## Request/Response Examples

### GET /api/v1/rooms

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": "room-xxx",
      "name": "Ruang Rapat 1",
      "code": "RR01",
      "capacity": 30,
      "floor": 3,
      "building": "Gedung A",
      "description": "Ruang rapat utama dengan video wall 3x2",
      "facilities": ["videowall", "audio_conference", "video_conference", "notulensi"],
      "status": "AVAILABLE",
      "current_booking": null,
      "next_booking": {
        "id": "booking-yyy",
        "title": "Rapat板门",
        "start_time": "2026-09-18T14:00:00Z"
      },
      "is_active": true
    },
    {
      "id": "room-yyy",
      "name": "Ruang Rapat 2",
      "code": "RR02",
      "capacity": 15,
      "floor": 3,
      "building": "Gedung A",
      "description": "Ruang rapat kecil",
      "facilities": ["audio_conference"],
      "status": "OCCUPIED",
      "current_booking": {
        "id": "booking-zzz",
        "title": "Rapat HRD",
        "start_time": "2026-09-18T10:00:00Z",
        "end_time": "2026-09-18T12:00:00Z"
      },
      "next_booking": {
        "id": "booking-aaa",
        "title": "Interview",
        "start_time": "2026-09-18T13:00:00Z"
      },
      "is_active": true
    }
  ],
  "meta": {
    "total": 2
  }
}
```

### POST /api/v1/rooms

**Request:**
```json
{
  "name": "Ruang Rapat 1",
  "code": "RR01",
  "capacity": 30,
  "floor": 3,
  "building": "Gedung A",
  "description": "Ruang rapat utama dengan video wall 3x2",
  "facilities": ["videowall", "audio_conference", "video_conference", "notulensi"],
  "equipment": [
    {
      "type": "videowall",
      "name": "LG Videowall 3x2",
      "model": "LG 55VL5PJ",
      "quantity": 6,
      "config": {
        "layout": "3x2",
        "processor": "Digibird"
      }
    },
    {
      "type": "audio",
      "name": "Conference Audio",
      "model": "Ashley M118",
      "quantity": 1
    },
    {
      "type": "display",
      "name": "Door Display",
      "model": "Samsung Tab A9",
      "quantity": 1
    }
  ]
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "id": "room-new",
    "name": "Ruang Rapat 1",
    "code": "RR01",
    "capacity": 30,
    "floor": 3,
    "building": "Gedung A",
    "description": "Ruang rapat utama dengan video wall 3x2",
    "facilities": ["videowall", "audio_conference", "video_conference", "notulensi"],
    "status": "AVAILABLE",
    "is_active": true,
    "equipment": [
      {
        "id": "equip-001",
        "type": "videowall",
        "name": "LG Videowall 3x2",
        "model": "LG 55VL5PJ",
        "quantity": 6,
        "config": { "layout": "3x2", "processor": "Digibird" }
      }
    ],
    "created_at": "2026-09-18T10:00:00Z"
  }
}
```

### GET /api/v1/rooms/{id}/status

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "room_id": "room-xxx",
    "status": "AVAILABLE",
    "current_meeting": null,
    "next_meeting": {
      "id": "booking-yyy",
      "title": "Rapat板门",
      "start_time": "2026-09-18T14:00:00Z",
      "organizer": "Budi Santoso"
    },
    "equipment_status": [
      { "type": "videowall", "status": "ONLINE", "power": "ON" },
      { "type": "audio", "status": "ONLINE", "power": "ON" },
      { "type": "display", "status": "ONLINE", "power": "ON" }
    ],
    "updated_at": "2026-09-18T10:30:00Z"
  }
}
```

### PUT /api/v1/rooms/{id}/status

**Request:**
```json
{
  "status": "MAINTENANCE"
}
```

### GET /api/v1/rooms/available

**Query Parameters:**
- `date` (string): Date ISO format
- `start_time` (string): Start time ISO format
- `end_time` (string): End time ISO format
- `capacity` (int): Minimum capacity (optional)
- `facilities` (string[]): Required facilities (optional)

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "room": {
        "id": "room-xxx",
        "name": "Ruang Rapat 1",
        "code": "RR01",
        "capacity": 30
      },
      "available": true,
      "conflicts": []
    },
    {
      "room": {
        "id": "room-yyy",
        "name": "Ruang Rapat 2",
        "code": "RR02",
        "capacity": 15
      },
      "available": false,
      "conflicts": [
        {
          "booking_id": "booking-zzz",
          "title": "Rapat HRD",
          "start_time": "2026-09-18T10:00:00Z",
          "end_time": "2026-09-18T12:00:00Z"
        }
      ]
    }
  ]
}
```

---

## Data Models

### Room

```typescript
interface Room {
  id: string;
  name: string;
  code: string;               // Unique room code (e.g., "RR01")
  capacity: number;
  floor?: number;
  building?: string;
  description?: string;
  facilities: Facility[];     // ["videowall", "audio_conference", etc.]
  equipment: Equipment[];
  status: RoomStatus;
  is_active: boolean;
  created_at: DateTime;
  updated_at: DateTime;
}

type RoomStatus = 'AVAILABLE' | 'OCCUPIED' | 'MAINTENANCE' | 'RESERVED';

interface Facility {
  id: string;
  code: string;               // "videowall"
  name: string;               // "Video Wall 3x2"
  description?: string;
}

interface Equipment {
  id: string;
  room_id: string;
  type: EquipmentType;
  name: string;
  model?: string;
  manufacturer?: string;
  serial_number?: string;
  quantity: number;
  config: Record<string, any>;
  status: DeviceStatus;
}

type EquipmentType = 
  | 'videowall' 
  | 'display' 
  | 'audio' 
  | 'camera' 
  | 'microphone'
  | 'lighting'
  | 'ac';

type DeviceStatus = 'ONLINE' | 'OFFLINE' | 'MAINTENANCE' | 'ERROR';
```

---

## Room Status Flow

```
AVAILABLE
    │
    ├── [booking starts] ──▶ OCCUPIED
    │                            │
    │                            └── [booking ends] ──▶ AVAILABLE
    │
    ├── [maintenance] ──▶ MAINTENANCE
    │                          │
    │                          └── [maintenance done] ──▶ AVAILABLE
    │
    └── [reserved] ──▶ RESERVED
                           │
                           └── [booking starts] ──▶ OCCUPIED
```

---

## Facilities List

| Code | Name | Description |
|------|------|-------------|
| `videowall` | Video Wall | Wall-mounted video display system |
| `audio_conference` | Audio Conference | Conference audio system |
| `video_conference` | Video Conference | Webcam + video conferencing |
| `notulensi` | Notulensi | Automatic transcription |
| `digital_signage` | Digital Signage | Digital display for info |
| `wireless_present` | Wireless Presentation | Cast/screen share |

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `ROOM_NOT_FOUND` | 404 | Ruang tidak ditemukan |
| `ROOM_CODE_EXISTS` | 409 | Kode ruang sudah ada |
| `EQUIPMENT_NOT_FOUND` | 404 | Equipment tidak ditemukan |
| `INVALID_STATUS` | 400 | Status tidak valid |
| `ROOM_HAS_BOOKINGS` | 400 | Ruang memiliki booking aktif |
