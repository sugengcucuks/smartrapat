# Module 18: Maintenance

## Overview

Modul Maintenance menangani system health monitoring, backup/restore, database maintenance, dan error logging.

## API Endpoints

### 18.01 Health & Metrics

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/maintenance/health` | System health check | Admin |
| GET | `/api/v1/maintenance/metrics` | System metrics | Admin |

### 18.02 Backup & Restore

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| POST | `/api/v1/maintenance/backup` | Create backup | Admin |
| GET | `/api/v1/maintenance/backups` | List backups | Admin |
| POST | `/api/v1/maintenance/restore/{id}` | Restore backup | Admin |
| DELETE | `/api/v1/maintenance/backups/{id}` | Delete backup | Admin |

### 18.03 Database

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/maintenance/db-stats` | Database statistics | Admin |
| POST | `/api/v1/maintenance/db-maintenance` | Run DB maintenance | Admin |

### 18.04 Error Logs

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/maintenance/error-logs` | Get error logs | Admin |

### 18.05 Updates

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/maintenance/update` | Check for updates | Admin |
| POST | `/api/v1/maintenance/update` | Apply update | Admin |

---

## Request/Response Examples

### GET /api/v1/maintenance/health

```json
{
  "success": true,
  "data": {
    "status": "healthy",
    "timestamp": "2026-09-18T10:30:00Z",
    "components": [
      {
        "name": "database",
        "status": "healthy",
        "latency_ms": 12,
        "details": {
          "connection_pool": 5,
          "max_connections": 100
        }
      },
      {
        "name": "redis",
        "status": "healthy",
        "latency_ms": 2
      },
      {
        "name": "filesystem",
        "status": "healthy",
        "details": {
          "disk_usage_percent": 45,
          "disk_free_gb": 450
        }
      },
      {
        "name": "gpu",
        "status": "healthy",
        "details": {
          "name": "NVIDIA RTX 5060",
          "memory_used_mb": 2048,
          "memory_total_mb": 8192,
          "temperature_c": 42
        }
      },
      {
        "name": "digibird",
        "status": "healthy",
        "details": {
          "ip_address": "192.168.1.100",
          "online": true
        }
      },
      {
        "name": "audio_device",
        "status": "healthy",
        "details": {
          "device": "Focusrite Scarlett 18i20",
          "online": true
        }
      }
    ],
    "uptime_seconds": 864000,
    "version": "1.0.0"
  }
}
```

### GET /api/v1/maintenance/metrics

```json
{
  "success": true,
  "data": {
    "timestamp": "2026-09-18T10:30:00Z",
    "system": {
      "cpu_usage_percent": 35,
      "memory_usage_percent": 62,
      "memory_used_gb": 19.8,
      "memory_total_gb": 32,
      "disk_usage_percent": 45,
      "disk_free_gb": 450
    },
    "application": {
      "active_connections": 24,
      "requests_per_minute": 150,
      "average_response_time_ms": 45,
      "error_rate_percent": 0.5
    },
    "database": {
      "queries_per_second": 85,
      "slow_queries_count": 3,
      "connection_pool_usage_percent": 35
    },
    "gpu": {
      "usage_percent": 25,
      "memory_used_mb": 2048,
      "memory_total_mb": 8192,
      "temperature_c": 42
    },
    "network": {
      "bytes_sent_mb": 1250,
      "bytes_received_mb": 3400,
      "active_connections": 12
    }
  }
}
```

### POST /api/v1/maintenance/backup

```json
// Response (202 Accepted)
{
  "success": true,
  "data": {
    "backup_id": "backup-xxx",
    "status": "in_progress",
    "estimated_duration_seconds": 300,
    "started_at": "2026-09-18T10:30:00Z"
  }
}
```

### GET /api/v1/maintenance/backups

```json
{
  "success": true,
  "data": [
    {
      "id": "backup-003",
      "filename": "smartmeeting_backup_20260918_103000.sql.gz",
      "size_mb": 256,
      "status": "completed",
      "created_at": "2026-09-18T10:30:00Z",
      "expires_at": "2026-10-18T10:30:00Z",
      "is_automatic": false
    },
    {
      "id": "backup-002",
      "filename": "smartmeeting_backup_20260917_020000.sql.gz",
      "size_mb": 245,
      "status": "completed",
      "created_at": "2026-09-17T02:00:00Z",
      "expires_at": "2026-10-17T02:00:00Z",
      "is_automatic": true
    },
    {
      "id": "backup-001",
      "filename": "smartmeeting_backup_20260916_020000.sql.gz",
      "size_mb": 240,
      "status": "completed",
      "created_at": "2026-09-16T02:00:00Z",
      "expires_at": "2026-10-16T02:00:00Z",
      "is_automatic": true
    }
  ]
}
```

### POST /api/v1/maintenance/restore/{id}

```json
// Response (202 Accepted)
{
  "success": true,
  "data": {
    "backup_id": "backup-001",
    "status": "restoring",
    "estimated_duration_seconds": 300,
    "warning": "System will be temporarily unavailable during restore"
  }
}
```

### GET /api/v1/maintenance/db-stats

```json
{
  "success": true,
  "data": {
    "database": "smartmeeting",
    "size_mb": 2048,
    "tables_count": 28,
    "indexes_count": 85,
    "tables": [
      {
        "name": "bookings",
        "rows": 4520,
        "size_mb": 128,
        "index_size_mb": 32,
        "last_vacuum": "2026-09-18T02:00:00Z"
      },
      {
        "name": "transcript_segments",
        "rows": 125000,
        "size_mb": 850,
        "index_size_mb": 120,
        "last_vacuum": "2026-09-18T02:00:00Z"
      },
      {
        "name": "users",
        "rows": 150,
        "size_mb": 0.5,
        "index_size_mb": 0.1
      }
    ],
    "slow_queries": [
      {
        "query": "SELECT * FROM bookings WHERE room_id = ? AND start_time > ?",
        "execution_time_ms": 2500,
        "called_count": 45,
        "last_called": "2026-09-18T10:00:00Z"
      }
    ]
  }
}
```

### GET /api/v1/maintenance/error-logs

```json
{
  "success": true,
  "data": [
    {
      "id": "err-001",
      "level": "ERROR",
      "message": "Failed to connect to Digibird",
      "module": "videowall",
      "details": {
        "device_ip": "192.168.1.100",
        "error_code": "CONNECTION_REFUSED"
      },
      "created_at": "2026-09-18T09:30:00Z",
      "resolved": true,
      "resolved_at": "2026-09-18T09:35:00Z"
    },
    {
      "id": "err-002",
      "level": "WARNING",
      "message": "Audio level low",
      "module": "audio",
      "details": {
        "mic_id": 3,
        "level_db": -45
      },
      "created_at": "2026-09-18T09:15:00Z",
      "resolved": false
    }
  ],
  "meta": {
    "page": 1,
    "limit": 20,
    "total": 5
  }
}
```

### GET /api/v1/maintenance/update

```json
{
  "success": true,
  "data": {
    "current_version": "1.0.0",
    "latest_version": "1.0.1",
    "update_available": true,
    "release_notes": "- Bug fix: Fixed video wall preset apply delay\n- Improvement: Audio metering performance\n- New feature: Door display quick book",
    "download_size_mb": 45,
    "can_auto_update": true,
    "release_date": "2026-09-15"
  }
}
```

---

## Data Models

```typescript
interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: DateTime;
  components: ComponentHealth[];
  uptime_seconds: number;
  version: string;
}

interface ComponentHealth {
  name: string;
  status: 'healthy' | 'degraded' | 'unhealthy';
  latency_ms?: number;
  details?: Record<string, any>;
}

interface SystemMetrics {
  timestamp: DateTime;
  system: SystemMetrics;
  application: ApplicationMetrics;
  database: DatabaseMetrics;
  gpu?: GPUMetrics;
  network: NetworkMetrics;
}

interface SystemMetrics {
  cpu_usage_percent: number;
  memory_usage_percent: number;
  memory_used_gb: number;
  memory_total_gb: number;
  disk_usage_percent: number;
  disk_free_gb: number;
}

interface ApplicationMetrics {
  active_connections: number;
  requests_per_minute: number;
  average_response_time_ms: number;
  error_rate_percent: number;
}

interface DatabaseMetrics {
  queries_per_second: number;
  slow_queries_count: number;
  connection_pool_usage_percent: number;
}

interface GPUMetrics {
  usage_percent: number;
  memory_used_mb: number;
  memory_total_mb: number;
  temperature_c: number;
}

interface Backup {
  id: string;
  filename: string;
  size_mb: number;
  status: 'in_progress' | 'completed' | 'failed';
  created_at: DateTime;
  expires_at: DateTime;
  is_automatic: boolean;
}

interface ErrorLog {
  id: string;
  level: 'DEBUG' | 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';
  message: string;
  module: string;
  details?: Record<string, any>;
  created_at: DateTime;
  resolved: boolean;
  resolved_at?: DateTime;
}
```

---

## Scheduled Maintenance

| Task | Schedule | Description |
|------|----------|-------------|
| Database Vacuum | Daily 02:00 | Clean up dead tuples |
| Database Analyze | Daily 02:30 | Update statistics |
| Log Rotation | Weekly Sunday | Rotate and compress logs |
| Backup | Daily 02:00 | Automatic database backup |
| Health Check | Every 5 min | Monitor system health |
| Error Alert | Real-time | Send alerts for critical errors |

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `BACKUP_IN_PROGRESS` | 409 | Backup sedang berlangsung |
| `BACKUP_NOT_FOUND` | 404 | Backup tidak ditemukan |
| `RESTORE_IN_PROGRESS` | 409 | Restore sedang berlangsung |
| `UPDATE_UNAVAILABLE` | 400 | Update tidak tersedia |
| `UPDATE_FAILED` | 500 | Update gagal |
| `COMPONENT_UNHEALTHY` | 503 | Komponen tidak sehat |
| `DATABASE_ERROR` | 500 | Database error |
