# Module 14: Reports

## Overview

Modul Reports menyediakan laporan dan analytics untuk booking, room utilization, dan notulensi stats.

## Sub-Modules

```
14_REPORTS
├── 14_01_BOOKING_REPORTS    # Booking analytics
├── 14_02_ROOM_REPORTS      # Room utilization
├── 14_03_NOTULENSI_REPORTS # Notulensi stats
└── 14_04_EXPORT           # Report export
```

---

## 14_01_BOOKING_REPORTS - Booking Reports

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/reports/booking/summary` | Booking summary | Admin |
| GET | `/api/v1/reports/booking/trends` | Booking trends | Admin |
| GET | `/api/v1/reports/booking/peak-hours` | Peak hours | Admin |
| GET | `/api/v1/reports/booking/no-show` | No-show rate | Admin |
| GET | `/api/v1/reports/booking/by-organizer` | Bookings by organizer | Admin |
| GET | `/api/v1/reports/booking/by-department` | Bookings by department | Admin |

### Query Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `date_from` | string | Start date (ISO format) |
| `date_to` | string | End date (ISO format) |
| `room_id` | string | Filter by room (optional) |

### Request/Response Examples

**GET /api/v1/reports/booking/summary**

```json
{
  "success": true,
  "data": {
    "period": {
      "date_from": "2026-09-01",
      "date_to": "2026-09-30"
    },
    "total_bookings": 145,
    "total_hours": 387.5,
    "average_duration_hours": 2.67,
    "by_status": {
      "completed": 120,
      "cancelled": 15,
      "no_show": 10
    },
    "by_room": [
      { "room_id": "room-xxx", "room_name": "Ruang Rapat 1", "count": 65 },
      { "room_id": "room-yyy", "room_name": "Ruang Rapat 2", "count": 45 },
      { "room_id": "room-zzz", "room_name": "Ruang Rapat 3", "count": 35 }
    ],
    "comparison_with_last_period": {
      "booking_change_percent": 12.5,
      "hours_change_percent": 8.3
    }
  }
}
```

**GET /api/v1/reports/booking/trends**

```json
{
  "success": true,
  "data": {
    "period": {
      "date_from": "2026-07-01",
      "date_to": "2026-09-30"
    },
    "trend": [
      { "month": "2026-07", "bookings": 120, "hours": 320 },
      { "month": "2026-08", "bookings": 135, "hours": 355 },
      { "month": "2026-09", "bookings": 145, "hours": 387.5 }
    ],
    "prediction": {
      "next_month_estimated_bookings": 155,
      "confidence": 0.85
    }
  }
}
```

**GET /api/v1/reports/booking/peak-hours**

```json
{
  "success": true,
  "data": {
    "period": {
      "date_from": "2026-09-01",
      "date_to": "2026-09-30"
    },
    "peak_hours": [
      { "hour": "09:00", "booking_count": 42, "utilization_percent": 85 },
      { "hour": "10:00", "booking_count": 45, "utilization_percent": 90 },
      { "hour": "11:00", "booking_count": 38, "utilization_percent": 76 },
      { "hour": "13:00", "booking_count": 40, "utilization_percent": 80 },
      { "hour": "14:00", "booking_count": 35, "utilization_percent": 70 }
    ],
    "peak_days": [
      { "day": "Senin", "booking_count": 35 },
      { "day": "Selasa", "booking_count": 32 },
      { "day": "Rabu", "booking_count": 30 },
      { "day": "Kamis", "booking_count": 28 },
      { "day": "Jumat", "booking_count": 20 }
    ]
  }
}
```

---

## 14_02_ROOM_REPORTS - Room Reports

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/reports/room/utilization` | Room utilization | Admin |
| GET | `/api/v1/reports/room/popularity` | Room popularity | Admin |
| GET | `/api/v1/reports/room/equipment-usage` | Equipment usage | Admin |

### Request/Response Examples

**GET /api/v1/reports/room/utilization**

```json
{
  "success": true,
  "data": {
    "period": {
      "date_from": "2026-09-01",
      "date_to": "2026-09-30"
    },
    "working_days": 22,
    "working_hours_per_day": 10,
    "rooms": [
      {
        "room_id": "room-xxx",
        "room_name": "Ruang Rapat 1",
        "total_bookings": 65,
        "total_hours": 175.5,
        "available_hours": 220,
        "utilization_percent": 79.77,
        "busiest_day": "Senin",
        "peak_hour": "10:00"
      },
      {
        "room_id": "room-yyy",
        "room_name": "Ruang Rapat 2",
        "total_bookings": 45,
        "total_hours": 112.5,
        "available_hours": 220,
        "utilization_percent": 51.14,
        "busiest_day": "Selasa",
        "peak_hour": "14:00"
      }
    ],
    "average_utilization": 65.45
  }
}
```

**GET /api/v1/reports/room/equipment-usage**

```json
{
  "success": true,
  "data": {
    "equipment_usage": [
      {
        "equipment_type": "videowall",
        "usage_count": 85,
        "total_hours": 255,
        "rooms": [
          { "room_id": "room-xxx", "room_name": "Ruang Rapat 1", "usage_count": 60 },
          { "room_id": "room-yyy", "room_name": "Ruang Rapat 2", "usage_count": 25 }
        ]
      },
      {
        "equipment_type": "notulensi",
        "usage_count": 45,
        "total_hours": 90,
        "rooms": [
          { "room_id": "room-xxx", "room_name": "Ruang Rapat 1", "usage_count": 40 },
          { "room_id": "room-yyy", "room_name": "Ruang Rapat 2", "usage_count": 5 }
        ]
      }
    ]
  }
}
```

---

## 14_03_NOTULENSI_REPORTS - Notulensi Reports

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/reports/notulensi/stats` | Notulensi stats | Admin |
| GET | `/api/v1/reports/notulensi/meeting-duration` | Meeting duration analysis | Admin |
| GET | `/api/v1/reports/notulensi/transcript-stats` | Transcript statistics | Admin |

### Request/Response Examples

**GET /api/v1/reports/notulensi/stats**

```json
{
  "success": true,
  "data": {
    "period": {
      "date_from": "2026-09-01",
      "date_to": "2026-09-30"
    },
    "total_recordings": 45,
    "total_duration_hours": 112.5,
    "average_duration_minutes": 150,
    "total_transcript_segments": 4520,
    "average_segments_per_meeting": 100,
    "language_distribution": {
      "id": 42,
      "en": 2,
      "mixed": 1
    },
    "storage_used_mb": 4500
  }
}
```

---

## 14_04_EXPORT - Report Export

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| POST | `/api/v1/reports/generate` | Generate report | Admin |
| GET | `/api/v1/reports/generate/{id}` | Get generated report | Admin |
| GET | `/api/v1/reports/export/pdf` | Export to PDF | Admin |
| GET | `/api/v1/reports/export/excel` | Export to Excel | Admin |
| GET | `/api/v1/reports/export/csv` | Export to CSV | Admin |
| POST | `/api/v1/reports/schedule` | Schedule report | Admin |

### Request/Response Examples

**POST /api/v1/reports/generate**

```json
{
  "report_type": "booking_summary",
  "format": "pdf",
  "date_from": "2026-09-01",
  "date_to": "2026-09-30",
  "room_id": "all",
  "include_charts": true,
  "title": "Laporan Pemesanan September 2026"
}
```

**Response (202 Accepted):**
```json
{
  "success": true,
  "data": {
    "report_id": "report-xxx",
    "status": "generating",
    "estimated_time_seconds": 30
  }
}
```

**GET /api/v1/reports/generate/{id}**

```json
{
  "success": true,
  "data": {
    "report_id": "report-xxx",
    "status": "completed",
    "download_url": "/api/v1/reports/download/report-xxx.pdf",
    "expires_at": "2026-09-25T10:00:00Z",
    "created_at": "2026-09-18T10:00:00Z"
  }
}
```

---

## Data Models

```typescript
interface ReportSummary {
  period: DateRange;
  total_bookings: number;
  total_hours: number;
  average_duration_hours: number;
  by_status: Record<string, number>;
}

interface DateRange {
  date_from: string;
  date_to: string;
}

interface RoomUtilization {
  room_id: string;
  room_name: string;
  total_bookings: number;
  total_hours: number;
  available_hours: number;
  utilization_percent: number;
  busiest_day: string;
  peak_hour: string;
}

interface PeakHour {
  hour: string;
  booking_count: number;
  utilization_percent: number;
}

interface ScheduledReport {
  id: string;
  name: string;
  report_type: string;
  schedule: CronExpression;
  format: 'pdf' | 'excel' | 'csv';
  recipients: string[];
  last_run_at?: DateTime;
  next_run_at?: DateTime;
  is_active: boolean;
}
```

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `REPORT_NOT_FOUND` | 404 | Report tidak ditemukan |
| `REPORT_GENERATION_FAILED` | 500 | Gagal generate report |
| `INVALID_DATE_RANGE` | 400 | Range tanggal tidak valid |
| `EXPORT_FORMAT_NOT_SUPPORTED` | 400 | Format export tidak didukung |
