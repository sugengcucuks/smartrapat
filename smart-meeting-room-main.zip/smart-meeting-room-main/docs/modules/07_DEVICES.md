# Modul 07: Perangkat IoT/AV

Daftar perangkat fisik per ruangan + perintah dasar (power/restart/lock) lewat
**device agent** (PC Monitoring) via MQTT. Kontrak topic: `docs/architecture/LIVE_MEETING.md` §3.

## Alur

```
UI ──REST──► FastAPI ──MQTT smr/devices/{id}/command/{action}──► device agent ──► perangkat
                ▲                                                     │
                └──────── smr/devices/{id}/ack  (≤ 3 dtk) ◄───────────┘
                └──────── smr/devices/{id}/state (retained, health poll 30 dtk)
                └──────── smr/agent/{agent_id}/status (retained, LWT offline)
```

- Status `online/offline` + `last_seen` **hanya** diperbarui dari topic `state`
  dan status agent (LWT → semua perangkat agent itu offline). Perintah tidak lagi
  mengubah status secara optimistis. Status `maintenance` manual tidak ditimpa.
- Tanpa broker (`MQTT_BROKER_URL` kosong) perintah → **503** `{"code": "MQTT_NOT_CONFIGURED"}`;
  broker terputus → 503 `MQTT_NOT_CONNECTED`. Tidak ada "mock sukses".
- `MQTT_SIMULATE=true` hanya untuk dev lokal: perintah di-ack otomatis (`response: "simulated"`).

## Tipe perangkat (`devices.device_type`)

| Tipe | Dipakai untuk |
|---|---|
| `tv` / `display` | Panel LG 55VL5PJ (anggota videowall) |
| `videowall_controller` | Processor Digibird; `config` = preset & sumber (lihat 08_VIDEOWALL) |
| `audio_mixer` | Behringer XR18 / Midas MR18 (`config: {"driver": "xair"}`) |
| `audio_processor` | Audio processor lain (dianggap mixer bila `config.driver = "xair"`) |
| `projector`, `ac`, `cctv`, `lights`, `curtain`, `sensor_*`, `door_lock`, `tablet` | lainnya |

`code` perangkat di aplikasi **harus sama** dengan `code` di `agent/devices.yaml`
(backend selalu mengirim `device_code`; agent mencocokkan UUID atau kode).

## REST (`/api/v1/devices`)

| Method | Path | Izin | Keterangan |
|---|---|---|---|
| GET | `/devices?search=&device_type=&status=&room_id=&page=&per_page=` | `devices.view` | item berisi `live` (state agent terakhir) |
| GET | `/devices/health/summary` | `devices.view` | `count_total/online/offline/error/maintenance`, `list_per_room` |
| GET | `/devices/{id}`, `/devices/{id}/status` | `devices.view` | |
| POST/PUT/DELETE | `/devices`, `/devices/{id}` | `devices.write` | `config` JSON bebas |
| POST | `/devices/{id}/power-on\|power-off\|restart\|lock\|unlock` | `devices.control` | respons perintah (di bawah) |

Respons perintah (HTTP 200, cek `status`):

```json
{"cmd_id": "…", "status": "acked|failed|timeout", "error": null,
 "results": [{"device_id", "device_code", "device_name", "action", "cmd_id", "status", "error", "response"}]}
```

## Device agent

Lihat `agent/README.md` (instalasi service Windows/NSSM, pairing LG, XR18, kredensial MQTT).
Aksi yang tidak ada di `devices.yaml` untuk perangkat tsb → ack `ok=false`
("Aksi … tidak dikonfigurasi"). Parameter perintah divalidasi whitelist
(`params:`/`map:`) sebelum masuk ke perintah ASCII/serial.
