# Module 02: Authentication

## Overview

Modul Authentication menangani login, logout, session management, dan password reset untuk semua user.

## API Endpoints

### 02.01 Login & Logout

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| POST | `/api/v1/auth/login` | User login | All |
| POST | `/api/v1/auth/logout` | User logout | All |
| POST | `/api/v1/auth/refresh` | Refresh access token | All |
| GET | `/api/v1/auth/session` | Get current session | All |

### 02.02 Password Management

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| POST | `/api/v1/auth/forgot-password` | Request password reset | All |
| POST | `/api/v1/auth/reset-password` | Reset password with token | All |
| POST | `/api/v1/auth/change-password` | Change password (logged in) | All |

### 02.03 Menu & Access

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/auth/menu` | Get accessible menu based on role | All |

---

## Request/Response Examples

### POST /api/v1/auth/login

**Request:**
```json
{
  "username": "operator01",
  "password": "securepassword123"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "access_token": "eyJhbGciOiJIUzI1NiIs...",
    "refresh_token": "eyJhbGciOiJIUzI1NiIs...",
    "token_type": "Bearer",
    "expires_in": 3600,
    "user": {
      "id": "uuid-xxx",
      "username": "operator01",
      "name": "Budi Santoso",
      "role": "operator",
      "permissions": [
        "booking.create",
        "videowall.control",
        "notulensi.start"
      ]
    }
  }
}
```

**Response (401 Unauthorized):**
```json
{
  "success": false,
  "error": {
    "code": "AUTH_INVALID",
    "message": "Username atau password salah"
  }
}
```

### POST /api/v1/auth/forgot-password

**Request:**
```json
{
  "email": "budi@email.com"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "message": "Link reset password telah dikirim ke email"
  }
}
```

### POST /api/v1/auth/reset-password

**Request:**
```json
{
  "token": "reset-token-xxx",
  "new_password": "newsecurepassword123"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "message": "Password berhasil direset"
  }
}
```

### GET /api/v1/auth/menu

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "menu": [
      {
        "id": "dashboard",
        "name": "Dashboard",
        "icon": "home",
        "path": "/dashboard"
      },
      {
        "id": "booking",
        "name": "Pemesanan",
        "icon": "calendar",
        "path": "/bookings",
        "children": [
          { "id": "booking-list", "name": "Daftar Pemesanan", "path": "/bookings" },
          { "id": "booking-create", "name": "Buat Pemesanan", "path": "/bookings/create" }
        ]
      },
      {
        "id": "videowall",
        "name": "Video Wall",
        "icon": "monitor",
        "path": "/videowall"
      },
      {
        "id": "notulensi",
        "name": "Notulensi",
        "icon": "file-text",
        "path": "/notulensi"
      },
      {
        "id": "rooms",
        "name": "Ruang Rapat",
        "icon": "door-open",
        "path": "/rooms"
      },
      {
        "id": "reports",
        "name": "Laporan",
        "icon": "bar-chart",
        "path": "/reports"
      },
      {
        "id": "settings",
        "name": "Pengaturan",
        "icon": "settings",
        "path": "/settings"
      }
    ]
  }
}
```

---

## Data Models

### User Session

```typescript
interface UserSession {
  id: string;              // UUID
  username: string;
  name: string;
  email: string;
  role: UserRole;
  permissions: string[];
  avatar_url?: string;
  department?: string;
}

type UserRole = 'admin' | 'operator' | 'user';

interface AuthTokens {
  access_token: string;
  refresh_token: string;
  token_type: 'Bearer';
  expires_in: number;       // seconds
}
```

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `AUTH_INVALID` | 401 | Username atau password salah |
| `AUTH_EXPIRED` | 401 | Token sudah kadaluarsa |
| `AUTH_REQUIRED` | 401 | Token tidak ditemukan |
| `USER_INACTIVE` | 403 | Akun nonaktif |
| `USER_LOCKED` | 423 | Akun terkunci |
| `PASSWORD_WEAK` | 422 | Password terlalu lemah |

---

## Security Considerations

1. **Password Storage**: bcrypt with salt rounds = 12
2. **Token Expiry**: Access token = 1 hour, Refresh token = 7 days
3. **Rate Limiting**: 5 failed login attempts = 15 min lockout
4. **Audit Logging**: All auth events logged to audit table
5. **Session Management**: Single session per user (configurable)

---

## WebSocket Events

```javascript
// Authentication events (optional real-time)
ws://server:8000/ws/auth

{
  "event": "session_expired",
  "data": {
    "reason": "token_expired"
  }
}

{
  "event": "force_logout",
  "data": {
    "reason": "admin_action"
  }
}
```
