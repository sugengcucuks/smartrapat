# Module 04: Role & Permission

## Overview

Modul Role & Permission mengelola role definitions dan permission assignments untuk access control.

## API Endpoints

### 04.01 Roles

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/roles` | List all roles | Web Admin |
| POST | `/api/v1/roles` | Create new role | Web Admin |
| GET | `/api/v1/roles/{id}` | Get role detail | Web Admin |
| PUT | `/api/v1/roles/{id}` | Update role | Web Admin |
| DELETE | `/api/v1/roles/{id}` | Delete role | Web Admin |

### 04.02 Permissions

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/permissions` | List all available permissions | Web Admin |
| GET | `/api/v1/permissions/categories` | List permission categories | Web Admin |
| GET | `/api/v1/roles/{id}/permissions` | Get role permissions | Web Admin |
| PUT | `/api/v1/roles/{id}/permissions` | Update role permissions | Web Admin |

### 04.03 Role Assignment

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| POST | `/api/v1/roles/{id}/assign-users` | Assign role to users | Web Admin |
| GET | `/api/v1/roles/{id}/users` | List users with this role | Web Admin |

---

## Request/Response Examples

### GET /api/v1/roles

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": "role-admin",
      "name": "admin",
      "description": "Administrator dengan akses penuh",
      "is_system": true,
      "user_count": 2,
      "created_at": "2026-01-01T00:00:00Z"
    },
    {
      "id": "role-operator",
      "name": "operator",
      "description": "Operator ruang rapat",
      "is_system": true,
      "user_count": 5,
      "created_at": "2026-01-01T00:00:00Z"
    },
    {
      "id": "role-user",
      "name": "user",
      "description": "Pengguna biasa - booking only",
      "is_system": true,
      "user_count": 38,
      "created_at": "2026-01-01T00:00:00Z"
    }
  ]
}
```

### POST /api/v1/roles

**Request:**
```json
{
  "name": "supervisor",
  "description": "Supervisor dengan akses monitoring"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "id": "role-supervisor",
    "name": "supervisor",
    "description": "Supervisor dengan akses monitoring",
    "is_system": false,
    "created_at": "2026-09-18T10:00:00Z"
  }
}
```

### GET /api/v1/permissions

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "category": "booking",
      "permissions": [
        { "id": "perm-001", "name": "booking.create", "description": "Buat pemesanan" },
        { "id": "perm-002", "name": "booking.read", "description": "Lihat pemesanan" },
        { "id": "perm-003", "name": "booking.update", "description": "Ubah pemesanan" },
        { "id": "perm-004", "name": "booking.delete", "description": "Hapus pemesanan" },
        { "id": "perm-005", "name": "booking.approve", "description": "Setujui pemesanan" }
      ]
    },
    {
      "category": "videowall",
      "permissions": [
        { "id": "perm-010", "name": "videowall.control", "description": "Kontrol video wall" },
        { "id": "perm-011", "name": "videowall.configure", "description": "Konfigurasi layout" }
      ]
    },
    {
      "category": "notulensi",
      "permissions": [
        { "id": "perm-020", "name": "notulensi.start", "description": "Mulai notulensi" },
        { "id": "perm-021", "name": "notulensi.stop", "description": "Stop notulensi" },
        { "id": "perm-022", "name": "notulensi.export", "description": "Export notulensi" }
      ]
    },
    {
      "category": "room",
      "permissions": [
        { "id": "perm-030", "name": "room.create", "description": "Buat ruang baru" },
        { "id": "perm-031", "name": "room.read", "description": "Lihat ruang" },
        { "id": "perm-032", "name": "room.update", "description": "Ubah ruang" },
        { "id": "perm-033", "name": "room.delete", "description": "Hapus ruang" }
      ]
    },
    {
      "category": "user",
      "permissions": [
        { "id": "perm-040", "name": "user.create", "description": "Buat pengguna" },
        { "id": "perm-041", "name": "user.read", "description": "Lihat pengguna" },
        { "id": "perm-042", "name": "user.update", "description": "Ubah pengguna" },
        { "id": "perm-043", "name": "user.delete", "description": "Hapus pengguna" }
      ]
    },
    {
      "category": "report",
      "permissions": [
        { "id": "perm-050", "name": "report.view", "description": "Lihat laporan" },
        { "id": "perm-051", "name": "report.export", "description": "Export laporan" }
      ]
    },
    {
      "category": "settings",
      "permissions": [
        { "id": "perm-060", "name": "settings.manage", "description": "Kelola pengaturan" }
      ]
    }
  ]
}
```

### PUT /api/v1/roles/{id}/permissions

**Request:**
```json
{
  "permissions": [
    "booking.create",
    "booking.read",
    "booking.update",
    "videowall.control",
    "videowall.configure",
    "notulensi.start",
    "notulensi.stop"
  ]
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "role_id": "role-operator",
    "permissions": [
      "booking.create",
      "booking.read",
      "booking.update",
      "videowall.control",
      "videowall.configure",
      "notulensi.start",
      "notulensi.stop"
    ],
    "updated_at": "2026-09-18T10:30:00Z"
  }
}
```

### POST /api/v1/roles/{id}/assign-users

**Request:**
```json
{
  "user_ids": [
    "user-xxx",
    "user-yyy",
    "user-zzz"
  ]
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "role_id": "role-supervisor",
    "assigned_users": 3,
    "users": [
      { "id": "user-xxx", "name": "Budi Santoso" },
      { "id": "user-yyy", "name": "Ani Wijaya" },
      { "id": "user-zzz", "name": "Dewi Lestari" }
    ]
  }
}
```

---

## Data Models

### Role

```typescript
interface Role {
  id: string;
  name: string;              // admin | operator | user | custom
  description?: string;
  is_system: boolean;        // true = system role (cannot delete)
  user_count: number;
  created_at: DateTime;
  updated_at: DateTime;
}

interface Permission {
  id: string;
  name: string;              // e.g., "booking.create"
  category: string;          // e.g., "booking"
  description?: string;
}

interface RolePermission {
  role_id: string;
  permission_id: string;
}
```

---

## Default Role Permissions

### Admin
```
* (all permissions)
```

### Operator
```
booking.create, booking.read, booking.update, booking.delete
videowall.control, videowall.configure
notulensi.start, notulensi.stop, notulensi.export
room.read
report.view, report.export
```

### User
```
booking.create, booking.read (own bookings only)
room.read
```

---

## Permission Categories

| Category | Description |
|----------|-------------|
| `booking` | Pemesanan ruang rapat |
| `videowall` | Kontrol video wall |
| `audio` | Kontrol audio |
| `notulensi` | Notulensi rapat |
| `room` | Manajemen ruang |
| `equipment` | Manajemen peralatan |
| `device` | Manajemen perangkat |
| `user` | Manajemen pengguna |
| `role` | Manajemen role |
| `report` | Laporan & analytics |
| `settings` | Pengaturan sistem |
| `door_display` | Door display |

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `ROLE_NOT_FOUND` | 404 | Role tidak ditemukan |
| `ROLE_SYSTEM` | 400 | Cannot modify system role |
| `PERMISSION_NOT_FOUND` | 400 | Permission tidak valid |
| `USER_NOT_FOUND` | 400 | User tidak ditemukan |
