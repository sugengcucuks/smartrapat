# Module 06: Equipment Management

## Overview

Modul Equipment Management menangani manajemen peralatan ruang rapat termasuk configure, calibrate, dan firmware update.

## API Endpoints

### 06.01 Equipment CRUD

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/equipment` | List all equipment | Web Admin |
| POST | `/api/v1/equipment` | Add new equipment | Web Admin |
| GET | `/api/v1/equipment/{id}` | Get equipment detail | Web Admin |
| PUT | `/api/v1/equipment/{id}` | Update equipment | Web Admin |
| DELETE | `/api/v1/equipment/{id}` | Remove equipment | Web Admin |

### 06.02 Equipment Status & Control

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/equipment/{id}/status` | Get equipment status | Web/Operator |
| POST | `/api/v1/equipment/{id}/calibrate` | Calibrate equipment | Web Admin |
| GET | `/api/v1/equipment/{id}/logs` | Get equipment logs | Web Admin |
| PUT | `/api/v1/equipment/{id}/firmware` | Update firmware | Web Admin |

### 06.03 Equipment Types

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/equipment/types` | List equipment types | Web Admin |
| POST | `/api/v1/equipment/types` | Add equipment type | Web Admin |

---

## Request/Response Examples

### GET /api/v1/equipment

**Query Parameters:**
- `room_id` (string): Filter by room
- `type` (string): Filter by type
- `status` (string): Filter by status

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": "equip-001",
      "room_id": "room-xxx",
      "room_name": "Ruang Rapat 1",
      "type": "videowall",
      "name": "LG Videowall 3x2",
      "model": "LG 55VL5PJ",
      "manufacturer": "LG Electronics",
      "serial_number": "LG55VL5PJ20240001",
      "quantity": 6,
      "config": {
        "layout": "3x2",
        "processor": "Digibird",
        "resolution": "1920x1080"
      },
      "status": "ONLINE",
      "last_maintenance": "2026-08-15T10:00:00Z",
      "created_at": "2026-01-15T10:00:00Z"
    },
    {
      "id": "equip-002",
      "room_id": "room-xxx",
      "room_name": "Ruang Rapat 1",
      "type": "audio",
      "name": "Ashley M118 Conference",
      "model": "Ashley M118",
      "manufacturer": "Ashley Microphones",
      "serial_number": "AM11820240012",
      "quantity": 1,
      "config": {
        "channels": 16,
        "receiver_type": "wireless"
      },
      "status": "ONLINE",
      "last_maintenance": null,
      "created_at": "2026-01-15T10:00:00Z"
    }
  ]
}
```

### POST /api/v1/equipment

**Request:**
```json
{
  "room_id": "room-xxx",
  "type": "videowall",
  "name": "LG Videowall 3x2",
  "model": "LG 55VL5PJ",
  "manufacturer": "LG Electronics",
  "serial_number": "LG55VL5PJ20240001",
  "quantity": 6,
  "config": {
    "layout": "3x2",
    "processor": "Digibird",
    "resolution": "1920x1080",
    "bezel_width_mm": 3.5
  }
}
```

### GET /api/v1/equipment/{id}/status

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "equipment_id": "equip-001",
    "type": "videowall",
    "status": "ONLINE",
    "power": "ON",
    "metrics": {
      "cpu_usage": 45,
      "memory_usage": 62,
      "temperature": 42,
      "uptime_hours": 720
    },
    "displays": [
      { "id": 1, "power": "ON", "source": "HDMI_1", "brightness": 100 },
      { "id": 2, "power": "ON", "source": "HDMI_2", "brightness": 100 },
      { "id": 3, "power": "ON", "source": "HDMI_3", "brightness": 100 },
      { "id": 4, "power": "ON", "source": "HDMI_4", "brightness": 100 },
      { "id": 5, "power": "ON", "source": "HDMI_5", "brightness": 100 },
      { "id": 6, "power": "ON", "source": "HDMI_6", "brightness": 100 }
    ],
    "updated_at": "2026-09-18T10:30:00Z"
  }
}
```

### POST /api/v1/equipment/{id}/calibrate

**Request:**
```json
{
  "calibration_type": "display",
  "params": {
    "brightness": true,
    "contrast": true,
    "color_calibration": true
  }
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "equipment_id": "equip-001",
    "calibration_id": "cal-xxx",
    "status": "IN_PROGRESS",
    "started_at": "2026-09-18T10:30:00Z",
    "estimated_duration": 300,
    "message": "Display calibration in progress"
  }
}
```

### PUT /api/v1/equipment/{id}/firmware

**Request (multipart/form-data):**
- `file`: Firmware binary file
- `version`: Version string (e.g., "2.1.5")

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "equipment_id": "equip-001",
    "current_version": "2.1.4",
    "new_version": "2.1.5",
    "status": "UPDATING",
    "message": "Firmware update started. Device will restart automatically."
  }
}
```

---

## Data Models

### Equipment

```typescript
interface Equipment {
  id: string;
  room_id: string;
  type: EquipmentType;
  name: string;
  model?: string;
  manufacturer?: string;
  serial_number?: string;
  quantity: number;
  config: EquipmentConfig;
  status: EquipmentStatus;
  last_maintenance?: DateTime;
  created_at: DateTime;
  updated_at: DateTime;
}

type EquipmentType = 
  | 'videowall'
  | 'display'
  | 'audio'
  | 'camera'
  | 'microphone'
  | 'video_processor'
  | 'lighting'
  | 'ac'
  | 'blinds';

type EquipmentStatus = 
  | 'ONLINE'
  | 'OFFLINE'
  | 'MAINTENANCE'
  | 'UPDATING'
  | 'ERROR';

interface EquipmentConfig {
  // Video Wall
  layout?: '2x2' | '3x2' | '3x3' | 'custom';
  processor?: string;
  resolution?: string;
  bezel_width_mm?: number;
  
  // Audio
  channels?: number;
  receiver_type?: 'wired' | 'wireless' | 'mixed';
  
  // General
  ip_address?: string;
  mac_address?: string;
  [key: string]: any;
}

interface EquipmentLog {
  id: string;
  equipment_id: string;
  level: 'INFO' | 'WARNING' | 'ERROR';
  message: string;
  details?: Record<string, any>;
  created_at: DateTime;
}

interface EquipmentMetrics {
  equipment_id: string;
  cpu_usage?: number;
  memory_usage?: number;
  temperature?: number;
  uptime_hours?: number;
  signal_strength?: number;
  [key: string]: any;
}
```

---

## Equipment Types Configuration

### Video Wall (LG 55VL5PJ)
```json
{
  "layout": "3x2",
  "processor": "Digibird",
  "resolution": "1920x1080",
  "bezel_width_mm": 3.5,
  "brightness_nits": 500,
  "ports": ["HDMI_1", "HDMI_2", "HDMI_3", "HDMI_4"]
}
```

### Video Processor (Digibird)
```json
{
  "model": "Digibird 4K",
  "inputs": 4,
  "outputs": 8,
  "protocol": "HTTP",
  "control_port": 8080,
  "video_matrix": true
}
```

### Audio Conference (Ashley M118)
```json
{
  "model": "Ashley M118",
  "type": "conference_microphone",
  "channels": 16,
  "capsule_type": "gooseneck",
  "frequency_response": "50Hz-20kHz",
  "connector": "XLR"
}
```

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `EQUIPMENT_NOT_FOUND` | 404 | Equipment tidak ditemukan |
| `EQUIPMENT_OFFLINE` | 503 | Equipment tidak dapat dijangkau |
| `CALIBRATION_FAILED` | 500 | Kalibrasi gagal |
| `FIRMWARE_INVALID` | 400 | Firmware file tidak valid |
| `UPDATE_IN_PROGRESS` | 409 | Update sedang berlangsung |
| `TYPE_NOT_FOUND` | 400 | Tipe equipment tidak ditemukan |
