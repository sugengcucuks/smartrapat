# Module 17: Audit

## Overview

Modul Audit menyediakan logging dan tracking untuk semua aktivitas user dalam sistem termasuk login history, action history, dan audit trail.

## API Endpoints

### 17.01 Activity Logs

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/audit/logs` | Get audit logs | Admin |
| GET | `/api/v1/audit/logs/{id}` | Get log detail | Admin |

### 17.02 Login History

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/audit/login-history` | Get login history | Admin |

### 17.03 Action History

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/audit/action-history` | Get action history | Admin |

### 17.04 Export & Search

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/audit/export` | Export audit logs | Admin |
| GET | `/api/v1/audit/search` | Search audit logs | Admin |

---

## Query Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `date_from` | string | Start date (ISO format) |
| `date_to` | string | End date (ISO format) |
| `user_id` | string | Filter by user |
| `module` | string | Filter by module |
| `action` | string | Filter by action type |
| `page` | int | Page number |
| `limit` | int | Items per page |

---

## Request/Response Examples

**GET /api/v1/audit/logs**

```json
{
  "success": true,
  "data": [
    {
      "id": "audit-001",
      "user": {
        "id": "user-xxx",
        "name": "Budi Santoso",
        "username": "budi.santoso"
      },
      "action": "booking.create",
      "module": "booking",
      "description": "Membuat booking baru",
      "details": {
        "booking_id": "booking-xxx",
        "title": "Rapat板门",
        "room": "Ruang Rapat 1"
      },
      "ip_address": "192.168.1.100",
      "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
      "status": "success",
      "created_at": "2026-09-18T10:00:00Z"
    },
    {
      "id": "audit-002",
      "user": {
        "id": "user-xxx",
        "name": "Budi Santoso",
        "username": "budi.santoso"
      },
      "action": "videowall.preset.apply",
      "module": "videowall",
      "description": "Apply preset video wall",
      "details": {
        "preset_id": "preset-xxx",
        "preset_name": "Full Board Meeting"
      },
      "ip_address": "192.168.1.100",
      "user_agent": "Mozilla/5.0 (iPad; CPU OS 14_0 like Mac OS X)",
      "status": "success",
      "created_at": "2026-09-18T09:45:00Z"
    },
    {
      "id": "audit-003",
      "user": {
        "id": "user-yyy",
        "name": "Ani Wijaya",
        "username": "ani.wijaya"
      },
      "action": "auth.login",
      "module": "auth",
      "description": "User login",
      "details": {
        "login_method": "password"
      },
      "ip_address": "192.168.1.101",
      "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
      "status": "success",
      "created_at": "2026-09-18T09:00:00Z"
    },
    {
      "id": "audit-004",
      "user": {
        "id": "user-zzz",
        "name": "Unknown",
        "username": "unknown"
      },
      "action": "auth.login",
      "module": "auth",
      "description": "Failed login attempt",
      "details": {
        "login_method": "password",
        "reason": "invalid_credentials"
      },
      "ip_address": "192.168.1.102",
      "user_agent": "Mozilla/5.0",
      "status": "failed",
      "created_at": "2026-09-18T08:30:00Z"
    }
  ],
  "meta": {
    "page": 1,
    "limit": 20,
    "total": 1250,
    "total_pages": 63
  }
}
```

**GET /api/v1/audit/login-history**

```json
{
  "success": true,
  "data": [
    {
      "id": "login-001",
      "user": {
        "id": "user-xxx",
        "name": "Budi Santoso",
        "username": "budi.santoso"
      },
      "action": "login_success",
      "ip_address": "192.168.1.100",
      "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
      "device_type": "desktop",
      "location": "Kantor Pusat",
      "created_at": "2026-09-18T09:00:00Z"
    },
    {
      "id": "login-002",
      "user": {
        "id": "user-xxx",
        "name": "Budi Santoso",
        "username": "budi.santoso"
      },
      "action": "logout",
      "ip_address": "192.168.1.100",
      "session_duration_minutes": 120,
      "created_at": "2026-09-18T11:00:00Z"
    },
    {
      "id": "login-003",
      "user": {
        "id": "user-xxx",
        "name": "Budi Santoso",
        "username": "budi.santoso"
      },
      "action": "login_success",
      "ip_address": "192.168.1.100",
      "user_agent": "Mozilla/5.0 (iPad; CPU OS 14_0 like Mac OS X)",
      "device_type": "tablet",
      "location": "Kantor Pusat",
      "created_at": "2026-09-18T11:05:00Z"
    }
  ]
}
```

**GET /api/v1/audit/search**

```json
// Query: GET /api/v1/audit/search?q=booking&date_from=2026-09-01&date_to=2026-09-18

{
  "success": true,
  "data": {
    "query": "booking",
    "filters": {
      "date_from": "2026-09-01",
      "date_to": "2026-09-18"
    },
    "results": [
      {
        "id": "audit-001",
        "user": { "name": "Budi Santoso" },
        "action": "booking.create",
        "description": "Membuat booking baru",
        "created_at": "2026-09-18T10:00:00Z",
        "relevance_score": 0.95
      }
    ],
    "total_results": 45,
    "search_time_ms": 125
  }
}
```

---

## Tracked Actions

### Authentication Module
| Action | Description |
|--------|-------------|
| `auth.login` | User login |
| `auth.login_failed` | Failed login |
| `auth.logout` | User logout |
| `auth.refresh_token` | Token refresh |
| `auth.forgot_password` | Password reset requested |
| `auth.change_password` | Password changed |

### Booking Module
| Action | Description |
|--------|-------------|
| `booking.create` | Booking dibuat |
| `booking.update` | Booking diupdate |
| `booking.cancel` | Booking dibatalkan |
| `booking.checkin` | Check-in |
| `booking.checkout` | Check-out |
| `booking.extend` | Meeting diperpanjang |
| `booking.approve` | Booking disetujui |
| `booking.reject` | Booking ditolak |

### Video Wall Module
| Action | Description |
|--------|-------------|
| `videowall.layout.create` | Layout dibuat |
| `videowall.layout.apply` | Layout di-apply |
| `videowall.preset.create` | Preset dibuat |
| `videowall.preset.apply` | Preset di-apply |
| `videowall.source.route` | Source di-route |

### Notulensi Module
| Action | Description |
|--------|-------------|
| `notulensi.start` | Recording dimulai |
| `notulensi.stop` | Recording dihentikan |
| `notulensi.summary.generate` | Summary di-generate |
| `notulensi.export` | Notulensi di-export |

### Admin Module
| Action | Description |
|--------|-------------|
| `user.create` | User dibuat |
| `user.update` | User diupdate |
| `user.delete` | User dihapus |
| `role.update` | Role diupdate |
| `settings.update` | Settings diupdate |

---

## Data Models

```typescript
interface AuditLog {
  id: string;
  user_id?: string;
  user?: UserSummary;
  action: string;
  module: string;
  description: string;
  details?: Record<string, any>;
  ip_address?: string;
  user_agent?: string;
  status: 'success' | 'failed';
  error_message?: string;
  created_at: DateTime;
}

interface LoginHistory {
  id: string;
  user_id: string;
  user: UserSummary;
  action: 'login_success' | 'login_failed' | 'logout' | 'session_expired';
  ip_address?: string;
  user_agent?: string;
  device_type?: 'desktop' | 'tablet' | 'mobile';
  location?: string;
  session_duration_minutes?: number;
  failure_reason?: string;
  created_at: DateTime;
}

interface UserSummary {
  id: string;
  name: string;
  username: string;
}

interface AuditSearchResult {
  id: string;
  user: UserSummary;
  action: string;
  description: string;
  created_at: DateTime;
  relevance_score: number;
}
```

---

## Log Retention

| Log Type | Retention Period |
|----------|-----------------|
| Login History | 90 days |
| Action Logs | 90 days |
| System Logs | 90 days |
| Security Logs | 1 year |
| Export Logs | 1 year |

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `AUDIT_LOG_NOT_FOUND` | 404 | Log tidak ditemukan |
| `INVALID_DATE_RANGE` | 400 | Range tanggal tidak valid |
| `EXPORT_FAILED` | 500 | Export gagal |
| `SEARCH_FAILED` | 500 | Search gagal |
