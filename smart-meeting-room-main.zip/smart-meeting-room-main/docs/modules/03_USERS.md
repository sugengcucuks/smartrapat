# Module 03: User Management

## Overview

Modul User Management menangani CRUD user, profile management, departments, dan import users.

## API Endpoints

### 03.01 User CRUD

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/users` | List all users (paginated) | Web Admin |
| POST | `/api/v1/users` | Create new user | Web Admin |
| GET | `/api/v1/users/{id}` | Get user detail | Web Admin |
| PUT | `/api/v1/users/{id}` | Update user | Web Admin |
| DELETE | `/api/v1/users/{id}` | Delete user | Web Admin |
| PUT | `/api/v1/users/{id}/password` | Set/reset user password | Web Admin |

### 03.02 User Profile

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/users/me` | Get current user profile | All |
| PUT | `/api/v1/users/me` | Update own profile | All |
| PUT | `/api/v1/users/me/avatar` | Upload profile picture | All |

### 03.03 User Import

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| POST | `/api/v1/users/import` | Import users from CSV | Web Admin |

### 03.04 User Groups

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/users/groups` | List user groups | Web Admin |
| POST | `/api/v1/users/groups` | Create user group | Web Admin |
| PUT | `/api/v1/users/groups/{id}` | Update user group | Web Admin |
| DELETE | `/api/v1/users/groups/{id}` | Delete user group | Web Admin |

### 03.05 Departments

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/users/departments` | List departments | Web Admin |
| POST | `/api/v1/users/departments` | Create department | Web Admin |
| PUT | `/api/v1/users/departments/{id}` | Update department | Web Admin |
| DELETE | `/api/v1/users/departments/{id}` | Delete department | Web Admin |

---

## Request/Response Examples

### GET /api/v1/users

**Query Parameters:**
- `page` (int): Page number, default 1
- `limit` (int): Items per page, default 20
- `search` (string): Search by name/username/email
- `role` (string): Filter by role
- `department` (string): Filter by department
- `is_active` (boolean): Filter by active status

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": "uuid-xxx",
      "username": "budi.santoso",
      "name": "Budi Santoso",
      "email": "budi@email.com",
      "role": {
        "id": "role-xxx",
        "name": "operator"
      },
      "department": {
        "id": "dept-xxx",
        "name": "IT"
      },
      "is_active": true,
      "last_login": "2026-09-18T08:30:00Z",
      "created_at": "2026-01-15T10:00:00Z"
    },
    {
      "id": "uuid-yyy",
      "username": "ani.wijaya",
      "name": "Ani Wijaya",
      "email": "ani@email.com",
      "role": { "id": "role-yyy", "name": "user" },
      "department": { "id": "dept-yyy", "name": "HR" },
      "is_active": true,
      "last_login": "2026-09-17T14:20:00Z",
      "created_at": "2026-02-01T09:00:00Z"
    }
  ],
  "meta": {
    "page": 1,
    "limit": 20,
    "total": 45,
    "total_pages": 3
  }
}
```

### POST /api/v1/users

**Request:**
```json
{
  "username": "dewi. Lestari",
  "name": "Dewi Lestari",
  "email": "dewi@email.com",
  "role_id": "role-xxx",
  "department_id": "dept-xxx",
  "password": "InitialPassword123"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "id": "uuid-new",
    "username": "dewi.lestari",
    "name": "Dewi Lestari",
    "email": "dewi@email.com",
    "role": { "id": "role-xxx", "name": "operator" },
    "department": { "id": "dept-xxx", "name": "IT" },
    "is_active": true,
    "created_at": "2026-09-18T10:00:00Z"
  }
}
```

### PUT /api/v1/users/{id}

**Request:**
```json
{
  "name": "Dewi Lestari S.Kom",
  "role_id": "role-admin",
  "department_id": "dept-yyy",
  "is_active": true
}
```

### POST /api/v1/users/import

**Request (multipart/form-data):**
- `file`: CSV file

**CSV Format:**
```csv
username,name,email,role,department
budi.santoso,Budi Santoso,budi@email.com,operator,IT
ani.wijaya,Ani Wijaya,ani@email.com,user,HR
```

**Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "imported": 2,
    "failed": 0,
    "errors": []
  }
}
```

---

## Data Models

### User

```typescript
interface User {
  id: string;                    // UUID
  username: string;              // Unique, 3-50 chars
  name: string;                  // Full name
  email: string;                 // Unique email
  role_id: string;
  role: Role;
  department_id?: string;
  department?: Department;
  avatar_url?: string;
  is_active: boolean;
  last_login?: DateTime;
  created_at: DateTime;
  updated_at: DateTime;
}

interface Role {
  id: string;
  name: string;                  // admin | operator | user
  description?: string;
}

interface Department {
  id: string;
  name: string;
  code?: string;
  parent_id?: string;            // For nested departments
}
```

---

## Validation Rules

| Field | Rules |
|-------|-------|
| username | 3-50 chars, alphanumeric + underscore, unique |
| name | 1-100 chars, required |
| email | Valid email format, unique |
| password | Min 8 chars, must contain uppercase, lowercase, number |
| role_id | Required, must exist |
| department_id | Optional, must exist if provided |

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `USER_NOT_FOUND` | 404 | User tidak ditemukan |
| `USER_EXISTS` | 409 | Username/email sudah ada |
| `ROLE_NOT_FOUND` | 400 | Role tidak ditemukan |
| `DEPT_NOT_FOUND` | 400 | Department tidak ditemukan |
| `IMPORT_FAILED` | 422 | Import CSV gagal |
| `INVALID_CSV` | 422 | Format CSV tidak valid |
