# Modul 11: Notulensi Otomatis

Rekam rapat → transkrip (faster-whisper, lokal) → pembicara dari mic/kursi → ringkasan
AI (Ollama, lokal) → koreksi notulis → finalisasi → export PDF/DOCX. Semua pemrosesan
berjalan di server sendiri; tidak ada audio/teks yang dikirim ke layanan cloud.

Kontrak antar-modul (hardware, MQTT, REST, WS): `docs/architecture/LIVE_MEETING.md`.

## Alur

```
Mode A/B  : mic → receiver M118 → audio interface → agent/recorder.py (PC Monitoring)
              VAD per kanal → segmen FLAC 16 kHz → POST /notes/recording/{booking}/segments (X-Agent-Key)
Mode C    : browser (getUserMedia) → potongan 10 detik → POST /notes/recording/{booking}/chunks
Unggah    : file rekaman penuh → POST /notes/{note}/transcribe-audio (field audio_file)
                 ↓
Backend   : UPLOAD_DIR/recordings/<booking>/<recording>/  → antrean STT (1 worker, services/transcription.py)
            → meeting_transcript_segments (kanal → audio_channels → room_seats → booking_seat_assignments → nama)
            → event WS transcript_segment / recording_status
Ringkasan : POST /notes/{note}/summarize → Ollama /api/chat (JSON schema) → summary_json, keputusan, action item (source=ai)
Final     : POST /notes/{note}/finalize (terkunci; /reopen butuh notes.write) → GET /notes/{note}/export/pdf|docx|txt|html
```

## Endpoint (prefix `/api/v1/notes`)

| Method | Path | Izin | Keterangan |
|---|---|---|---|
| GET | `/stt/status` | notes.view | `{engine_available, model, device, queue_size, last_error, ffmpeg_available, ...}` |
| GET | `/llm/status` | notes.view | `{reachable, model, model_available, models}` (dari `/api/tags`) |
| GET/POST | ``, `/{id}` PUT/DELETE | view / write | CRUD; `?search=&status=draft|final` pada daftar |
| GET/POST | `/by-booking/{booking_id}` | view | ambil / buat notulen untuk booking |
| POST | `/recording/{booking_id}/start` `{source}` | write atau pemilik booking | `multichannel|mix|browser`; satu rekaman aktif per booking |
| POST | `/recording/{booking_id}/pause|resume|stop` · GET `/status` | idem | `elapsed_ms` = waktu rekam efektif (tanpa jeda) |
| GET | `/recording/active?room_code=` | X-Agent-Key | untuk recorder; 204 bila tidak ada rekaman aktif |
| POST | `/recording/{booking_id}/segments` | X-Agent-Key atau JWT notes.write | multipart `audio`, `channel_no`, `start_ms`, `end_ms`, `recording_id`, `segment_uid` (idempoten) |
| POST | `/recording/{booking_id}/chunks` | write atau pemilik booking | multipart `audio` (webm/ogg/mp4/wav), `start_ms`, `speaker_name?`, `participant_id?`, `chunk_uid?` |
| POST | `/{id}/transcribe-audio` | edit | field `audio_file` (atau `audio`), maks `MAX_FILE_SIZE_MB`, diproses di latar (202) |
| GET | `/{id}/segments?after=<ISO>` | view | `{items, total, cursor, transcript_processing}` |
| POST/PATCH/DELETE | `/{id}/segments[/{seg}]` | edit | koreksi teks/pembicara (`is_edited=true`) |
| POST | `/{id}/summarize` | edit | 503 jelas bila Ollama mati / model belum di-pull |
| POST | `/{id}/finalize` · `/{id}/reopen` | edit · write | final = terkunci |
| GET | `/{id}/export/{pdf|docx|txt|html}?include_transcript=1` | view | alias lama: `/export/{id}/{fmt}` |
| GET/POST/PATCH/DELETE | `/{id}/action-items[/{item}]` | view / edit | `source`: manual|ai |

"edit" = `notes.write`, pembuat notulen, atau pemilik booking. Alias lama tetap ada:
`POST /recording/start {booking_id}`, `/meetings/{booking_id}/summarize|summary|action-items`,
`/{id}/regenerate-summary`.

## Instalasi di server

### 1. Paket Python & ffmpeg
```
pip install -r requirements.txt          # termasuk faster-whisper==1.2.1, numpy, soundfile
```
ffmpeg dianjurkan (mp3/m4a/webm dari berbagai browser, file panjang):
- Windows: `winget install Gyan.FFmpeg` (pastikan `ffmpeg` ada di PATH, lalu restart backend)
- Ubuntu/Debian: `sudo apt install ffmpeg`

Tanpa ffmpeg, WAV/FLAC/OGG dibaca lewat libsndfile dan webm/opus lewat PyAV (ikut
terpasang bersama faster-whisper); cek `ffmpeg_available` di `/notes/stt/status`.

### 2. Model Whisper (speech-to-text)
Diatur lewat `.env`:
```
WHISPER_MODEL=small          # tiny | base | small | medium | large-v3 (atau path folder model)
WHISPER_DEVICE=cpu           # cpu | cuda
WHISPER_COMPUTE_TYPE=int8    # CPU: int8 · GPU NVIDIA: float16 (atau int8_float16)
STT_LANGUAGE=id              # "auto" untuk deteksi bahasa
WHISPER_MODEL_DIR=           # folder cache model (opsional)
```
Panduan (bahasa Indonesia, rapat berjam-jam):

| Perangkat | Model | Perkiraan |
|---|---|---|
| CPU 4–8 core, RAM 8 GB | `small` + `int8` | ±0.3–0.6× waktu nyata; akurasi cukup |
| CPU 8+ core, RAM 16 GB | `medium` + `int8` | lebih akurat, ±1× waktu nyata (bisa tertinggal saat rapat ramai; antrean tetap aman) |
| GPU NVIDIA ≥ 6 GB VRAM | `large-v3` + `float16` | paling akurat, jauh lebih cepat dari waktu nyata |

Model diunduh otomatis dari HuggingFace saat pertama dipakai. Untuk server **offline**,
unduh di komputer lain (`python -c "from faster_whisper import WhisperModel; WhisperModel('small')"`),
salin folder `models--Systran--faster-whisper-small` ke cache server atau set
`WHISPER_MODEL` ke path folder model. Bila model gagal dimuat, job ditahan (audio tetap
tersimpan dan diproses ulang otomatis setelah backend di-restart) dan pesannya tampil di
`/notes/stt/status` serta di halaman notulensi.

### 3. Ollama (ringkasan AI)
```
# https://ollama.com/download  (Windows/Linux)
ollama pull qwen2.5:7b-instruct   # direkomendasikan untuk bahasa Indonesia
# alternatif: ollama pull llama3.1:8b
```
`.env`: `OLLAMA_BASE_URL=http://localhost:11434`, `OLLAMA_MODEL=qwen2.5:7b-instruct`,
`OLLAMA_TIMEOUT_SECONDS=600`. Model 7–8B butuh RAM ±8 GB; di CPU satu ringkasan rapat
1 jam bisa 1–5 menit. Transkrip panjang diringkas bertahap (map-reduce per ±6000 token).

### 4. Recorder multikanal (PC Monitoring)
```
cd agent
.\run-recorder.ps1 -InstallOnly        # buat venv + install sounddevice/soundfile/numpy/requests
.\.venv\Scripts\python recorder.py --list-devices
# edit recorder.yaml: backend_url, agent_key (= AGENT_API_KEY di .env server), room_code,
#                     input_device, peta channels (capture_channel -> channel_no), mode
.\run-recorder.ps1
```
- Recorder hanya merekam saat operator menekan **Mulai Rekam** dengan sumber
  Multichannel/Mix di aplikasi (poll tiap 2 detik; jeda/hentikan diikuti).
- Segmen disimpan dulu di `recorder_spool/` lalu dikirim; bila jaringan putus, dikirim
  ulang otomatis (idempoten lewat `segment_uid`). Segmen yang ditolak server dipindah ke
  `recorder_spool/rejected/`.
- VAD: ambang `-45 dBFS`, ucapan minimal 0.6 s, hangover 0.8 s, segmen maks 30 s,
  anti-crosstalk 15 dB (suara pembicara yang bocor ke mic tetangga diabaikan).
- Opsional `mqtt:` → publikasi `smr/audio/{room_code}/levels|active` (indikator
  "sedang bicara" untuk ruangan tanpa mixer X-Air).
- Mode B (mix): 2 kanal, pembicara tercatat "Grup A (Mic 1–8)" / "Grup B (Mic 9–16)";
  notulis mengoreksi nama di UI.

Setup data di aplikasi: Ruangan → Kanal Mic (channel_no) & Denah Kursi (kursi ↔ mic);
Live Meeting → penugasan kursi ↔ peserta. Nama pembicara = peserta di kursi tsb →
`display_name` penugasan → label kursi → label kanal → "Mic N".

### 5. Konfigurasi lain
- `UPLOAD_DIR` (default `./uploads`) → audio di `UPLOAD_DIR/recordings/<booking>/<recording>/`.
- `RECORDING_RETENTION_DAYS` (0 = simpan selamanya) → hapus audio lama otomatis.
- `MAX_FILE_SIZE_MB` → batas unggah rekaman penuh.
- Kop dokumen export: pengaturan sistem `org_name` & `org_address` (fallback `app_title`).
- Migrasi: `python scripts/migrate.py` (017: `meeting_note_action_items.source`, `meeting_recordings.paused_ms`).

## Pengujian

```
SMR_TEST_DB=smr_test_notes python -m pytest tests -q        # unit + suite keamanan
```
Uji end-to-end terhadap server berjalan (mesin STT palsu + Ollama palsu):
```
uvicorn tests.notes.fake_ollama:app --port 11999 &
STT_ENGINE=fake OLLAMA_BASE_URL=http://127.0.0.1:11999 OLLAMA_MODEL=qwen2.5:7b-instruct \
  AGENT_API_KEY=testagentkey123 uvicorn src.api.main:app --port 8104 &
SMR_E2E_URL=http://127.0.0.1:8104 python -m pytest tests/notes/test_e2e_api.py
```
`STT_ENGINE=fake` **hanya untuk pengujian** — menghasilkan teks berlabel `[STT uji]`,
bukan transkrip nyata. Default produksi: `faster_whisper`. Data seed e2e: ruangan
`RR-B3`, booking `3333…3333` (`psql -f tests/notes/e2e_seed.sql` pada DB uji).

## Batasan
- Satu worker STT (model dimuat sekali); rapat paralel di banyak ruangan mengantre.
- Ringkasan AI bersifat sinkron (request menunggu hingga selesai).
- Mode browser: pembicara tidak dikenali otomatis (pilih manual per potongan / koreksi).
- Tanpa mixer digital, mute per mic tidak tersedia (lihat LIVE_MEETING.md).
