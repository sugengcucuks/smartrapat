# Modul 19: Denah Kursi, Mic & Live Meeting

Kontrak lengkap: `docs/architecture/LIVE_MEETING.md`. Kode: `src/api/routers/live_meeting.py`,
`src/web/pages/rooms/RoomLayoutPage.tsx`, `src/web/pages/bookings/MeetingLivePage.tsx`,
`src/web/components/live/*`.

Rantai "siapa bicara": **kanal mic → kursi → peserta**. Kanal mic (`audio_channels`) dipasang
ke kursi pada denah ruangan (`room_seats`); per rapat, kursi diisi peserta
(`booking_seat_assignments`). Saat kanal Mic 3 aktif, konsol menyorot kursinya dan nama pesertanya.

## Panduan singkat

### 1. Buat denah ruangan (sekali per ruangan) — izin `rooms.write`

1. **Ruangan** → ikon **Denah & Mic** (`ri-layout`) pada baris ruangan → `/rooms/{id}/layout`.
2. **Buat Denah Otomatis**: pilih tata letak (Huruf U, Boardroom, Kelas, Melingkar), jumlah kursi
   (maks 64), jumlah kursi pimpinan, dan centang **Petakan kursi n → Mic n**.
   Bila ruangan belum punya kanal mic, sistem membuat Mic 1..N dengan label receiver
   `M118-A CH1..8`, `M118-B CH1..8` (`mixer_channel = capture_channel = n`).
3. Rapikan: seret kursi (posisi dibulatkan 1%), atau pilih kursi lalu geser dengan panah
   keyboard (Shift = 5%). Di panel kanan atur nomor, label, jenis kursi
   (Pimpinan/Peserta/Notulis/Tamu/Operator), arah hadap, dan **kanal mic**.
   Satu kanal hanya untuk satu kursi — memilih kanal yang sudah dipakai memindahkannya.
4. **Kanal Mic Ruangan** (di bawah denah) untuk mengubah label receiver/kanal mixer.
5. **Simpan Denah**. Id kursi tetap stabil; kursi yang dihapus ikut menghapus penempatan
   kursinya. Menghapus kursi / membuat ulang denah saat ada rapat **berlangsung** di ruangan
   itu ditolak (409).

### 2. Saat rapat — presensi otomatis memilih kursi

Peserta memindai QR tiket di layar pintu. Bila belum punya kursi, sistem menempatkan di kursi
kosong pertama (jenis **Peserta**, lalu **Tamu**; kursi Pimpinan/Notulis/Operator tidak pernah
diisi otomatis). Layar pintu menampilkan **"Silakan duduk di Kursi 7"**.

### 3. Konsol live — `/bookings/{id}/meeting`

- **Header**: status Terjadwal / Berlangsung / Selesai, timer dari jam server (sisa waktu
  terhadap jam selesai efektif), tombol **Mulai**, **+15 / +30 mnt**, **Akhiri** (pemilik booking
  atau `bookings.approve`).
  - Mulai: booking disetujui, hari ini, mulai 30 menit sebelum jadwal sampai jam selesai.
  - Perpanjang: ditolak bila bentrok dengan booking lain (disetujui/menunggu) di ruangan itu;
    layar pintu ikut diperbarui.
  - Akhiri: booking menjadi `completed` (ruangan kembali tersedia), rekaman aktif dihentikan.
- **Denah**: nama peserta per kursi, kursi redup = belum hadir, garis putus = kosong, cincin hijau
  berdenyut = sedang bicara, bar level mic (bila mixer/recorder mengirim level).
  Klik kursi → pilih peserta atau ketik nama tamu, atau **Kosongkan**. **Isi otomatis** menempatkan
  peserta yang belum punya kursi (yang sudah hadir lebih dulu; pemilik booking → kursi Pimpinan).
- **Tab**: Peserta (kehadiran live), Mic & Audio (mixer per kursi), Kontrol AV, Notulensi.
- Data diperbarui lewat WebSocket ruangan (`attendance_changed`, `seats_changed`,
  `meeting_status`) dengan polling cadangan tiap 15 detik.

## REST (prefix `/api/v1`)

| Method | Path | Izin |
|---|---|---|
| GET | `/rooms/{room_id}/seats` → `{seats[], audio_channels[], layout}` | `rooms.view` / `bookings.view` |
| PUT | `/rooms/{room_id}/seats` `{items: [{id?, seat_no, label, seat_type, pos_x, pos_y, rotation, audio_channel_id?}], layout?}` | `rooms.write` |
| POST | `/rooms/{room_id}/seats/generate` `{layout, count, chair_count=1, link_channels=true}` | `rooms.write` |
| GET | `/bookings/{id}/live` — snapshot booking, peserta, kursi+penugasan, kanal, rekaman aktif, `server_time` | pemilik, peserta, `bookings.view` |
| POST | `/bookings/{id}/meeting/start` \| `/meeting/end` \| `/meeting/extend {minutes: 5..120}` | pemilik / `bookings.approve` |
| GET | `/bookings/{id}/seat-assignments` | pemilik, peserta, `bookings.view` |
| PUT | `/bookings/{id}/seat-assignments` `{items: [{seat_id, participant_id?, display_name?, role_label?}], replace=false}` — item tanpa peserta & nama = kosongkan kursi | pemilik / `bookings.approve` |
| POST | `/bookings/{id}/seat-assignments/auto` `{strategy: attended_first\|all}` | pemilik / `bookings.approve` |

Kode error (`detail.code`): `DUPLICATE_SEAT_NO`, `DUPLICATE_CHANNEL`, `CHANNEL_NOT_IN_ROOM`,
`SEAT_NOT_IN_ROOM`, `SEAT_IN_LIVE_MEETING` (409), `PARTICIPANT_NOT_IN_BOOKING`,
`DUPLICATE_PARTICIPANT`, `NOT_APPROVED`, `NOT_TODAY`, `TOO_EARLY`, `TOO_LATE`,
`SCHEDULE_CONFLICT` (409), `MEETING_ENDED` (409), `MEETING_NOT_LIVE` (409).

Bentuk meja denah disimpan di `rooms.seat_layout` (migration 018).
Endpoint lama `/bookings/{id}/mic-assignments*` dihapus — diganti penempatan kursi.
