# Module 15: Settings

## Overview

Modul Settings mengelola semua pengaturan sistem termasuk general settings, appearance, integration, dan localization.

## Sub-Modules

```
15_SETTINGS
├── 15_01_GENERAL       # Organization info, working hours, holidays
├── 15_02_APPEARANCE   # Branding, logos, themes
├── 15_03_INTEGRATION  # API keys, webhooks, LDAP
└── 15_04_LOCALIZATION # Language, translations
```

---

## 15_01_GENERAL - General Settings

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/settings/general` | Get general settings | Admin |
| PUT | `/api/v1/settings/general` | Update general settings | Admin |
| GET | `/api/v1/settings/working-hours` | Get working hours | Admin |
| PUT | `/api/v1/settings/working-hours` | Set working hours | Admin |
| GET | `/api/v1/settings/holidays` | Get holidays | Admin |
| POST | `/api/v1/settings/holidays` | Add holiday | Admin |
| PUT | `/api/v1/settings/holidays/{id}` | Update holiday | Admin |
| DELETE | `/api/v1/settings/holidays/{id}` | Delete holiday | Admin |
| GET | `/api/v1/settings/timezone` | Get timezone | Admin |
| PUT | `/api/v1/settings/timezone` | Set timezone | Admin |

### Request/Response Examples

**GET /api/v1/settings/general**

```json
{
  "success": true,
  "data": {
    "organization": {
      "name": "Kementerian Pertahanan",
      "short_name": "Kemhan",
      "logo_url": "/uploads/logo.png",
      "favicon_url": "/uploads/favicon.ico"
    },
    "system": {
      "name": "Smart Meeting Room",
      "version": "1.0.0",
      "environment": "production"
    },
    "booking": {
      "max_advance_days": 30,
      "min_duration_minutes": 30,
      "max_duration_hours": 8,
      "allow_overlap": false,
      "auto_checkout_minutes": 15,
      "require_approval": false
    },
    "notifications": {
      "reminder_minutes_before": [15, 5],
      "auto_end_reminder": true
    }
  }
}
```

**PUT /api/v1/settings/general**

```json
{
  "organization": {
    "name": "Kementerian Pertahanan RI",
    "short_name": "Kemhan"
  },
  "booking": {
    "max_advance_days": 14,
    "min_duration_minutes": 15,
    "max_duration_hours": 4,
    "allow_overlap": false,
    "auto_checkout_minutes": 10,
    "require_approval": true
  }
}
```

**GET /api/v1/settings/working-hours**

```json
{
  "success": true,
  "data": {
    "timezone": "Asia/Jakarta",
    "working_days": ["monday", "tuesday", "wednesday", "thursday", "friday"],
    "working_hours": {
      "monday": { "start": "08:00", "end": "17:00" },
      "tuesday": { "start": "08:00", "end": "17:00" },
      "wednesday": { "start": "08:00", "end": "17:00" },
      "thursday": { "start": "08:00", "end": "17:00" },
      "friday": { "start": "08:00", "end": "16:30" }
    },
    "saturday": null,
    "sunday": null
  }
}
```

**GET /api/v1/settings/holidays**

```json
{
  "success": true,
  "data": [
    {
      "id": "holiday-001",
      "date": "2026-08-17",
      "name": "Hari Ulang Tahun Republik Indonesia",
      "is_recurring": true
    },
    {
      "id": "holiday-002",
      "date": "2026-12-25",
      "name": "Natal",
      "is_recurring": true
    },
    {
      "id": "holiday-003",
      "date": "2026-01-01",
      "name": "Tahun Baru",
      "is_recurring": true
    }
  ]
}
```

---

## 15_02_APPEARANCE - Appearance Settings

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/settings/appearance` | Get appearance settings | Admin |
| PUT | `/api/v1/settings/appearance` | Update appearance | Admin |
| POST | `/api/v1/settings/appearance/logo` | Upload logo | Admin |
| DELETE | `/api/v1/settings/appearance/logo` | Remove logo | Admin |
| GET | `/api/v1/settings/appearance/themes` | List themes | Admin |
| POST | `/api/v1/settings/appearance/themes` | Create theme | Admin |
| PUT | `/api/v1/settings/appearance/themes/{id}` | Update theme | Admin |

### Request/Response Examples

**GET /api/v1/settings/appearance**

```json
{
  "success": true,
  "data": {
    "theme": {
      "id": "theme-default",
      "name": "Default",
      "is_active": true
    },
    "colors": {
      "primary": "#1976D2",
      "secondary": "#424242",
      "accent": "#FFC107",
      "background": "#FFFFFF",
      "surface": "#F5F5F5",
      "error": "#D32F2F",
      "success": "#388E3C",
      "warning": "#FFA000"
    },
    "layout": {
      "sidebar_collapsed": false,
      "compact_mode": false
    },
    "custom_css": ""
  }
}
```

**PUT /api/v1/settings/appearance**

```json
{
  "theme_id": "theme-custom",
  "colors": {
    "primary": "#1E88E5",
    "secondary": "#37474F",
    "accent": "#FFB300"
  }
}
```

---

## 15_03_INTEGRATION - Integration Settings

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/settings/integration` | Get integrations | Admin |
| POST | `/api/v1/settings/integration/api-keys` | Generate API key | Admin |
| DELETE | `/api/v1/settings/integration/api-keys/{id}` | Revoke API key | Admin |
| GET | `/api/v1/settings/integration/webhooks` | List webhooks | Admin |
| POST | `/api/v1/settings/integration/webhooks` | Add webhook | Admin |
| PUT | `/api/v1/settings/integration/webhooks/{id}` | Update webhook | Admin |
| DELETE | `/api/v1/settings/integration/webhooks/{id}` | Delete webhook | Admin |
| POST | `/api/v1/settings/integration/webhooks/{id}/test` | Test webhook | Admin |
| POST | `/api/v1/settings/integration/ldap/sync` | Sync LDAP/AD | Admin |

### Webhook Events

| Event | Description |
|-------|-------------|
| `booking.created` | Booking baru dibuat |
| `booking.updated` | Booking diupdate |
| `booking.cancelled` | Booking dibatalkan |
| `booking.started` | Meeting dimulai |
| `booking.ended` | Meeting selesai |
| `recording.started` | Notulensi dimulai |
| `recording.completed` | Notulensi selesai |
| `room.status_changed` | Status ruangan berubah |

### Request/Response Examples

**POST /api/v1/settings/integration/webhooks**

```json
{
  "name": "Slack Integration",
  "url": "https://hooks.slack.com/services/xxx",
  "events": ["booking.created", "booking.cancelled"],
  "secret": "webhook_secret_xxx",
  "is_active": true
}
```

---

## 15_04_LOCALIZATION - Localization Settings

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/settings/localization` | Get localization | Admin |
| PUT | `/api/v1/settings/localization` | Update localization | Admin |
| GET | `/api/v1/settings/localization/translations` | Get translations | Admin |
| PUT | `/api/v1/settings/localization/translations` | Update translations | Admin |

### Request/Response Examples

**GET /api/v1/settings/localization**

```json
{
  "success": true,
  "data": {
    "default_language": "id",
    "supported_languages": [
      { "code": "id", "name": "Bahasa Indonesia", "native_name": "Bahasa Indonesia" },
      { "code": "en", "name": "English", "native_name": "English" }
    ],
    "date_format": "DD/MM/YYYY",
    "time_format": "HH:mm",
    "first_day_of_week": "monday"
  }
}
```

**GET /api/v1/settings/localization/translations**

```json
{
  "success": true,
  "data": {
    "language": "id",
    "translations": {
      "common": {
        "save": "Simpan",
        "cancel": "Batal",
        "delete": "Hapus",
        "edit": "Ubah",
        "search": "Cari",
        "loading": "Memuat...",
        "no_data": "Tidak ada data"
      },
      "booking": {
        "title": "Pemesanan",
        "create": "Buat Pemesanan",
        "edit": "Ubah Pemesanan",
        "cancel": "Batalkan Pemesanan",
        "room": "Ruang",
        "date": "Tanggal",
        "time": "Waktu",
        "participants": "Peserta"
      },
      "room": {
        "available": "Tersedia",
        "occupied": "Sedang Digunakan",
        "maintenance": "Pemeliharaan"
      }
    }
  }
}
```

---

## Data Models

```typescript
interface SystemSettings {
  organization: OrganizationSettings;
  system: SystemInfo;
  booking: BookingSettings;
  notifications: NotificationSettings;
}

interface OrganizationSettings {
  name: string;
  short_name: string;
  logo_url?: string;
  favicon_url?: string;
}

interface SystemInfo {
  name: string;
  version: string;
  environment: 'development' | 'staging' | 'production';
}

interface BookingSettings {
  max_advance_days: number;
  min_duration_minutes: number;
  max_duration_hours: number;
  allow_overlap: boolean;
  auto_checkout_minutes: number;
  require_approval: boolean;
}

interface WorkingHours {
  timezone: string;
  working_days: string[];
  working_hours: Record<string, { start: string; end: string } | null>;
}

interface Holiday {
  id: string;
  date: string;
  name: string;
  is_recurring: boolean;
}

interface AppearanceSettings {
  theme_id: string;
  colors: ColorPalette;
  layout: LayoutSettings;
  custom_css?: string;
}

interface ColorPalette {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  surface: string;
  error: string;
  success: string;
  warning: string;
}

interface Webhook {
  id: string;
  name: string;
  url: string;
  events: string[];
  secret?: string;
  is_active: boolean;
  created_at: DateTime;
}

interface LocalizationSettings {
  default_language: string;
  supported_languages: Language[];
  date_format: string;
  time_format: string;
  first_day_of_week: string;
}
```

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `SETTING_NOT_FOUND` | 404 | Pengaturan tidak ditemukan |
| `INVALID_SETTING_VALUE` | 400 | Nilai pengaturan tidak valid |
| `LOGO_UPLOAD_FAILED` | 400 | Upload logo gagal |
| `THEME_NOT_FOUND` | 404 | Theme tidak ditemukan |
| `WEBHOOK_NOT_FOUND` | 404 | Webhook tidak ditemukan |
| `WEBHOOK_TEST_FAILED` | 500 | Test webhook gagal |
| `TRANSLATION_INVALID` | 400 | Translation tidak valid |
