# Module 10: Booking Management

## Overview

Modul Booking Management menangani semua aspek pemesanan ruang rapat termasuk create, update, cancel, recurring bookings, conflict detection, dan check-in/out.

## Sub-Modules

```
10_BOOKINGS
├── 10_01_CORE          # CRUD bookings
├── 10_02_EXTENSIONS   # Extend, end early, copy, recurring
├── 10_03_CONFLICT     # Availability & conflict detection
└── 10_04_CHECKIN      # Check-in management
```

---

## 10_01_CORE - Core Booking

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/bookings` | List bookings (filtered) | All |
| POST | `/api/v1/bookings` | Create new booking | All |
| GET | `/api/v1/bookings/{id}` | Get booking detail | All |
| PUT | `/api/v1/bookings/{id}` | Update booking | Owner/Admin |
| DELETE | `/api/v1/bookings/{id}` | Cancel booking | Owner/Admin |
| GET | `/api/v1/bookings/{id}/attendees` | Get attendees | All |
| POST | `/api/v1/bookings/{id}/attendees` | Add attendee | Owner/Admin |
| DELETE | `/api/v1/bookings/{id}/attendees/{uid}` | Remove attendee | Owner/Admin |

### Request/Response Examples

**GET /api/v1/bookings**

**Query Parameters:**
- `room_id` (string): Filter by room
- `status` (string): Filter by status (SCHEDULED, ONGOING, COMPLETED, CANCELLED)
- `date_from` (string): Start date filter
- `date_to` (string): End date filter
- `organizer_id` (string): Filter by organizer
- `page` (int): Page number
- `limit` (int): Items per page

**Response (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": "booking-xxx",
      "room": {
        "id": "room-xxx",
        "name": "Ruang Rapat 1",
        "code": "RR01"
      },
      "title": "Rapat Evaluasi Kinerja Bulanan",
      "description": "Evaluasi kinerja divisi untuk bulan Agustus 2026",
      "organizer": {
        "id": "user-xxx",
        "name": "Budi Santoso"
      },
      "start_time": "2026-09-20T09:00:00Z",
      "end_time": "2026-09-20T11:00:00Z",
      "participants": [
        { "id": "user-1", "name": "Budi Santoso", "rsvp": "accepted" },
        { "id": "user-2", "name": "Ani Wijaya", "rsvp": "accepted" },
        { "id": "user-3", "name": "Dewi Lestari", "rsvp": "pending" }
      ],
      "equipment": ["videowall", "notulensi"],
      "status": "SCHEDULED",
      "is_recurring": false,
      "checked_in_at": null,
      "created_at": "2026-09-18T10:00:00Z"
    },
    {
      "id": "booking-yyy",
      "room": {
        "id": "room-xxx",
        "name": "Ruang Rapat 1",
        "code": "RR01"
      },
      "title": "Rapat板门",
      "description": "Rapat rutin mingguan",
      "organizer": {
        "id": "user-yyy",
        "name": "Ani Wijaya"
      },
      "start_time": "2026-09-20T14:00:00Z",
      "end_time": "2026-09-20T15:00:00Z",
      "participants": [
        { "id": "user-yyy", "name": "Ani Wijaya", "rsvp": "accepted" }
      ],
      "equipment": ["videowall"],
      "status": "SCHEDULED",
      "is_recurring": true,
      "recurring_group_id": "recurring-xxx",
      "created_at": "2026-09-17T15:00:00Z"
    }
  ],
  "meta": {
    "page": 1,
    "limit": 20,
    "total": 45,
    "total_pages": 3
  }
}
```

**POST /api/v1/bookings**

```json
{
  "room_id": "room-xxx",
  "title": "Rapat Evaluasi Kinerja Bulanan",
  "description": "Evaluasi kinerja divisi untuk bulan Agustus 2026",
  "start_time": "2026-09-20T09:00:00Z",
  "end_time": "2026-09-20T11:00:00Z",
  "participants": [
    { "user_id": "user-1", "name": "Budi Santoso" },
    { "user_id": "user-2", "name": "Ani Wijaya" }
  ],
  "equipment": ["videowall", "notulensi"],
  "notes": "Mohon prepare dokumen evaluasi"
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "id": "booking-new",
    "room_id": "room-xxx",
    "title": "Rapat Evaluasi Kinerja Bulanan",
    "status": "SCHEDULED",
    "start_time": "2026-09-20T09:00:00Z",
    "end_time": "2026-09-20T11:00:00Z",
    "created_at": "2026-09-18T10:30:00Z"
  }
}
```

**PUT /api/v1/bookings/{id}**

```json
{
  "title": "Rapat Evaluasi Kinerja - REVISI",
  "end_time": "2026-09-20T12:00:00Z",
  "participants": [
    { "user_id": "user-1", "name": "Budi Santoso" },
    { "user_id": "user-2", "name": "Ani Wijaya" },
    { "user_id": "user-3", "name": "Dewi Lestari" }
  ]
}
```

---

## 10_02_EXTENSIONS - Booking Extensions

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| POST | `/api/v1/bookings/{id}/extend` | Extend meeting duration | Operator |
| POST | `/api/v1/bookings/{id}/end-early` | End meeting early | Operator |
| POST | `/api/v1/bookings/{id}/copy` | Copy booking | All |
| GET | `/api/v1/bookings/{id}/history` | Get booking history | Admin |

### Request/Response Examples

**POST /api/v1/bookings/{id}/extend**

```json
// Request
{
  "extend_minutes": 30
}

// Response
{
  "success": true,
  "data": {
    "booking_id": "booking-xxx",
    "original_end_time": "2026-09-20T11:00:00Z",
    "new_end_time": "2026-09-20T11:30:00Z",
    "conflict_check": {
      "has_conflict": false,
      "conflicting_booking": null
    }
  }
}
```

**POST /api/v1/bookings/{id}/end-early**

```json
// Response
{
  "success": true,
  "data": {
    "booking_id": "booking-xxx",
    "ended_at": "2026-09-20T10:30:00Z",
    "original_end_time": "2026-09-20T11:00:00Z",
    "status": "COMPLETED"
  }
}
```

**POST /api/v1/bookings/{id}/copy**

```json
// Request
{
  "new_date": "2026-09-27",
  "new_start_time": "2026-09-27T09:00:00Z"
}

// Response
{
  "success": true,
  "data": {
    "original_booking_id": "booking-xxx",
    "new_booking_id": "booking-copy",
    "new_date": "2026-09-27",
    "new_start_time": "2026-09-27T09:00:00Z",
    "new_end_time": "2026-09-27T11:00:00Z"
  }
}
```

---

## 10_03_CONFLICT - Conflict & Availability

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/bookings/availability` | Check room availability | All |
| GET | `/api/v1/bookings/conflicts` | Check for conflicts | All |
| GET | `/api/v1/bookings/waitlist` | Get waitlist | Admin |
| POST | `/api/v1/bookings/waitlist` | Join waitlist | All |

### Recurring Bookings

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| POST | `/api/v1/bookings/recurring` | Create recurring booking | All |
| GET | `/api/v1/bookings/recurring/{id}` | Get recurring series | All |
| PUT | `/api/v1/bookings/recurring/{id}` | Update recurring series | Owner |
| DELETE | `/api/v1/bookings/recurring/{id}` | Delete recurring series | Owner |
| GET | `/api/v1/bookings/recurring/{id}/instances` | List instances | All |

### Request/Response Examples

**POST /api/v1/bookings/recurring**

```json
{
  "room_id": "room-xxx",
  "title": "Rapat板门 Mingguan",
  "description": "Rapat rutin setiap hari Jumat",
  "start_time": "2026-09-26T14:00:00Z",
  "end_time": "2026-09-26T15:00:00Z",
  "recurring_pattern": {
    "type": "weekly",
    "interval": 1,
    "days_of_week": ["friday"],
    "end_date": "2026-12-31"
  },
  "participants": [
    { "user_id": "user-1", "name": "Budi Santoso" }
  ],
  "equipment": ["videowall"]
}
```

**Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "recurring_group_id": "recurring-xxx",
    "booking_count": 14,
    "instances": [
      {
        "booking_id": "booking-instance-1",
        "date": "2026-09-26",
        "start_time": "2026-09-26T14:00:00Z",
        "end_time": "2026-09-26T15:00:00Z",
        "status": "SCHEDULED"
      },
      {
        "booking_id": "booking-instance-2",
        "date": "2026-10-03",
        "start_time": "2026-10-03T14:00:00Z",
        "end_time": "2026-10-03T15:00:00Z",
        "status": "SCHEDULED"
      }
    ]
  }
}
```

---

## 10_04_CHECKIN - Check-in Management

### API Endpoints

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| POST | `/api/v1/bookings/{id}/checkin` | Check in to meeting | Operator |
| POST | `/api/v1/bookings/{id}/checkout` | Check out from meeting | Operator |
| GET | `/api/v1/bookings/{id}/attendance` | Get attendance status | Owner/Admin |

### Booking Approvals

| Method | Endpoint | Description | Device |
|--------|----------|-------------|--------|
| GET | `/api/v1/bookings/pending` | List pending approvals | Admin |
| POST | `/api/v1/bookings/{id}/approve` | Approve booking | Admin |
| POST | `/api/v1/bookings/{id}/reject` | Reject booking | Admin |

### Request/Response Examples

**POST /api/v1/bookings/{id}/checkin**

```json
// Response
{
  "success": true,
  "data": {
    "booking_id": "booking-xxx",
    "checked_in_at": "2026-09-20T08:55:00Z",
    "room_status": "OCCUPIED",
    "equipment_ready": {
      "videowall": true,
      "audio": true,
      "notulensi": true
    }
  }
}
```

**POST /api/v1/bookings/{id}/checkout**

```json
// Response
{
  "success": true,
  "data": {
    "booking_id": "booking-xxx",
    "checked_out_at": "2026-09-20T10:55:00Z",
    "original_end_time": "2026-09-20T11:00:00Z",
    "status": "COMPLETED",
    "room_status": "AVAILABLE"
  }
}
```

---

## Data Models

```typescript
interface Booking {
  id: string;
  room_id: string;
  room: RoomSummary;
  title: string;
  description?: string;
  organizer_id: string;
  organizer: UserSummary;
  start_time: DateTime;
  end_time: DateTime;
  participants: Participant[];
  equipment: string[];
  status: BookingStatus;
  is_recurring: boolean;
  recurring_group_id?: string;
  parent_booking_id?: string;
  checked_in_at?: DateTime;
  checked_out_at?: DateTime;
  created_at: DateTime;
  updated_at: DateTime;
}

type BookingStatus = 
  | 'PENDING_APPROVAL'
  | 'SCHEDULED'
  | 'ONGOING'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'NO_SHOW';

interface Participant {
  user_id: string;
  name: string;
  rsvp?: 'accepted' | 'declined' | 'pending';
}

interface RecurringPattern {
  type: 'daily' | 'weekly' | 'monthly';
  interval: number;
  days_of_week?: string[];
  day_of_month?: number;
  end_date: DateTime;
  count?: number;
}

interface RoomSummary {
  id: string;
  name: string;
  code: string;
}

interface UserSummary {
  id: string;
  name: string;
}
```

---

## Booking Status Flow

```
PENDING_APPROVAL (if approval required)
       │
       ├── [approved] ──▶ SCHEDULED
       │
       └── [rejected] ──▶ CANCELLED

SCHEDULED
       │
       ├── [check-in] ──▶ ONGOING
       │
       ├── [cancelled] ──▶ CANCELLED
       │
       └── [no show + 15min] ──▶ NO_SHOW

ONGOING
       │
       ├── [check-out / end_time] ──▶ COMPLETED
       │
       └── [extended] ──▶ ONGOING (new end_time)
```

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `BOOKING_NOT_FOUND` | 404 | Booking tidak ditemukan |
| `BOOKING_CONFLICT` | 409 | Ruang sudah dibooking |
| `BOOKING_PAST` | 400 | Tidak bisa booking waktu lalu |
| `BOOKING_CANCELLED` | 400 | Booking sudah dibatalkan |
| `INVALID_DURATION` | 400 | Durasi tidak valid |
| `ROOM_NOT_AVAILABLE` | 400 | Ruang tidak tersedia |
| `NO_SHOW_DETECTED` | 400 | No-show terdeteksi |
| `UNAUTHORIZED` | 403 | Tidak punya akses |
