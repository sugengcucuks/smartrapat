# Modul 08: Videowall

Wall **LG 55VL5PJ 3×2** (6 panel) digerakkan processor **Digibird DB-VWC2-B-4H8H-PV**
(4 HDMI in, 8 HDMI out, LAN UDP 5000 / RS232). Kontrol per ruangan lewat device agent.

## Perangkat

| Perangkat | Aksi agent | Protokol |
|---|---|---|
| Panel LG (`tv`) | `power_on` | Wake-on-LAN (+ opsional IP control `ka 01 01`) |
| | `power_off` | IP control TCP 9761 `ka 01 00` (atau SSAP `ssap://system/turnOff`) |
| | health | `ka 01 ff` → `a 01 OK01x` (on) / `OK00x` (off) |
| Digibird (`videowall_controller`) | `apply_layout {scene}` | UDP `[call,{scene}]` → `[OK]`/`[ERR]` |
| | `change_source {input, window}` | UDP `[SWCH,{input},{window},1]` |
| | `power_off` | `[SALL]` (tutup semua jendela) |

**Power ON ruangan** = WoL semua panel + controller; **power OFF** = IP control off semua
panel + `[SALL]`. Perintah dikirim paralel, backend menunggu ack masing-masing ≤ 3 dtk.

## Preset & sumber — satu sumber kebenaran

Diambil dari `devices.config` milik `videowall_controller` ruangan; bila kosong dipakai default:

| id | label | scene Digibird | jendela |
|---|---|---|---|
| `fullscreen` | Fullscreen (1 layar penuh) | 1 | 1 |
| `split2` | 2 Layar (kiri \| kanan) | 2 | 2 |
| `main_side` | Utama + 2 samping | 3 | 3 |
| `quad` | 4 Jendela (2x2) | 4 | 4 |
| `panels6` | 6 Panel terpisah (3x2) | 5 | 6 |

Sumber default `hdmi1..hdmi4` → input 1..4. **Scene harus disimpan dulu di processor**
(app DigiBird, `[save,ID]`) dengan nomor di atas. Contoh config kustom:

```json
{"presets": [{"id": "fullscreen", "label": "Fullscreen", "scene": 1,
              "windows": [{"id": 1, "x": 0, "y": 0, "w": 1, "h": 1}]}],
 "sources": [{"id": "hdmi1", "label": "Laptop Meja", "code": 1}],
 "grid": {"cols": 3, "rows": 2},
 "panels": ["TV-PANEL-1", "TV-PANEL-2"]}
```

`windows` (pecahan 0..1) hanya untuk pratinjau UI. `panels` opsional (default: semua `tv` di ruangan).

## REST

| Method | Path | Izin |
|---|---|---|
| GET | `/rooms/{room_id}/av/capabilities` — preset, sumber, grid, controller, panel, audio | `rooms.view`/`devices.view` |
| GET | `/rooms/{room_id}/av/state` — perangkat + state live, mixer, level, pembicara | idem |
| POST | `/rooms/{room_id}/av/videowall/power-on`, `/power-off` | `videowall.control` |
| POST | `/rooms/{room_id}/av/videowall/layout` `{"preset": "quad"}` | `videowall.control` |
| POST | `/rooms/{room_id}/av/videowall/source` `{"source": "hdmi2", "window": 1}` | `videowall.control` |
| GET/POST/PUT/DELETE | `/videowall`, `/videowall/{id}` — skenario tersimpan (`layout_mode` = id preset, `inputs: [{input, window}]`) | baca `devices.view`; tulis `videowall.control`/`devices.write` |
| POST | `/videowall/{id}/apply` — preset lalu sumber per jendela (berurutan) | `videowall.control` |
| POST | `/videowall/rooms/{room_id}/power-on\|power-off\|layout\|source` — alias lama | `videowall.control` |

Preset/sumber tak dikenal → 400 (`INVALID_PRESET` / `INVALID_SOURCE`). Migrasi 016 mengubah
`videowall_configs.layout_mode` dari enum lama ke VARCHAR (2x2→quad, 3x3→panels6, …).

## UI

- `src/web/components/av/RoomControlPanel.tsx` (`roomId`, `compact?`, `variant?`, `live?`)
- Halaman: Videowall (`/videowall`), Mobile (`/m/:room_code`).
