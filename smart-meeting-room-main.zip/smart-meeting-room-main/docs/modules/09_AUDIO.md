# Modul 09: Audio & Mikrofon

Hardware terpasang: 2× **Ashley M118** (receiver UHF 8 kanal, 16 mic gooseneck) →
**FC-A5400** (amplifier analog). Keduanya **tanpa port kontrol**. Kontrol mic per kursi
butuh digital mixer **Behringer XR18 / Midas MR18** (OSC UDP 10024) — lihat
`docs/architecture/LIVE_MEETING.md` §1 dan `agent/README.md`.

## Dua mode

| Mode | Syarat | Kemampuan |
|---|---|---|
| `xair` | Device `audio_mixer` (`config.driver = "xair"`) di ruangan + agent dengan blok XR18 | mute/unmute per mic, mute semua, fader (per kanal & master), gain, **level meter** & pembicara aktif dari mixer |
| `none` | Tanpa mixer | Perintah audio → **409** `MIXER_NOT_INSTALLED` "Mixer tidak terpasang; atur manual di receiver"; level/pembicara dari recorder multikanal (bila ada) |

## Kanal mic (`audio_channels`)

`channel_no` (1..64, unik per ruangan), `label`, `receiver_label` (mis. "M118-A CH3"),
`mixer_channel` (kanal XR18), `capture_channel` (kanal audio interface untuk recorder), `enabled`.
Default 16 kanal: Mic 1..16 = M118-A CH1..8 + M118-B CH1..8, `mixer_channel = capture_channel = n`.
Kursi (`room_seats.audio_channel_id`) merujuk kanal ini → pembicara aktif dipetakan ke kursi & peserta.

## REST

| Method | Path | Izin |
|---|---|---|
| GET | `/rooms/{room_id}/audio-channels` | `rooms.view` |
| PUT | `/rooms/{room_id}/audio-channels` `{"channels": [...]}` — ganti batch; `channel_no`/`mixer_channel`/`capture_channel` unik; id dipertahankan per `channel_no` | `rooms.write` |
| POST | `/rooms/{room_id}/av/audio/mic/{channel_no}/mute\|unmute` | `audio.control` |
| POST | `/rooms/{room_id}/av/audio/mute-all\|unmute-all` | `audio.control` |
| POST | `/rooms/{room_id}/av/audio/fader` `{"target": 3 \| "main", "value": 0..1}` | `audio.control` |
| POST | `/rooms/{room_id}/av/audio/gain` `{"channel_no": 3, "db": -12..60}` | `audio.control` |
| GET | `/audio/microphones?room_id=` — kanal + `muted/fader/gain/level_db/active` live | `devices.view`/`audio.control`/`rooms.view` |
| CRUD | `/audio/zones` — zona speaker; kontrol (`/volume`, `/mute`, `/unmute`, `/source`) hanya bila zona punya `device_id`, selain itu 409 | tulis `audio.control`/`devices.write` |

Semua perintah mengembalikan `{cmd_id, status: acked|failed|timeout, error, results}`.
Mixer X-Air tidak membalas perintah set, jadi agent **memverifikasi dengan query ulang**:
`acked` berarti nilai di mixer benar-benar berubah.

## Realtime (WS `/api/v1/ws/rooms/{room_id}/live?token=`)

- `audio_levels` `{levels: {channel_no: dBFS}}` maks 5 Hz
- `active_speakers` `{channels, seats, participants, booking_id}` (ambang −45 dBFS, hold 800 ms di agent)
- `mixer_state` `{channels: {channel_no: {muted, fader, gain}}, main: {muted, fader}}`

Agent X-Air mengirim nomor **kanal mixer** dengan `"key": "mixer_channel"`; backend
menerjemahkannya ke `channel_no` lewat `audio_channels.mixer_channel`.

## UI

- `src/web/components/av/MicMixerPanel.tsx` (`roomId`, `seatsByChannel?`, `compact?`, `variant?`, `live?`)
- `src/web/components/av/AudioChannelEditor.tsx` — tab "Kanal Mic" di halaman Audio (`/audio`).
