# SMART MEETING ROOM - System Specification

**Versi:** 2.5  
**Tanggal:** 2026-09-29  
**Status:** In Development — modul inti + Live Meeting/Denah Kursi/Transkrip + Presensi/Lisensi/Kiosk/Deployment/Device-Agent + Pencarian FTS/Dashboard Tindak Lanjut/Setup Wizard terimplementasi; pytest 120 passed + 5 skipped + smoke E2E lulus  

---

## Overview

Dokumentasi sistem Smart Meeting Room terdiri dari module-module berikut:

| No | Module | File | Deskripsi |
|----|--------|------|-----------|
| 01 | Main Index | `SPEC.md` | Dokumen utama (file ini) |
| 02 | Authentication | `modules/02_AUTH.md` | Login, logout, session management |
| 03 | Users | `modules/03_USERS.md` | Manajemen pengguna |
| 04 | Roles | `modules/04_ROLES.md` | Role & permission management |
| 05 | Rooms | `modules/05_ROOMS.md` | Manajemen ruang rapat |
| 06 | Equipment | `modules/06_EQUIPMENT.md` | Manajemen peralatan |
| 07 | Devices | `modules/07_DEVICES.md` | Manajemen perangkat |
| 08 | Video Wall | `modules/08_VIDEOWALL.md` | Kontrol video wall |
| 09 | Audio | `modules/09_AUDIO.md` | Kontrol audio |
| 10 | Bookings | `modules/10_BOOKINGS.md` | Manajemen pemesanan |
| 11 | Notulensi | `modules/11_NOTULENSI.md` | Notulensi otomatis |
| 12 | Calendar | `modules/12_CALENDAR.md` | Kalendar & jadwal |
| 13 | Notifications | `modules/13_NOTIFICATIONS.md` | Notifikasi |
| 14 | Reports | `modules/14_REPORTS.md` | Laporan & analytics |
| 15 | Settings | `modules/15_SETTINGS.md` | Pengaturan sistem |
| 16 | Door Display | `modules/16_DOOR_DISPLAY.md` | Door display |
| 17 | Audit | `modules/17_AUDIT.md` | Audit trail |
| 18 | Maintenance | `modules/18_MAINTENANCE.md` | Pemeliharaan |

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                      SMART MEETING ROOM                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐       │
│   │  iPad   │  │  Door    │  │  PC      │  │ Hardware │       │
│   │Controller│  │ Display  │  │Monitoring│  │Interfaces│       │
│   │(Touch)  │  │(Android) │  │ (Server) │  │          │       │
│   └────┬────┘  └────┬─────┘  └────┬─────┘  └────┬────┘       │
│        │             │             │              │              │
│        └─────────────┴──────┬──────┴──────────────┘              │
│                            │                                     │
│                    ┌───────┴───────┐                             │
│                    │  REST API     │                             │
│                    │  (FastAPI)    │                             │
│                    └───────┬───────┘                             │
│                            │                                     │
│        ┌───────────────────┼───────────────────┐                 │
│        │                   │                   │                 │
│   ┌────┴────┐        ┌─────┴─────┐       ┌────┴────┐            │
│   │Booking  │        │VideoWall │       │Notulensi│            │
│   │Service  │        │Service   │       │Service  │            │
│   └─────────┘        └──────────┘       └─────────┘            │
│                                                                  │
│   ┌─────────────────────────────────────────────────────┐       │
│   │              PostgreSQL Database                      │       │
│   └─────────────────────────────────────────────────────┘       │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Teknologi Stack

| Layer | Teknologi | Justifikasi |
|-------|-----------|-------------|
| **Backend** | FastAPI (Python 3.11+) | High performance, auto-generated docs, async support |
| **Database** | PostgreSQL 15 | Robust, reliable, JSON support |
| **Frontend (Web)** | React + TypeScript + Vite | Component-based, maintainable |
| **Frontend (iPad)** | React + TypeScript (PWA) | Cross-platform, touch-optimized |
| **Frontend (Door)** | React Native Android | Native Android performance |
| **AI/STT** | Faster Whisper + pyannote | Local, accurate, open-source |
| **AI/Summary** | Local LLM (Gemma 2B via Ollama) | 100% local processing |
| **PDF Export** | WeasyPrint | Free, Python-native, professional output |
| **DOCX Export** | python-docx | Free, well-supported |

---

## Device-Specific Feature Matrix

| Feature | Web Admin | Web User | iPad Operator | Mobile | Door Display |
|---------|-----------|----------|---------------|--------|--------------|
| **Authentication** | ✅ | ✅ | ✅ | ✅ | ❌ |
| User Management | ✅ | ❌ | ❌ | ❌ | ❌ |
| Role Management | ✅ | ❌ | ❌ | ❌ | ❌ |
| Room Management | ✅ | Read-only | ❌ | ❌ | ❌ |
| Equipment Config | ✅ | ❌ | ❌ | ❌ | ❌ |
| Video Wall Control | ✅ | ❌ | ✅ | ❌ | ❌ |
| Audio Control | ✅ | ❌ | ✅ | ❌ | ❌ |
| Create Booking | ✅ | ✅ | ✅ | ✅ | ✅ |
| View Schedule | ✅ | ✅ | ✅ | ✅ | ✅ |
| Quick Book | ❌ | ❌ | ❌ | ❌ | ✅ |
| Notulensi Control | ✅ | ❌ | ✅ | ❌ | ❌ |
| View Transcript | ✅ | ✅ | ✅ | ✅ | ❌ |
| Export Minutes | ✅ | ✅ | ✅ | ✅ | ❌ |
| Reports | ✅ | ❌ | ❌ | ❌ | ❌ |
| System Settings | ✅ | ❌ | ❌ | ❌ | ❌ |
| Door Display Config | ✅ | ❌ | ✅ | ❌ | ❌ |

---

## Common API Response Format

### Success Response

```json
{
  "success": true,
  "data": { ... },
  "meta": {
    "page": 1,
    "limit": 20,
    "total": 100
  }
}
```

### Error Response

```json
{
  "success": false,
  "error": {
    "code": "BOOKING_CONFLICT",
    "message": "Ruangan sudah dibooking pada waktu tersebut",
    "details": { ... }
  }
}
```

### Common Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `AUTH_INVALID` | 401 | Invalid credentials |
| `AUTH_EXPIRED` | 401 | Token expired |
| `PERMISSION_DENIED` | 403 | No permission |
| `NOT_FOUND` | 404 | Resource not found |
| `BOOKING_CONFLICT` | 409 | Booking time conflict |
| `VALIDATION_ERROR` | 422 | Request validation failed |
| `DEVICE_OFFLINE` | 503 | Hardware device offline |
| `LICENSE_REQUIRED` | 402 | Lisensi tidak aktif / kedaluwarsa (blokir total) |

---

## WebSocket Events

### Room Status Updates

```javascript
// Subscribe
ws://server:8000/ws/room/{room_id}

// Events
{
  "event": "status_changed",
  "data": {
    "room_id": "room-xxx",
    "status": "OCCUPIED",
    "current_meeting": { ... }
  }
}
```

### Live Transcript

```javascript
// Subscribe to live transcript
ws://server:8000/ws/notulensi/{recording_id}

// Events
{
  "event": "segment",
  "data": {
    "speaker": "Pimpinan Rapat",
    "text": "Ayo kita mulai rapat...",
    "start_time": 15.5,
    "confidence": 0.95
  }
}
```

### Live Meeting Hub (terimplementasi) — `src/api/routers/live_ws.py`

```javascript
// Auth via query param token (JWT), wajib rooms.view / bookings.view
ws://server:8000/api/v1/ws/rooms/{room_id}/live?token=<access_token>

// Server → klien: {"event", "room_id", "data", "ts"}
// Saat connect: "connected" + state awal (device_state, mixer_state, audio_levels, active_speakers)
// Push berkala dari MQTT → hub (audio_levels throttled maks 5 Hz):
{ "event": "audio_levels",   "data": { "ch1": 0.42, ... } }
{ "event": "active_speakers","data": { "seat_no": 3, "participant": "..." } }
{ "event": "seats_changed",  "data": { ... } }        // perubahan denah/assignment
{ "event": "meeting_status", "data": { "status": "live" } }
{ "event": "recording_status","data": { ... } }
{ "event": "transcript_segment", "data": { ... } }
// Klien → server: hanya {"type":"ping"} → dijawab "pong"
```

---

## Database Schema (Core Tables)

```sql
-- Users
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    role_id UUID REFERENCES roles(id),
    department_id UUID REFERENCES departments(id),
    avatar_url VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Rooms
CREATE TABLE rooms (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    code VARCHAR(20) UNIQUE NOT NULL,
    capacity INTEGER NOT NULL,
    floor INTEGER,
    building VARCHAR(100),
    description TEXT,
    facilities JSONB DEFAULT '[]',
    status VARCHAR(20) DEFAULT 'AVAILABLE',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bookings
CREATE TABLE bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id UUID REFERENCES rooms(id),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    organizer_id UUID REFERENCES users(id),
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    participants JSONB DEFAULT '[]',
    equipment JSONB DEFAULT '[]',
    status VARCHAR(20) DEFAULT 'SCHEDULED',
    is_recurring BOOLEAN DEFAULT FALSE,
    recurring_group_id UUID,
    parent_booking_id UUID REFERENCES bookings(id),
    checked_in_at TIMESTAMP,
    checked_out_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Meetings (for notulensi)
CREATE TABLE meetings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID REFERENCES bookings(id),
    room_id UUID REFERENCES rooms(id),
    title VARCHAR(255) NOT NULL,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    status VARCHAR(20) DEFAULT 'ONGOING',
    summary TEXT,
    action_items JSONB DEFAULT '[]',
    decisions JSONB DEFAULT '[]',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Transcript Segments
CREATE TABLE transcript_segments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    meeting_id UUID REFERENCES meetings(id),
    start_time FLOAT NOT NULL,
    end_time FLOAT NOT NULL,
    speaker_id VARCHAR(50) NOT NULL,
    speaker_name VARCHAR(100),
    text TEXT NOT NULL,
    language VARCHAR(10) DEFAULT 'id',
    confidence FLOAT DEFAULT 1.0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## Server Specifications (PC Monitoring MSI)

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| CPU | Core Ultra 7 | Core Ultra 9 |
| RAM | 16GB | 32GB |
| GPU | RTX 3060 8GB | RTX 5060 8GB |
| Storage | 512GB NVMe | 2TB NVMe |
| OS | Windows 11 Pro | Windows 11 Pro |

---

## Modul Tambahan Terimplementasi

Modul berikut sudah diimplementasikan dan diverifikasi end-to-end.

### 19. Presensi QR — `/api/v1/presensi`

Presensi peserta rapat via scan QR tiket.

| Method | Endpoint | Deskripsi |
|--------|----------|-----------|
| GET | `/presensi/tickets/my` | Tiket QR milik user login |
| GET | `/presensi/tickets/{participant_id}` | Detail tiket peserta |
| POST | `/presensi/scan` | Scan code tiket → catat hadir (duplikat/token asing ditolak) |
| GET | `/presensi/bookings/{booking_id}/attendance` | Rekap kehadiran per rapat |

- Tiket & `ticket_code` unik dibuat otomatis saat booking (migrasi `009_participant_ticket_code.sql`).
- Frontend: `MyTicketsPage` (tampil QR), `PresensiScannerPage` (kamera scan via `useQrScanner` + bunyi `chime.ts`), tombol **PRESENSI** di kiosk `PublicRoomDisplayPage`.
- Implementasi: `src/api/routers/presensi.py`, `src/api/utils/ticket.py`.

### 20. Lisensi (SaaS Licensing) — `/api/v1/license`

Aplikasi terkunci lisensi offline bertanda tangan **Ed25519** + fingerprint mesin.

| Method | Endpoint | Deskripsi |
|--------|----------|-----------|
| GET | `/license/status` | Status lisensi perangkat (aktif, sisa hari, fingerprint) |
| GET | `/license/fingerprint` | Fingerprint mesin untuk permintaan lisensi ke vendor |
| POST | `/license/activate` | Simpan & verifikasi berkas lisensi (`license.key`) |

- **Gating blokir total**: middleware `src/api/middleware/license_gate.py` menolak semua endpoint (kecuali `/license/*`, `/auth/login|refresh`, `/docs`, `/health`) dengan **402 `LICENSE_REQUIRED`** bila lisensi tidak aktif/kedaluwarsa.
- Verifikasi: signature Ed25519 + fingerprint mesin + masa berlaku (`src/api/licensing/`: `core.py`, `fingerprint.py`, `service.py`).
- Generator lisensi vendor: CLI `src/api/licensing/` (sign berkas lisensi per customer).
- Frontend: halaman aktivasi `src/web/pages/license/LicenseActivatePage.tsx` + banner status di admin.

### 21. Kiosk Security — ADM-03/04, DSP-07/09

Pengamanan kiosk pintu ruangan.

| Kode | Fitur | Endpoint |
|------|-------|----------|
| ADM-03 | Generate/regenerate Pairing Key `RM-XXXXXX` per ruangan | `POST /rooms/{id}/pairing-key/regenerate` |
| ADM-04 | Set Master PIN kiosk (4–8 digit, bcrypt) | `PUT /rooms/{id}/master-pin` |
| DSP-09 | Setup pairing di kiosk (layar gate sebelum data tampil) | `POST /door-display/pair` |
| DSP-07 | Buka ruangan lebih awal via Master PIN | `POST /door-display/early-release/{booking_id}` |

- **Alur pairing**: admin buat key dari dashboard → kiosk buka `/public/room/{room_code}` → layar pairing → submit key → sukses → flag `kiosk_paired_{room_code}` di localStorage → data + WebSocket dimuat. Key lama otomatis hangus setelah regenerate.
- **Early Release**: kiosk rapat berjalan → modal input PIN → verifikasi bcrypt → booking berjalan/draft/pending/approved diakhiri → WS broadcast `early_released`.
- DB (migrasi `010_kiosk_security.sql`): `rooms.pairing_key`, `rooms.master_pin_hash`.
- Frontend: pairing gate + modal PIN di `PublicRoomDisplayPage.tsx`; modal admin ADM-03/04 di `RoomListPage`.
- Akses admin endpoint: role `Super Admin`/`Admin`/`Staff` (normalisasi variasi penulisan nama role).

### 22. Deployment — DEP-01/02

| Kode | Fitur | File |
|------|-------|------|
| DEP-02 | One-command dev launcher (venv + deps + backend + frontend) | `start-dev.ps1` |
| — | Production launcher: build frontend + **single port 8000** (API + WS + UI) | `start-prod.ps1` |
| DEP-01 | Installer kiosk desktop: shortcut fullscreen + auto-restart | `kiosk/install-kiosk.ps1` |
| — | Kiosk launcher Edge/Chrome `--kiosk` + watchdog + profil terisolasi per ruangan | `kiosk/start-kiosk.ps1` |

- Mode produksi: FastAPI menyajikan hasil `vite build` (folder `dist/`) — SPA fallback di semua path non-API; license gate hanya memblokir `/api/*` dan `/ws/*` sehingga halaman aktivasi tetap tampil.

Contoh setup PC kiosk:

```powershell
# Server (produksi, single port)
.\start-prod.ps1

# PC kiosk (sekali saja)
.\kiosk\install-kiosk.ps1 -RoomCode A101 -ServerUrl http://<ip-server>:8000 -Autostart
```

### 23. Kontrol Device via MQTT & Agent — v2.3

Kontrol perangkat fisik via MQTT: backend publish perintah, agent lokal eksekusi ke hardware.

| Komponen | File | Peran |
|----------|------|-------|
| Publisher (backend) | `src/api/utils/mqtt_client.py` | `MqttManager` singleton — publish command, fallback mock jika broker mati (tidak pernah throw) |
| Agent (edge) | `agent/device_agent.py` | Subscribe `{prefix}/+/command/+` (QoS 1), eksekusi step ke hardware |
| Mapping device | `agent/devices.yaml` | UUID/code perangkat → langkah protokol per action |
| Broker | Mosquitto (docker-compose, port 1883) | Message bus lokal |

- **Topic**: `smr/devices/{device_id}/command/{action}` — action: `power_on`, `power_off`, `apply_layout`, `change_source`, dll.
- **Env backend**: `MQTT_BROKER_URL`, `MQTT_PORT`, `MQTT_USERNAME`, `MQTT_PASSWORD`, `MQTT_TOPIC_PREFIX` (`.env` di-load via `load_dotenv()` di `main.py`). Tanpa broker, response API tetap sukses dengan `"via": "mock"`.
- **Protokol yang didukung agent** (step di `devices.yaml`): `wol` (Wake-on-LAN), `tcp`, `udp`, `ssap` (webOS LG, port 3000), `serial` (RS232), `delay`, plus template payload `{payload.field}` dan mapping label→nilai (`map:`).
- **Perangkat terpetakan**: 6 panel LG 55VL5PJ videowall 3x2 (power ON via WoL, OFF via `ssap://system/turnOff`, pairing sekali via `python device_agent.py --pair <ip-tv>`), video processor Digibird DB-VWC2-B-4H8H-PV (UDP port 5000, ASCII `[SWCH,src,sub,wid]`, `[call,ID]`, `[SALL]`), HDMI switch GainTech (opsional, RS232).
- Jalankan agent di PC yang satu LAN dengan perangkat:

```powershell
venv\Scripts\python agent\device_agent.py
```

- **Smoke test E2E (2026-09-24)**: `POST /devices/{id}/power-on` → publish via broker (`via: "mqtt"`) → `mosquitto_sub` menangkap payload di topic yang benar; alur booking `draft → approve → door display` dan presensi QR (`scan → hadir → auto-approve → duplikat terdeteksi`) lulus penuh.

### 24. Live Meeting & Denah Kursi — v2.4

Rapat live: denah kursi interaktif, assignment peserta, transkrip realtime, kontrol siklus rapat.

**Denah kursi ruangan** (DB: `room_seats`, `rooms.seat_layout` — migrasi `015`, `018`):

| Method | Endpoint | Permission | Deskripsi |
|--------|----------|------------|-----------|
| GET | `/rooms/{room_id}/seats` | `rooms.view` / `bookings.view` | Kursi + layout meja + kanal audio ter-petakan |
| PUT | `/rooms/{room_id}/seats` | `rooms.write` | Batch upsert kursi + layout (`{type, tables[]}`: rect/ellipse/u); kursi tak dikirim dihapus; duplikat `seat_no`/kanal ditolak 409 |
| POST | `/rooms/{room_id}/seats/generate` | `rooms.write` | Generator tata letak (`u_shape`/`boardroom`/`classroom`/`circle`, 1–64 kursi, `chair_count` 0–4); `link_channels` auto-buat `audio_channels` bila room belum punya |

**Seat assignment peserta** (DB: `booking_seat_assignments`; `assigned_via: manual|checkin|auto`):

| Method | Endpoint | Deskripsi |
|--------|----------|-----------|
| GET | `/bookings/{id}/seat-assignments` | Pemilik/peserta/`bookings.view` — daftar assignment |
| PUT | `/bookings/{id}/seat-assignments` | Pemilik/`bookings.approve` — batch assign (kursi kosong = item tanpa peserta); `replace=true` bersihkan sisanya |
| POST | `/bookings/{id}/seat-assignments/auto` | Auto-isi kursi (`attended_first`/`all`); owner → kursi `chair`, tamu → `guest`; 400 `NO_SEATS` bila ruangan belum punya denah |

- Check-in presensi otomatis assign kursi (`assigned_via=checkin`) via `assign_seat_on_checkin`.

**Siklus rapat live:**

| Method | Endpoint | Deskripsi |
|--------|----------|-----------|
| GET | `/bookings/{id}/live` | Snapshot live: booking, permissions, attendance, participants+seat, seats+channel, layout, recording, note_id |
| POST | `/bookings/{id}/meeting/start` | `approved` + hari H (boleh 30 mnt sebelum jadwal) → `meeting_status=live`; 409 bila sudah ended |
| POST | `/bookings/{id}/meeting/extend` | Perpanjang 5–120 menit, cek konflik booking |
| POST | `/bookings/{id}/meeting/end` | → `ended`, booking `approved` → `completed`, rekaman dihentikan |

- Background scheduler (`src/api/services/status_scheduler.py`) auto-complete booking yang waktunya terlewat.
- **Auto-release no-show (v2.5)**: booking `approved` hari ini yang tidak pernah dimulai melewati grace 15 menit sejak jadwal mulai (selama slot masih berjalan) dilepas otomatis — ruangan kembali tersedia dan penyelenggara dapat notifikasi `booking_released`. Satu pass saat startup + sweep tiap 60 detik.
- Frontend: `LiveMeetingPage`, `SeatLayoutEditorPage`, `LiveTranscriptPanel` (polling `GET /notes/{id}/segments?after=` + WS `transcript_segment`).
- WebSocket hub: `src/api/services/live_hub.py` — jembatan MQTT (device/mixer/audio levels/active speakers) → semua klien WS per ruangan (lihat bagian *WebSocket Events*).

### 25. Pencarian Lintas Rapat (FTS) — v2.5

Pencarian full-text PostgreSQL (`websearch_to_tsquery`) atas notulen, transkrip, dan tindak lanjut di seluruh rapat.

| Method | Endpoint | Permission | Deskripsi |
|--------|----------|------------|-----------|
| GET | `/search?q=&type=&limit=&offset=` | `notes.view` | Cari di `all` / `notes` / `transcripts` / `actions`; hasil + counts per tipe |

- DB (migrasi `019_search_fts.sql`): kolom generated `tsvector` + index **GIN** pada notulen dan segmen transkrip — pencarian pakai index, bukan `ILIKE` penuh.
- Highlight cuplikan via `ts_headline` (`<b>…</b>` di frontend dirender aman); pencarian tindak lanjut memakai kombinasi FTS + `ILIKE` (judul/owner).
- Read-only: semua role dengan `notes.view` (termasuk Staff) boleh mencari; tidak ada endpoint tulis.
- Frontend: `src/web/pages/search/SearchPage.tsx` — filter tipe, highlight, pagination.

### 26. Dashboard Tindak Lanjut — v2.5

Agregasi action items lintas rapat untuk monitoring tindak lanjut.

| Method | Endpoint | Permission | Deskripsi |
|--------|----------|------------|-----------|
| GET | `/followups/summary` | `notes.view` | Ringkasan: total, per status, overdue, due minggu ini |
| GET | `/followups/items?status=&owner=&q=&booking_id=&page=&per_page=` | `notes.view` | Daftar item lintas rapat; `status` juga menerima `overdue` & `due_this_week` |
| PATCH | `/followups/items/{item_id}` | pemilik item / `notes.write` / admin | Update status/owner/due date item; staff lain → 403 |

- Sortir default: tanggal rapat terbaru, lalu item terbaru.
- Frontend: `src/web/pages/followups/FollowupsDashboardPage.tsx` — kartu ringkasan + filter status/owner + ubah status inline.

### 27. Setup Wizard ala WordPress — v2.5

Wizard instalasi bertahap (seperti installer WordPress) untuk onboarding sistem baru.

| Method | Endpoint | Auth | Deskripsi |
|--------|----------|------|-----------|
| GET | `/setup/status` | publik | Status langkah instalasi: database, migrasi, akun Super Admin, profil organisasi, lisensi, finalize |
| POST | `/setup/profile` | Super Admin | Simpan profil organisasi (nama, alamat, telp, email) |
| POST | `/setup/complete` | Super Admin | Tandai instalasi selesai; 400 `SETUP_PROFILE_REQUIRED` bila profil kosong |

- `GET /setup/status` sengaja tanpa auth (wizard harus bisa dibuka sebelum ada user/lisensi) dan tidak membocorkan data sensitif — hanya `done`/`detail` per langkah. Prefix `/setup` masuk whitelist license gate.
- Endpoint tulis dilindungi `require_super_admin()` (factory dependency).
- Frontend: `src/web/pages/setup/SetupWizardPage.tsx` — stepper ala WordPress + route guard ke `/setup` bila instalasi belum selesai.

---

## Hasil Smoke Test E2E (v2.3, 2026-09-24)

| Alur | Hasil |
|------|-------|
| Infra (Postgres 5435 + Mosquitto 1883) | PASS |
| Auth login + endpoint utama | PASS |
| Booking: create `draft` → approve → cancel → door display status | PASS |
| MQTT power-on via broker beneran + subscriber terima payload | PASS |
| Audio zones: create/volume/mute/source | PASS |
| Presensi QR: scan → hadir 1/2 → auto-approve → duplikat | PASS |
| Door display public + WebSocket | PASS |
| Build frontend (tsc + vite) | PASS (0 error) |

Bugfix yang menyertai:

- `main.py` load `.env` via `load_dotenv()` (sebelumnya env MQTT tidak terbaca).
- Install `paho-mqtt` di venv (MQTT publish sebelumnya selalu mock).
- Model `AudioZone.input_source` → `SAEnum(name="audio_source")` (DB pakai PostgreSQL ENUM, insert sempat 500).
- Frontend audio API disamakan dengan backend: `volume`/`source` pakai query param (`?value=`, `?input=`), `mute`/`unmute`/`phantom` pakai PUT (`phantom_power` di body).
- Frontend calendar API disamakan: `GET /calendar?start=&end=`, `GET /calendar/day?date=`, `GET /calendar/rooms/{id}?month=YYYY-MM`; 48 error TypeScript diperbaiki hingga build lulus.

---

## Hasil Test Suite (v2.5, 2026-09-29)

| Suite | Hasil |
|-------|-------|
| `pytest tests` (RBAC, kiosk bookings, live meeting, search/followups, setup wizard, IoT/MQTT, backup DB) | **120 passed, 5 skipped** (skip: test IoT/MQTT yang butuh broker/device fisik) |
| E2E notulensi `tests/notes/test_e2e_api.py` (DB uji + fake Ollama + STT fake) | **3 passed** (pipeline penuh: upload audio → transkrip → ringkasan AI → export PDF/DOCX/TXT/HTML) |
| WebSocket live hub (connected, state awal, ping/pong) | PASS |
| Smoke API live meeting (denah kursi generate/batch, seat assignment manual+auto, start/extend/end + guard 409) | PASS (31/31 checks) |
| Build frontend (tsc + vite, PWA) | PASS (bundle 1,072 kB / gzip 271 kB, precache 45 entries) |

Catatan lingkungan test:

- Test suite pakai DB PostgreSQL nyata terpisah (`SMR_TEST_DB`, default `smr_test_security`) — di-drop+create tiap sesi, semua migrasi dijalankan fresh (`tests/conftest.py`).
- Test backup butuh `pg_dump` di PATH (mis. `C:\Program Files\PostgreSQL\17\bin`).
- Test E2E notulensi butuh server khusus port 8104 + `STT_ENGINE=fake` + fake Ollama (lihat `docs/modules/11_NOTULENSI.md` §Pengujian).
- Perilaku by design yang perlu diketahui: `link_channels` hanya auto-buat kanal bila ruangan belum punya kanal; scheduler auto-complete booking yang jadwalnya terlewat.

---

## Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2026-09-18 | System Analyst | Initial draft |
| 2.0 | 2026-09-18 | System Analyst | Complete module breakdown, full API specs |
| 2.1 | 2026-09-23 | Dev | Tambah modul terimplementasi: Presensi QR, Lisensi Ed25519 (gating 402), Kiosk Security (ADM-03/04, DSP-07/09), Deployment (DEP-01/02); error code `LICENSE_REQUIRED` |
| 2.2 | 2026-09-24 | Dev | Single-port produksi: FastAPI serve frontend (`dist/`) + SPA fallback; license gate hanya blokir `/api/*` & `/ws/*`; `start-prod.ps1`; fix duplikat `exportNote` (bug export notulensi) |
| 2.3 | 2026-09-24 | Dev | Modul 23 Kontrol Device via MQTT & Agent (`agent/device_agent.py` + `devices.yaml`: WoL/SSAP LG, UDP Digibird, RS232); smoke test E2E lulus (booking, MQTT power-on, audio, presensi QR, door display); bugfix: `load_dotenv` di main.py, install paho-mqtt, ENUM `audio_source`, frontend audio & calendar API alignment, build TS 0 error |
| 2.4 | 2026-09-28 | Dev | Merge PR fitur Live Meeting: modul 24 Denah Kursi + Seat Assignment + siklus rapat live (start/extend/end); WebSocket hub `live_ws.py`/`live_hub.py`; transkrip realtime + STT (`faster-whisper`) + ringkasan Ollama; migrasi 011–018; test suite 126 lulus (122 unit + 3 E2E notulensi + 1 backup); README.md setup guide; `python-osc` masuk requirements |
| 2.5 | 2026-09-29 | Dev | Modul 25 Pencarian Lintas Rapat (migrasi 019 FTS tsvector+GIN, `ts_headline` highlight), modul 26 Dashboard Tindak Lanjut (summary/items/PATCH, RBAC `notes.view`), auto-release ruangan no-show (grace 15 menit + notif), modul 27 Setup Wizard ala WordPress (`/setup` public status + super-admin write, FE guard); test: pytest 120 passed / 5 skipped + build FE lulus |
