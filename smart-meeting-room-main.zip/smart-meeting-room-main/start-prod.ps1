# =============================================================
# SMART MEETING ROOM - Production Launcher (single port)
# Build frontend -> jalankan backend yang juga menyajikan UI.
# Semua (API + WebSocket + Frontend) di http://<host>:8000
# Usage:
#   .\start-prod.ps1              -> build + start
#   .\start-prod.ps1 -SkipBuild   -> start tanpa build ulang
# =============================================================
param(
    [switch]$SkipBuild
)

$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot

function Info($m) { Write-Host "[PROD] $m" -ForegroundColor Cyan }

# --- 1. .env -------------------------------------------------
if (-not (Test-Path (Join-Path $Root '.env'))) {
    Copy-Item (Join-Path $Root '.env.example') (Join-Path $Root '.env')
    Info '.env tidak ada -> dibuat dari .env.example. SESUAIKAN kredensial DB!'
}

# --- 2. Python virtualenv -------------------------------------
$Venv   = Join-Path $Root '.venv'
$Python = Join-Path $Venv 'Scripts\python.exe'
if (-not (Test-Path $Python)) {
    Info 'Membuat virtualenv .venv ...'
    python -m venv $Venv
    & (Join-Path $Venv 'Scripts\pip.exe') install -q -r (Join-Path $Root 'requirements.txt')
}

# --- 3. Build frontend ----------------------------------------
if (-not $SkipBuild) {
    if (-not (Test-Path (Join-Path $Root 'node_modules'))) {
        Info 'Install dependencies Node (npm install) ...'
        Push-Location $Root
        try { npm install } finally { Pop-Location }
    }
    Info 'Build frontend (vite build) ...'
    Push-Location $Root
    try { npx vite build } finally { Pop-Location }
}

# --- 4. Migrasi database --------------------------------------
Info 'Menerapkan migrasi database tertunda (scripts/migrate.py) ...'
& $Python (Join-Path $Root 'scripts\migrate.py')
if ($LASTEXITCODE -ne 0) { throw 'Migrasi database gagal - server tidak dijalankan.' }

# --- 5. Jalankan server (API + UI di satu port) ----------------
# Mode produksi: DEBUG & Swagger selalu mati. Secret (JWT_SECRET, DB_PASSWORD,
# SMTP, MQTT) HANYA dibaca dari .env - jangan ditulis di skrip ini.
$env:DEBUG = 'false'
$env:API_DEBUG = 'false'
$env:ENABLE_API_DOCS = 'false'

# Host/port diambil dari env (SMR_BIND_HOST / API_PORT). Default 0.0.0.0 agar
# tablet kiosk di LAN bisa mengakses. PENTING: di produksi letakkan server ini
# di belakang reverse proxy TLS (Caddy/Nginx/IIS ARR) dan batasi port 8000
# lewat firewall, atau set SMR_BIND_HOST=127.0.0.1 bila proxy di mesin yang sama.
$BindHost = if ($env:SMR_BIND_HOST) { $env:SMR_BIND_HOST } else { '0.0.0.0' }
$BindPort = if ($env:API_PORT) { $env:API_PORT } else { '8000' }

Info "Server produksi -> http://${BindHost}:${BindPort}  (UI di /, API di /api/v1)"
Info 'Gunakan HTTPS lewat reverse proxy untuk akses dari jaringan.'
& $Python -m uvicorn src.api.main:app --host $BindHost --port $BindPort --proxy-headers --no-server-header
