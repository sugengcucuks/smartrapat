# Smart Meeting Room

Sistem manajemen ruang rapat pintar: booking ruangan, kiosk & door display, kontrol AV
(TV/videowall/mixer) via MQTT, live meeting (denah kursi, transkrip, ringkasan AI), notulensi,
presensi QR, hingga laporan & audit.

Monorepo satu unit deploy:

```
src/api      FastAPI + PostgreSQL + MQTT  (REST + WebSocket, single port :8000)
src/web      React + TypeScript + Vite    (PWA, dev :3000)
agent/       Device agent Python (PC monitoring) — LG signage, Digibird videowall, XR18 mixer
kiosk/       Script setup kiosk Windows (Chrome/Edge fullscreen)
deploy/      Konfigurasi Mosquitto (MQTT broker)
docs/        Dokumentasi per modul
```

## Prasyarat

- Python 3.11+
- Node.js 18+ (LTS)
- Docker Desktop (PostgreSQL 15, pgAdmin, Mosquitto)
- (Opsional, notulensi AI) [Ollama](https://ollama.com) — model rekomendasi `qwen2.5:7b-instruct`

## Mulai Cepat (Development)

```powershell
# 1. Layanan pendukung: PostgreSQL :5435, pgAdmin :5051, MQTT :1883
docker compose up -d

# 2. Konfigurasi environment
Copy-Item .env.example .env
#   -> WAJIB isi: DB_PASSWORD, PGADMIN_PASSWORD, JWT_SECRET (min 32 karakter acak)
#   -> JWT_SECRET: python -c "import secrets;print(secrets.token_urlsafe(48))"

# 3. Dependensi + migrasi + start (backend :8000 + frontend :3000)
.\start-dev.ps1 -Migrate
```

Login awal: `admin` / `admin123` — **wajib ganti password saat login pertama**
(sistem memaksa `must_change_password`).

### Catatan MQTT (kontrol perangkat)

Broker Mosquitto docker mewajibkan autentikasi + ACL. Buat file password dulu —
lihat [deploy/mosquitto/README.md](deploy/mosquitto/README.md). Tanpa broker/kredensial,
endpoint perintah perangkat membalas `503 MQTT_NOT_CONFIGURED`
(atau set `MQTT_SIMULATE=true` untuk dev tanpa broker — jangan dipakai produksi).

## Produksi (single port)

```powershell
.\start-prod.ps1          # build frontend + serve semuanya di http://<host>:8000
.\start-prod.ps1 -SkipBuild   # start tanpa build ulang
```

Taruh di belakang reverse proxy TLS (lihat `SMR_BIND_HOST` di `.env.example`).

## Migrasi Database

Migrasi berjalan otomatis lewat `scripts/migrate.py` (tabel `schema_migrations`):

```powershell
python scripts/migrate.py            # terapkan migrasi yang belum jalan
python scripts/migrate.py --status   # lihat status
python scripts/migrate.py --dry-run  # pratinjau
python scripts/migrate.py --baseline # tandai semua sudah applied (DB lama eksisting)
```

## Testing

```powershell
# Suite utama (RBAC, kiosk, live meeting, IoT/MQTT) — DB uji nyata terpisah
python -m pytest tests -q

# E2E notulensi (butuh server + fake engine, lihat docs/modules/11_NOTULENSI.md §Pengujian)
uvicorn tests.notes.fake_ollama:app --port 11999
STT_ENGINE=fake OLLAMA_BASE_URL=http://127.0.0.1:11999 OLLAMA_MODEL=qwen2.5:7b-instruct `
  AGENT_API_KEY=testagentkey123 uvicorn src.api.main:app --port 8104
SMR_E2E_URL=http://127.0.0.1:8104 python -m pytest tests/notes/test_e2e_api.py
```

Build frontend: `npm run build` (tsc + vite, PWA).

## Device Agent & Kiosk

- **Agent** (WoL/kontrol TV LG, Digibird, mixer XR18): [agent/README.md](agent/README.md) —
  jalankan di PC monitoring, daftarkan perangkat di `agent/devices.yaml`,
  service Windows via NSSM.
- **Kiosk/door display**: [kiosk/](kiosk/) — script PowerShell fullscreen,
  pairing kiosk per ruangan lewat menu admin (Rooms → QR/Kiosk).

## Dokumentasi

| Dokumen | Isi |
|---|---|
| [SPEC.md](SPEC.md) | Spesifikasi lengkap sistem (v2.3) |
| [docs/modules/](docs/modules/) | 18 modul: auth, booking, notulensi, live meeting, dll |
| [docs/architecture/LIVE_MEETING.md](docs/architecture/LIVE_MEETING.md) | Kontrak MQTT & arsitektur live |
| [.env.example](.env.example) | Semua variabel environment + penjelasan |

## Struktur Uji & Perintah Penting

```powershell
.\start-dev.ps1 -SkipInstall       # start tanpa install ulang deps
npm run dev                        # frontend saja (Vite :3000, proxy /api -> :8000)
npm run lint                       # ESLint
python scripts/license_cli.py      # utilitas lisensi (generate/aktivasi offline)
```
