# SMART MEETING ROOM - Recorder notulensi launcher
# Jalankan dari folder agent:  .\run-agent.ps1
param(
    [switch]$InstallOnly
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

# 1. Venv lokal
if (-not (Test-Path ".venv")) {
    Write-Host "[SETUP] Membuat virtual environment..." -ForegroundColor Cyan
    python -m venv .venv
}

$pip = ".\.venv\Scripts\pip.exe"
$py  = ".\.venv\Scripts\python.exe"

# 2. Dependencies
Write-Host "[SETUP] Install dependencies..." -ForegroundColor Cyan
& $pip install -q -r requirements.txt

if ($InstallOnly) {
    Write-Host "[OK] Install selesai." -ForegroundColor Green
    exit 0
}

# 3. Cek config
if (-not (Test-Path "recorder.yaml")) {
    Write-Host "[FATAL] recorder.yaml tidak ditemukan." -ForegroundColor Red
    exit 1
}

# 4. Jalankan agent
Write-Host "[AGENT] Menjalankan Recorder (Ctrl+C untuk berhenti)..." -ForegroundColor Green
& $py .\recorder.py
