# SMART MEETING ROOM - Device Agent launcher
# Jalankan dari folder agent:
#   .\run-agent.ps1                 # install dependency (sekali) lalu jalankan agent
#   .\run-agent.ps1 -InstallOnly    # hanya siapkan .venv + dependency
#   .\run-agent.ps1 -Pair 192.168.10.101   # pairing SSAP TV LG, cetak client-key
# Untuk berjalan sebagai Windows service (NSSM) lihat README.md.
param(
    [switch]$InstallOnly,
    [string]$Pair = "",
    [string]$Config = "devices.yaml"
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

# 1. Venv lokal
if (-not (Test-Path ".venv")) {
    Write-Host "[SETUP] Membuat virtual environment..." -ForegroundColor Cyan
    python -m venv .venv
}

$pip = ".\.venv\Scripts\pip.exe"
$py  = ".\.venv\Scripts\python.exe"

# 2. Dependencies (paho-mqtt 1.x, python-osc, websocket-client, pyserial, PyYAML)
Write-Host "[SETUP] Install dependencies..." -ForegroundColor Cyan
& $pip install -q -r requirements.txt

if ($InstallOnly) {
    Write-Host "[OK] Install selesai." -ForegroundColor Green
    exit 0
}

if ($Pair -ne "") {
    & $py .\device_agent.py --pair $Pair
    exit $LASTEXITCODE
}

# 3. Cek config
if (-not (Test-Path $Config)) {
    Write-Host "[FATAL] $Config tidak ditemukan." -ForegroundColor Red
    exit 1
}

# 4. Jalankan agent
Write-Host "[AGENT] Menjalankan Device Agent (Ctrl+C untuk berhenti)..." -ForegroundColor Green
& $py .\device_agent.py --config $Config
