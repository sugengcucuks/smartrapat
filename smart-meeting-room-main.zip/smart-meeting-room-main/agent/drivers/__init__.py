"""Driver perangkat untuk device agent Smart Meeting Room.

- wol.py         : Wake-on-LAN (power ON panel LG)
- net.py         : TCP/UDP/ping generik + serial RS232
- digibird.py    : Videowall processor Digibird (UDP 5000 ASCII / RS232), parsing [OK]/[ERR]
- lg_signage.py  : LG webOS signage — SSAP (WebSocket 3000) & IP control (TCP 9761)
- xair.py        : Behringer X-Air XR18 / Midas MR18 (OSC UDP 10024): mute/fader/gain + meter

Semua fungsi mengembalikan hasil sebagai (ok: bool, response: str|None) atau
melempar DriverError dengan pesan berbahasa Indonesia.
"""


class DriverError(RuntimeError):
    """Kegagalan perintah ke perangkat (dikirim sebagai `error` di ack)."""
