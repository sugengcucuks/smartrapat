"""Wake-on-LAN magic packet (power ON TV LG via LAN)."""
import re
import socket

from . import DriverError


def send_wol(mac: str, broadcast: str = "255.255.255.255", port: int = 9) -> str:
    mac_clean = re.sub(r"[^0-9a-fA-F]", "", str(mac))
    if len(mac_clean) != 12:
        raise DriverError(f"MAC tidak valid: {mac}")
    packet = b"\xff" * 6 + bytes.fromhex(mac_clean) * 16
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            s.sendto(packet, (broadcast, int(port)))
    except OSError as exc:
        raise DriverError(f"WoL gagal dikirim ke {broadcast}: {exc}") from exc
    # WoL tidak punya balasan: sukses = paket terkirim (TV butuh ~10-20 dtk untuk menyala)
    return f"WoL terkirim ke {mac}"
