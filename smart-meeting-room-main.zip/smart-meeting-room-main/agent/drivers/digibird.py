"""Videowall processor Digibird DB-VWC2-B-4H8H-PV.

Protokol LAN: UDP port 5000, 1 datagram = 1 perintah ASCII, mis.
  [call,ID]          panggil scene tersimpan (ID 1..32)
  [SWCH,src,win,1]   input HDMI src (1..4) ke jendela win
  [SALL]             tutup semua jendela
Balasan: "[OK]" / "[CMD,OK]" (sukses) atau "[ERR]" / "[CMD,ERR...]" (gagal).
RS232 memakai perintah yang sama (9600 8N1 default — cek manual).
"""
from typing import Optional, Tuple

from . import DriverError
from .net import send_serial, send_udp


def parse_reply(raw: Optional[bytes]) -> Tuple[bool, Optional[str]]:
    """(ok, teks). Tanpa balasan -> ok=True, teks None (UDP tidak wajib membalas)."""
    if not raw:
        return True, None
    text = raw.decode("utf-8", "replace").strip()
    upper = text.upper()
    if "ERR" in upper or "FAIL" in upper:
        return False, text
    return True, text


def send(host: str, port: int, command: str, wait_ms: int = 800, expect_reply: bool = False) -> str:
    raw = send_udp(host, port, command.encode("ascii"), wait_ms)
    ok, text = parse_reply(raw)
    if not ok:
        raise DriverError(f"Digibird menolak {command}: {text}")
    if text is None:
        if expect_reply:
            raise DriverError(f"Digibird {host}:{port} tidak membalas {command}")
        return "terkirim (tanpa balasan)"
    return text


def send_rs232(port: str, baud: int, command: str) -> str:
    raw = send_serial(port, baud, command.encode("ascii"))
    ok, text = parse_reply(raw)
    if not ok:
        raise DriverError(f"Digibird (RS232) menolak {command}: {text}")
    return text or "terkirim (tanpa balasan)"
