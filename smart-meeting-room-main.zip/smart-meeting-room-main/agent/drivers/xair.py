"""Behringer X-Air XR18 / Midas MR18 — kontrol & meter via OSC (UDP 10024).

Alamat OSC (X-Air):
  /ch/NN/mix/on      i  0|1   (1 = ON = TIDAK mute)
  /ch/NN/mix/fader   f  0..1
  /headamp/NN/gain   f  0..1  (-12..+60 dB)
  /lr/mix/on, /lr/mix/fader  (main L/R)
  /xremote           keepalive <10 dtk agar mixer mengirim perubahan (push)
  /meters ,s "/meters/1"  langganan meter (diperbarui <10 dtk); balasan
                     /meters/1 berisi blob: int32 LE jumlah nilai + int16 LE per
                     nilai; dB = nilai / 256. 16 nilai pertama = kanal input 1..16.
  /info              identitas mixer (dipakai health check)

Set tidak dibalas mixer, jadi setiap perintah diverifikasi dengan query ulang
(nilai harus cocok) -> ack ok hanya bila mixer benar-benar berubah.

Publikasi (lihat docs/architecture/LIVE_MEETING.md §3), semua memakai nomor
KANAL MIXER dengan "key": "mixer_channel" (backend memetakan ke channel_no):
  smr/audio/{room}/levels  {"levels": {"1": -42.1, ...}, "key": "mixer_channel", "ts"}  <= 5 Hz
  smr/audio/{room}/active  {"active": [3], "key": "mixer_channel", "ts"}  (ambang + hold)
  smr/audio/{room}/mixer   retained {"channels": {"3": {"muted", "fader", "gain"}}, "main": {...}, ...}
"""
from __future__ import annotations

import socket
import struct
import threading
import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple

from . import DriverError

try:
    from pythonosc.osc_message_builder import OscMessageBuilder
    from pythonosc.osc_packet import OscPacket
except ImportError:  # pragma: no cover
    OscMessageBuilder = None  # type: ignore
    OscPacket = None  # type: ignore

Publish = Callable[[str, Dict[str, Any], bool], None]   # (kind, payload, retain)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def build(address: str, *args: Tuple[Any, str]) -> bytes:
    if OscMessageBuilder is None:
        raise DriverError("python-osc belum terinstall (pip install python-osc)")
    b = OscMessageBuilder(address)
    for value, typ in args:
        b.add_arg(value, typ)
    return b.build().dgram


def parse_meters_blob(blob: bytes, count: int) -> List[float]:
    """Blob /meters/N -> daftar dBFS (count nilai pertama)."""
    if len(blob) < 4:
        return []
    n = struct.unpack("<i", blob[:4])[0]
    n = max(0, min(n, (len(blob) - 4) // 2))
    vals = struct.unpack(f"<{n}h", blob[4:4 + 2 * n])
    return [round(v / 256.0, 1) for v in vals[:count]]


def gain_db_to_f(db: float) -> float:
    return max(0.0, min(1.0, (float(db) + 12.0) / 72.0))


def gain_f_to_db(f: float) -> float:
    return round(-12.0 + 72.0 * float(f), 1)


class XAirMixer:
    def __init__(
        self,
        host: str,
        room_code: str,
        publish: Publish,
        port: int = 10024,
        channels: int = 16,
        threshold_db: float = -45.0,
        hold_ms: int = 800,
        levels_hz: float = 5.0,
        log: Callable[[str], None] = print,
    ):
        self.host = host
        self.port = int(port)
        self.room_code = room_code
        self.publish = publish
        self.channels = int(channels)
        self.threshold_db = float(threshold_db)
        self.hold_s = int(hold_ms) / 1000.0
        self.levels_interval = 1.0 / max(0.5, min(float(levels_hz), 5.0))
        self.log = log

        self.sock: Optional[socket.socket] = None
        self._stop = threading.Event()
        self._cond = threading.Condition()
        self._values: Dict[str, Any] = {}          # alamat OSC -> nilai terakhir
        self._seen: Dict[str, float] = {}          # alamat -> waktu terima
        self.last_rx = 0.0
        self.levels: Dict[int, float] = {}
        self._last_above: Dict[int, float] = {}
        self._active: List[int] = []
        self._last_levels_pub = 0.0
        self._mixer_dirty = threading.Event()
        self.info: Optional[str] = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def start(self) -> None:
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("0.0.0.0", 0))
        self.sock.settimeout(0.5)
        threading.Thread(target=self._rx_loop, name=f"xair-rx-{self.host}", daemon=True).start()
        threading.Thread(target=self._keepalive_loop, name=f"xair-ka-{self.host}", daemon=True).start()
        threading.Thread(target=self._mixer_pub_loop, name=f"xair-pub-{self.host}", daemon=True).start()
        self._send(build("/xremote"))
        self._subscribe_meters()
        self.refresh_state()

    def stop(self) -> None:
        self._stop.set()
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass

    @property
    def online(self) -> bool:
        return time.time() - self.last_rx < 12.0

    # ------------------------------------------------------------------
    # IO
    # ------------------------------------------------------------------
    def _send(self, dgram: bytes) -> None:
        if not self.sock:
            raise DriverError("Driver X-Air belum start")
        try:
            self.sock.sendto(dgram, (self.host, self.port))
        except OSError as exc:
            raise DriverError(f"Gagal kirim OSC ke {self.host}:{self.port}: {exc}") from exc

    def _subscribe_meters(self) -> None:
        self._send(build("/meters", ("/meters/1", "s")))

    def _keepalive_loop(self) -> None:
        while not self._stop.wait(8.0):
            try:
                self._send(build("/xremote"))
                self._subscribe_meters()
                self._send(build("/info"))
            except DriverError as exc:
                self.log(f"[XAIR] keepalive gagal: {exc}")

    def _rx_loop(self) -> None:
        while not self._stop.is_set():
            try:
                data, _ = self.sock.recvfrom(8192)  # type: ignore[union-attr]
            except socket.timeout:
                self._tick_active()
                continue
            except OSError:
                if self._stop.is_set():
                    return
                time.sleep(0.2)
                continue
            try:
                packet = OscPacket(data)
            except Exception:
                continue
            for timed in packet.messages:
                self._handle(timed.message.address, list(timed.message.params))

    def _handle(self, address: str, params: List[Any]) -> None:
        now = time.time()
        self.last_rx = now
        if address == "/meters/1" and params and isinstance(params[0], (bytes, bytearray)):
            self._on_meters(bytes(params[0]))
            return
        if address == "/info":
            self.info = " ".join(str(p) for p in params)
            return
        if not params:
            return
        with self._cond:
            self._values[address] = params[0]
            self._seen[address] = now
            self._cond.notify_all()
        if address.startswith(("/ch/", "/lr/", "/headamp/")):
            self._mixer_dirty.set()

    # ------------------------------------------------------------------
    # Meter & deteksi pembicara
    # ------------------------------------------------------------------
    def _on_meters(self, blob: bytes) -> None:
        vals = parse_meters_blob(blob, self.channels)
        now = time.time()
        for i, db in enumerate(vals, start=1):
            self.levels[i] = db
            if db > self.threshold_db:
                self._last_above[i] = now
        self._tick_active(now)
        if now - self._last_levels_pub >= self.levels_interval:
            self._last_levels_pub = now
            self.publish("levels", {"levels": {str(k): v for k, v in self.levels.items()},
                                    "key": "mixer_channel", "ts": _now_iso()}, False)

    def _tick_active(self, now: Optional[float] = None) -> None:
        now = now or time.time()
        active = sorted(ch for ch, t in self._last_above.items() if now - t <= self.hold_s)
        if active != self._active:
            self._active = active
            self.publish("active", {"active": active, "key": "mixer_channel", "ts": _now_iso()}, False)

    # ------------------------------------------------------------------
    # State mixer
    # ------------------------------------------------------------------
    @staticmethod
    def _ch_addr(ch: int, leaf: str) -> str:
        return f"/ch/{ch:02d}/mix/{leaf}"

    def refresh_state(self) -> None:
        """Query semua kanal (on/fader/gain) + main; balasan masuk lewat _handle."""
        for ch in range(1, self.channels + 1):
            self._send(build(self._ch_addr(ch, "on")))
            self._send(build(self._ch_addr(ch, "fader")))
            self._send(build(f"/headamp/{ch:02d}/gain"))
        self._send(build("/lr/mix/on"))
        self._send(build("/lr/mix/fader"))
        self._mixer_dirty.set()

    def snapshot(self) -> Dict[str, Any]:
        chans: Dict[str, Any] = {}
        with self._cond:
            vals = dict(self._values)
        for ch in range(1, self.channels + 1):
            on = vals.get(self._ch_addr(ch, "on"))
            fader = vals.get(self._ch_addr(ch, "fader"))
            gain = vals.get(f"/headamp/{ch:02d}/gain")
            if on is None and fader is None and gain is None:
                continue
            chans[str(ch)] = {
                "muted": None if on is None else int(on) == 0,
                "fader": None if fader is None else round(float(fader), 3),
                "gain": None if gain is None else gain_f_to_db(gain),
            }
        main_on = vals.get("/lr/mix/on")
        main_fader = vals.get("/lr/mix/fader")
        return {
            "channels": chans,
            "main": {"muted": None if main_on is None else int(main_on) == 0,
                     "fader": None if main_fader is None else round(float(main_fader), 3)},
            "key": "mixer_channel",
            "online": self.online,
            "ts": _now_iso(),
        }

    def _mixer_pub_loop(self) -> None:
        while not self._stop.is_set():
            if self._mixer_dirty.wait(1.0):
                time.sleep(0.15)   # kumpulkan balasan beruntun
                self._mixer_dirty.clear()
                self.publish("mixer", self.snapshot(), True)

    # ------------------------------------------------------------------
    # Perintah
    # ------------------------------------------------------------------
    def _set_verify(self, items: List[Tuple[str, Any, str]], timeout: float = 1.0) -> None:
        """Kirim set untuk tiap (alamat, nilai, tipe), lalu query & tunggu nilai cocok."""
        start = time.time()
        for addr, value, typ in items:
            self._send(build(addr, (value, typ)))
        for addr, _v, _t in items:
            self._send(build(addr))
        deadline = start + timeout
        with self._cond:
            while True:
                pending = [a for a, v, t in items
                           if not (self._seen.get(a, 0) >= start and self._match(self._values.get(a), v, t))]
                if not pending:
                    break
                remaining = deadline - time.time()
                if remaining <= 0:
                    raise DriverError(f"Mixer {self.host} tidak mengonfirmasi: {', '.join(pending[:4])}")
                self._cond.wait(remaining)
        self._mixer_dirty.set()

    @staticmethod
    def _match(actual: Any, expected: Any, typ: str) -> bool:
        if actual is None:
            return False
        if typ == "i":
            return int(actual) == int(expected)
        return abs(float(actual) - float(expected)) < 0.01

    def _mixer_ch(self, payload: Dict[str, Any]) -> int:
        raw = payload.get("mixer_channel", payload.get("channel_no"))
        try:
            ch = int(raw)
        except (TypeError, ValueError):
            raise DriverError(f"mixer_channel tidak valid: {raw!r}")
        if not 1 <= ch <= self.channels:
            raise DriverError(f"mixer_channel harus 1..{self.channels}: {ch}")
        return ch

    @staticmethod
    def _unit(payload: Dict[str, Any], key: str = "value") -> float:
        try:
            v = float(payload.get(key))
        except (TypeError, ValueError):
            raise DriverError(f"{key} harus angka 0..1")
        if not 0.0 <= v <= 1.0:
            raise DriverError(f"{key} harus 0..1")
        return v

    def execute(self, action: str, payload: Dict[str, Any]) -> str:
        is_main = str(payload.get("target", "")) == "main"
        if action in ("mute", "unmute"):
            on = 0 if action == "mute" else 1
            addr = "/lr/mix/on" if is_main else self._ch_addr(self._mixer_ch(payload), "on")
            self._set_verify([(addr, on, "i")])
            return f"{addr}={on}"
        if action in ("mute_all", "unmute_all"):
            on = 0 if action == "mute_all" else 1
            chans = payload.get("mixer_channels") or list(range(1, self.channels + 1))
            items = [(self._ch_addr(self._mixer_ch({"mixer_channel": c}), "on"), on, "i") for c in chans]
            self._set_verify(items, timeout=2.0)
            return f"{len(items)} kanal on={on}"
        if action == "set_fader":
            value = self._unit(payload)
            addr = "/lr/mix/fader" if is_main else self._ch_addr(self._mixer_ch(payload), "fader")
            self._set_verify([(addr, value, "f")])
            return f"{addr}={value:.3f}"
        if action == "set_gain":
            ch = self._mixer_ch(payload)
            try:
                db = float(payload.get("db"))
            except (TypeError, ValueError):
                raise DriverError("db harus angka -12..60")
            if not -12.0 <= db <= 60.0:
                raise DriverError("db harus -12..60")
            addr = f"/headamp/{ch:02d}/gain"
            self._set_verify([(addr, gain_db_to_f(db), "f")])
            return f"{addr}={db:.1f}dB"
        if action == "refresh":
            self.refresh_state()
            return "refresh dikirim"
        raise DriverError(f"Aksi '{action}' tidak didukung mixer X-Air")

    def health(self) -> bool:
        try:
            self._send(build("/info"))
        except DriverError:
            return False
        deadline = time.time() + 1.0
        while time.time() < deadline:
            if time.time() - self.last_rx < 1.2:
                return True
            time.sleep(0.05)
        return self.online
