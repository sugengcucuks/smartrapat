"""LG webOS signage (mis. 55VL5PJ): SSAP (WebSocket 3000) & IP control (TCP 9761).

IP control (protokol RS232 LG lewat LAN, port 9761 — aktifkan di menu
Installer/Signage: "Network Ready"/"IP Control" & set ID):
  kirim  "ka 01 01\\r"  -> power on   (butuh "Wake On LAN"/"Network Standby" aktif)
  kirim  "ka 01 00\\r"  -> power off
  kirim  "ka 01 ff\\r"  -> query power, balasan "a 01 OK01x" (on) / "a 01 OK00x" (off)
  kirim  "xb 01 90\\r"  -> input HDMI1 (90=HDMI1, 91=HDMI2, ...)
  balasan gagal: "a 01 NG..x"

SSAP (WebSocket ws://IP:3000, butuh pairing sekali -> client-key):
  ssap://system/turnOff, ssap://tv/switchInput {"inputId": "HDMI_1"}, ...
  Pairing memakai manifest bertanda tangan (lg_manifest.json) berisi izin
  CONTROL_POWER, CONTROL_INPUT_TV, READ_INPUT_DEVICE_LIST, dst. Client-key hasil
  pairing lama dengan manifest kosong TIDAK punya izin turnOff -> pairing ulang.
"""
import json
import re
import time
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from . import DriverError
from .net import send_tcp

MANIFEST_PATH = Path(__file__).resolve().parent / "lg_manifest.json"

# ---------------------------------------------------------------------------
# IP control (TCP 9761)
# ---------------------------------------------------------------------------

_HEX2 = re.compile(r"^[0-9a-fA-F]{2}$")
_CMD = re.compile(r"^[a-z]{2}$")

_REPLY = re.compile(r"([a-z])\s+([0-9a-fA-F]{2})\s+(OK|NG)([0-9a-fA-F]*)x", re.IGNORECASE)


def build_ip_command(cmd: str, set_id: str, data: str) -> bytes:
    if not _CMD.match(cmd or ""):
        raise DriverError(f"Perintah LG tidak valid: {cmd!r}")
    if not _HEX2.match(set_id or "") or not _HEX2.match(data or ""):
        raise DriverError(f"Set ID/data LG harus 2 digit hex: {set_id!r} {data!r}")
    return f"{cmd} {set_id} {data}\r".encode("ascii")


def parse_ip_reply(raw: Optional[bytes]) -> Tuple[bool, Optional[str], Optional[str]]:
    """(ok, data_hex, teks). Balasan contoh: 'a 01 OK01x'."""
    if not raw:
        return False, None, None
    text = raw.decode("ascii", "replace").strip()
    m = _REPLY.search(text)
    if not m:
        return False, None, text
    return m.group(3).upper() == "OK", (m.group(4) or None), text


def ip_control(host: str, cmd: str, data: str, set_id: str = "01", port: int = 9761,
               wait_ms: int = 1500) -> str:
    raw = send_tcp(host, port, build_ip_command(cmd, set_id, data), wait_ms)
    ok, _data, text = parse_ip_reply(raw)
    if text is None:
        raise DriverError(f"LG {host}:{port} tidak membalas '{cmd} {set_id} {data}'")
    if not ok:
        raise DriverError(f"LG {host} menolak '{cmd} {set_id} {data}': {text}")
    return text


def query_power(host: str, set_id: str = "01", port: int = 9761) -> Optional[str]:
    """'on' / 'off' / None (tidak terjangkau)."""
    try:
        raw = send_tcp(host, port, build_ip_command("ka", set_id, "ff"), 1500)
    except DriverError:
        return None
    ok, data, _ = parse_ip_reply(raw)
    if not ok or data is None:
        return None
    return "on" if data.endswith("1") else "off"


# ---------------------------------------------------------------------------
# SSAP (WebSocket 3000)
# ---------------------------------------------------------------------------

def load_manifest(path: Optional[str] = None) -> Dict[str, Any]:
    p = Path(path) if path else MANIFEST_PATH
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def _register(ws, client_key: Optional[str], manifest: Dict[str, Any], wait_s: float) -> Dict[str, Any]:
    payload: Dict[str, Any] = {"forcePairing": False, "pairingType": "PROMPT", "manifest": manifest}
    if client_key:
        payload["client-key"] = client_key
    ws.send(json.dumps({"type": "register", "id": "register_0", "payload": payload}))
    deadline = time.time() + wait_s
    while time.time() < deadline:
        msg = json.loads(ws.recv())
        mtype = msg.get("type")
        if mtype == "error":
            raise DriverError(f"SSAP register ditolak TV: {msg.get('error')}")
        if mtype == "registered":
            return msg.get("payload") or {}
        # type=response {"pairingType": "PROMPT"} = menunggu konfirmasi di layar
    raise DriverError("SSAP register timeout (cek client_key / jalankan --pair ulang)")


def ssap_request(host: str, uri: str, client_key: str, port: int = 3000,
                 payload: Optional[Dict[str, Any]] = None, wait_s: float = 5,
                 manifest_path: Optional[str] = None) -> str:
    try:
        from websocket import create_connection  # type: ignore
    except ImportError as exc:
        raise DriverError("websocket-client belum terinstall (pip install websocket-client)") from exc
    if not client_key or client_key.upper().startswith("GANTI"):
        raise DriverError(f"client_key TV {host} belum diisi (jalankan: device_agent.py --pair {host})")
    try:
        ws = create_connection(f"ws://{host}:{int(port)}/", timeout=wait_s)
    except Exception as exc:
        raise DriverError(f"SSAP {host}:{port} tidak terjangkau: {exc}") from exc
    try:
        _register(ws, client_key, load_manifest(manifest_path), wait_s)
        req: Dict[str, Any] = {"type": "request", "id": "req_1", "uri": uri}
        if payload:
            req["payload"] = payload
        ws.send(json.dumps(req))
        try:
            msg = json.loads(ws.recv())
        except Exception:
            # turnOff sering memutus koneksi sebelum balasan -> anggap sukses
            return "terkirim (koneksi ditutup TV)"
        if msg.get("type") == "error":
            raise DriverError(f"SSAP {uri} ditolak: {msg.get('error')} (izin kurang? pairing ulang)")
        body = msg.get("payload") or {}
        if body.get("returnValue") is False:
            raise DriverError(f"SSAP {uri} gagal: {body.get('errorText') or body}")
        return json.dumps(body)[:200]
    finally:
        try:
            ws.close()
        except Exception:
            pass


def pair_tv(host: str, port: int = 3000, wait_s: int = 60, manifest_path: Optional[str] = None) -> str:
    """Pairing sekali: TV menampilkan prompt, terima di TV; kembalikan client-key."""
    try:
        from websocket import create_connection  # type: ignore
    except ImportError as exc:
        raise DriverError("websocket-client belum terinstall (pip install websocket-client)") from exc
    print(f"[*] Konek ke {host}:{port} - LIHAT LAYAR TV, terima permintaan koneksinya...")
    ws = create_connection(f"ws://{host}:{port}/", timeout=wait_s)
    try:
        payload = _register(ws, None, load_manifest(manifest_path), wait_s)
        key = payload.get("client-key")
        if not key:
            raise DriverError("TV tidak mengirim client-key")
        return key
    finally:
        ws.close()
