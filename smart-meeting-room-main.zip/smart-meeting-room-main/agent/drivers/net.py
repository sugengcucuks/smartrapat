"""Transport jaringan/serial generik + probe kesehatan."""
import platform
import socket
import subprocess
import time
from typing import Optional

from . import DriverError


def send_tcp(host: str, port: int, payload: bytes, wait_ms: int = 500) -> Optional[bytes]:
    """Kirim bytes via TCP, kembalikan balasan (atau None bila tidak ada)."""
    try:
        with socket.create_connection((host, int(port)), timeout=max(wait_ms, 300) / 1000) as s:
            s.sendall(payload)
            s.settimeout(max(wait_ms, 300) / 1000)
            try:
                data = s.recv(1024)
                return data or None
            except socket.timeout:
                return None
    except OSError as exc:
        raise DriverError(f"TCP {host}:{port} gagal: {exc}") from exc


def send_udp(host: str, port: int, payload: bytes, wait_ms: int = 800) -> Optional[bytes]:
    """Kirim satu datagram UDP, tunggu balasan maks wait_ms."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.settimeout(wait_ms / 1000)
            s.sendto(payload, (host, int(port)))
            try:
                data, _ = s.recvfrom(2048)
                return data or None
            except socket.timeout:
                return None
    except OSError as exc:
        raise DriverError(f"UDP {host}:{port} gagal: {exc}") from exc


def send_serial(port: str, baud: int, payload: bytes, wait_ms: int = 300) -> Optional[bytes]:
    try:
        import serial  # type: ignore  # lazy: hanya bila ada langkah serial
    except ImportError as exc:
        raise DriverError("pyserial belum terinstall (pip install pyserial)") from exc
    try:
        with serial.Serial(port, int(baud), timeout=wait_ms / 1000) as ser:
            ser.write(payload)
            time.sleep(0.1)
            data = ser.read(256)
            return data or None
    except Exception as exc:
        raise DriverError(f"Serial {port} gagal: {exc}") from exc


def tcp_probe(host: str, port: int, timeout: float = 1.5) -> bool:
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            return True
    except OSError:
        return False


def ping(host: str, timeout_ms: int = 1000) -> bool:
    """ICMP ping via perintah sistem (tanpa hak admin)."""
    if platform.system().lower().startswith("win"):
        cmd = ["ping", "-n", "1", "-w", str(timeout_ms), host]
    else:
        cmd = ["ping", "-c", "1", "-W", str(max(1, timeout_ms // 1000)), host]
    try:
        res = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             timeout=timeout_ms / 1000 + 2)
        return res.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False
