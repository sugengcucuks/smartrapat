# -*- coding: utf-8 -*-
"""
SMART MEETING ROOM - Recorder Multikanal (PC Monitoring)
=======================================================
Menangkap audio per kanal mic (audio interface USB / digital mixer), mendeteksi
siapa yang bicara (VAD energi per kanal), memotong ucapan menjadi segmen, lalu
mengirim segmen ke backend untuk ditranskrip (faster-whisper) dengan label
kanal -> kursi -> peserta. Lihat docs/architecture/LIVE_MEETING.md.

Alur:
  sounddevice InputStream (N kanal)  ->  antrean blok  ->  worker:
     - level dBFS per kanal  -> MQTT smr/audio/{room}/levels|active (opsional, maks 5 Hz)
     - bila backend bilang rekaman aktif: VAD per kanal -> segmen (16 kHz mono FLAC)
       -> folder spool di disk -> uploader (retry) -> POST /notes/recording/{booking}/segments

Hanya merekam saat backend menyatakan ada rekaman aktif untuk ruangan ini
(poll GET /api/v1/notes/recording/active?room_code=... tiap 2 detik; jeda dihormati).
Segmen selalu ditulis ke disk dulu, jadi gangguan jaringan tidak menghilangkan audio.

Pemakaian:
  python recorder.py --list-devices
  python recorder.py --config recorder.yaml

Logika VAD & segmentasi berupa fungsi/kelas murni (tanpa hardware) agar dapat diuji.
"""
from __future__ import annotations

import argparse
import io
import json
import os
import queue
import sys
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

try:  # butuh PortAudio; dijaga agar unit test tetap jalan tanpa hardware
    import sounddevice as sd  # type: ignore
except Exception as _sd_err:  # pragma: no cover - tergantung sistem
    sd = None
    _SD_IMPORT_ERROR = _sd_err
else:
    _SD_IMPORT_ERROR = None

BASE_DIR = Path(__file__).resolve().parent
TARGET_SR = 16000


def log(msg: str) -> None:
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)


# ---------------------------------------------------------------------------
# Konfigurasi
# ---------------------------------------------------------------------------
@dataclass
class VADConfig:
    threshold_dbfs: float = -45.0     # level minimum dianggap bicara
    min_speech_s: float = 0.6         # ucapan lebih pendek dari ini dibuang (batuk/klik)
    hangover_s: float = 0.8           # diam selama ini = ucapan selesai
    max_segment_s: float = 30.0       # segmen dipotong bila lebih panjang
    pre_roll_s: float = 0.3           # audio sebelum onset ikut disimpan
    crosstalk_db: float = 15.0        # kanal lebih pelan >X dB dari kanal terkeras dianggap bocoran


@dataclass
class ChannelMap:
    capture_channel: int              # indeks kanal di audio interface (1-based)
    channel_no: int                   # nomor mic logis di aplikasi (audio_channels.channel_no)


@dataclass
class RecorderConfig:
    backend_url: str
    agent_key: str
    room_code: str
    channels: List[ChannelMap]
    input_device: Any = None          # nama (substring) atau indeks; None = default
    samplerate: int = 48000
    block_ms: int = 50
    mode: str = "multichannel"        # multichannel | mix
    vad: VADConfig = field(default_factory=VADConfig)
    poll_interval_s: float = 2.0
    spool_dir: str = str(BASE_DIR / "recorder_spool")
    upload_format: str = "FLAC"       # FLAC | WAV
    verify_tls: bool = True
    mqtt: Optional[Dict[str, Any]] = None

    @property
    def total_capture_channels(self) -> int:
        return max(c.capture_channel for c in self.channels)


def parse_config(raw: Dict[str, Any]) -> RecorderConfig:
    for key in ("backend_url", "agent_key", "room_code", "channels"):
        if not raw.get(key):
            raise ValueError(f"recorder.yaml: '{key}' wajib diisi")
    chans = []
    for c in raw["channels"]:
        cm = ChannelMap(int(c["capture_channel"]), int(c["channel_no"]))
        if cm.capture_channel < 1 or cm.channel_no < 1:
            raise ValueError("capture_channel & channel_no dimulai dari 1")
        chans.append(cm)
    if len({c.channel_no for c in chans}) != len(chans):
        raise ValueError("channel_no duplikat di recorder.yaml")
    mode = str(raw.get("mode", "multichannel")).lower()
    if mode not in ("multichannel", "mix"):
        raise ValueError("mode harus multichannel atau mix")
    vad_raw = raw.get("vad") or {}
    vad = VADConfig(**{k: float(v) for k, v in vad_raw.items() if k in VADConfig.__dataclass_fields__})
    return RecorderConfig(
        backend_url=str(raw["backend_url"]).rstrip("/"), agent_key=str(raw["agent_key"]),
        room_code=str(raw["room_code"]), channels=chans, input_device=raw.get("input_device"),
        samplerate=int(raw.get("samplerate", 48000)), block_ms=int(raw.get("block_ms", 50)), mode=mode,
        vad=vad, poll_interval_s=float(raw.get("poll_interval_s", 2.0)),
        spool_dir=str(raw.get("spool_dir") or (BASE_DIR / "recorder_spool")),
        upload_format=str(raw.get("upload_format", "FLAC")).upper(), verify_tls=bool(raw.get("verify_tls", True)),
        mqtt=raw.get("mqtt") or None,
    )


def load_config(path: Path) -> RecorderConfig:
    import yaml
    with open(path, "r", encoding="utf-8") as f:
        return parse_config(yaml.safe_load(f) or {})


# ---------------------------------------------------------------------------
# DSP murni
# ---------------------------------------------------------------------------
def rms_dbfs(x: np.ndarray) -> float:
    if x.size == 0:
        return -120.0
    rms = float(np.sqrt(np.mean(np.square(x, dtype=np.float64))))
    return round(float(20.0 * np.log10(max(rms, 1e-6))), 1)


def channel_levels(block: np.ndarray, channels: Sequence[ChannelMap]) -> Dict[int, float]:
    """block: (frames, capture_channels) float32 -> {channel_no: dBFS}."""
    return {c.channel_no: rms_dbfs(block[:, c.capture_channel - 1]) for c in channels}


def voiced_mask(levels: Dict[int, float], threshold_dbfs: float, crosstalk_db: float) -> Dict[int, bool]:
    """Kanal dianggap bersuara bila di atas ambang DAN tidak jauh lebih pelan dari kanal
    terkeras (suara pembicara yang bocor ke mic tetangga tidak ikut direkam)."""
    if not levels:
        return {}
    loudest = max(levels.values())
    return {ch: (lvl >= threshold_dbfs and lvl >= loudest - crosstalk_db) for ch, lvl in levels.items()}


def resample_to_16k(x: np.ndarray, sr: int) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32)
    if sr == TARGET_SR or x.size == 0:
        return x
    if sr > TARGET_SR and sr % TARGET_SR == 0:
        f = sr // TARGET_SR
        n = (x.size // f) * f
        return x[:n].reshape(-1, f).mean(axis=1).astype(np.float32)
    n_out = int(round(x.size * TARGET_SR / sr))
    return np.interp(np.arange(n_out) / TARGET_SR, np.arange(x.size) / sr, x).astype(np.float32)


@dataclass
class Segment:
    channel_no: int
    start_ms: int
    end_ms: int
    audio: np.ndarray                 # float32 mono, samplerate asli
    samplerate: int


class ChannelVAD:
    """VAD energi + segmentasi untuk satu kanal. Semua waktu dalam ms rekaman."""

    def __init__(self, channel_no: int, samplerate: int, cfg: VADConfig):
        self.channel_no = channel_no
        self.sr = samplerate
        self.cfg = cfg
        self.reset()

    def reset(self) -> None:
        self.active = False
        self._pre: List[np.ndarray] = []
        self._pre_len = 0
        self._buf: List[np.ndarray] = []
        self._buf_len = 0
        self._start_ms = 0
        self._voiced_ms = 0.0
        self._silence_ms = 0.0

    @property
    def speaking(self) -> bool:
        """Untuk indikator 'sedang bicara' (termasuk masa hangover)."""
        return self.active

    def _dur_ms(self, n: int) -> float:
        return n * 1000.0 / self.sr

    def feed(self, block: np.ndarray, t_ms: int, voiced: bool) -> List[Segment]:
        """block: sampel mono kanal ini; t_ms: waktu rekaman awal blok."""
        out: List[Segment] = []
        bms = self._dur_ms(block.size)
        if not self.active:
            if voiced:
                self.active = True
                self._buf = list(self._pre) + [block]
                self._buf_len = self._pre_len + block.size
                self._start_ms = int(round(t_ms - self._dur_ms(self._pre_len)))
                self._voiced_ms, self._silence_ms = bms, 0.0
                self._pre, self._pre_len = [], 0
            else:
                self._pre.append(block)
                self._pre_len += block.size
                max_pre = int(self.cfg.pre_roll_s * self.sr)
                while self._pre and self._pre_len - self._pre[0].size >= max_pre:
                    self._pre_len -= self._pre.pop(0).size
            return out

        self._buf.append(block)
        self._buf_len += block.size
        if voiced:
            self._voiced_ms += bms
            self._silence_ms = 0.0
        else:
            self._silence_ms += bms
        end_ms = int(round(t_ms + bms))
        if self._silence_ms >= self.cfg.hangover_s * 1000:
            seg = self._emit(end_ms, trim_silence=True)
            if seg:
                out.append(seg)
            self.reset()
        elif self._dur_ms(self._buf_len) >= self.cfg.max_segment_s * 1000:
            seg = self._emit(end_ms, trim_silence=False)
            if seg:
                out.append(seg)
            # lanjut bicara: segmen berikutnya mulai dari sini
            self._buf, self._buf_len = [], 0
            self._start_ms = end_ms
            self._voiced_ms, self._silence_ms = 0.0, 0.0
        return out

    def flush(self, t_ms: Optional[int] = None) -> List[Segment]:
        """Tutup ucapan yang sedang berjalan (mis. rekaman dijeda/dihentikan)."""
        out: List[Segment] = []
        if self.active and self._buf_len:
            end = int(round(self._start_ms + self._dur_ms(self._buf_len))) if t_ms is None else int(t_ms)
            seg = self._emit(end, trim_silence=True)
            if seg:
                out.append(seg)
        self.reset()
        return out

    def _emit(self, end_ms: int, trim_silence: bool) -> Optional[Segment]:
        if self._voiced_ms < self.cfg.min_speech_s * 1000 or not self._buf:
            return None
        audio = np.concatenate(self._buf).astype(np.float32)
        if trim_silence and self._silence_ms > 0:
            keep_tail = int(0.25 * self.sr)  # sisakan 250 ms ekor
            cut = int(self._silence_ms * self.sr / 1000) - keep_tail
            if 0 < cut < audio.size:
                audio = audio[:-cut]
        end = int(round(self._start_ms + self._dur_ms(audio.size)))
        return Segment(self.channel_no, self._start_ms, min(end, end_ms), audio, self.sr)


def encode_segment(seg: Segment, fmt: str = "FLAC") -> bytes:
    import soundfile as sf
    buf = io.BytesIO()
    sf.write(buf, resample_to_16k(seg.audio, seg.samplerate), TARGET_SR, format=fmt, subtype="PCM_16")
    return buf.getvalue()


class RecordingClock:
    """Waktu rekaman efektif (ms) = elapsed dari server + waktu lokal sejak anchor."""

    def __init__(self) -> None:
        self.recording_id: Optional[str] = None
        self._anchor_mono = 0.0
        self._anchor_ms = 0

    def anchor(self, recording_id: str, elapsed_ms: int, mono: float) -> None:
        self.recording_id = recording_id
        self._anchor_mono = mono
        self._anchor_ms = int(elapsed_ms)

    def now_ms(self, mono: float) -> int:
        return int(self._anchor_ms + (mono - self._anchor_mono) * 1000)

    def drift_ms(self, server_elapsed_ms: int, mono: float) -> int:
        return self.now_ms(mono) - int(server_elapsed_ms)


# ---------------------------------------------------------------------------
# Spool (antrean di disk) & uploader
# ---------------------------------------------------------------------------
def spool_write(spool_dir: Path, meta: Dict[str, Any], audio: bytes, ext: str) -> Path:
    spool_dir.mkdir(parents=True, exist_ok=True)
    uid = meta["segment_uid"]
    audio_path = spool_dir / f"{meta['start_ms']:010d}_{meta['channel_no']:02d}_{uid}.{ext}"
    tmp = audio_path.with_suffix(audio_path.suffix + ".tmp")
    tmp.write_bytes(audio)
    os.replace(tmp, audio_path)
    meta_path = audio_path.with_suffix(audio_path.suffix + ".json")
    meta_path.write_text(json.dumps(meta), encoding="utf-8")  # ditulis terakhir = siap kirim
    return meta_path


def spool_pending(spool_dir: Path) -> List[Path]:
    if not spool_dir.exists():
        return []
    return sorted(spool_dir.glob("*.json"), key=lambda p: p.name)


class Uploader(threading.Thread):
    def __init__(self, cfg: RecorderConfig, stop: threading.Event):
        super().__init__(daemon=True, name="uploader")
        self.cfg = cfg
        self.stop_event = stop
        self.spool = Path(cfg.spool_dir)
        self.rejected = self.spool / "rejected"
        self.wake = threading.Event()

    def run(self) -> None:
        import requests
        session = requests.Session()
        session.headers["X-Agent-Key"] = self.cfg.agent_key
        backoff = 1.0
        while not self.stop_event.is_set():
            items = spool_pending(self.spool)
            if not items:
                self.wake.wait(1.0)
                self.wake.clear()
                continue
            ok_all = True
            for meta_path in items:
                if self.stop_event.is_set():
                    break
                result = self._send(session, meta_path)
                if result == "retry":
                    ok_all = False
                    break
            if ok_all:
                backoff = 1.0
            else:
                time.sleep(backoff)
                backoff = min(backoff * 2, 60.0)

    def _send(self, session, meta_path: Path) -> str:
        audio_path = meta_path.with_suffix("")  # hapus ".json"
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self._reject(meta_path, audio_path, "metadata rusak")
            return "rejected"
        if not audio_path.exists():
            meta_path.unlink(missing_ok=True)
            return "rejected"
        url = f"{self.cfg.backend_url}/api/v1/notes/recording/{meta['booking_id']}/segments"
        mime = "audio/flac" if audio_path.suffix == ".flac" else "audio/wav"
        try:
            with open(audio_path, "rb") as f:
                r = session.post(url, data={k: str(meta[k]) for k in ("channel_no", "start_ms", "end_ms",
                                                                       "recording_id", "segment_uid")},
                                 files={"audio": (audio_path.name, f, mime)}, timeout=30,
                                 verify=self.cfg.verify_tls)
        except Exception as e:
            log(f"[UPLOAD] gagal kirim ({type(e).__name__}); dicoba lagi")
            return "retry"
        if r.status_code in (200, 201, 202):
            audio_path.unlink(missing_ok=True)
            meta_path.unlink(missing_ok=True)
            return "ok"
        if r.status_code in (401, 408, 429) or r.status_code >= 500:
            log(f"[UPLOAD] server {r.status_code}; dicoba lagi")
            return "retry"
        self._reject(meta_path, audio_path, f"HTTP {r.status_code}: {r.text[:200]}")
        return "rejected"

    def _reject(self, meta_path: Path, audio_path: Path, reason: str) -> None:
        self.rejected.mkdir(parents=True, exist_ok=True)
        log(f"[UPLOAD] segmen ditolak ({reason}); dipindah ke {self.rejected}")
        for p in (audio_path, meta_path):
            if p.exists():
                os.replace(p, self.rejected / p.name)


# ---------------------------------------------------------------------------
# Status backend (poll)
# ---------------------------------------------------------------------------
class BackendPoller(threading.Thread):
    """Poll rekaman aktif ruangan. state: None | dict(recording_id, booking_id, status, elapsed_ms, ...)."""

    def __init__(self, cfg: RecorderConfig, stop: threading.Event):
        super().__init__(daemon=True, name="poller")
        self.cfg = cfg
        self.stop_event = stop
        self.lock = threading.Lock()
        self.state: Optional[Dict[str, Any]] = None
        self.state_mono = 0.0
        self.last_error: Optional[str] = None

    def run(self) -> None:
        import requests
        s = requests.Session()
        s.headers["X-Agent-Key"] = self.cfg.agent_key
        url = f"{self.cfg.backend_url}/api/v1/notes/recording/active"
        while not self.stop_event.is_set():
            t0 = time.monotonic()
            try:
                r = s.get(url, params={"room_code": self.cfg.room_code}, timeout=5, verify=self.cfg.verify_tls)
                if r.status_code == 204:
                    self._set(None, t0)
                elif r.status_code == 200:
                    self._set(r.json().get("data"), t0 + (time.monotonic() - t0) / 2)
                else:
                    self._error(f"HTTP {r.status_code}: {r.text[:200]}")
            except Exception as e:
                # Jaringan putus: pertahankan state terakhir agar rekaman tidak terputus.
                self._error(f"{type(e).__name__}: {e}")
            self.stop_event.wait(self.cfg.poll_interval_s)

    def _set(self, state: Optional[Dict[str, Any]], mono: float) -> None:
        with self.lock:
            self.state, self.state_mono, self.last_error = state, mono, None

    def _error(self, msg: str) -> None:
        if msg != self.last_error:
            log(f"[POLL] {msg}")
        self.last_error = msg

    def snapshot(self) -> Tuple[Optional[Dict[str, Any]], float]:
        with self.lock:
            return self.state, self.state_mono


# ---------------------------------------------------------------------------
# MQTT (opsional): level & kanal aktif untuk indikator pembicara
# ---------------------------------------------------------------------------
class LevelPublisher:
    def __init__(self, cfg: RecorderConfig):
        self.cfg = cfg
        self.client = None
        self.prefix = f"{(cfg.mqtt or {}).get('topic_prefix', 'smr/audio')}/{cfg.room_code}"
        self.interval = 1.0 / float((cfg.mqtt or {}).get("levels_hz", 5))
        self._last = 0.0
        self._last_active: Optional[List[int]] = None
        self._last_active_pub = 0.0
        self._peak: Dict[int, float] = {}

    def start(self) -> None:
        m = self.cfg.mqtt
        if not m or not m.get("host"):
            return
        try:
            import paho.mqtt.client as mqtt
        except ImportError:
            log("[MQTT] paho-mqtt tidak terpasang; publikasi level dimatikan")
            return
        c = mqtt.Client(client_id=f"smr-recorder-{self.cfg.room_code}-{uuid.uuid4().hex[:6]}")  # API paho 1.6
        if m.get("username"):
            c.username_pw_set(m["username"], m.get("password") or "")
        if m.get("tls"):
            c.tls_set(ca_certs=m.get("ca_certs"))
        try:
            c.connect_async(m["host"], int(m.get("port", 1883)), keepalive=30)
            c.loop_start()
            self.client = c
            log(f"[MQTT] publikasi level ke {self.prefix}/levels|active")
        except Exception as e:
            log(f"[MQTT] gagal konek: {e}")

    def update(self, levels: Dict[int, float], active: List[int]) -> None:
        if self.client is None:
            return
        for ch, lv in levels.items():
            self._peak[ch] = max(self._peak.get(ch, -120.0), lv)
        now = time.monotonic()
        ts = time.strftime("%Y-%m-%dT%H:%M:%S%z")
        if now - self._last >= self.interval:
            self.client.publish(f"{self.prefix}/levels", json.dumps(
                {"levels": {str(k): v for k, v in self._peak.items()}, "ts": ts}), qos=0)
            self._peak.clear()
            self._last = now
        if active != self._last_active or now - self._last_active_pub >= 1.0:
            self.client.publish(f"{self.prefix}/active", json.dumps({"active": active, "ts": ts}), qos=0)
            self._last_active, self._last_active_pub = list(active), now

    def stop(self) -> None:
        if self.client is not None:
            self.client.loop_stop()
            self.client.disconnect()


# ---------------------------------------------------------------------------
# Inti pemrosesan (tanpa I/O perangkat audio; dapat diuji)
# ---------------------------------------------------------------------------
class SegmentProcessor:
    """Menerima blok multikanal + status backend; menghasilkan segmen per kanal."""

    def __init__(self, cfg: RecorderConfig):
        self.cfg = cfg
        self.vads = {c.channel_no: ChannelVAD(c.channel_no, cfg.samplerate, cfg.vad) for c in cfg.channels}
        self.clock = RecordingClock()
        self.recording: Optional[Dict[str, Any]] = None  # state backend saat ini (status recording)
        # indikator pembicara (untuk MQTT) juga saat tidak merekam
        self.speak_hold: Dict[int, float] = {c.channel_no: -1e9 for c in cfg.channels}

    def set_backend_state(self, state: Optional[Dict[str, Any]], mono: float) -> List[Tuple[Dict[str, Any], Segment]]:
        """Perbarui status rekaman. Mengembalikan segmen yang ditutup (flush) karena jeda/berhenti."""
        out: List[Tuple[Dict[str, Any], Segment]] = []
        rec_now = state if state and state.get("status") == "recording" else None
        prev = self.recording
        changed = (prev is None) != (rec_now is None) or (
            prev is not None and rec_now is not None and prev["recording_id"] != rec_now["recording_id"])
        if changed:
            if prev is not None:
                t = self.clock.now_ms(mono)
                for v in self.vads.values():
                    out += [(prev, s) for s in v.flush(t)]
            for v in self.vads.values():
                v.reset()
            if rec_now is not None:
                self.clock.anchor(rec_now["recording_id"], int(rec_now.get("elapsed_ms", 0)), mono)
                log(f"[REC] merekam: recording {rec_now['recording_id']} (booking {rec_now['booking_id']})")
            else:
                log("[REC] tidak merekam (tidak ada rekaman aktif / dijeda)")
        elif rec_now is not None and abs(self.clock.drift_ms(int(rec_now.get("elapsed_ms", 0)), mono)) > 1500:
            self.clock.anchor(rec_now["recording_id"], int(rec_now.get("elapsed_ms", 0)), mono)
        self.recording = rec_now
        return out

    def process_block(self, block: np.ndarray, mono: float) -> Tuple[Dict[int, float], List[int], List[Tuple[Dict[str, Any], Segment]]]:
        levels = channel_levels(block, self.cfg.channels)
        mask = voiced_mask(levels, self.cfg.vad.threshold_dbfs, self.cfg.vad.crosstalk_db)
        hold_s = self.cfg.vad.hangover_s
        for ch, v in mask.items():
            if v:
                self.speak_hold[ch] = mono
        active = sorted(ch for ch, t in self.speak_hold.items() if mono - t <= hold_s)
        segs: List[Tuple[Dict[str, Any], Segment]] = []
        if self.recording is not None:
            t_ms = self.clock.now_ms(mono)
            for c in self.cfg.channels:
                mono_ch = block[:, c.capture_channel - 1].astype(np.float32)
                for s in self.vads[c.channel_no].feed(mono_ch, t_ms, mask[c.channel_no]):
                    segs.append((self.recording, s))
        return levels, active, segs


def segment_meta(rec: Dict[str, Any], seg: Segment) -> Dict[str, Any]:
    return {"booking_id": rec["booking_id"], "recording_id": rec["recording_id"], "channel_no": seg.channel_no,
            "start_ms": max(0, seg.start_ms), "end_ms": max(0, seg.end_ms), "segment_uid": str(uuid.uuid4())}


# ---------------------------------------------------------------------------
# Runtime (perangkat audio)
# ---------------------------------------------------------------------------
def _require_sd():
    if sd is None:
        raise SystemExit(f"[FATAL] sounddevice/PortAudio tidak tersedia: {_SD_IMPORT_ERROR}. "
                         "Jalankan: pip install -r requirements.txt")


def list_devices() -> None:
    _require_sd()
    for i, d in enumerate(sd.query_devices()):
        if d.get("max_input_channels", 0) > 0:
            print(f"[{i:2d}] {d['name']}  (input {d['max_input_channels']} kanal, "
                  f"{int(d.get('default_samplerate', 0))} Hz, hostapi {d.get('hostapi')})")


def resolve_device(spec: Any) -> Optional[int]:
    _require_sd()
    if spec is None or spec == "":
        return None
    if isinstance(spec, int) or str(spec).isdigit():
        return int(spec)
    for i, d in enumerate(sd.query_devices()):
        if str(spec).lower() in d["name"].lower() and d.get("max_input_channels", 0) > 0:
            return i
    raise SystemExit(f"[FATAL] perangkat input '{spec}' tidak ditemukan (lihat --list-devices)")


def run(cfg: RecorderConfig) -> None:
    _require_sd()
    stop = threading.Event()
    blocks: "queue.Queue[Tuple[np.ndarray, float]]" = queue.Queue(maxsize=2000)
    poller = BackendPoller(cfg, stop)
    uploader = Uploader(cfg, stop)
    publisher = LevelPublisher(cfg)
    processor = SegmentProcessor(cfg)
    spool = Path(cfg.spool_dir)
    ext = "flac" if cfg.upload_format == "FLAC" else "wav"
    dropped = [0]

    def callback(indata, frames, time_info, status):  # thread PortAudio: seringan mungkin
        if status:
            log(f"[AUDIO] {status}")
        try:
            blocks.put_nowait((indata.copy(), time.monotonic()))
        except queue.Full:
            dropped[0] += 1

    device = resolve_device(cfg.input_device)
    n_ch = cfg.total_capture_channels
    blocksize = int(cfg.samplerate * cfg.block_ms / 1000)
    log(f"[INIT] ruangan {cfg.room_code}, mode {cfg.mode}, {len(cfg.channels)} kanal mic, perangkat {device}, "
        f"{cfg.samplerate} Hz")
    poller.start()
    uploader.start()
    publisher.start()
    last_poll_mono = -1.0
    try:
        with sd.InputStream(device=device, channels=n_ch, samplerate=cfg.samplerate, blocksize=blocksize,
                            dtype="float32", callback=callback):
            while True:
                try:
                    block, mono = blocks.get(timeout=1.0)
                except queue.Empty:
                    continue
                state, smono = poller.snapshot()
                if smono != last_poll_mono:
                    last_poll_mono = smono
                    for rec, seg in processor.set_backend_state(state, smono or mono):
                        spool_write(spool, segment_meta(rec, seg), encode_segment(seg, cfg.upload_format), ext)
                        uploader.wake.set()
                levels, active, segs = processor.process_block(block, mono)
                publisher.update(levels, active)
                for rec, seg in segs:
                    spool_write(spool, segment_meta(rec, seg), encode_segment(seg, cfg.upload_format), ext)
                    uploader.wake.set()
                if dropped[0]:
                    log(f"[AUDIO] {dropped[0]} blok audio terbuang (CPU terlalu sibuk)")
                    dropped[0] = 0
    except KeyboardInterrupt:
        log("[EXIT] dihentikan")
    finally:
        mono = time.monotonic()
        for rec, seg in processor.set_backend_state(None, mono):
            spool_write(spool, segment_meta(rec, seg), encode_segment(seg, cfg.upload_format), ext)
        stop.set()
        publisher.stop()


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Recorder multikanal Smart Meeting Room")
    ap.add_argument("--config", default=str(BASE_DIR / "recorder.yaml"))
    ap.add_argument("--list-devices", action="store_true", help="tampilkan perangkat input audio")
    args = ap.parse_args(argv)
    if args.list_devices:
        list_devices()
        return 0
    cfg = load_config(Path(args.config))
    run(cfg)
    return 0


if __name__ == "__main__":
    sys.exit(main())
