# Device Agent — Smart Meeting Room

Gateway antara server (MQTT) dan perangkat AV di ruangan: panel LG 55VL5PJ,
processor videowall Digibird, dan (opsional) digital mixer Behringer XR18 / Midas MR18.
Berjalan di **PC Monitoring** (Windows) yang satu LAN dengan perangkat.

```
FastAPI ──MQTT──► Mosquitto ◄──MQTT── device_agent.py ──┬─ WoL / TCP 9761 / WS 3000 ─► 6× LG 55VL5PJ
                                                         ├─ UDP 5000 / RS232 ─────────► Digibird
                                                         └─ OSC UDP 10024 ────────────► XR18 (opsional)
```

Kontrak topic & payload: `docs/architecture/LIVE_MEETING.md` §3.

## 1. Instalasi

Butuh Python 3.10+ (centang "Add to PATH").

```powershell
cd C:\smr\agent
.\run-agent.ps1 -InstallOnly      # buat .venv + install requirements.txt
notepad devices.yaml              # isi IP/MAC/kode perangkat & kredensial MQTT
.\run-agent.ps1                   # uji jalan di console (Ctrl+C untuk berhenti)
```

Log: `agent\agent.log` dan console.

### Jalankan sebagai Windows service (NSSM)

1. Unduh NSSM (https://nssm.cc), salin `nssm.exe` ke `C:\smr\tools\`.
2. PowerShell **as Administrator**:

```powershell
C:\smr\tools\nssm.exe install SMR-DeviceAgent "C:\smr\agent\.venv\Scripts\python.exe" "C:\smr\agent\device_agent.py"
C:\smr\tools\nssm.exe set SMR-DeviceAgent AppDirectory "C:\smr\agent"
C:\smr\tools\nssm.exe set SMR-DeviceAgent Start SERVICE_AUTO_START
C:\smr\tools\nssm.exe set SMR-DeviceAgent AppStdout "C:\smr\agent\service.log"
C:\smr\tools\nssm.exe set SMR-DeviceAgent AppStderr "C:\smr\agent\service.log"
C:\smr\tools\nssm.exe set SMR-DeviceAgent AppRotateFiles 1
C:\smr\tools\nssm.exe set SMR-DeviceAgent AppRotateBytes 5000000
C:\smr\tools\nssm.exe set SMR-DeviceAgent AppExit Default Restart
C:\smr\tools\nssm.exe start SMR-DeviceAgent
```

Setelah mengubah `devices.yaml`: `nssm restart SMR-DeviceAgent`.
Firewall Windows: izinkan Python keluar ke broker (1883/8883) dan **masuk UDP** dari
IP XR18 (balasan OSC) & Digibird (balasan UDP).

## 2. Kredensial MQTT

Broker Mosquitto mewajibkan login + ACL (`deploy/mosquitto/`). Agent memakai user
`smr_agent` (baca `smr/devices/+/command/#`, tulis `state`/`ack`/`smr/audio/#`/`smr/agent/#`):

```yaml
mqtt:
  host: "192.168.10.5"
  port: 1883            # 8883 bila TLS
  username: "smr_agent"
  password: "..."       # dari deploy/mosquitto/make-passwd.*
  agent_id: "pc-monitoring-1"
  tls: { enabled: false, ca_cert: "C:/smr/agent/ca.crt" }
```

- Agent mengirim status retained `smr/agent/<agent_id>/status {online: true, devices: [...]}`;
  bila agent mati/putus, broker mengirim **LWT** `{online: false}` dan server menandai
  semua perangkat agent itu offline.
- Health poll tiap `health_interval_s` (30 dtk) → `smr/devices/<id>/state` (retained).
- Perintah untuk satu perangkat dieksekusi berurutan; perangkat berbeda paralel.
- Perintah lebih tua dari `max_command_age_s` (60 dtk) ditolak (mencegah WoL "telat").

## 3. Perangkat di aplikasi ↔ devices.yaml

Buat perangkat di menu **Perangkat IoT** dengan ruangan yang benar:

| Aplikasi (tipe / kode) | devices.yaml |
|---|---|
| `tv` / `TV-PANEL-1..6` | panel LG (WoL + IP control) |
| `videowall_controller` / `DIGIBIRD-4X8` | Digibird (`params` scene/input/window) |
| `audio_mixer` / `XR18-RAPAT`, config `{"driver": "xair"}` | blok `driver: xair` |

`code` harus sama persis. `id` di yaml boleh UUID aplikasi (disarankan) atau dibiarkan
placeholder (dicocokkan via kode).

**Keamanan:** nilai dari server yang masuk ke perintah ASCII/serial hanya diterima bila
tercantum di `params:` (int min/max atau enum) atau `map:` perangkat tsb. Selain itu
agent membalas ack `ok=false "Parameter ditolak"` tanpa menyentuh perangkat.

## 4. Panel LG 55VL5PJ

Di tiap panel (menu Installer / Admin, bisa dengan remote):
- **Network → IP statis** (mis. 192.168.10.101..106), catat **MAC** (Settings > Network > Info).
- **Wake On LAN = On**, **Network Ready / LAN standby = On** (agar bisa dinyalakan & di-query saat standby).
- **IP Control (port 9761) aktif**, **Set ID = 1**.
- Input tetap **HDMI 1** (sumber diatur Digibird).

Uji manual dari PC Monitoring (PowerShell):

```powershell
$c = New-Object Net.Sockets.TcpClient("192.168.10.101", 9761); $s = $c.GetStream()
$b = [Text.Encoding]::ASCII.GetBytes("ka 01 ff`r"); $s.Write($b,0,$b.Length); Start-Sleep -m 300
$r = New-Object byte[] 64; $n = $s.Read($r,0,64); [Text.Encoding]::ASCII.GetString($r,0,$n)   # a 01 OK01x
```

### Pairing SSAP (opsional, alternatif power off)

Hanya bila memakai langkah `ssap:`. Jalankan `.\run-agent.ps1 -Pair 192.168.10.101`,
terima prompt di layar TV, salin `client-key` ke `client_key` di yaml. Manifest pairing
(`drivers/lg_manifest.json`) meminta izin `CONTROL_POWER`, `CONTROL_INPUT_TV`,
`READ_INPUT_DEVICE_LIST`, dst. **Client-key lama hasil pairing tanpa izin harus di-pairing ulang**
(gejala: `401 insufficient permissions` saat turnOff).

## 5. Digibird DB-VWC2-B-4H8H-PV

- Set IP LAN processor (app DigiBird / web). Kontrol: UDP 5000, ASCII, balasan `[OK]`/`[ERR]`.
- **Simpan scene** di processor sesuai preset aplikasi: 1 = fullscreen, 2 = split2,
  3 = main_side, 4 = quad, 5 = panels6 (atau ubah `config.presets` perangkat controller di aplikasi).
- Sumber: HDMI 1..4 = input 1..4. Jendela 1..16.

## 6. XR18 / MR18 (opsional, direkomendasikan)

Wiring:

```
M118-A CH1..8 OUT ─► XR18 CH1..8     (Mic 1..8)
M118-B CH1..8 OUT ─► XR18 CH9..16    (Mic 9..16)
XR18 Main L/R    ─► FC-A5400 LINE/DVD IN
XR18 USB         ─► PC Monitoring (recorder 18 kanal)
XR18 LAN         ─► switch (mode LAN/Client, IP statis mis. 192.168.10.130)
```

- Di X-AIR Edit: Setup → Network → **LAN mode**, IP statis. OSC aktif otomatis (UDP 10024).
- Aplikasi: tambahkan perangkat `audio_mixer` (config `{"driver": "xair"}`) di ruangan,
  lalu Audio → **Kanal Mic** → "Generate 16 kanal default" (mixer_channel = n).
- `devices.yaml`: aktifkan blok XR18 (`driver: xair`, `host`, `room_code` = kode ruangan).
- Agent menjaga `/xremote` (<10 dtk), berlangganan `/meters/1`, mengirim level ≤5 Hz,
  status pembicara (ambang `active_threshold_db` −45 dBFS, hold 800 ms) dan state mixer
  (retained). Set mute/fader/gain diverifikasi dengan query ulang.
- Tanpa XR18: jangan buat device `audio_mixer`; aplikasi otomatis mode "tanpa mixer".

## 7. Uji tanpa hardware

`python -m pytest tests/iot -q` (dari root repo) menjalankan broker MQTT mini, Digibird/LG/XR18
palsu, dan agent sungguhan — memverifikasi command → ack, whitelist parameter, LWT, level &
pembicara aktif.
