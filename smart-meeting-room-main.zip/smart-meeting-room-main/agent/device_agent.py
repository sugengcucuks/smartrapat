# -*- coding: utf-8 -*-
"""
SMART MEETING ROOM - Device Agent (gateway AV)
==============================================
Jalan di PC Monitoring (Windows service via NSSM, lihat agent/README.md).

  1. Subscribe  {prefix}/+/command/+           (prefix default smr/devices)
  2. Cocokkan device_id / payload.device_code dengan devices.yaml
  3. Validasi parameter (whitelist `params:`/`map:`) -> jalankan langkah fisik
     (WoL, UDP Digibird, LG IP control 9761, SSAP, TCP, RS232, delay) atau
     driver X-Air (OSC)
  4. Publish ack   {prefix}/{device_id}/ack    {cmd_id, ok, error, response, ts}
  5. Publish state {prefix}/{device_id}/state  (retained; health poll tiap 30 dtk)
  6. Status agent  {root}/agent/{agent_id}/status (retained; LWT = offline)

Setiap perangkat punya antrean & thread sendiri: perintah untuk satu perangkat
dieksekusi berurutan, perangkat berbeda paralel; on_message tidak pernah blok.

Pairing TV LG (sekali per TV, untuk client-key SSAP):
  .venv\\Scripts\\python device_agent.py --pair <IP-TV>
"""
from __future__ import annotations

import argparse
import collections
import json
import queue
import re
import socket
import ssl
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

try:
    import paho.mqtt.client as mqtt
except ImportError:  # pragma: no cover
    print("[FATAL] paho-mqtt belum terinstall. Jalankan: pip install -r requirements.txt")
    sys.exit(1)

BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from drivers import DriverError  # noqa: E402
from drivers import digibird, lg_signage, net, wol  # noqa: E402

AGENT_VERSION = "2.0.0"
CONFIG_PATH = BASE_DIR / "devices.yaml"
LOG_PATH = BASE_DIR / "agent.log"
_log_lock = threading.Lock()


def log(msg: str) -> None:
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    with _log_lock:
        print(line, flush=True)
        try:
            with open(LOG_PATH, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except OSError:
            pass


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Validasi & render parameter (menutup celah injeksi perintah)
# ---------------------------------------------------------------------------

_PLACEHOLDER = re.compile(r"\{payload\.(\w+)\}")


class ParamError(ValueError):
    pass


def validate_param(dev: Dict[str, Any], key: str, value: Any) -> str:
    """Nilai parameter hanya boleh lolos bila:
    - `params.<key>` mendefinisikan tipe int (min/max) atau daftar `enum`, atau
    - `map.<key>` memuat nilai tsb sebagai kunci (hasil = nilai protokol di yaml).
    Selain itu ditolak. Hasil selalu string aman untuk ASCII/hex/serial."""
    spec = (dev.get("params") or {}).get(key)
    table = (dev.get("map") or {}).get(key)
    if value is None:
        raise ParamError(f"parameter '{key}' wajib diisi")
    if table is not None:
        for src, dst in table.items():
            if str(src) == str(value):
                return str(dst)
        if spec is None:
            raise ParamError(f"nilai '{value}' untuk '{key}' tidak ada di map devices.yaml")
    if spec is None:
        raise ParamError(f"parameter '{key}' tidak diizinkan (tambahkan ke params:/map: di devices.yaml)")
    typ = str(spec.get("type", "int"))
    if typ == "int":
        if isinstance(value, bool):
            raise ParamError(f"'{key}' harus bilangan bulat")
        try:
            iv = int(str(value), 10)
        except ValueError:
            raise ParamError(f"'{key}' harus bilangan bulat: {value!r}")
        lo, hi = spec.get("min"), spec.get("max")
        if (lo is not None and iv < int(lo)) or (hi is not None and iv > int(hi)):
            raise ParamError(f"'{key}'={iv} di luar rentang {lo}..{hi}")
        return str(iv)
    if typ == "enum":
        allowed = [str(x) for x in spec.get("values") or []]
        if str(value) not in allowed:
            raise ParamError(f"'{key}'={value!r} tidak diizinkan (pilihan: {', '.join(allowed)})")
        return str(value)
    raise ParamError(f"tipe params '{typ}' untuk '{key}' tidak dikenal (int|enum)")


def render(template: str, dev: Dict[str, Any], payload: Dict[str, Any]) -> str:
    return _PLACEHOLDER.sub(lambda m: validate_param(dev, m.group(1), payload.get(m.group(1))), str(template))


def _step_body(step: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
    if len(step) != 1:
        raise ValueError(f"Langkah harus punya tepat 1 jenis: {list(step)}")
    kind, cfg = next(iter(step.items()))
    return kind, (cfg or {})


def prepare_steps(dev: Dict[str, Any], steps: List[Dict[str, Any]], payload: Dict[str, Any]) -> List[Tuple[str, Dict[str, Any]]]:
    """Render SEMUA placeholder sebelum eksekusi -> tidak ada eksekusi setengah jalan."""
    out = []
    for step in steps:
        kind, cfg = _step_body(step)
        rendered = {k: (render(v, dev, payload) if isinstance(v, str) else v) for k, v in cfg.items()}
        out.append((kind, rendered))
    return out


def step_bytes(cfg: Dict[str, Any]) -> bytes:
    if "hex" in cfg:
        return bytes.fromhex(str(cfg["hex"]).replace(":", "").replace(" ", ""))
    if "ascii" in cfg:
        return str(cfg["ascii"]).encode("utf-8")
    raise ValueError("Langkah butuh 'hex' atau 'ascii'")


def execute_step(kind: str, cfg: Dict[str, Any], ssap_manifest: Optional[str] = None) -> Optional[str]:
    """Jalankan satu langkah; kembalikan teks respons. Lempar DriverError bila gagal."""
    if kind == "delay":
        time.sleep(int(cfg.get("ms", 0)) / 1000)
        return None
    if kind == "wol":
        return wol.send_wol(cfg["mac"], cfg.get("broadcast", "255.255.255.255"), int(cfg.get("port", 9)))
    if kind in ("udp", "digibird"):
        data = step_bytes(cfg).decode("ascii", "replace")
        return digibird.send(cfg["host"], int(cfg.get("port", 5000)), data,
                             int(cfg.get("wait_ms", 800)), bool(cfg.get("expect_reply", False)))
    if kind == "tcp":
        raw = net.send_tcp(cfg["host"], int(cfg["port"]), step_bytes(cfg), int(cfg.get("wait_ms", 500)))
        ok, text = digibird.parse_reply(raw)
        if not ok:
            raise DriverError(f"Perangkat menolak: {text}")
        return text
    if kind == "serial":
        raw = net.send_serial(cfg["port"], int(cfg.get("baud", 9600)), step_bytes(cfg))
        ok, text = digibird.parse_reply(raw)
        if not ok:
            raise DriverError(f"Perangkat (serial) menolak: {text}")
        return text
    if kind == "lg_ip":
        return lg_signage.ip_control(cfg["host"], str(cfg.get("cmd", "ka")), str(cfg.get("data", "01")),
                                     str(cfg.get("set_id", "01")), int(cfg.get("port", 9761)),
                                     int(cfg.get("wait_ms", 1500)))
    if kind == "ssap":
        return lg_signage.ssap_request(cfg["host"], cfg["uri"], str(cfg.get("client_key", "")),
                                       int(cfg.get("port", 3000)), cfg.get("payload"),
                                       float(cfg.get("wait_s", 5)), ssap_manifest)
    raise ValueError(f"Jenis langkah tidak dikenal: {kind}")


# ---------------------------------------------------------------------------
# Perangkat
# ---------------------------------------------------------------------------

ACTION_STATE = {
    "power_on": ("power", "on"),
    "power_off": ("power", "off"),
}


class Device:
    def __init__(self, cfg: Dict[str, Any], agent: "DeviceAgent"):
        self.cfg = cfg
        self.agent = agent
        self.id = str(cfg.get("id") or "")
        self.code = str(cfg.get("code") or "")
        self.name = str(cfg.get("name") or self.code or self.id)
        self.state: Dict[str, Any] = {"online": None, "power": None, "source": None, "layout": None}
        self.queue: "queue.Queue[Optional[Tuple[str, Dict[str, Any]]]]" = queue.Queue()
        self.mixer = None
        self._thread = threading.Thread(target=self._worker, name=f"dev-{self.code}", daemon=True)

    @property
    def topic_ref(self) -> str:
        """Id di topic: UUID aplikasi bila sudah diisi, selain itu kode."""
        if re.fullmatch(r"[0-9a-fA-F-]{36}", self.id):
            return self.id
        return self.code or self.id

    def matches(self, device_id: str, code: Optional[str]) -> bool:
        if self.id and self.id.lower() == device_id.lower():
            return True
        return bool(code) and self.code == code

    def start(self) -> None:
        driver = str(self.cfg.get("driver", "")).lower()
        if driver == "xair":
            from drivers.xair import XAirMixer
            room = str(self.cfg.get("room_code") or "")
            if not room:
                log(f"[WARN] {self.name}: room_code wajib untuk mixer X-Air (topic smr/audio/<room_code>/...)")
            self.mixer = XAirMixer(
                host=self.cfg["host"], port=int(self.cfg.get("port", 10024)), room_code=room,
                publish=lambda kind, payload, retain: self.agent.publish_audio(room, kind, payload, retain),
                channels=int(self.cfg.get("channels", 16)),
                threshold_db=float(self.cfg.get("active_threshold_db", -45)),
                hold_ms=int(self.cfg.get("active_hold_ms", 800)),
                levels_hz=float(self.cfg.get("levels_hz", 5)),
                log=log,
            )
            try:
                self.mixer.start()
            except Exception as exc:
                log(f"[ERROR] {self.name}: gagal start driver X-Air: {exc}")
        self._thread.start()

    def enqueue(self, action: str, payload: Dict[str, Any]) -> None:
        self.queue.put((action, payload))

    def _worker(self) -> None:
        while True:
            item = self.queue.get()
            if item is None:
                return
            action, payload = item
            ok, error, response = self.run(action, payload)
            self.agent.publish_ack(self, payload.get("cmd_id"), action, ok, error, response)
            if ok:
                self._apply_state(action, payload)
                self.agent.publish_state(self)

    def run(self, action: str, payload: Dict[str, Any]) -> Tuple[bool, Optional[str], Optional[str]]:
        log(f"[CMD] {self.name}: {action} cmd={payload.get('cmd_id')}")
        try:
            if self.mixer is not None and action not in (self.cfg.get("actions") or {}):
                resp = self.mixer.execute(action, payload)
                log(f"  [OK] {self.name}: {action} -> {resp}")
                return True, None, resp
            steps = (self.cfg.get("actions") or {}).get(action)
            if steps is None:
                return False, f"Aksi '{action}' tidak dikonfigurasi untuk {self.code} di devices.yaml", None
            prepared = prepare_steps(self.cfg, steps, payload)
            responses = []
            for i, (kind, cfg) in enumerate(prepared, 1):
                resp = execute_step(kind, cfg, self.cfg.get("ssap_manifest"))
                log(f"  step {i}: {kind} -> {resp or 'ok'}")
                if resp:
                    responses.append(resp)
            return True, None, " | ".join(responses)[:500] or None
        except ParamError as exc:
            log(f"  [TOLAK] {self.name}: {exc}")
            return False, f"Parameter ditolak: {exc}", None
        except (DriverError, OSError, ValueError, KeyError) as exc:
            log(f"  [ERROR] {self.name}: {exc}")
            return False, str(exc) or exc.__class__.__name__, None
        except Exception as exc:  # jangan sampai worker mati
            log(f"  [ERROR] {self.name}: {exc!r}")
            return False, f"Kesalahan agent: {exc}", None

    def _apply_state(self, action: str, payload: Dict[str, Any]) -> None:
        if action in ACTION_STATE:
            k, v = ACTION_STATE[action]
            self.state[k] = v
        elif action == "apply_layout":
            self.state["layout"] = payload.get("preset") or payload.get("scene")
        elif action == "change_source":
            self.state["source"] = payload.get("source") or payload.get("input")

    # ------------------------------------------------------------------
    # Health
    # ------------------------------------------------------------------
    def check_health(self) -> None:
        h = self.cfg.get("health") or {}
        typ = str(h.get("type") or ("xair" if self.mixer else "ping" if self.cfg.get("host") else "none"))
        host = h.get("host") or self.cfg.get("host")
        online: Optional[bool] = None
        if typ == "none" or not (host or self.mixer):
            return
        if typ == "xair" and self.mixer is not None:
            online = self.mixer.health()
        elif typ == "lg_ip":
            power = lg_signage.query_power(host, str(h.get("set_id", "01")), int(h.get("port", 9761)))
            online = power is not None
            if power:
                self.state["power"] = power
            elif h.get("fallback_ping", True):
                # Panel standby (LAN standby) kadang tidak menjawab IP control
                online = net.ping(host)
                if online:
                    self.state["power"] = self.state.get("power") or "off"
        elif typ == "tcp":
            online = net.tcp_probe(host, int(h.get("port", 80)))
        elif typ == "ping":
            online = net.ping(host)
        self.state["online"] = online
        self.agent.publish_state(self)


# ---------------------------------------------------------------------------
# Agent MQTT
# ---------------------------------------------------------------------------

class DeviceAgent:
    def __init__(self, config: Dict[str, Any]):
        mcfg = config.get("mqtt") or {}
        self.mcfg = mcfg
        self.prefix = str(mcfg.get("topic_prefix", "smr/devices")).rstrip("/")
        self.root = self.prefix.rsplit("/", 1)[0] if "/" in self.prefix else self.prefix
        self.agent_id = str(mcfg.get("agent_id") or socket.gethostname()).replace("/", "_")
        self.health_interval = float(config.get("health_interval_s", 30))
        self.max_age = float(config.get("max_command_age_s", 60))
        self.devices = [Device(d, self) for d in (config.get("devices") or [])]
        self._seen_cmds: "collections.OrderedDict[str, float]" = collections.OrderedDict()
        self._stop = threading.Event()

        self.status_topic = f"{self.root}/agent/{self.agent_id}/status"
        self.client = mqtt.Client(client_id=f"smr-agent-{self.agent_id}", clean_session=True)
        if mcfg.get("username"):
            self.client.username_pw_set(str(mcfg["username"]), str(mcfg.get("password") or "") or None)
        tls = mcfg.get("tls") or {}
        if tls.get("enabled"):
            ctx = ssl.create_default_context(cafile=tls.get("ca_cert") or None)
            if tls.get("insecure"):
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
            self.client.tls_set_context(ctx)
        self.client.will_set(self.status_topic, json.dumps(self._status_payload(False)), qos=1, retain=True)
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message
        self.client.reconnect_delay_set(1, 30)

    # ------------------------------------------------------------------
    def _status_payload(self, online: bool) -> Dict[str, Any]:
        return {
            "online": online,
            "agent_id": self.agent_id,
            "version": AGENT_VERSION,
            "devices": [{"id": d.topic_ref, "code": d.code, "name": d.name} for d in self.devices],
            "ts": now_iso(),
        }

    def _on_connect(self, client, _userdata, _flags, rc, *_a) -> None:
        if rc != 0:
            log(f"[MQTT] Koneksi ditolak rc={rc} ({mqtt.connack_string(rc)}) - cek username/password/ACL")
            return
        topic = f"{self.prefix}/+/command/+"
        client.subscribe(topic, qos=1)
        client.publish(self.status_topic, json.dumps(self._status_payload(True)), qos=1, retain=True)
        log(f"[MQTT] Terhubung sebagai agent '{self.agent_id}'. Subscribe: {topic}")

    def _on_disconnect(self, _client, _userdata, rc, *_a) -> None:
        if rc != 0:
            log(f"[MQTT] Terputus (rc={rc}); mencoba ulang otomatis")

    def _on_message(self, _client, _userdata, msg) -> None:
        """Cepat & tidak blok: parsing, dedup, lalu masukkan ke antrean perangkat."""
        try:
            parts = msg.topic.split("/")
            device_id, action = parts[-3], parts[-1]
            try:
                payload = json.loads(msg.payload or b"{}")
            except ValueError:
                log(f"[WARN] payload bukan JSON di {msg.topic}")
                return
            if not isinstance(payload, dict):
                return
            dev = self.find_device(device_id, payload.get("device_code"))
            if dev is None:
                return  # milik agent lain / belum terdaftar di devices.yaml
            cmd_id = str(payload.get("cmd_id") or "")
            if cmd_id:
                if cmd_id in self._seen_cmds:
                    return  # duplikat QoS 1
                self._seen_cmds[cmd_id] = time.time()
                while len(self._seen_cmds) > 500:
                    self._seen_cmds.popitem(last=False)
            if not re.fullmatch(r"[a-z0-9_]{1,40}", action):
                self.publish_ack(dev, cmd_id, action, False, "Nama aksi tidak valid", None)
                return
            age = self._age(payload.get("ts"))
            if self.max_age > 0 and age is not None and age > self.max_age:
                self.publish_ack(dev, cmd_id, action, False, f"Perintah kedaluwarsa ({age:.0f} dtk)", None)
                return
            dev.enqueue(action, payload)
        except Exception as exc:
            log(f"[ERROR] on_message: {exc!r}")

    @staticmethod
    def _age(ts: Any) -> Optional[float]:
        if not ts:
            return None
        try:
            t = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
            if t.tzinfo is None:
                t = t.replace(tzinfo=timezone.utc)
            return (datetime.now(timezone.utc) - t).total_seconds()
        except ValueError:
            return None

    def find_device(self, device_id: str, code: Optional[str]) -> Optional[Device]:
        for d in self.devices:
            if d.matches(device_id, code):
                return d
        return None

    # ------------------------------------------------------------------
    def _publish(self, topic: str, payload: Dict[str, Any], retain: bool = False, qos: int = 1) -> None:
        self.client.publish(topic, json.dumps(payload, default=str), qos=qos, retain=retain)

    def publish_ack(self, dev: Device, cmd_id: Any, action: str, ok: bool,
                    error: Optional[str], response: Optional[str]) -> None:
        self._publish(f"{self.prefix}/{dev.topic_ref}/ack", {
            "cmd_id": cmd_id, "ok": ok, "error": error, "response": response,
            "action": action, "device_code": dev.code, "ts": now_iso(),
        })

    def publish_state(self, dev: Device) -> None:
        self._publish(f"{self.prefix}/{dev.topic_ref}/state", {**dev.state, "ts": now_iso()}, retain=True)

    def publish_audio(self, room_code: str, kind: str, payload: Dict[str, Any], retain: bool) -> None:
        if not room_code:
            return
        # level/active sering & tidak kritis -> QoS 0
        self._publish(f"{self.root}/audio/{room_code}/{kind}", payload, retain=retain,
                      qos=1 if kind == "mixer" else 0)

    # ------------------------------------------------------------------
    def _health_loop(self) -> None:
        while not self._stop.is_set():
            for dev in self.devices:
                if self._stop.is_set():
                    return
                try:
                    dev.check_health()
                except Exception as exc:
                    log(f"[WARN] health {dev.name}: {exc}")
            self._stop.wait(self.health_interval)

    def start(self, blocking: bool = True) -> None:
        host = str(self.mcfg.get("host", "127.0.0.1"))
        tls = (self.mcfg.get("tls") or {}).get("enabled")
        port = int(self.mcfg.get("port", 8883 if tls else 1883))
        log(f"[AGENT] Smart Meeting Room Device Agent v{AGENT_VERSION} - broker {host}:{port} tls={bool(tls)}")
        log(f"[AGENT] {len(self.devices)} perangkat di devices.yaml")
        for dev in self.devices:
            dev.start()
        self.client.connect_async(host, port, keepalive=30)
        if self.health_interval > 0:
            threading.Thread(target=self._health_loop, name="health", daemon=True).start()
        if blocking:
            self.client.loop_forever(retry_first_connection=True)
        else:
            self.client.loop_start()

    def stop(self) -> None:
        self._stop.set()
        try:
            self.client.publish(self.status_topic, json.dumps(self._status_payload(False)), qos=1, retain=True)
            self.client.disconnect()
            self.client.loop_stop()
        except Exception:
            pass
        for dev in self.devices:
            dev.queue.put(None)
            if dev.mixer is not None:
                dev.mixer.stop()


def load_config(path: Path) -> Dict[str, Any]:
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def main() -> None:
    ap = argparse.ArgumentParser(description="Smart Meeting Room device agent")
    ap.add_argument("--config", default=str(CONFIG_PATH))
    ap.add_argument("--pair", metavar="IP_TV", help="pairing SSAP TV LG lalu cetak client-key")
    args = ap.parse_args()
    if args.pair:
        try:
            key = lg_signage.pair_tv(args.pair)
            print(f"[OK] client-key TV {args.pair}: {key}")
            print("     -> isi ke kolom client_key device TV tsb di devices.yaml")
        except DriverError as exc:
            print(f"[GAGAL] {exc}")
            sys.exit(2)
        return
    path = Path(args.config)
    if not path.exists():
        log(f"[FATAL] Config tidak ditemukan: {path}")
        sys.exit(1)
    agent = DeviceAgent(load_config(path))
    try:
        agent.start(blocking=True)
    except KeyboardInterrupt:
        log("[AGENT] Dihentikan oleh user")
        agent.stop()


if __name__ == "__main__":
    main()
