# =============================================================
# SMART MEETING ROOM - DEP-01: Kiosk Launcher (fullscreen)
# Usage:
#   .\start-kiosk.ps1 -RoomCode A101
#   .\start-kiosk.ps1 -RoomCode A101 -Watchdog -ServerUrl http://192.168.1.10:3000
# Catatan: -Watchdog me-restart otomatis browser bila ditutup user.
# =============================================================
param(
    [Parameter(Mandatory = $true)][string]$RoomCode,
    [string]$ServerUrl = 'http://localhost:8000',
    [switch]$Watchdog
)

$ErrorActionPreference = 'Stop'

# --- 1. Cari browser kiosk (Edge bawaan Windows, fallback Chrome)
$Browsers = @(
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
)
$Browser = $Browsers | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $Browser) {
    throw 'Tidak menemukan Edge/Chrome. Install Microsoft Edge terlebih dahulu.'
}
Write-Host "[KIOSK] Browser : $Browser"

# --- 2. Susun argumen kiosk mode ------------------------------
# user-data-dir terpisah: instance benar-benar terisolasi dari
# browser harian (wajib agar watchdog bekerja) + localStorage
# pairing kiosk tersimpan khusus per ruangan.
$ProfileDir = Join-Path $env:LOCALAPPDATA "SMRKiosk\$RoomCode"
New-Item -ItemType Directory -Force -Path $ProfileDir | Out-Null

$Url = "$ServerUrl/public/room/$RoomCode"
$BrowserArgs = @(
    "--kiosk=`"$Url`"",
    "--user-data-dir=`"$ProfileDir`"",
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-pinch',
    '--overscroll-history-navigation=0',
    '--check-for-update-interval=31536000'
)
if ($Browser -like '*msedge.exe') {
    $BrowserArgs += @('--edge-kiosk-type=fullscreen', '--kiosk-idle-timeout-minutes=0')
}

Write-Host "[KIOSK] Ruangan : $RoomCode"
Write-Host "[KIOSK] URL     : $Url"
Write-Host "[KIOSK] Watchdog: $([bool]$Watchdog)"

# --- 3. Jalankan (dengan/tanpa watchdog) ----------------------
if ($Watchdog) {
    while ($true) {
        Write-Host "[KIOSK] Menjalankan browser kiosk ..."
        $proc = Start-Process -FilePath $Browser -ArgumentList $BrowserArgs -PassThru
        Wait-Process -Id $proc.Id -ErrorAction SilentlyContinue
        Write-Host "[KIOSK] Browser tertutup -> restart dalam 2 detik ..."
        Start-Sleep -Seconds 2
    }
}
else {
    Start-Process -FilePath $Browser -ArgumentList $BrowserArgs | Out-Null
}
