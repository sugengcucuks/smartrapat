# =============================================================
# SMART MEETING ROOM - DEP-01: Installer Kiosk Desktop
# Membuat shortcut desktop "Kiosk Ruangan <kode>" yang menjalankan
# browser fullscreen (kiosk mode) + watchdog auto-restart.
# Usage (jalankan di PC kiosk, butuh backend+frontend sudah jalan):
#   .\install-kiosk.ps1 -RoomCode A101
#   .\install-kiosk.ps1 -RoomCode A101 -ServerUrl http://192.168.1.10:3000 -Autostart
# =============================================================
param(
    [Parameter(Mandatory = $true)][string]$RoomCode,
    [string]$ServerUrl = 'http://localhost:8000',
    [string]$DisplayName = "Kiosk Ruangan $RoomCode",
    [switch]$Autostart
)

$ErrorActionPreference = 'Stop'

$ProjectRoot = Split-Path -Parent $PSScriptRoot          # folder project (induk dari kiosk/)
$Launcher    = Join-Path $PSScriptRoot 'start-kiosk.ps1'
if (-not (Test-Path $Launcher)) { throw "Launcher tidak ditemukan: $Launcher" }

# --- 1. Buat shortcut di Desktop -------------------------------
$Wsh     = New-Object -ComObject WScript.Shell
$Desktop = [Environment]::GetFolderPath('Desktop')
$LnkPath = Join-Path $Desktop "$DisplayName.lnk"

$Shortcut              = $Wsh.CreateShortcut($LnkPath)
$Shortcut.TargetPath   = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$Shortcut.Arguments    = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$Launcher`" -RoomCode `"$RoomCode`" -ServerUrl `"$ServerUrl`" -Watchdog"
$Shortcut.WorkingDirectory = $ProjectRoot
$Shortcut.Description  = 'Smart Meeting Room - Mode Kiosk Fullscreen (DEP-01)'
$Shortcut.IconLocation = "$env:SystemRoot\System32\imageres.dll,109"
$Shortcut.Save()
Write-Host "[INSTALL] Shortcut dibuat : $LnkPath" -ForegroundColor Green

# --- 2. Opsional: auto-start saat Windows login ----------------
if ($Autostart) {
    $StartupDir = [Environment]::GetFolderPath('Startup')
    $AutoLnk    = Join-Path $StartupDir "$DisplayName.lnk"
    Copy-Item $LnkPath $AutoLnk -Force
    Write-Host "[INSTALL] Auto-start : $AutoLnk" -ForegroundColor Green
}

Write-Host ''
Write-Host 'Selesai. Dobel-klik shortcut untuk masuk mode kiosk.' -ForegroundColor Cyan
Write-Host 'Keluar kiosk: Alt+F4 (disarankan Windows kiosk account terpisah).' -ForegroundColor Yellow
