"""CLI pembuat & penandatangan lisensi Smart Meeting Room (sisi vendor).

Contoh pemakaian:
    # 1. Sekali saja: buat pasangan kunci
    python scripts/license_cli.py keygen

    # 2. Lihat fingerprint mesin pelanggan (dijalankan di server pelanggan)
    python scripts/license_cli.py fingerprint

    # 3. Terbitkan lisensi
    python scripts/license_cli.py issue --customer "PT Contoh" --fingerprint <hex> \
        --expires 2027-12-31 --edition enterprise --max-rooms 50 --max-users 500

    # 4. Periksa berkas lisensi
    python scripts/license_cli.py inspect license.key
"""
import argparse
import sys
from datetime import date
from pathlib import Path
from uuid import uuid4

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.api.licensing.core import (  # noqa: E402
    LICENSE_FILE_NAME,
    LicensePayload,
    generate_keypair,
    read_license_file,
    sign_payload,
    validate_license_text,
    verify_license_text,
    write_license_file,
)
from src.api.licensing.fingerprint import (  # noqa: E402
    format_fingerprint,
    get_machine_fingerprint,
)

DEFAULT_KEYS_DIR = ROOT / "license_keys"
DEFAULT_PUBLIC_KEY = ROOT / "src" / "api" / "licensing" / "public_key.pem"


def cmd_keygen(args: argparse.Namespace) -> int:
    keys_dir = Path(args.keys_dir)
    private_path = keys_dir / "private_key.pem"
    public_path = Path(args.public_key)

    if private_path.exists() and not args.force:
        print(f"Kunci privat sudah ada: {private_path}")
        print("Gunakan --force untuk menimpanya (SEMUA lisensi lama jadi tidak valid).")
        return 1

    private_pem, public_pem = generate_keypair()
    keys_dir.mkdir(parents=True, exist_ok=True)
    private_path.write_bytes(private_pem)
    public_path.parent.mkdir(parents=True, exist_ok=True)
    public_path.write_bytes(public_pem)

    print("[OK] Pasangan kunci dibuat.")
    print(f"  Kunci privat (RAHASIA, jangan disebar) : {private_path}")
    print(f"  Kunci publik (dibundel ke aplikasi)    : {public_path}")
    return 0


def cmd_fingerprint(_: argparse.Namespace) -> int:
    fp = get_machine_fingerprint()
    print("Fingerprint perangkat ini:")
    print(format_fingerprint(fp))
    print()
    print(f"RAW: {fp}")
    return 0


def cmd_issue(args: argparse.Namespace) -> int:
    keys_dir = Path(args.keys_dir)
    private_path = Path(args.private_key) if args.private_key else keys_dir / "private_key.pem"
    if not private_path.exists():
        print(f"Kunci privat tidak ditemukan: {private_path}")
        print("Jalankan dulu: python scripts/license_cli.py keygen")
        return 1

    if args.expires:
        try:
            date.fromisoformat(args.expires)
        except ValueError:
            print("Format --expires harus YYYY-MM-DD")
            return 1

    payload = LicensePayload(
        license_id=args.license_id or str(uuid4()),
        customer=args.customer,
        fingerprint=(args.fingerprint or "").strip().lower(),
        edition=args.edition,
        issued_at=date.today().isoformat(),
        expires_at=args.expires or None,
        max_rooms=args.max_rooms,
        max_users=args.max_users,
        features=[f.strip() for f in (args.features or "").split(",") if f.strip()],
        notes=args.notes or "",
    )

    text = sign_payload(payload, private_path.read_bytes())
    out = Path(args.out)
    write_license_file(out, text)

    check = verify_license_text(text, DEFAULT_PUBLIC_KEY.read_bytes())
    print(f"[{'OK' if check.valid else 'GAGAL'}] Lisensi ditulis ke: {out}")
    print(f"  ID       : {payload.license_id}")
    print(f"  Pelanggan: {payload.customer}")
    print(f"  Edisi    : {payload.edition}")
    print(f"  Mesin    : {payload.fingerprint or '(tanpa ikatan mesin)'}")
    print(f"  Berlaku  : {payload.issued_at} s/d {payload.expires_at or 'PERMANEN'}")
    return 0


def cmd_inspect(args: argparse.Namespace) -> int:
    text = read_license_file(args.file)
    check = verify_license_text(text, DEFAULT_PUBLIC_KEY.read_bytes())
    if not check.valid or not check.payload:
        print(f"[TIDAK VALID] {check.reason}")
        return 1

    p = check.payload
    print("[VALID] Tanda tangan cocok dengan kunci publik aplikasi.")
    print(f"  ID       : {p.license_id}")
    print(f"  Pelanggan: {p.customer}")
    print(f"  Edisi    : {p.edition}")
    print(f"  Mesin    : {p.fingerprint or '(tanpa ikatan mesin)'}")
    print(f"  Berlaku  : {p.issued_at} s/d {p.expires_at or 'PERMANEN'}")
    print(f"  Batas    : ruangan={p.max_rooms or 'unlimited'} pengguna={p.max_users or 'unlimited'}")
    if p.features:
        print(f"  Fitur    : {', '.join(p.features)}")

    local = validate_license_text(text, DEFAULT_PUBLIC_KEY.read_bytes(), get_machine_fingerprint())
    print(f"  Cocok perangkat ini: {'YA' if local.valid else 'TIDAK — ' + local.reason}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Generator lisensi Smart Meeting Room")
    sub = parser.add_subparsers(dest="command", required=True)

    p_key = sub.add_parser("keygen", help="Buat pasangan kunci Ed25519")
    p_key.add_argument("--keys-dir", default=str(DEFAULT_KEYS_DIR))
    p_key.add_argument("--public-key", default=str(DEFAULT_PUBLIC_KEY))
    p_key.add_argument("--force", action="store_true")
    p_key.set_defaults(func=cmd_keygen)

    p_fp = sub.add_parser("fingerprint", help="Tampilkan fingerprint perangkat ini")
    p_fp.set_defaults(func=cmd_fingerprint)

    p_issue = sub.add_parser("issue", help="Terbitkan berkas lisensi")
    p_issue.add_argument("--customer", required=True)
    p_issue.add_argument("--fingerprint", required=True, help="Fingerprint mesin pelanggan (wajib; lisensi tanpa fingerprint ditolak aplikasi)")
    p_issue.add_argument("--expires", default="", help="YYYY-MM-DD (kosong = permanen)")
    p_issue.add_argument("--edition", default="standard")
    p_issue.add_argument("--max-rooms", type=int, default=0)
    p_issue.add_argument("--max-users", type=int, default=0)
    p_issue.add_argument("--features", default="")
    p_issue.add_argument("--notes", default="")
    p_issue.add_argument("--license-id", default="")
    p_issue.add_argument("--keys-dir", default=str(DEFAULT_KEYS_DIR))
    p_issue.add_argument("--private-key", default="")
    p_issue.add_argument("--out", default=str(ROOT / LICENSE_FILE_NAME))
    p_issue.set_defaults(func=cmd_issue)

    p_insp = sub.add_parser("inspect", help="Periksa berkas lisensi")
    p_insp.add_argument("file", nargs="?", default=str(ROOT / LICENSE_FILE_NAME))
    p_insp.set_defaults(func=cmd_inspect)

    return parser


def main() -> int:
    args = build_parser().parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
