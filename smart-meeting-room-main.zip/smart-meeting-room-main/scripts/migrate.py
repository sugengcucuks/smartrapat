"""Terapkan migrasi database yang tertunda.

Pemakaian (dari root project):
    python scripts/migrate.py            # terapkan semua migrasi tertunda
    python scripts/migrate.py --status   # tampilkan status tanpa menerapkan
    python scripts/migrate.py --baseline # tandai semua berkas sudah diterapkan
                                         # (untuk DB lama yang dibuat manual)

Koneksi memakai DB_* dari .env (lihat src/api/config.py).
Kode keluar != 0 bila ada migrasi mode ketat yang gagal.
"""
import argparse
import asyncio
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(ROOT / ".env")

import asyncpg  # noqa: E402

from src.api.config import get_settings  # noqa: E402
from src.api.db.migrator import (  # noqa: E402
    CREATE_TABLE_SQL,
    applied_migrations,
    list_migration_files,
    run_pending,
)


async def _status(dsn: str) -> None:
    conn = await asyncpg.connect(dsn)
    try:
        done = await applied_migrations(conn)
    finally:
        await conn.close()
    for f in list_migration_files():
        mark = f"applied {done[f]:%Y-%m-%d %H:%M}" if f in done else "PENDING"
        print(f"  {f:40s} {mark}")


async def _baseline(dsn: str) -> None:
    conn = await asyncpg.connect(dsn)
    try:
        await conn.execute(CREATE_TABLE_SQL)
        for f in list_migration_files():
            await conn.execute(
                "INSERT INTO schema_migrations (filename) VALUES ($1) ON CONFLICT DO NOTHING", f
            )
            print(f"  ditandai: {f}")
    finally:
        await conn.close()


def main() -> int:
    ap = argparse.ArgumentParser(description="Runner migrasi Smart Meeting Room")
    ap.add_argument("--status", action="store_true", help="tampilkan status migrasi")
    ap.add_argument("--baseline", action="store_true", help="tandai semua migrasi sudah diterapkan")
    ap.add_argument("--dry-run", action="store_true", help="tampilkan migrasi tertunda saja")
    args = ap.parse_args()

    dsn = get_settings().SYNC_DATABASE_URL
    if args.status:
        asyncio.run(_status(dsn))
        return 0
    if args.baseline:
        asyncio.run(_baseline(dsn))
        return 0

    results = asyncio.run(run_pending(dsn, log=print, dry_run=args.dry_run))
    failed = [r for r in results if not r.ok]
    if failed:
        print(f"\nMigrasi GAGAL pada {failed[0].filename}. Perbaiki lalu jalankan ulang.")
        return 1
    print("\nSelesai.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
