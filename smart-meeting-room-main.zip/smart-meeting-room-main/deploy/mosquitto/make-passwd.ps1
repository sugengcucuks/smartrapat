# Buat deploy\mosquitto\passwd berisi akun smr_backend & smr_agent (Windows/PowerShell).
# Pemakaian: .\deploy\mosquitto\make-passwd.ps1   (akan menanyakan password)
$ErrorActionPreference = 'Stop'
$Dir = $PSScriptRoot
$File = Join-Path $Dir 'passwd'
if (-not (Test-Path $File)) { New-Item -ItemType File -Path $File | Out-Null }
foreach ($U in @('smr_backend', 'smr_agent')) {
    Write-Host "Password untuk $U :"
    docker run --rm -it -v "${Dir}:/work" eclipse-mosquitto:2 mosquitto_passwd /work/passwd $U
    if ($LASTEXITCODE -ne 0) { throw "mosquitto_passwd gagal untuk $U" }
}
Write-Host 'Selesai. Isi MQTT_USERNAME/MQTT_PASSWORD di .env (smr_backend) dan mqtt.username/password di agent\devices.yaml (smr_agent).'
