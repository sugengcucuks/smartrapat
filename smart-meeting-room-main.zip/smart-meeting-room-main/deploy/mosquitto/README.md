# Mosquitto (MQTT) - autentikasi & ACL

Broker menolak koneksi anonim. Dua akun dipakai:

| User          | Dipakai oleh                        | Hak akses (lihat `acl`)                                      |
|---------------|-------------------------------------|--------------------------------------------------------------|
| `smr_backend` | API FastAPI (`.env`)                | tulis `smr/devices/+/command/#`, baca state/ack/audio/agent  |
| `smr_agent`   | Device agent (`agent/devices.yaml`) | baca command, tulis state/ack/audio/agent                    |

## Membuat file password

File `passwd` **tidak** di-commit (ada di `.gitignore`). Buat sekali sebelum
`docker compose up`:

```sh
./deploy/mosquitto/make-passwd.sh        # Linux/macOS
.\deploy\mosquitto\make-passwd.ps1       # Windows PowerShell
```

Atau manual dengan `mosquitto_passwd`:

```sh
mosquitto_passwd -c deploy/mosquitto/passwd smr_backend   # -c = buat file baru (menimpa!)
mosquitto_passwd    deploy/mosquitto/passwd smr_agent
```

Lalu isi:

- `.env`: `MQTT_USERNAME=smr_backend`, `MQTT_PASSWORD=...`
- `agent/devices.yaml`: `mqtt.username: smr_agent`, `mqtt.password: ...`

Restart broker setelah mengubah `passwd` atau `acl`: `docker compose restart mosquitto`.

Untuk akses lintas jaringan gunakan listener TLS (port 8883) dan buka port broker
hanya untuk LAN tepercaya (`BIND_ADDR` di `.env`, default 127.0.0.1).
