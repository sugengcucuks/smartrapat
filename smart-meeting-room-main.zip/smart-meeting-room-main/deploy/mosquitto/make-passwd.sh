#!/usr/bin/env sh
# Buat deploy/mosquitto/passwd berisi akun smr_backend & smr_agent.
# Pemakaian: ./deploy/mosquitto/make-passwd.sh   (akan menanyakan password)
set -eu
DIR="$(cd "$(dirname "$0")" && pwd)"
touch "$DIR/passwd"
for U in smr_backend smr_agent; do
  echo "Password untuk $U:"
  if command -v mosquitto_passwd >/dev/null 2>&1; then
    mosquitto_passwd "$DIR/passwd" "$U"
  else
    docker run --rm -it -v "$DIR:/work" eclipse-mosquitto:2 mosquitto_passwd /work/passwd "$U"
  fi
done
chmod 600 "$DIR/passwd" 2>/dev/null || true
echo "Selesai. Isi MQTT_USERNAME/MQTT_PASSWORD di .env (smr_backend) dan mqtt.username/password di agent/devices.yaml (smr_agent)."
