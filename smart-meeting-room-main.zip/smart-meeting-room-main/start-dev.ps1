# =============================================================
# SMART MEETING ROOM - DEP-02: One-command Dev Launcher
# Usage:
#   .\start-dev.ps1                 -> start backend + frontend
#   .\start-dev.ps1 -Migrate        -> jalankan migrasi DB dulu
#   .\start-dev.ps1 -SkipInstall    -> lewati instalasi dependensi
# =============================================================
param(
    [switch]$SkipInstall,
    [switch]$Migrate
)

$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot

function Info($m) { Write-Host "[SMR] $m" -ForegroundColor Cyan }

# --- 1. .env -------------------------------------------------
if (-not (Test-Path (Join-Path $Root '.env'))) {
    Copy-Item (Join-Path $Root '.env.example') (Join-Path $Root '.env')
    Info '.env tidak ada -> dibuat dari .env.example. SESUAIKAN kredensial DB!'
}

# --- 2. Python virtualenv + dependencies ---------------------
$Venv   = Join-Path $Root '.venv'
$Python = Join-Path $Venv 'Scripts\python.exe'
$Pip    = Join-Path $Venv 'Scripts\pip.exe'

if (-not (Test-Path $Python)) {
    Info 'Membuat virtualenv .venv ...'
    python -m venv $Venv
}

if (-not $SkipInstall) {
    Info 'Install dependencies Python (requirements.txt) ...'
    & $Pip install -q -r (Join-Path $Root 'requirements.txt')
}

# --- 3. Node dependencies ------------------------------------
if (-not $SkipInstall) {
    if (-not (Test-Path (Join-Path $Root 'node_modules'))) {
        Info 'Install dependencies Node (npm install) ...'
        Push-Location $Root
        try { npm install } finally { Pop-Location }
    }
}

# --- 4. Migrasi database (opsional) --------------------------
if ($Migrate) {
    Info 'Menjalankan migrasi database (scripts/migrate.py) ...'
    & $Python (Join-Path $Root 'scripts\migrate.py')
    if ($LASTEXITCODE -ne 0) { throw 'Migrasi database gagal' }
}

# --- 5. Jalankan backend + frontend (window terpisah) --------
Info 'Backend  -> http://localhost:8000  (docs: set ENABLE_API_DOCS=true di .env)'
Start-Process -FilePath $Python `
    -ArgumentList '-m', 'uvicorn', 'src.api.main:app', '--host', '0.0.0.0', '--port', '8000' `
    -WorkingDirectory $Root

Info 'Frontend -> http://localhost:3000'
Start-Process -FilePath 'cmd.exe' `
    -ArgumentList '/c', 'npm', 'run', 'dev' `
    -WorkingDirectory $Root

Info 'Selesai. Tutup kedua window untuk menghentikan aplikasi.'
