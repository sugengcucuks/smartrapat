"""Broker MQTT 3.1.1 minimal untuk tes (tanpa dependensi).

Mendukung: CONNECT (+will, username/password diabaikan), PUBLISH QoS 0/1 (+retain),
SUBSCRIBE/UNSUBSCRIBE dengan wildcard + dan #, PINGREQ, DISCONNECT.
Cukup untuk menguji paho-mqtt 1.6 (backend & agent). BUKAN untuk produksi.
"""
from __future__ import annotations

import asyncio
import struct
import threading
from typing import Dict, List, Optional, Tuple


def topic_matches(flt: str, topic: str) -> bool:
    fp, tp = flt.split("/"), topic.split("/")
    for i, f in enumerate(fp):
        if f == "#":
            return True
        if i >= len(tp):
            return False
        if f != "+" and f != tp[i]:
            return False
    return len(fp) == len(tp)


def _enc_len(n: int) -> bytes:
    out = bytearray()
    while True:
        b = n % 128
        n //= 128
        if n:
            b |= 0x80
        out.append(b)
        if not n:
            return bytes(out)


def _str(b: bytes, i: int) -> Tuple[str, int]:
    n = struct.unpack(">H", b[i:i + 2])[0]
    return b[i + 2:i + 2 + n].decode("utf-8"), i + 2 + n


def _bin(b: bytes, i: int) -> Tuple[bytes, int]:
    n = struct.unpack(">H", b[i:i + 2])[0]
    return b[i + 2:i + 2 + n], i + 2 + n


class _Client:
    def __init__(self, writer: asyncio.StreamWriter):
        self.writer = writer
        self.subs: Dict[str, int] = {}
        self.will: Optional[Tuple[str, bytes, int, bool]] = None
        self.pid = 0

    def next_pid(self) -> int:
        self.pid = self.pid % 65535 + 1
        return self.pid


class MiniBroker:
    def __init__(self, host: str = "127.0.0.1", port: int = 0):
        self.host, self.port = host, port
        self.clients: List[_Client] = []
        self.retained: Dict[str, Tuple[bytes, int]] = {}
        self.log: List[Tuple[str, bytes]] = []   # semua publish yang diterima
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._server = None
        self._ready = threading.Event()
        self._thread: Optional[threading.Thread] = None

    # ------------------------------------------------------------------
    def start(self) -> int:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        self._ready.wait(5)
        return self.port

    def _run(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._server = self._loop.run_until_complete(asyncio.start_server(self._handle, self.host, self.port))
        self.port = self._server.sockets[0].getsockname()[1]
        self._ready.set()
        self._loop.run_forever()

    def stop(self) -> None:
        if self._loop is None:
            return

        async def _close():
            self._server.close()
            for c in list(self.clients):
                c.writer.close()
        fut = asyncio.run_coroutine_threadsafe(_close(), self._loop)
        try:
            fut.result(2)
        except Exception:
            pass
        self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread:
            self._thread.join(2)

    # ------------------------------------------------------------------
    async def _read_packet(self, reader: asyncio.StreamReader) -> Tuple[int, int, bytes]:
        h = await reader.readexactly(1)
        mult, length = 1, 0
        while True:
            b = (await reader.readexactly(1))[0]
            length += (b & 0x7F) * mult
            if not b & 0x80:
                break
            mult *= 128
        body = await reader.readexactly(length) if length else b""
        return h[0] >> 4, h[0] & 0x0F, body

    def _send(self, c: _Client, ptype: int, flags: int, body: bytes) -> None:
        try:
            c.writer.write(bytes([(ptype << 4) | flags]) + _enc_len(len(body)) + body)
        except Exception:
            pass

    def _deliver(self, c: _Client, topic: str, payload: bytes, qos: int, retain: bool = False) -> None:
        t = topic.encode()
        body = struct.pack(">H", len(t)) + t
        if qos > 0:
            body += struct.pack(">H", c.next_pid())
        self._send(c, 3, (qos << 1) | (1 if retain else 0), body + payload)

    def _publish(self, topic: str, payload: bytes, qos: int, retain: bool) -> None:
        self.log.append((topic, payload))
        if retain:
            if payload:
                self.retained[topic] = (payload, qos)
            else:
                self.retained.pop(topic, None)
        for c in list(self.clients):
            granted = [q for f, q in c.subs.items() if topic_matches(f, topic)]
            if granted:
                self._deliver(c, topic, payload, min(qos, max(granted)))

    async def _handle(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        c = _Client(writer)
        clean = False
        try:
            ptype, _f, body = await self._read_packet(reader)
            if ptype != 1:
                writer.close()
                return
            _proto, i = _str(body, 0)
            i += 1  # level
            flags = body[i]
            i += 3  # flags + keepalive
            _cid, i = _str(body, i)
            if flags & 0x04:
                wt, i = _str(body, i)
                wm, i = _bin(body, i)
                c.will = (wt, wm, (flags >> 3) & 3, bool(flags & 0x20))
            self.clients.append(c)
            self._send(c, 2, 0, b"\x00\x00")
            while True:
                ptype, flags, body = await self._read_packet(reader)
                if ptype == 3:
                    qos = (flags >> 1) & 3
                    topic, i = _str(body, 0)
                    if qos:
                        pid = body[i:i + 2]
                        i += 2
                        self._send(c, 4, 0, pid)
                    self._publish(topic, body[i:], qos, bool(flags & 1))
                elif ptype == 8:
                    pid = body[:2]
                    i, granted, new = 2, [], []
                    while i < len(body):
                        flt, i = _str(body, i)
                        q = min(body[i], 1)
                        i += 1
                        c.subs[flt] = q
                        granted.append(q)
                        new.append((flt, q))
                    self._send(c, 9, 0, pid + bytes(granted))
                    for flt, q in new:
                        for topic, (payload, rq) in list(self.retained.items()):
                            if topic_matches(flt, topic):
                                self._deliver(c, topic, payload, min(q, rq), retain=True)
                elif ptype == 10:
                    pid = body[:2]
                    i = 2
                    while i < len(body):
                        flt, i = _str(body, i)
                        c.subs.pop(flt, None)
                    self._send(c, 11, 0, pid)
                elif ptype == 12:
                    self._send(c, 13, 0, b"")
                elif ptype == 14:
                    clean = True
                    break
                await writer.drain()
        except (asyncio.IncompleteReadError, ConnectionError):
            pass
        finally:
            if c in self.clients:
                self.clients.remove(c)
            if not clean and c.will:
                wt, wm, wq, wr = c.will
                self._publish(wt, wm, wq, wr)
            try:
                writer.close()
            except Exception:
                pass

    def drop_client_abruptly(self, index: int = -1) -> None:
        """Putus paksa koneksi (memicu LWT)."""
        c = self.clients[index]
        self._loop.call_soon_threadsafe(c.writer.transport.abort)  # type: ignore[union-attr]
