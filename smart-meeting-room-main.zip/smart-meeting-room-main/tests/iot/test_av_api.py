"""API kontrol AV per ruangan (DB sungguhan dari tests/conftest.py).

Perintah memakai MQTT_SIMULATE (ack otomatis) — jalur MQTT/agent nyata diuji di
test_mqtt_e2e.py. Di sini: validasi, izin, 503/409, kanal mic, WebSocket live.
"""
import pytest

from src.api.utils.mqtt_client import mqtt_manager

API = "/api/v1"


@pytest.fixture(scope="module")
def room(client, admin):
    r = client.get(f"{API}/rooms", headers=admin, params={"per_page": 100})
    assert r.status_code == 200, r.text
    body = r.json()
    items = body.get("items") or body.get("data", {}).get("items")
    rooms = sorted(items, key=lambda x: x["code"])
    assert len(rooms) >= 2
    return rooms[0], rooms[1]


@pytest.fixture(scope="module")
def devices(client, admin, room):
    rid = room[0]["id"]
    ids = {}
    for code, typ, cfg in [
        ("T-TV-1", "tv", {}), ("T-TV-2", "tv", {}),
        ("T-VWC", "videowall_controller", {}),
        ("T-MIX", "audio_mixer", {"driver": "xair"}),
    ]:
        r = client.post(f"{API}/devices", headers=admin, json={
            "code": code, "name": code, "device_type": typ, "location_id": rid, "config": cfg})
        assert r.status_code == 200, r.text
        ids[code] = r.json()["data"]["id"]
    return ids


@pytest.fixture
def simulate():
    old = (mqtt_manager.simulate, mqtt_manager.broker_url)
    mqtt_manager.simulate, mqtt_manager.broker_url = True, ""
    yield
    mqtt_manager.simulate, mqtt_manager.broker_url = old


@pytest.fixture
def no_broker():
    old = (mqtt_manager.simulate, mqtt_manager.broker_url)
    mqtt_manager.simulate, mqtt_manager.broker_url = False, ""
    yield
    mqtt_manager.simulate, mqtt_manager.broker_url = old


def test_capabilities_defaults(client, admin, room, devices):
    r = client.get(f"{API}/rooms/{room[0]['id']}/av/capabilities", headers=admin)
    assert r.status_code == 200, r.text
    d = r.json()["data"]
    assert d["videowall"]["controller"]["code"] == "T-VWC"
    assert [p["code"] for p in d["videowall"]["panels"]] == ["T-TV-1", "T-TV-2"]
    assert [p["id"] for p in d["videowall"]["presets"]] == ["fullscreen", "split2", "main_side", "quad", "panels6"]
    assert [s["id"] for s in d["videowall"]["sources"]] == ["hdmi1", "hdmi2", "hdmi3", "hdmi4"]
    assert d["audio"]["mode"] == "xair" and d["audio"]["can_control"] is True


def test_command_without_broker_is_503(client, admin, room, devices, no_broker):
    r = client.post(f"{API}/rooms/{room[0]['id']}/av/videowall/power-on", headers=admin)
    assert r.status_code == 503
    assert r.json()["detail"]["code"] == "MQTT_NOT_CONFIGURED"
    r = client.post(f"{API}/devices/{devices['T-TV-1']}/power-on", headers=admin)
    assert r.status_code == 503


def test_videowall_commands_simulated(client, admin, room, devices, simulate):
    rid = room[0]["id"]
    r = client.post(f"{API}/rooms/{rid}/av/videowall/power-on", headers=admin)
    assert r.status_code == 200, r.text
    d = r.json()["data"]
    assert d["status"] == "acked" and len(d["results"]) == 3   # 2 panel + controller
    r = client.post(f"{API}/rooms/{rid}/av/videowall/layout", headers=admin, json={"preset": "quad"})
    assert r.json()["data"]["status"] == "acked"
    r = client.post(f"{API}/rooms/{rid}/av/videowall/layout", headers=admin, json={"preset": "9x9"})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "INVALID_PRESET"
    r = client.post(f"{API}/rooms/{rid}/av/videowall/source", headers=admin, json={"source": "dp", "window": 1})
    assert r.status_code == 400
    # status perangkat TIDAK diubah optimistis oleh perintah
    r = client.get(f"{API}/devices/{devices['T-TV-1']}", headers=admin)
    assert r.json()["data"]["status"] == "offline"


def test_audio_channels_and_mixer(client, admin, room, devices, simulate):
    rid, rid2 = room[0]["id"], room[1]["id"]
    chans = [{"channel_no": n, "label": f"Mic {n}", "receiver_label": f"M118-{'A' if n <= 8 else 'B'} CH{(n - 1) % 8 + 1}",
              "mixer_channel": n, "capture_channel": n, "enabled": True} for n in range(1, 17)]
    r = client.put(f"{API}/rooms/{rid}/audio-channels", headers=admin, json={"channels": chans + [chans[0]]})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "DUPLICATE_CHANNEL"
    r = client.put(f"{API}/rooms/{rid}/audio-channels", headers=admin, json={"channels": chans})
    assert r.status_code == 200 and len(r.json()["data"]) == 16
    first_id = r.json()["data"][0]["id"]
    # simpan ulang: id kanal yang sama dipertahankan (kaitan kursi aman)
    chans[0]["label"] = "Pimpinan"
    r = client.put(f"{API}/rooms/{rid}/audio-channels", headers=admin, json={"channels": chans[:8]})
    data = r.json()["data"]
    assert len(data) == 8 and data[0]["id"] == first_id and data[0]["label"] == "Pimpinan"

    assert client.post(f"{API}/rooms/{rid}/av/audio/mic/3/mute", headers=admin).json()["data"]["status"] == "acked"
    assert client.post(f"{API}/rooms/{rid}/av/audio/mute-all", headers=admin).json()["data"]["status"] == "acked"
    r = client.post(f"{API}/rooms/{rid}/av/audio/fader", headers=admin, json={"target": "main", "value": 0.7})
    assert r.json()["data"]["status"] == "acked"
    r = client.post(f"{API}/rooms/{rid}/av/audio/mic/12/mute", headers=admin)
    assert r.status_code == 404
    # ruangan tanpa mixer
    r = client.post(f"{API}/rooms/{rid2}/av/audio/mic/1/mute", headers=admin)
    assert r.status_code == 409
    assert r.json()["detail"]["message"] == "Mixer tidak terpasang; atur manual di receiver"
    r = client.get(f"{API}/audio/microphones", headers=admin, params={"room_id": rid})
    assert r.status_code == 200 and r.json()["data"]["audio_mode"] == "xair"
    r = client.get(f"{API}/rooms/{rid}/av/state", headers=admin)
    assert r.status_code == 200 and "active_speakers" in r.json()["data"]


def test_permissions(client, staff, room, devices, simulate):
    rid = room[0]["id"]
    assert client.post(f"{API}/rooms/{rid}/av/videowall/power-on", headers=staff["headers"]).status_code == 403
    assert client.post(f"{API}/rooms/{rid}/av/audio/mute-all", headers=staff["headers"]).status_code == 403
    assert client.put(f"{API}/rooms/{rid}/audio-channels", headers=staff["headers"],
                      json={"channels": []}).status_code == 403
    assert client.post(f"{API}/devices/{devices['T-TV-1']}/restart", headers=staff["headers"]).status_code == 403


def test_live_ws_auth(client, admin, room):
    rid = room[0]["id"]
    token = admin["Authorization"].split()[1]
    with client.websocket_connect(f"{API}/ws/rooms/{rid}/live?token={token}") as ws:
        msg = ws.receive_json()
        assert msg["event"] == "connected"
        ws.send_json({"type": "ping"})
        seen = [ws.receive_json()["event"] for _ in range(2)]
        assert "pong" in seen or "active_speakers" in seen
    with client.websocket_connect(f"{API}/ws/rooms/{rid}/live?token=salah") as ws:
        assert ws.receive_json()["event"] == "error"
