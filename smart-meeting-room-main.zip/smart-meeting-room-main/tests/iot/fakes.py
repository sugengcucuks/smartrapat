"""Perangkat palsu di localhost untuk tes: Digibird (UDP), LG IP control (TCP), X-Air (OSC UDP)."""
from __future__ import annotations

import socket
import socketserver
import struct
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

from pythonosc.osc_message_builder import OscMessageBuilder
from pythonosc.osc_packet import OscPacket


class FakeDigibird:
    """Balas [OK] untuk perintah dikenal, [ERR] untuk lainnya."""

    VALID = ("[call,", "[SWCH,", "[SALL]")

    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("127.0.0.1", 0))
        self.port = self.sock.getsockname()[1]
        self.received: List[str] = []
        self._stop = False
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        self.sock.settimeout(0.2)
        while not self._stop:
            try:
                data, addr = self.sock.recvfrom(1024)
            except socket.timeout:
                continue
            except OSError:
                return
            cmd = data.decode()
            self.received.append(cmd)
            ok = cmd.startswith(self.VALID) and cmd.endswith("]") and cmd.count("[") == 1
            self.sock.sendto(b"[OK]" if ok else b"[ERR]", addr)

    def close(self):
        self._stop = True
        self.sock.close()


class FakeLG:
    """LG IP control TCP: 'ka 01 01\\r' -> 'a 01 OK01x'."""

    def __init__(self):
        self.power = "01"
        self.received: List[str] = []
        outer = self

        class Handler(socketserver.BaseRequestHandler):
            def handle(self):
                data = self.request.recv(1024).decode().strip()
                outer.received.append(data)
                parts = data.split()
                if len(parts) == 3 and parts[0] == "ka":
                    if parts[2] == "ff":
                        reply = f"a {parts[1]} OK{outer.power}x"
                    elif parts[2] in ("00", "01"):
                        outer.power = parts[2]
                        reply = f"a {parts[1]} OK{parts[2]}x"
                    else:
                        reply = f"a {parts[1]} NG{parts[2]}x"
                elif len(parts) == 3 and parts[0] == "xb":
                    reply = f"b {parts[1]} OK{parts[2]}x"
                else:
                    reply = "a 01 NG00x"
                self.request.sendall(reply.encode())

        self.server = socketserver.ThreadingTCPServer(("127.0.0.1", 0), Handler)
        self.server.daemon_threads = True
        self.port = self.server.server_address[1]
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def close(self):
        self.server.shutdown()
        self.server.server_close()


class FakeXAir:
    """Mixer X-Air palsu: query dibalas, set disimpan, meter dikirim ke pelanggan /meters/1."""

    def __init__(self, channels: int = 16):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("127.0.0.1", 0))
        self.port = self.sock.getsockname()[1]
        self.values: Dict[str, Any] = {}
        for ch in range(1, channels + 1):
            self.values[f"/ch/{ch:02d}/mix/on"] = 1
            self.values[f"/ch/{ch:02d}/mix/fader"] = 0.75
            self.values[f"/headamp/{ch:02d}/gain"] = 0.5
        self.values["/lr/mix/on"] = 1
        self.values["/lr/mix/fader"] = 0.8
        self.levels_db: Dict[int, float] = {ch: -90.0 for ch in range(1, channels + 1)}
        self.meter_subscriber: Optional[Tuple[str, int]] = None
        self.xremote = 0
        self.sets: List[Tuple[str, Any]] = []
        self._stop = False
        threading.Thread(target=self._run, daemon=True).start()
        threading.Thread(target=self._meters, daemon=True).start()

    @staticmethod
    def _msg(address: str, *args) -> bytes:
        b = OscMessageBuilder(address)
        for a in args:
            b.add_arg(a)
        return b.build().dgram

    def _run(self):
        self.sock.settimeout(0.2)
        while not self._stop:
            try:
                data, addr = self.sock.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                return
            for tm in OscPacket(data).messages:
                m = tm.message
                if m.address == "/xremote":
                    self.xremote += 1
                elif m.address == "/meters":
                    self.meter_subscriber = addr
                elif m.address == "/info":
                    self.sock.sendto(self._msg("/info", "V0.04", "XR18-FAKE", "XR18", "1.17"), addr)
                elif m.params:
                    self.values[m.address] = m.params[0]
                    self.sets.append((m.address, m.params[0]))
                elif m.address in self.values:
                    self.sock.sendto(self._msg(m.address, self.values[m.address]), addr)

    def _meters(self):
        while not self._stop:
            time.sleep(0.05)   # 20 Hz seperti mixer asli
            if not self.meter_subscriber:
                continue
            vals = [int(self.levels_db.get(i + 1, -90.0) * 256) for i in range(40)]
            blob = struct.pack("<i", len(vals)) + struct.pack(f"<{len(vals)}h", *[max(-32768, v) for v in vals])
            b = OscMessageBuilder("/meters/1")
            b.add_arg(blob, "b")
            try:
                self.sock.sendto(b.build().dgram, self.meter_subscriber)
            except OSError:
                return

    def close(self):
        self._stop = True
        self.sock.close()
