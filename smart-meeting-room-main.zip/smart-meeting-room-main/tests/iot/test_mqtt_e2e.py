"""End-to-end: backend MqttManager -> broker -> device agent -> perangkat palsu -> ack.

Juga menguji live_hub: level/active/mixer dari driver X-Air diteruskan ke
subscriber WebSocket (dengan pemetaan kanal mixer -> channel_no -> kursi -> peserta).
"""
import asyncio
import time

import pytest

import device_agent as da
from fakes import FakeDigibird, FakeLG, FakeXAir
from mini_broker import MiniBroker

from src.api.services.live_hub import LiveHub, _RoomMap
from src.api.utils.mqtt_client import MqttManager, MqttNotConfigured

ROOM_ID = "11111111-1111-1111-1111-111111111111"
ROOM_CODE = "R-TEST"
TV_ID = "22222222-2222-2222-2222-222222222222"
DIGI_ID = "33333333-3333-3333-3333-333333333333"
MIX_ID = "44444444-4444-4444-4444-444444444444"


class FakeWS:
    def __init__(self):
        self.messages = []

    async def send_json(self, msg):
        self.messages.append(msg)

    def events(self, name):
        return [m for m in self.messages if m["event"] == name]


async def wait_for(pred, timeout=5.0, step=0.05):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if pred():
            return True
        await asyncio.sleep(step)
    return False


@pytest.fixture
def env():
    broker = MiniBroker()
    port = broker.start()
    digi, lg, mixer = FakeDigibird(), FakeLG(), FakeXAir()
    cfg = {
        "mqtt": {"host": "127.0.0.1", "port": port, "topic_prefix": "smr/devices", "agent_id": "test-agent"},
        "health_interval_s": 0.5,
        "devices": [
            {"id": TV_ID, "code": "TV-PANEL-1", "name": "Panel 1", "host": "127.0.0.1",
             "health": {"type": "lg_ip", "port": lg.port, "fallback_ping": False},
             "actions": {
                 "power_on": [{"lg_ip": {"host": "127.0.0.1", "port": lg.port, "cmd": "ka", "data": "01"}}],
                 "power_off": [{"lg_ip": {"host": "127.0.0.1", "port": lg.port, "cmd": "ka", "data": "00"}}],
             }},
            {"id": "placeholder-digibird", "code": "DIGIBIRD-4X8", "name": "Digibird",
             "health": {"type": "none"},
             "params": {"scene": {"type": "int", "min": 1, "max": 32},
                        "input": {"type": "int", "min": 1, "max": 4},
                        "window": {"type": "int", "min": 1, "max": 16}},
             "actions": {
                 "apply_layout": [{"udp": {"host": "127.0.0.1", "port": digi.port, "ascii": "[call,{payload.scene}]"}}],
                 "change_source": [{"udp": {"host": "127.0.0.1", "port": digi.port,
                                            "ascii": "[SWCH,{payload.input},{payload.window},1]"}}],
                 "power_off": [{"udp": {"host": "127.0.0.1", "port": digi.port, "ascii": "[SALL]"}}],
                 "bad": [{"udp": {"host": "127.0.0.1", "port": digi.port, "ascii": "[NOPE]"}}],
             }},
            {"id": MIX_ID, "code": "XR18", "name": "XR18", "driver": "xair", "host": "127.0.0.1",
             "port": mixer.port, "room_code": ROOM_CODE, "channels": 16, "health": {"type": "xair"}},
        ],
    }
    agent = da.DeviceAgent(cfg)
    agent.start(blocking=False)
    yield {"broker": broker, "port": port, "digi": digi, "lg": lg, "mixer": mixer, "agent": agent}
    agent.stop()
    for f in (digi, lg, mixer):
        f.close()
    broker.stop()


async def make_backend(port, monkeypatch, listener=None) -> MqttManager:
    monkeypatch.setenv("MQTT_BROKER_URL", "127.0.0.1")
    monkeypatch.setenv("MQTT_PORT", str(port))
    monkeypatch.setenv("MQTT_SIMULATE", "false")
    mgr = MqttManager()
    if listener:
        mgr.add_listener(listener)
    mgr.start(asyncio.get_running_loop())
    assert await wait_for(lambda: mgr.is_connected), "backend tidak terhubung ke broker"
    await asyncio.sleep(0.2)  # tunggu SUBACK
    return mgr


async def test_not_configured_raises(monkeypatch):
    monkeypatch.delenv("MQTT_BROKER_URL", raising=False)
    monkeypatch.setenv("MQTT_SIMULATE", "false")
    mgr = MqttManager()
    mgr.start(asyncio.get_running_loop())
    with pytest.raises(MqttNotConfigured):
        mgr.publish_command("x", "power_on", {})


async def test_simulate_mode_acks(monkeypatch):
    monkeypatch.delenv("MQTT_BROKER_URL", raising=False)
    monkeypatch.setenv("MQTT_SIMULATE", "true")
    mgr = MqttManager()
    mgr.start(asyncio.get_running_loop())
    cid = mgr.publish_command("x", "power_on", {})
    ack = await mgr.wait_ack(cid, 1.0)
    assert ack and ack["ok"] and ack["response"] == "simulated"


async def test_commands_roundtrip(env, monkeypatch):
    mgr = await make_backend(env["port"], monkeypatch)
    try:
        # Agent online (retained status)
        # Digibird: layout scene 3 -> [call,3] -> [OK]
        cid = mgr.publish_command(DIGI_ID, "apply_layout", {"device_code": "DIGIBIRD-4X8", "scene": 3, "preset": "main_side"})
        ack = await mgr.wait_ack(cid, 3.0)
        assert ack is not None and ack["ok"] is True, ack
        assert ack["response"] == "[OK]"
        assert env["digi"].received[-1] == "[call,3]"

        cid = mgr.publish_command(DIGI_ID, "change_source", {"device_code": "DIGIBIRD-4X8", "input": 2, "window": 1})
        ack = await mgr.wait_ack(cid, 3.0)
        assert ack["ok"] and env["digi"].received[-1] == "[SWCH,2,1,1]"

        # Injeksi ditolak SEBELUM dikirim ke perangkat
        before = len(env["digi"].received)
        cid = mgr.publish_command(DIGI_ID, "apply_layout", {"device_code": "DIGIBIRD-4X8", "scene": "1],[SALL"})
        ack = await mgr.wait_ack(cid, 3.0)
        assert ack["ok"] is False and "Parameter ditolak" in ack["error"]
        assert len(env["digi"].received) == before

        # Balasan [ERR] -> ack gagal
        cid = mgr.publish_command(DIGI_ID, "bad", {"device_code": "DIGIBIRD-4X8"})
        ack = await mgr.wait_ack(cid, 3.0)
        assert ack["ok"] is False and "[ERR]" in ack["error"]

        # Aksi tak dikonfigurasi
        cid = mgr.publish_command(DIGI_ID, "restart", {"device_code": "DIGIBIRD-4X8"})
        ack = await mgr.wait_ack(cid, 3.0)
        assert ack["ok"] is False and "tidak dikonfigurasi" in ack["error"]

        # LG IP control power off
        cid = mgr.publish_command(TV_ID, "power_off", {"device_code": "TV-PANEL-1"})
        ack = await mgr.wait_ack(cid, 3.0)
        assert ack["ok"] and env["lg"].power == "00" and "OK00" in ack["response"]

        # X-Air: mute kanal mixer 3 -> diverifikasi query ulang
        cid = mgr.publish_command(MIX_ID, "mute", {"device_code": "XR18", "channel_no": 3, "mixer_channel": 3})
        ack = await mgr.wait_ack(cid, 3.0)
        assert ack["ok"], ack
        assert env["mixer"].values["/ch/03/mix/on"] == 0
        cid = mgr.publish_command(MIX_ID, "set_fader", {"device_code": "XR18", "target": "main", "value": 0.5})
        ack = await mgr.wait_ack(cid, 3.0)
        assert ack["ok"] and abs(env["mixer"].values["/lr/mix/fader"] - 0.5) < 0.01
        cid = mgr.publish_command(MIX_ID, "set_gain", {"device_code": "XR18", "mixer_channel": 5, "db": 30})
        ack = await mgr.wait_ack(cid, 3.0)
        assert ack["ok"] and abs(env["mixer"].values["/headamp/05/gain"] - 0.5833) < 0.01
        cid = mgr.publish_command(MIX_ID, "mute", {"device_code": "XR18", "mixer_channel": 99})
        ack = await mgr.wait_ack(cid, 3.0)
        assert ack["ok"] is False and "mixer_channel" in ack["error"]
        cid = mgr.publish_command(MIX_ID, "mute_all", {"device_code": "XR18", "mixer_channels": list(range(1, 17))})
        ack = await mgr.wait_ack(cid, 3.0)
        assert ack["ok"] and all(env["mixer"].values[f"/ch/{c:02d}/mix/on"] == 0 for c in range(1, 17))

        # Perangkat tak dikenal agent -> tidak ada ack (timeout)
        cid = mgr.publish_command("99999999-9999-9999-9999-999999999999", "power_on", {"device_code": "NOPE"})
        assert await mgr.wait_ack(cid, 0.5) is None
    finally:
        mgr.stop()


async def test_parallel_devices_and_ordering(env, monkeypatch):
    """Perintah berurutan untuk satu perangkat tetap urut; perangkat lain paralel."""
    mgr = await make_backend(env["port"], monkeypatch)
    try:
        ids = [mgr.publish_command(DIGI_ID, "apply_layout", {"device_code": "DIGIBIRD-4X8", "scene": n})
               for n in (1, 2, 3, 4)]
        ids.append(mgr.publish_command(TV_ID, "power_on", {"device_code": "TV-PANEL-1"}))
        acks = await asyncio.gather(*(mgr.wait_ack(c, 3.0) for c in ids))
        assert all(a and a["ok"] for a in acks)
        assert [c for c in env["digi"].received if c.startswith("[call")][-4:] == [
            "[call,1]", "[call,2]", "[call,3]", "[call,4]"]
    finally:
        mgr.stop()


async def test_live_hub_audio_and_state(env, monkeypatch):
    hub = LiveHub()
    hub._persist_enabled = False
    hub.remember_room(ROOM_ID, ROOM_CODE)
    hub._codes_fetched_at = time.monotonic()
    m = _RoomMap()
    m.fetched_at = time.monotonic() + 3600
    m.mixer_to_channel = {c: c for c in range(1, 17)}
    m.channel_to_seat = {3: "seat-3"}
    m.seat_to_participant = {"seat-3": "participant-A"}
    hub._room_maps[ROOM_ID] = m
    hub.device_room[TV_ID] = ROOM_ID
    ws = FakeWS()
    hub.connect(ROOM_ID, ws)
    await asyncio.sleep(1.0)  # biarkan agent memuat state mixer (retained)
    mgr = await make_backend(env["port"], monkeypatch, hub.handle_mqtt)
    try:
        # mixer state retained -> mixer_state
        assert await wait_for(lambda: ws.events("mixer_state"), 5)
        # Kanal 3 bicara
        env["mixer"].levels_db[3] = -20.0
        assert await wait_for(lambda: any(e["data"]["channels"] == [3] for e in ws.events("active_speakers")), 5)
        ev = [e for e in ws.events("active_speakers") if e["data"]["channels"] == [3]][0]
        assert ev["data"]["seats"] == ["seat-3"] and ev["data"]["participants"] == ["participant-A"]
        # Level dikirim <= 5 Hz
        n0 = len(ws.events("audio_levels"))
        await asyncio.sleep(2.0)
        n1 = len(ws.events("audio_levels"))
        assert 3 <= n1 - n0 <= 11, n1 - n0
        last = ws.events("audio_levels")[-1]["data"]["levels"]
        assert last["3"] == -20.0
        # Setelah diam > hold 800 ms -> active kosong
        env["mixer"].levels_db[3] = -90.0
        assert await wait_for(lambda: ws.events("active_speakers")[-1]["data"]["channels"] == [], 3)
        # Health poll panel -> device_state
        assert await wait_for(lambda: any(e["data"]["device_id"] == TV_ID for e in ws.events("device_state")), 5)
        st = [e for e in ws.events("device_state") if e["data"]["device_id"] == TV_ID][-1]["data"]["state"]
        assert st["online"] is True and st["power"] in ("on", "off")
        # Snapshot REST
        snap = await hub.room_av_state(ROOM_ID, ROOM_CODE)
        assert snap["mixer"]["channels"]["3"]["fader"] == 0.75
    finally:
        mgr.stop()


async def test_agent_lwt_marks_offline(env, monkeypatch):
    mgr = await make_backend(env["port"], monkeypatch)
    got = []
    mgr.add_listener(lambda topic, payload: got.append((topic, payload)))
    try:
        # retained status online dari agent
        await asyncio.sleep(0.3)
        broker = env["broker"]
        # cari koneksi agent (klien yang subscribe command)
        idx = next(i for i, c in enumerate(broker.clients) if any("command" in s for s in c.subs))
        broker.drop_client_abruptly(idx)
        assert await wait_for(lambda: any(t.endswith("/agent/test-agent/status") and p.get("online") is False
                                          for t, p in got), 5)
        payload = [p for t, p in got if t.endswith("/status") and p.get("online") is False][-1]
        codes = {d["code"] for d in payload["devices"]}
        assert {"TV-PANEL-1", "DIGIBIRD-4X8", "XR18"} <= codes
    finally:
        mgr.stop()
