import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
for p in (ROOT, ROOT / "agent", Path(__file__).resolve().parent):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

# Settings backend dibaca saat import; tes IoT tidak butuh DB sungguhan.
os.environ.setdefault("JWT_SECRET", "x" * 48)
