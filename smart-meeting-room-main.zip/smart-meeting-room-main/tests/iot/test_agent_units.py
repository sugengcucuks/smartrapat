"""Unit test agent: whitelist parameter & parser balasan perangkat."""
import struct

import pytest

import device_agent as da
from drivers import digibird, lg_signage, xair

DIGIBIRD = {
    "code": "DIGIBIRD-4X8",
    "params": {
        "scene": {"type": "int", "min": 1, "max": 32},
        "input": {"type": "int", "min": 1, "max": 4},
        "window": {"type": "int", "min": 1, "max": 16},
    },
    "map": {"legacy_layout": {"Fullscreen": 1, "2x2": 2}},
}


def test_render_accepts_whitelisted_ints():
    assert da.render("[call,{payload.scene}]", DIGIBIRD, {"scene": 5}) == "[call,5]"
    assert da.render("[SWCH,{payload.input},{payload.window},1]", DIGIBIRD, {"input": "2", "window": 3}) == "[SWCH,2,3,1]"


@pytest.mark.parametrize("value", ["1],[SALL", "1\r\n[SALL]", "0", "33", "1.5", "abc", True, None, "-1"])
def test_render_rejects_injection_and_out_of_range(value):
    with pytest.raises(da.ParamError):
        da.render("[call,{payload.scene}]", DIGIBIRD, {"scene": value})


def test_render_rejects_unknown_param():
    with pytest.raises(da.ParamError):
        da.render("[x,{payload.evil}]", DIGIBIRD, {"evil": "1"})


def test_map_whitelist():
    assert da.render("[call,{payload.legacy_layout}]", DIGIBIRD, {"legacy_layout": "2x2"}) == "[call,2]"
    with pytest.raises(da.ParamError):
        da.render("[call,{payload.legacy_layout}]", DIGIBIRD, {"legacy_layout": "3x3]"})


def test_enum_param():
    dev = {"params": {"input_source": {"type": "enum", "values": ["hdmi", "usb"]}}}
    assert da.render("S {payload.input_source}", dev, {"input_source": "usb"}) == "S usb"
    with pytest.raises(da.ParamError):
        da.render("S {payload.input_source}", dev, {"input_source": "usb;rm"})


def test_prepare_steps_validates_all_before_execution():
    steps = [{"udp": {"host": "h", "port": 5000, "ascii": "[call,{payload.scene}]"}},
             {"udp": {"host": "h", "port": 5000, "ascii": "[SWCH,{payload.input},1,1]"}}]
    with pytest.raises(da.ParamError):
        da.prepare_steps(DIGIBIRD, steps, {"scene": 1, "input": 9})


def test_digibird_parse():
    assert digibird.parse_reply(b"[OK]") == (True, "[OK]")
    assert digibird.parse_reply(b"[call,OK]")[0] is True
    assert digibird.parse_reply(b"[ERR]")[0] is False
    assert digibird.parse_reply(None) == (True, None)


def test_lg_ip_parse_and_build():
    assert lg_signage.build_ip_command("ka", "01", "00") == b"ka 01 00\r"
    assert lg_signage.parse_ip_reply(b"a 01 OK01x") == (True, "01", "a 01 OK01x")
    assert lg_signage.parse_ip_reply(b"a 01 NG00x")[0] is False
    with pytest.raises(Exception):
        lg_signage.build_ip_command("ka", "01", "0; x")


def test_xair_meter_blob_and_gain():
    vals = [int(-20 * 256), int(-60.5 * 256), 0]
    blob = struct.pack("<i", 3) + struct.pack("<3h", *vals)
    assert xair.parse_meters_blob(blob, 2) == [-20.0, -60.5]
    assert xair.gain_f_to_db(xair.gain_db_to_f(30)) == 30.0
    assert xair.gain_db_to_f(-12) == 0.0 and xair.gain_db_to_f(60) == 1.0
