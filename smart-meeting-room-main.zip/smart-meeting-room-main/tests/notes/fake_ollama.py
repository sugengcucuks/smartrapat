"""Server Ollama palsu untuk pengujian (tanpa model sungguhan).

Jalankan: uvicorn tests.notes.fake_ollama:app --port 11999
Mengembalikan JSON notulen realistis sesuai skema summarizer.
"""
import json

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

MODEL = "qwen2.5:7b-instruct"
CALLS = []

SAMPLE = {
    "ringkasan": (
        "Rapat koordinasi dibuka oleh pimpinan rapat yang menyampaikan tujuan pertemuan, yaitu "
        "evaluasi persiapan kegiatan.\n\nPeserta membahas kesiapan anggaran & jadwal pelaksanaan. "
        "Disepakati beberapa langkah tindak lanjut."
    ),
    "pokok_bahasan": [
        {"judul": "Evaluasi anggaran", "uraian": "Realisasi anggaran triwulan III mencapai 72% <dan> perlu dipercepat."},
        {"judul": "Jadwal kegiatan", "uraian": "Pelaksanaan dijadwalkan ulang ke bulan Oktober."},
    ],
    "keputusan": ["Kegiatan dilaksanakan pada 15 Oktober 2026", "Anggaran tambahan diajukan ke biro keuangan"],
    "tindak_lanjut": [
        {"tugas": "Menyusun revisi RAB", "pic": "Budi Santoso", "tenggat": "2026-10-01"},
        {"tugas": "Mengirim undangan peserta", "pic": None, "tenggat": "minggu depan"},
    ],
    "peserta_aktif": ["Budi Santoso", "Siti Rahayu"],
}

app = FastAPI()


@app.get("/api/tags")
async def tags():
    return {"models": [{"name": MODEL, "model": MODEL}]}


@app.post("/api/chat")
async def chat(req: Request):
    body = await req.json()
    CALLS.append(body)
    if body.get("model") != MODEL:
        return JSONResponse({"error": f"model '{body.get('model')}' not found"}, status_code=404)
    return {"model": MODEL, "message": {"role": "assistant", "content": json.dumps(SAMPLE, ensure_ascii=False)},
            "done": True}
