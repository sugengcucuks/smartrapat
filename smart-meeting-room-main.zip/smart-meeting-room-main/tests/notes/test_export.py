"""Uji export notulen (PDF/DOCX/TXT/HTML) termasuk escaping teks pengguna."""
import io
import os
from datetime import date

import pytest

os.environ.setdefault("JWT_SECRET", "x" * 40)

from src.api.services import note_export as E  # noqa: E402

EVIL = "Rapat <b>tebal & </para><font size=99>'\"</font>"


def ctx(**kw):
    base = dict(
        org_name="Dinas Uji", org_address="Jl. Merdeka No. 1", title=EVIL, tanggal=E.tanggal_indo(date(2026, 9, 24)),
        waktu="09:00 – 11:00 WIB", tempat="Ruang <Rapat>", pimpinan="Budi & Rekan", notulis="Siti",
        peserta=["Budi", "Siti <script>"], ringkasan="Paragraf 1 <x>.\n\nParagraf 2 & selesai.",
        pokok_bahasan=[{"judul": "Anggaran <2026>", "uraian": "Uraian & detail"}], keputusan=["Setuju <semua>"],
        tindak_lanjut=[{"tugas": "Revisi <RAB>", "pic": "Budi", "tenggat": date(2026, 10, 1), "status": "open"}],
        transcript=[{"start_ms": 61000, "speaker_name": "Budi <ketua>", "text": "Halo & selamat </para>"}],
        status="draft",
    )
    base.update(kw)
    return E.ExportContext(**base)


def test_tanggal_indo():
    assert E.tanggal_indo(date(2026, 9, 24)) == "Kamis, 24 September 2026"
    assert E.tanggal_pendek("2026-10-01") == "1 Oktober 2026"


def test_pdf_renders_with_hostile_text():
    pdf = E.render_pdf(ctx())
    assert pdf.startswith(b"%PDF-") and len(pdf) > 1500


def test_docx_is_real_docx_with_structure():
    docx = pytest.importorskip("docx")
    data = E.render_docx(ctx(status="final"))
    d = docx.Document(io.BytesIO(data))
    text = "\n".join(p.text for p in d.paragraphs)
    cells = [c.text for t in d.tables for r in t.rows for c in r.cells]
    assert "NOTULEN RAPAT" in text and "(DRAFT)" not in text
    assert EVIL in cells and "Revisi <RAB>" in cells and "1 Oktober 2026" in cells
    assert "Lampiran: Transkrip Rapat" in text and "Halo & selamat </para>" in text


def test_html_escapes_everything():
    html = E.render_html(ctx()).decode()
    assert "<script>" not in html and "&lt;script&gt;" in html
    assert "<b>tebal" not in html


def test_txt_and_filename():
    txt = E.render_txt(ctx()).decode()
    assert "Pimpinan Rapat : Budi & Rekan" in txt and "[01:01] Budi <ketua>" in txt
    assert E.safe_filename("Rapat: Évaluasi/Q3 <x>", "pdf") == "notulensi_rapat_evaluasi_q3_x.pdf"
