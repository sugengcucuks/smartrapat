"""Uji unit layanan transkripsi dengan mesin STT palsu (tanpa model Whisper/DB)."""
import io
import os
import sys
import types
from pathlib import Path

import numpy as np
import pytest

os.environ.setdefault("JWT_SECRET", "x" * 40)

from src.api.services import audio_io  # noqa: E402
from src.api.services import transcription as T  # noqa: E402

sf = pytest.importorskip("soundfile")


def write_wav(path: Path, seconds=1.0, sr=16000, amp=0.3, channels=1):
    t = np.arange(int(seconds * sr)) / sr
    x = (amp * np.sin(2 * np.pi * 220 * t)).astype(np.float32)
    if channels == 2:
        x = np.stack([x, x], axis=1)
    sf.write(str(path), x, sr, subtype="PCM_16")
    return path


# --- atribusi pembicara ------------------------------------------------------
def test_pick_speaker_name_priority():
    assert T.pick_speaker_name("Budi", "Pak B", "Kursi 1", "Mic 1", 1) == "Budi"
    assert T.pick_speaker_name(None, "Tamu VIP", "Kursi 1", "Mic 1", 1) == "Tamu VIP"
    assert T.pick_speaker_name(None, " ", "Kursi 1", "Mic 1", 1) == "Kursi 1"
    assert T.pick_speaker_name(None, None, None, "Mic 7 (M118-A)", 7) == "Mic 7 (M118-A)"
    assert T.pick_speaker_name(None, None, None, None, 9) == "Mic 9"
    assert T.pick_speaker_name(None, None, None, None, None) == "Peserta"


@pytest.mark.asyncio
async def test_resolve_speaker_mix_groups_without_db():
    r = await T.resolve_speaker(None, "b", "room", 1, "mix")
    assert r["speaker_name"] == "Grup A (Mic 1–8)"
    r = await T.resolve_speaker(None, "b", "room", 2, "mix")
    assert r["speaker_name"] == "Grup B (Mic 9–16)"


# --- audio -------------------------------------------------------------------
def test_read_audio_resamples_and_mixes(tmp_path):
    p = write_wav(tmp_path / "a.wav", seconds=1.0, sr=48000, channels=2)
    x = audio_io.read_audio_16k(str(p))
    assert x.dtype == np.float32 and x.ndim == 1 and x.size == 16000


def test_is_allowed_audio():
    assert audio_io.is_allowed_audio("rapat.MP3", "audio/mpeg")
    assert audio_io.is_allowed_audio("c.webm", "video/webm")
    assert audio_io.is_allowed_audio("c.wav", "application/octet-stream")
    assert not audio_io.is_allowed_audio("c.exe", "audio/wav")
    assert not audio_io.is_allowed_audio("c.wav", "text/html")


def test_find_quiet_cut_prefers_silence():
    sr = 16000
    x = np.concatenate([np.ones(sr), np.zeros(sr // 5), np.ones(sr)]).astype(np.float32) * 0.5
    cut = audio_io.find_quiet_cut(x, 0, x.size)
    assert sr <= cut <= sr + sr // 5


def test_convert_to_wav16k_without_ffmpeg(tmp_path, monkeypatch):
    monkeypatch.setattr(audio_io, "ffmpeg_path", lambda: None)
    src = write_wav(tmp_path / "long.wav", seconds=3.0, sr=44100)
    dur = audio_io.convert_to_wav16k(str(src), str(tmp_path / "out.wav"))
    assert dur == pytest.approx(3.0, abs=0.01)
    assert sf.info(str(tmp_path / "out.wav")).samplerate == 16000


def test_undecodable_audio_raises(tmp_path, monkeypatch):
    bad = tmp_path / "x.webm"
    bad.write_bytes(b"not audio at all")
    monkeypatch.setattr(audio_io, "ffmpeg_path", lambda: None)
    with pytest.raises(audio_io.AudioDecodeError):
        audio_io.read_audio_16k(str(bad))


# --- mesin STT ---------------------------------------------------------------
def test_fake_engine_labels_text_and_ignores_silence():
    eng = T.FakeSTTEngine()
    segs, _ = eng.transcribe(np.zeros(16000, dtype=np.float32), "id")
    assert segs == []
    segs, _ = eng.transcribe(0.3 * np.ones(16000, dtype=np.float32), "id")
    assert segs[0].text.startswith("[STT uji]")


def test_faster_whisper_load_failure_is_clear(monkeypatch):
    fake_mod = types.ModuleType("faster_whisper")

    class Boom:
        def __init__(self, *a, **k):
            raise RuntimeError("koneksi ke huggingface ditolak")

    fake_mod.WhisperModel = Boom
    monkeypatch.setitem(sys.modules, "faster_whisper", fake_mod)
    eng = T.FasterWhisperEngine("small", "cpu", "int8")
    with pytest.raises(T.STTUnavailableError) as ei:
        eng.transcribe(np.zeros(1600, dtype=np.float32), "id")
    assert "Model Whisper belum terpasang" in str(ei.value) and "small" in str(ei.value)
    assert not eng.loaded


def test_faster_whisper_engine_maps_segments(monkeypatch):
    fake_mod = types.ModuleType("faster_whisper")
    calls = {}

    class Seg:
        def __init__(self, s, e, t, lp):
            self.start, self.end, self.text, self.avg_logprob = s, e, t, lp

    class Model:
        def __init__(self, name, device, compute_type, download_root=None):
            calls["init"] = (name, device, compute_type)

        def transcribe(self, audio, **kw):
            calls["kw"] = kw
            return iter([Seg(0.0, 1.2, " Selamat pagi ", -0.1), Seg(1.2, 1.5, "  ", -0.5)]), types.SimpleNamespace(language="id")

    fake_mod.WhisperModel = Model
    monkeypatch.setitem(sys.modules, "faster_whisper", fake_mod)
    eng = T.FasterWhisperEngine("medium", "cuda", "float16")
    segs, lang = eng.transcribe(np.zeros(16000, dtype=np.float32), "id")
    assert calls["init"] == ("medium", "cuda", "float16")
    assert calls["kw"]["vad_filter"] is True and calls["kw"]["beam_size"] == 5 and calls["kw"]["language"] == "id"
    assert [s.text for s in segs] == ["Selamat pagi"] and lang == "id"
    assert 0.8 < segs[0].confidence <= 1.0


# --- service: jalur error & pemotongan file -----------------------------------
class _NullSession:
    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False

    async def get(self, *a, **k):
        return None

    async def commit(self):
        return None


class _FailingEngine:
    name = "failing"
    loaded = False

    def load(self):
        raise T.STTUnavailableError("Model Whisper belum terpasang: uji")

    def transcribe(self, audio, language):
        self.load()


@pytest.mark.asyncio
async def test_engine_unavailable_keeps_job_for_retry(tmp_path):
    svc = T.TranscriptionService(session_factory=_NullSession, engine=_FailingEngine())
    audio = write_wav(tmp_path / "seg.wav")
    job = T.TranscriptionJob(kind="segment", note_id="00000000-0000-0000-0000-000000000001",
                             booking_id="00000000-0000-0000-0000-000000000002", audio_path=str(audio), channel_no=1)
    await svc.enqueue(job)
    assert Path(job.sidecar).exists() and svc.pending_for_note(job.note_id) == 1
    await svc.process(await svc._queue.get())
    assert "Model Whisper belum terpasang" in svc.last_error
    assert Path(job.sidecar).exists()  # disimpan untuk dicoba ulang saat restart
    assert svc.pending_for_note(job.note_id) == 0
    # sidecar dimuat ulang saat start berikutnya
    reloaded = T.TranscriptionJob.from_json(Path(job.sidecar).read_text())
    assert reloaded.audio_path == str(audio) and reloaded.channel_no == 1


@pytest.mark.asyncio
async def test_corrupt_audio_marks_job_failed(tmp_path):
    svc = T.TranscriptionService(session_factory=_NullSession, engine=T.FakeSTTEngine())
    bad = tmp_path / "seg.flac"
    bad.write_bytes(b"garbage")
    job = T.TranscriptionJob(kind="segment", note_id="00000000-0000-0000-0000-000000000001",
                             booking_id="00000000-0000-0000-0000-000000000002", audio_path=str(bad))
    await svc.enqueue(job)
    await svc.process(await svc._queue.get())
    assert svc.last_error.startswith("Audio tidak dapat dibaca")
    assert not Path(job.sidecar).exists() and Path(str(bad) + ".job.failed.json").exists()


@pytest.mark.asyncio
async def test_file_job_is_processed_in_pieces_with_offsets(tmp_path, monkeypatch):
    monkeypatch.setattr(T, "FILE_PIECE_SECONDS", 2)
    monkeypatch.setattr(T, "FILE_CUT_SEARCH_SECONDS", 1)
    lengths = []

    class RecEngine(T.FakeSTTEngine):
        def transcribe(self, audio, language):
            lengths.append(audio.size)
            return super().transcribe(audio, language)

    persisted = []

    async def fake_persist(self, job, segs, lang, offset_ms):
        persisted.append((offset_ms, [s.text for s in segs]))

    async def fake_broadcast_rec(self, job, status, **extra):
        return None

    monkeypatch.setattr(T.TranscriptionService, "_persist", fake_persist)
    monkeypatch.setattr(T.TranscriptionService, "_broadcast_recording", fake_broadcast_rec)
    svc = T.TranscriptionService(session_factory=_NullSession, engine=RecEngine())
    src = write_wav(tmp_path / "rapat.wav", seconds=5.0, sr=48000)
    job = T.TranscriptionJob(kind="file", note_id="00000000-0000-0000-0000-000000000001", booking_id="",
                             audio_path=str(src), start_ms=1000)
    await svc._process_file(job)
    assert sum(lengths) == 5 * 16000
    assert len(lengths) >= 3 and all(n <= 2 * 16000 for n in lengths)
    assert persisted[0][0] == 1000
    assert persisted[1][0] == 1000 + int(lengths[0] * 1000 / 16000)
    assert not Path(str(src) + ".16k.wav").exists()


def test_recording_dir_is_path_safe(tmp_path, monkeypatch):
    monkeypatch.setattr(T.settings, "UPLOAD_DIR", str(tmp_path))
    d = T.recording_dir("33333333-3333-3333-3333-333333333333", "44444444-4444-4444-4444-444444444444")
    assert d.is_dir() and str(d).startswith(str(tmp_path))
    with pytest.raises(ValueError):
        T.recording_dir("../../etc", "44444444-4444-4444-4444-444444444444")


def test_status_reports_engine(monkeypatch):
    svc = T.TranscriptionService(engine=T.FakeSTTEngine())
    st = svc.status()
    assert st["engine_available"] is True and st["queue_size"] == 0 and "last_error" in st


def _make_webm(path: Path, seconds=2.0):
    av = pytest.importorskip("av")
    sr = 48000
    out = av.open(str(path), "w", format="webm")
    try:
        st = out.add_stream("libopus", rate=sr)
    except Exception:
        out.close()
        pytest.skip("PyAV tanpa encoder libopus")
    st.layout = "mono"
    x = (0.3 * np.sin(2 * np.pi * 300 * np.arange(int(sr * seconds)) / sr) * 32767).astype(np.int16)
    for i in range(0, x.size, 960):
        fr = av.AudioFrame.from_ndarray(x[i:i + 960].reshape(1, -1), format="s16", layout="mono")
        fr.sample_rate = sr
        for p in st.encode(fr):
            out.mux(p)
    for p in st.encode(None):
        out.mux(p)
    out.close()
    return path


def test_browser_webm_decodes_without_ffmpeg(tmp_path, monkeypatch):
    """Potongan MediaRecorder (webm/opus) tetap bisa dibaca lewat PyAV bila ffmpeg tidak ada."""
    monkeypatch.setattr(audio_io, "ffmpeg_path", lambda: None)
    p = _make_webm(tmp_path / "chunk.webm")
    x = audio_io.read_audio_16k(str(p))
    assert x.size == pytest.approx(32000, abs=400)
    assert audio_io.convert_to_wav16k(str(p), str(tmp_path / "c.wav")) == pytest.approx(2.0, abs=0.05)
