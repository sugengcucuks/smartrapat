"""Uji VAD & segmentasi recorder dengan sinyal sintetis (tanpa hardware)."""
import io
import json
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "agent"))
import recorder as R  # noqa: E402

SR = 48000
BLOCK = SR // 20  # 50 ms


def tone(seconds, amp=0.3, freq=300.0):
    t = np.arange(int(seconds * SR)) / SR
    return (amp * np.sin(2 * np.pi * freq * t)).astype(np.float32)


def silence(seconds, amp=0.0005):
    return (amp * np.random.default_rng(1).standard_normal(int(seconds * SR))).astype(np.float32)


def run_vad(signal, cfg=None, t0=0):
    cfg = cfg or R.VADConfig()
    vad = R.ChannelVAD(3, SR, cfg)
    segs = []
    for i in range(0, signal.size, BLOCK):
        blk = signal[i:i + BLOCK]
        t_ms = t0 + int(i * 1000 / SR)
        voiced = R.rms_dbfs(blk) >= cfg.threshold_dbfs
        segs += vad.feed(blk, t_ms, voiced)
    return vad, segs


def test_rms_dbfs():
    assert R.rms_dbfs(np.zeros(10, dtype=np.float32)) == -120.0
    assert abs(R.rms_dbfs(np.ones(100, dtype=np.float32)) - 0.0) < 0.01
    assert R.rms_dbfs(tone(0.1, amp=0.3)) == pytest.approx(-13.5, abs=0.2)  # 0.3/sqrt(2)


def test_single_utterance_detected_with_timing():
    sig = np.concatenate([silence(1.0), tone(2.0), silence(1.5)])
    vad, segs = run_vad(sig, t0=10_000)
    assert len(segs) == 1
    s = segs[0]
    assert s.channel_no == 3
    # onset 1.0 s (+10 s offset) dikurangi pre-roll 0.3 s
    assert abs(s.start_ms - 10_700) <= 60
    # akhir ~ akhir ucapan + ekor 250 ms
    assert 12_900 <= s.end_ms <= 13_400
    assert s.audio.size / SR == pytest.approx((s.end_ms - s.start_ms) / 1000, abs=0.06)
    assert not vad.active


def test_short_blip_discarded():
    sig = np.concatenate([silence(0.5), tone(0.3), silence(1.5)])
    _, segs = run_vad(sig)
    assert segs == []


def test_short_pause_within_hangover_keeps_one_segment():
    sig = np.concatenate([tone(1.0), silence(0.5), tone(1.0), silence(1.2)])
    _, segs = run_vad(sig)
    assert len(segs) == 1


def test_long_speech_split_at_max_segment():
    cfg = R.VADConfig(max_segment_s=5.0)
    sig = np.concatenate([tone(12.0), silence(1.2)])
    _, segs = run_vad(sig, cfg)
    assert len(segs) == 3
    assert segs[0].end_ms == segs[1].start_ms
    assert all((s.end_ms - s.start_ms) <= 5100 for s in segs)


def test_flush_on_pause_emits_open_segment():
    vad, segs = run_vad(tone(2.0))
    assert segs == [] and vad.active
    out = vad.flush()
    assert len(out) == 1 and not vad.active


def test_voiced_mask_ignores_crosstalk():
    levels = {1: -12.0, 2: -35.0, 3: -60.0}
    m = R.voiced_mask(levels, -45, 15)
    assert m == {1: True, 2: False, 3: False}
    m = R.voiced_mask({1: -20.0, 2: -24.0}, -45, 15)
    assert m == {1: True, 2: True}


def test_resample_to_16k():
    x = tone(1.0)
    y = R.resample_to_16k(x, SR)
    assert y.size == 16000
    y2 = R.resample_to_16k(np.ones(44100, dtype=np.float32), 44100)
    assert abs(y2.size - 16000) <= 1


def test_encode_segment_flac_16k():
    sf = pytest.importorskip("soundfile")
    seg = R.Segment(1, 0, 1000, tone(1.0), SR)
    data = R.encode_segment(seg, "FLAC")
    y, sr = sf.read(io.BytesIO(data))
    assert sr == 16000 and y.ndim == 1 and abs(y.size - 16000) <= 1


def _cfg(n=3, mode="multichannel"):
    return R.parse_config({
        "backend_url": "http://x/", "agent_key": "k", "room_code": "RR", "mode": mode, "samplerate": SR,
        "channels": [{"capture_channel": i, "channel_no": i} for i in range(1, n + 1)],
        "vad": {"threshold_dbfs": -45},
    })


def test_parse_config_validation():
    cfg = _cfg()
    assert cfg.backend_url == "http://x" and cfg.total_capture_channels == 3
    with pytest.raises(ValueError):
        R.parse_config({"backend_url": "x", "agent_key": "k", "room_code": "r",
                        "channels": [{"capture_channel": 1, "channel_no": 1}, {"capture_channel": 2, "channel_no": 1}]})
    with pytest.raises(ValueError):
        R.parse_config({"backend_url": "x", "agent_key": "", "room_code": "r", "channels": []})


def test_processor_records_only_when_backend_active_and_attributes_channel():
    cfg = _cfg(3)
    p = R.SegmentProcessor(cfg)
    speech = np.concatenate([tone(1.5), silence(1.2)])
    frames = speech.size
    block_all = np.zeros((frames, 3), dtype=np.float32)
    block_all[:, 1] = speech                      # mic 2 bicara
    block_all[:, 0] = speech * 0.02               # bocoran ke mic 1 (-34 dB) -> diabaikan
    block_all[:, 2] = silence(frames / SR)

    def feed(mono0):
        segs = []
        for i in range(0, frames, BLOCK):
            _, active, s = p.process_block(block_all[i:i + BLOCK], mono0 + i / SR)
            segs += s
        return segs

    # tidak ada rekaman aktif -> tidak ada segmen, tetapi indikator aktif tetap jalan
    assert feed(100.0) == []
    rec = {"recording_id": "r1", "booking_id": "b1", "status": "recording", "elapsed_ms": 60_000}
    assert p.set_backend_state(rec, 200.0) == []
    segs = feed(200.0)
    assert len(segs) == 1
    meta_rec, seg = segs[0]
    assert seg.channel_no == 2 and meta_rec["recording_id"] == "r1"
    assert 60_000 - 400 <= seg.start_ms <= 60_100
    meta = R.segment_meta(meta_rec, seg)
    assert meta["booking_id"] == "b1" and meta["channel_no"] == 2

    # jeda: ucapan yang sedang berjalan di-flush
    for i in range(0, int(1.0 * SR), BLOCK):
        p.process_block(block_all[i:i + BLOCK], 300.0 + i / SR)
    flushed = p.set_backend_state({**rec, "status": "paused"}, 301.0)
    assert len(flushed) == 1 and flushed[0][1].channel_no == 2
    assert p.recording is None


def test_clock_and_reanchor_on_resume():
    cfg = _cfg(1)
    p = R.SegmentProcessor(cfg)
    p.set_backend_state({"recording_id": "r", "booking_id": "b", "status": "recording", "elapsed_ms": 0}, 10.0)
    assert p.clock.now_ms(15.0) == 5000
    p.set_backend_state({"recording_id": "r", "booking_id": "b", "status": "paused", "elapsed_ms": 5000}, 15.0)
    # dilanjutkan 20 detik kemudian: server elapsed tetap 5000 (tidak menghitung jeda)
    p.set_backend_state({"recording_id": "r", "booking_id": "b", "status": "recording", "elapsed_ms": 5000}, 35.0)
    assert p.clock.now_ms(36.0) == 6000


def test_spool_roundtrip(tmp_path):
    meta = {"booking_id": "b", "recording_id": "r", "channel_no": 4, "start_ms": 1234, "end_ms": 2000,
            "segment_uid": "u1"}
    mp = R.spool_write(tmp_path, meta, b"RIFF....", "wav")
    assert R.spool_pending(tmp_path) == [mp]
    assert json.loads(mp.read_text())["channel_no"] == 4
    assert mp.with_suffix("").read_bytes() == b"RIFF...."
