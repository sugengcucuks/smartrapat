"""Uji end-to-end API notulensi terhadap server yang sedang berjalan.

Dilewati kecuali env SMR_E2E_URL diset. Server harus dijalankan dengan
STT_ENGINE=fake (mesin uji), OLLAMA_BASE_URL menunjuk ke tests/notes/fake_ollama.py,
AGENT_API_KEY=$SMR_E2E_AGENT_KEY, dan data seed (room RR-B3, booking 3333...).
Lihat docs/modules/11_NOTULENSI.md bagian "Pengujian".
"""
import io
import os
import time
import uuid

import numpy as np
import pytest

httpx = pytest.importorskip("httpx")
sf = pytest.importorskip("soundfile")

BASE = os.environ.get("SMR_E2E_URL")
AGENT_KEY = os.environ.get("SMR_E2E_AGENT_KEY", "testagentkey123")
BOOKING = os.environ.get("SMR_E2E_BOOKING", "33333333-3333-3333-3333-333333333333")
ROOM_CODE = os.environ.get("SMR_E2E_ROOM_CODE", "RR-B3")

pytestmark = pytest.mark.skipif(not BASE, reason="SMR_E2E_URL tidak diset (uji e2e butuh server berjalan)")


def wav_bytes(seconds=1.5, freq=220.0, sr=16000, fmt="WAV") -> bytes:
    t = np.arange(int(seconds * sr)) / sr
    x = 0.3 * np.sin(2 * np.pi * freq * t) + 0.02 * np.random.default_rng(0).standard_normal(t.size)
    buf = io.BytesIO()
    sf.write(buf, x.astype(np.float32), sr, format=fmt, subtype="PCM_16")
    return buf.getvalue()


@pytest.fixture(scope="module")
def client():
    c = httpx.Client(base_url=BASE.rstrip("/") + "/api/v1", timeout=60)
    token = None
    for pw in ("admin123", "Admin12345!"):
        r = c.post("/auth/login", json={"username": "admin", "password": pw})
        if r.status_code == 200:
            token = r.json()["access_token"]
            if pw == "admin123":
                c.headers["Authorization"] = f"Bearer {token}"
                r2 = c.post("/auth/change-password", json={"current_password": "admin123", "old_password": "admin123",
                                                           "new_password": "Admin12345!", "confirm_password": "Admin12345!"})
                assert r2.status_code in (200, 204), r2.text
                r = c.post("/auth/login", json={"username": "admin", "password": "Admin12345!"})
                token = r.json()["access_token"]
            break
    assert token, "login admin gagal"
    c.headers["Authorization"] = f"Bearer {token}"
    yield c
    c.close()


def _poll_segments(client, note_id, n, timeout=20):
    deadline = time.time() + timeout
    while time.time() < deadline:
        data = client.get(f"/notes/{note_id}/segments").json()["data"]
        if data["total"] >= n:
            return data["items"]
        time.sleep(0.3)
    raise AssertionError(f"segmen tidak mencapai {n}")


def _stop_if_active(client):
    st = client.get(f"/notes/recording/{BOOKING}/status").json()["data"]
    if st["status"] in ("recording", "paused"):
        client.post(f"/notes/recording/{BOOKING}/stop")


def test_status_endpoints(client):
    stt = client.get("/notes/stt/status").json()["data"]
    assert stt["engine_available"] is True and "queue_size" in stt
    llm = client.get("/notes/llm/status").json()["data"]
    assert llm["reachable"] is True and llm["model_available"] is True


def test_full_pipeline(client):
    _stop_if_active(client)
    # pastikan notulen draft
    note = client.post(f"/notes/by-booking/{BOOKING}").json()["data"]
    if note["status"] == "final":
        client.post(f"/notes/{note['id']}/reopen")

    r = client.post(f"/notes/recording/{BOOKING}/start", json={"source": "multichannel"})
    assert r.status_code == 200, r.text
    rec = r.json()["data"]
    assert rec["status"] == "recording" and rec["source"] == "multichannel"
    note_id = rec["note_id"]
    before = client.get(f"/notes/{note_id}/segments").json()["data"]["total"]

    # recorder: endpoint aktif (agent key)
    assert httpx.get(f"{BASE}/api/v1/notes/recording/active", params={"room_code": ROOM_CODE},
                     headers={"X-Agent-Key": "salah"}).status_code == 401
    act = httpx.get(f"{BASE}/api/v1/notes/recording/active", params={"room_code": ROOM_CODE},
                    headers={"X-Agent-Key": AGENT_KEY})
    assert act.status_code == 200, act.text
    assert act.json()["data"]["recording_id"] == rec["recording_id"]
    assert len(act.json()["data"]["channels"]) == 3

    uids = {}
    for ch, start in ((1, 1000), (2, 5000), (3, 9000)):
        uids[ch] = str(uuid.uuid4())
        r = httpx.post(f"{BASE}/api/v1/notes/recording/{BOOKING}/segments", headers={"X-Agent-Key": AGENT_KEY},
                       data={"channel_no": ch, "start_ms": start, "end_ms": start + 1500,
                             "recording_id": rec["recording_id"], "segment_uid": uids[ch]},
                       files={"audio": (f"seg{ch}.flac", wav_bytes(fmt="FLAC"), "audio/flac")})
        assert r.status_code == 202, r.text
    # duplikat (retry recorder) tidak menggandakan
    r = httpx.post(f"{BASE}/api/v1/notes/recording/{BOOKING}/segments", headers={"X-Agent-Key": AGENT_KEY},
                   data={"channel_no": 1, "start_ms": 1000, "recording_id": rec["recording_id"], "segment_uid": uids[1]},
                   files={"audio": ("seg1.flac", wav_bytes(fmt="FLAC"), "audio/flac")})
    assert r.json()["data"].get("duplicate") is True
    # tanpa kunci -> 401
    r = httpx.post(f"{BASE}/api/v1/notes/recording/{BOOKING}/segments", data={"channel_no": 1},
                   files={"audio": ("a.wav", wav_bytes(), "audio/wav")})
    assert r.status_code == 401

    items = _poll_segments(client, note_id, before + 3)
    by_ch = {s["audio_channel_no"]: s for s in items if s["recording_id"] == rec["recording_id"]}
    assert by_ch[1]["speaker_name"] == "Budi Santoso" and by_ch[1]["seat_label"] == "Kursi Pimpinan"
    assert by_ch[1]["participant_id"] == "44444444-0000-0000-0000-000000000001"
    assert by_ch[2]["speaker_name"] == "Siti Rahayu"
    assert by_ch[3]["speaker_name"] == "Kursi 3"
    assert by_ch[1]["start_ms"] == 1000 and by_ch[1]["text"].startswith("[STT uji]")

    # koreksi pembicara
    r = client.patch(f"/notes/{note_id}/segments/{by_ch[3]['id']}", json={"speaker_name": "Andi", "text": "Teks dikoreksi"})
    assert r.status_code == 200 and r.json()["data"]["is_edited"] is True

    # polling inkremental
    cur = client.get(f"/notes/{note_id}/segments").json()["data"]["cursor"]
    assert client.get(f"/notes/{note_id}/segments", params={"after": cur}).json()["data"]["items"] == []

    assert client.post(f"/notes/recording/{BOOKING}/pause").json()["data"]["status"] == "paused"
    assert client.post(f"/notes/recording/{BOOKING}/resume").json()["data"]["status"] == "recording"
    st = client.post(f"/notes/recording/{BOOKING}/stop").json()["data"]
    assert st["status"] in ("done", "processing")
    assert httpx.get(f"{BASE}/api/v1/notes/recording/active", params={"room_code": ROOM_CODE},
                     headers={"X-Agent-Key": AGENT_KEY}).status_code == 204

    # ringkasan AI (fake Ollama) + action item manual dipertahankan
    manual = client.post(f"/notes/{note_id}/action-items", json={"task": "Tugas manual", "assignee": "Siti"}).json()["data"]
    assert manual["source"] == "manual" and manual["owner"] == "Siti"
    for _ in range(2):
        r = client.post(f"/notes/{note_id}/summarize", timeout=120)
        assert r.status_code == 200, r.text
    n = r.json()["data"]
    assert n["summary_json"]["pokok_bahasan"][0]["judul"] == "Evaluasi anggaran"
    assert n["ai_model"] == "qwen2.5:7b-instruct"
    assert len(n["decisions"]) == 2
    ai_items = [a for a in n["action_items"] if a["source"] == "ai"]
    assert len(ai_items) == 2
    assert {a["due_date"] for a in ai_items} == {"2026-10-01", None}
    assert any(a["id"] == manual["id"] for a in n["action_items"])

    # edit ringkasan
    r = client.put(f"/notes/{note_id}", json={"summary_json": {"ringkasan": "Ringkasan diedit notulis."}})
    assert r.json()["data"]["summary"] == "Ringkasan diedit notulis."

    # finalisasi -> terkunci
    assert client.post(f"/notes/{note_id}/finalize").json()["data"]["status"] == "final"
    assert client.patch(f"/notes/{note_id}/segments/{by_ch[1]['id']}", json={"text": "x"}).status_code == 409

    # export
    pdf = client.get(f"/notes/{note_id}/export/pdf", params={"include_transcript": 1})
    assert pdf.status_code == 200 and pdf.content[:5] == b"%PDF-"
    assert "attachment" in pdf.headers["content-disposition"]
    docx_r = client.get(f"/notes/export/{note_id}/docx")  # alias lama
    assert docx_r.status_code == 200
    from docx import Document
    doc = Document(io.BytesIO(docx_r.content))
    text = "\n".join(p.text for p in doc.paragraphs)
    cells = "\n".join(c.text for t in doc.tables for row in t.rows for c in row.cells)
    assert "NOTULEN RAPAT" in text and "Ringkasan diedit notulis." in text
    assert "Rapat Koordinasi <Anggaran> & Jadwal" in cells
    assert "Budi Santoso" in cells  # pimpinan rapat (kursi chair)
    assert "Andi (tidak hadir)" not in text
    txt = client.get(f"/notes/{note_id}/export/txt", params={"include_transcript": 1}).text
    assert "Teks dikoreksi" in txt and "Siti Rahayu" in txt
    html = client.get(f"/notes/{note_id}/export/html").text
    assert "&lt;Anggaran&gt;" in html and "<Anggaran>" not in html

    assert client.post(f"/notes/{note_id}/reopen").json()["data"]["status"] == "draft"


def test_mix_and_browser_and_upload(client):
    _stop_if_active(client)
    note = client.post(f"/notes/by-booking/{BOOKING}").json()["data"]
    if note["status"] == "final":
        client.post(f"/notes/{note['id']}/reopen")
    note_id = note["id"]
    base = client.get(f"/notes/{note_id}/segments").json()["data"]["total"]

    rec = client.post(f"/notes/recording/{BOOKING}/start", json={"source": "mix"}).json()["data"]
    # rekaman lain dengan sumber berbeda ditolak
    assert client.post(f"/notes/recording/{BOOKING}/start", json={"source": "browser"}).status_code == 409
    r = httpx.post(f"{BASE}/api/v1/notes/recording/{BOOKING}/segments", headers={"X-Agent-Key": AGENT_KEY},
                   data={"channel_no": 2, "start_ms": 0, "recording_id": rec["recording_id"]},
                   files={"audio": ("b.wav", wav_bytes(), "audio/wav")})
    assert r.status_code == 202
    items = _poll_segments(client, note_id, base + 1)
    assert any(s["speaker_name"] == "Grup B (Mic 9–16)" for s in items)
    client.post(f"/notes/recording/{BOOKING}/stop")

    rec = client.post(f"/notes/recording/{BOOKING}/start", json={"source": "browser"}).json()["data"]
    r = client.post(f"/notes/recording/{BOOKING}/chunks",
                    data={"start_ms": 20000, "participant_id": "44444444-0000-0000-0000-000000000002",
                          "speaker_name": "Siti Rahayu"},
                    files={"audio": ("c.wav", wav_bytes(), "audio/wav")})
    assert r.status_code == 202, r.text
    items = _poll_segments(client, note_id, base + 2)
    chunk_seg = [s for s in items if s["recording_id"] == rec["recording_id"]][0]
    assert chunk_seg["speaker_name"] == "Siti Rahayu" and chunk_seg["start_ms"] == 20000
    client.post(f"/notes/recording/{BOOKING}/stop")

    # unggah file penuh
    bad = client.post(f"/notes/{note_id}/transcribe-audio", files={"audio_file": ("x.exe", b"MZ", "application/x-msdownload")})
    assert bad.status_code == 415
    up = client.post(f"/notes/{note_id}/transcribe-audio", files={"audio_file": ("rapat.wav", wav_bytes(4.0), "audio/wav")})
    assert up.status_code == 202, up.text
    rid = up.json()["data"]["recording_id"]
    deadline = time.time() + 20
    while time.time() < deadline:
        st = client.get(f"/notes/recording/{BOOKING}/status").json()["data"]
        if st["recording_id"] == rid and st["status"] in ("done", "failed"):
            break
        time.sleep(0.3)
    assert st["status"] == "done", st
    items = _poll_segments(client, note_id, base + 3)
    assert any(s["recording_id"] == rid and s["speaker_name"] == "Peserta" for s in items)
