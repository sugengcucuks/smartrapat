"""Uji summarizer Ollama dengan transport HTTP palsu (httpx.MockTransport)."""
import json
import os

import httpx
import pytest

os.environ.setdefault("JWT_SECRET", "x" * 40)

from src.api.services import summarizer as S  # noqa: E402

GOOD = {
    "ringkasan": "Paragraf satu.\n\nParagraf dua.",
    "pokok_bahasan": [{"judul": "Anggaran", "uraian": "Realisasi 72%."}, "Jadwal"],
    "keputusan": ["Kegiatan 15 Oktober", {"keputusan": "Ajukan tambahan anggaran"}, ""],
    "tindak_lanjut": [
        {"tugas": "Revisi RAB", "pic": "Budi", "tenggat": "2026-10-01"},
        {"tugas": "Undangan", "pic": "-", "tenggat": "minggu depan"},
        {"tugas": "", "pic": "X"},
        "Siapkan ruangan",
    ],
    "peserta_aktif": ["Budi", "Siti", "Budi"],
}

SEGS = [
    {"start_ms": 1000, "speaker_name": "Budi Santoso", "text": "Selamat pagi, kita mulai rapat."},
    {"start_ms": 65_000, "speaker_name": "Siti Rahayu", "text": "Realisasi anggaran 72 persen."},
    {"start_ms": 3_700_000, "speaker_name": None, "text": "Baik, disepakati."},
]


def client_with(handler, model="qwen2.5:7b-instruct"):
    return S.OllamaClient(base_url="http://ollama.test", model=model, timeout=5,
                          transport=httpx.MockTransport(handler))


def chat_ok(content, calls=None):
    def handler(req: httpx.Request):
        if req.url.path == "/api/tags":
            return httpx.Response(200, json={"models": [{"name": "qwen2.5:7b-instruct"}, {"name": "llama3.1:8b"}]})
        body = json.loads(req.content)
        if calls is not None:
            calls.append(body)
        return httpx.Response(200, json={"message": {"role": "assistant", "content": content}, "done": True})
    return handler


def test_transcript_lines_format():
    lines = S.build_transcript_lines(SEGS)
    assert lines[0] == "[00:01] Budi Santoso: Selamat pagi, kita mulai rapat."
    assert lines[1].startswith("[01:05] Siti Rahayu:")
    assert lines[2].startswith("[1:01:40] Peserta:")


@pytest.mark.asyncio
async def test_summarize_single_call_normalizes():
    calls = []
    res, info = await S.summarize_segments(SEGS, {"judul": "Rapat"}, client_with(chat_ok(json.dumps(GOOD), calls)))
    assert len(calls) == 1
    body = calls[0]
    assert body["stream"] is False and body["options"]["temperature"] == 0.2
    assert body["format"]["type"] == "object"  # JSON schema (structured outputs)
    assert "[00:01] Budi Santoso:" in body["messages"][1]["content"]
    assert body["messages"][0]["role"] == "system" and "Bahasa Indonesia" in body["messages"][0]["content"]
    assert res.ringkasan.startswith("Paragraf satu.")
    assert [p.judul for p in res.pokok_bahasan] == ["Anggaran", "Jadwal"]
    assert res.keputusan == ["Kegiatan 15 Oktober", "Ajukan tambahan anggaran"]
    assert [(t.tugas, t.pic, t.tenggat) for t in res.tindak_lanjut] == [
        ("Revisi RAB", "Budi", "2026-10-01"), ("Undangan", None, None), ("Siapkan ruangan", None, None)]
    assert res.peserta_aktif == ["Budi", "Siti"]
    assert info == {"model": "qwen2.5:7b-instruct", "chunks": 1}


@pytest.mark.asyncio
async def test_long_transcript_map_reduce():
    calls = []
    segs = [{"start_ms": i * 1000, "speaker_name": "Budi", "text": "kalimat panjang " * 20} for i in range(60)]
    res, info = await S.summarize_segments(segs, {}, client_with(chat_ok(json.dumps(GOOD), calls)), chunk_chars=2000)
    assert info["chunks"] > 1
    parts = [c for c in calls if "BAGIAN" in c["messages"][1]["content"]]
    merges = [c for c in calls if "Gabungkan" in c["messages"][1]["content"]]
    assert len(parts) == info["chunks"] and len(merges) >= 1
    assert res.ringkasan


@pytest.mark.asyncio
async def test_fenced_json_and_retry_on_garbage():
    seq = iter(["ini bukan json", "```json\n" + json.dumps(GOOD) + "\n```"])

    def handler(req):
        return httpx.Response(200, json={"message": {"content": next(seq)}})

    res, _ = await S.summarize_segments(SEGS, {}, client_with(handler))
    assert res.keputusan[0] == "Kegiatan 15 Oktober"


@pytest.mark.asyncio
async def test_old_ollama_schema_fallback_to_json():
    formats = []

    def handler(req):
        body = json.loads(req.content)
        formats.append(body["format"])
        if isinstance(body["format"], dict):
            return httpx.Response(400, json={"error": "invalid format: expected \"json\""})
        return httpx.Response(200, json={"message": {"content": json.dumps(GOOD)}})

    await S.summarize_segments(SEGS, {}, client_with(handler))
    assert isinstance(formats[0], dict) and formats[1] == "json"


@pytest.mark.asyncio
async def test_unreachable_is_503_without_fake_summary():
    def handler(req):
        raise httpx.ConnectError("connection refused", request=req)

    with pytest.raises(S.SummarizerError) as ei:
        await S.summarize_segments(SEGS, {}, client_with(handler))
    assert ei.value.status_code == 503 and ei.value.code == "LLM_UNAVAILABLE"
    assert "tidak dapat dihubungi" in ei.value.message


@pytest.mark.asyncio
async def test_model_missing_message():
    def handler(req):
        return httpx.Response(404, json={"error": "model \"llama3.1:8b\" not found, try pulling it first"})

    with pytest.raises(S.SummarizerError) as ei:
        await S.summarize_segments(SEGS, {}, client_with(handler, model="llama3.1:8b"))
    assert ei.value.code == "LLM_MODEL_MISSING" and "ollama pull llama3.1:8b" in ei.value.message


@pytest.mark.asyncio
async def test_empty_transcript_rejected():
    with pytest.raises(S.SummarizerError) as ei:
        await S.summarize_segments([{"start_ms": 0, "text": "  "}], {}, client_with(chat_ok("{}")))
    assert ei.value.status_code == 400


@pytest.mark.asyncio
async def test_status_reachable_and_model_available():
    st = await client_with(chat_ok("{}"), model="llama3.1:8b").status()
    assert st["reachable"] and st["model_available"]
    st = await client_with(chat_ok("{}"), model="mistral").status()
    assert st["reachable"] and not st["model_available"]

    def down(req):
        raise httpx.ConnectError("x", request=req)

    st = await client_with(down).status()
    assert st["reachable"] is False and st["error"]


def test_chunk_lines_respects_limit():
    lines = [f"[00:{i:02d}] A: " + "x" * 50 for i in range(40)]
    chunks = S.chunk_lines(lines, 500)
    assert all(len(c) <= 500 for c in chunks)
    assert sum(c.count("\n") + 1 for c in chunks) == 40
