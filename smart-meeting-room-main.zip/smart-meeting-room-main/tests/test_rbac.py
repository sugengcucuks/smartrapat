"""Matriks RBAC: user biasa vs admin vs super admin + anti eskalasi hak akses."""
import pytest

from tests.conftest import login, make_user, role_id

API = "/api/v1"


# Endpoint admin yang WAJIB ditolak (403) untuk role 'User'.
FORBIDDEN_FOR_USER = [
    ("post", "/users", {"username": "x1", "name": "X", "email": "x1@example.com", "password": "Rahasia123!"}),
    ("get", "/roles/permissions", None),
    ("post", "/roles", {"name": "Hacker"}),
    ("get", "/settings", None),
    ("put", "/settings/batch", {"settings": [{"key": "app_title", "value": "hacked"}]}),
    ("get", "/audit", None),
    ("get", "/audit/stats/summary", None),
    ("get", "/reports/bookings", None),
    ("get", "/reports/export?format=json", None),
    ("get", "/maintenance/health", None),
    ("post", "/maintenance/backup", None),
    ("post", "/maintenance/migrations/run", None),
    ("post", "/maintenance/seed-demo", None),
    ("post", "/notifications/send", {"user_ids": [], "title": "x"}),
    ("post", "/notifications/send-many", {"user_ids": [], "title": "x"}),
    ("post", "/notifications/broadcast", {"title": "x"}),
    ("post", "/buildings", {"name": "G", "code": "G1"}),
    ("post", "/rooms", {"name": "R", "code": "RX", "capacity": 2}),
    ("post", "/equipment", {"name": "E", "code": "E1"}),
    ("post", "/devices", {"name": "D"}),
    ("post", "/audio/zones", {"name": "Z"}),
    ("post", "/videowall", {"name": "V"}),
    ("post", "/notes", {"title": "N"}),
]


@pytest.mark.parametrize("method,path,body", FORBIDDEN_FOR_USER)
def test_user_forbidden_on_admin_endpoints(client, staff, method, path, body):
    kwargs = {"headers": staff["headers"]}
    if body is not None:
        kwargs["json"] = body
    r = getattr(client, method)(API + path, **kwargs)
    assert r.status_code == 403, (path, r.status_code, r.text)


def test_unauthenticated_rejected(client):
    for path in ["/users", "/settings", "/audit", "/reports/bookings", "/bookings"]:
        assert client.get(API + path).status_code in (401, 403)


def test_user_directory_and_own_profile(client, admin, staff):
    h = staff["headers"]
    # Direktori untuk memilih peserta: boleh, tapi tanpa data sensitif.
    r = client.get(f"{API}/users", headers=h, params={"per_page": 100})
    assert r.status_code == 200
    for item in r.json()["data"]["items"]:
        assert item["phone"] is None and item["nik"] is None and item["role_id"] is None

    me = client.get(f"{API}/users/me", headers=h)
    assert me.status_code == 200
    admin_id = client.get(f"{API}/users/me", headers=admin).json()["data"]["id"]
    assert client.get(f"{API}/users/{admin_id}", headers=h).status_code == 403
    assert client.get(f"{API}/users/{staff['id']}", headers=h).status_code == 200

    # Profil sendiri (field terbatas) OK lewat PUT /users/{id} dan PUT /users/me.
    r = client.put(f"{API}/users/{staff['id']}", headers=h, json={"name": "Staf Satu", "phone": "0812"})
    assert r.status_code == 200, r.text
    assert r.json()["data"]["name"] == "Staf Satu"
    assert client.put(f"{API}/users/me", headers=h, json={"name": "Staf Satu B"}).status_code == 200

    # Tidak boleh ubah role / status / username sendiri, atau profil orang lain.
    super_role = role_id(client, admin, "Super Admin")
    assert client.put(f"{API}/users/{staff['id']}", headers=h, json={"role_id": super_role}).status_code == 403
    assert client.put(f"{API}/users/{staff['id']}", headers=h, json={"status": "ACTIVE"}).status_code == 403
    assert client.put(f"{API}/users/{staff['id']}", headers=h, json={"username": "root"}).status_code == 403
    assert client.put(f"{API}/users/{admin_id}", headers=h, json={"name": "pwned"}).status_code == 403
    assert client.put(f"{API}/users/{admin_id}/password", headers=h,
                      json={"new_password": "Pwned12345"}).status_code == 403
    assert client.delete(f"{API}/users/{admin_id}", headers=h).status_code == 403


def test_privilege_escalation_blocked(client, admin, staff):
    # Role kustom pengelola peran/pengguna (bukan super admin).
    r = client.post(f"{API}/roles", headers=admin, json={
        "name": "RoleManager",
        "permission_ids": ["perm_roles_view", "perm_roles_write", "perm_users_view",
                           "perm_users_edit", "perm_users_create"],
    })
    assert r.status_code == 200, r.text
    rm = r.json()["data"]
    assert set(rm["permissions"]) == {"roles.view", "roles.write", "users.view", "users.edit", "users.create"}
    assert "perm_roles_write" in rm["permission_ids"]

    mgr = make_user(client, admin, "rolemgr", "RoleManager")
    h = mgr["headers"]
    super_role = role_id(client, admin, "Super Admin")
    admin_role = role_id(client, admin, "Admin")
    admin_id = client.get(f"{API}/users/me", headers=admin).json()["data"]["id"]

    # Tidak bisa memberi role Super Admin / role dengan izin melebihi dirinya.
    assert client.put(f"{API}/users/{staff['id']}", headers=h, json={"role_id": super_role}).status_code == 403
    assert client.put(f"{API}/users/{staff['id']}", headers=h, json={"role_id": admin_role}).status_code == 403
    assert client.post(f"{API}/users", headers=h, json={
        "username": "evil", "name": "Evil", "email": "evil@example.com", "password": "Rahasia123!",
        "role_id": super_role}).status_code == 403
    # Tidak bisa mengubah / reset password akun Super Admin.
    assert client.put(f"{API}/users/{admin_id}", headers=h, json={"name": "x"}).status_code == 403
    assert client.put(f"{API}/users/{admin_id}/password", headers=h,
                      json={"new_password": "Pwned12345"}).status_code == 403
    # Tidak bisa mengubah role sendiri.
    assert client.put(f"{API}/users/{mgr['id']}", headers=h, json={"role_id": admin_role}).status_code == 403
    # Role: tidak bisa grant "*" / izin yang tidak dimiliki / nama Super Admin / edit role Super Admin.
    assert client.post(f"{API}/roles", headers=h, json={"name": "X1", "permissions": ["*"]}).status_code == 403
    assert client.post(f"{API}/roles", headers=h,
                       json={"name": "X2", "permissions": ["settings.write"]}).status_code == 403
    assert client.post(f"{API}/roles", headers=h, json={"name": "super admin"}).status_code == 403
    assert client.post(f"{API}/roles/{super_role}/permissions", headers=h,
                       json={"permission_ids": []}).status_code == 403
    assert client.delete(f"{API}/roles/{super_role}", headers=admin).status_code == 403
    # Sinkronisasi izin role sendiri ke izin lebih tinggi -> ditolak.
    assert client.post(f"{API}/roles/{rm['id']}/permissions", headers=h,
                       json={"permission_ids": ["perm_settings_write"]}).status_code == 403
    # Izin valid (subset) diterima & disimpan sebagai kode.
    r = client.post(f"{API}/roles/{rm['id']}/permissions", headers=h,
                    json={"permission_ids": ["perm_roles_view", "perm_roles_write", "perm_users_view",
                                             "perm_users_edit", "perm_users_create"]})
    assert r.status_code == 200, r.text
    # Permission tak dikenal -> 400.
    assert client.post(f"{API}/roles/{rm['id']}/permissions", headers=h,
                       json={"permissions": ["bogus.perm"]}).status_code == 400


def test_password_reset_revokes_sessions(client, admin):
    u = make_user(client, admin, "victim", "User")
    assert client.get(f"{API}/users/me", headers=u["headers"]).status_code == 200
    r = client.put(f"{API}/users/{u['id']}/password", headers=admin, json={"new_password": "BaruSekali123"})
    assert r.status_code == 200
    assert client.get(f"{API}/users/me", headers=u["headers"]).status_code == 401
    # Login baru wajib ganti password.
    h = login(client, "victim", "BaruSekali123")
    assert client.get(f"{API}/bookings", headers=h).status_code == 403


def test_settings_secret_masking(client, admin):
    r = client.put(f"{API}/settings/batch", headers=admin,
                   json={"settings": [{"key": "smtp_pass", "value": "sup3r-secret"},
                                      {"key": "smtp_host", "value": "mail.local"}]})
    assert r.status_code == 200, r.text
    items = {i["key"]: i for i in client.get(f"{API}/settings", headers=admin).json()["data"]}
    assert items["smtp_pass"]["value"] == "" and items["smtp_pass"]["is_secret"] is True
    assert items["smtp_pass"]["has_value"] is True
    assert items["smtp_host"]["value"] == "mail.local"
    # Nilai rahasia kosong = tidak diubah.
    r = client.put(f"{API}/settings", headers=admin, json={"settings": {"smtp_pass": ""}})
    assert r.status_code == 200 and r.json()["data"]["count"] == 0
    # Format dict juga diterima; PUT /settings/{key} menerima {"value"}.
    assert client.put(f"{API}/settings/smtp_host", headers=admin, json={"value": "smtp2.local"}).status_code == 200
    public = client.get(f"{API}/settings/public").json()["data"]
    assert all("pass" not in i["key"] for i in public)


def test_audit_log_server_side_identity(client, admin, staff):
    r = client.post(f"{API}/audit/log", headers=staff["headers"], json={
        "action": "login", "module": "auth", "user_id": "00000000-0000-0000-0000-000000000000",
        "ip_address": "6.6.6.6", "user_agent": "forged"})
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    assert data["user_id"] == staff["id"]
    assert data["ip_address"] != "6.6.6.6"
    assert data["user_agent"] != "forged"
    logs = client.get(f"{API}/audit", headers=admin, params={"module": "users", "action": "create"})
    assert logs.status_code == 200 and logs.json()["data"]["total"] >= 1


def test_notifications_static_route_order(client, staff):
    r = client.delete(f"{API}/notifications/read", headers=staff["headers"])
    assert r.status_code == 200, r.text
