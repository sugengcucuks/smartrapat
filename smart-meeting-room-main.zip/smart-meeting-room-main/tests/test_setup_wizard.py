"""Setup Wizard ala WordPress: status publik, proteksi super admin, profil + finalisasi."""
import pytest

from tests.conftest import login

API = "/api/v1"
STEP_KEYS = {"database", "migrations", "admin", "organization", "license", "finalize"}


def _steps(data: dict) -> dict:
    return {s["key"]: s for s in data["steps"]}


def test_setup_status_public(client):
    """GET /setup/status terbuka tanpa auth dan hanya memuat status langkah."""
    r = client.get(f"{API}/setup/status")
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    assert isinstance(data["completed"], bool)
    steps = _steps(data)
    assert set(steps) == STEP_KEYS
    # Tidak membocorkan data sensitif.
    body = r.text
    assert "password" not in body.lower()
    # DB & admin tersedia di lingkungan tes; profil organisasi belum diisi.
    assert steps["database"]["done"] is True
    assert steps["migrations"]["done"] is True
    assert steps["admin"]["done"] is True


def test_setup_profile_requires_super_admin(client, staff):
    r = client.post(f"{API}/setup/profile", headers=staff["headers"],
                    json={"org_name": "PT Hacker"})
    assert r.status_code == 403, r.text
    assert client.post(f"{API}/setup/complete", headers=staff["headers"]).status_code == 403
    assert client.post(f"{API}/setup/profile", json={"org_name": "PT Anonim"}).status_code in (401, 403)


def test_setup_profile_and_complete(client, admin):
    # Finalisasi sebelum profil -> ditolak.
    r = client.post(f"{API}/setup/complete", headers=admin)
    assert r.status_code == 400, r.text
    assert r.json()["detail"]["code"] == "SETUP_PROFILE_REQUIRED"

    # Simpan profil organisasi.
    r = client.post(f"{API}/setup/profile", headers=admin, json={
        "org_name": "PT Uji Coba Sejahtera",
        "org_address": "Jl. Testing No. 1",
        "org_email": "tes@example.com",
    })
    assert r.status_code == 200, r.text
    steps = _steps(r.json()["data"])
    assert steps["organization"]["done"] is True
    assert "PT Uji Coba Sejahtera" in steps["organization"]["detail"]

    # Finalisasi.
    r = client.post(f"{API}/setup/complete", headers=admin)
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    assert data["completed"] is True

    # Status kini completed; idempoten bila diselesaikan lagi.
    status = client.get(f"{API}/setup/status").json()["data"]
    assert status["completed"] is True
    assert client.post(f"{API}/setup/complete", headers=admin).status_code == 200


def test_setup_profile_update_after_complete(client, admin):
    """Profil tetap bisa diperbarui setelah wizard selesai (koreksi typo)."""
    r = client.post(f"{API}/setup/profile", headers=admin, json={"org_name": "PT Uji Coba Sejahtera 2"})
    assert r.status_code == 200, r.text
    steps = _steps(r.json()["data"])
    assert steps["organization"]["done"] is True


def test_menu_exposes_setup_for_super_admin_only(client, admin, staff):
    r = client.get(f"{API}/auth/menu", headers=admin)
    ids = {m["id"] for m in r.json()["menu"]}
    assert "search" in ids and "followups" in ids and "setup" in ids

    # Role 'User' punya notes.view (search/followups tampil), tapi bukan super admin.
    r = client.get(f"{API}/auth/menu", headers=staff["headers"])
    ids = {m["id"] for m in r.json()["menu"]}
    assert "setup" not in ids
    assert "search" in ids and "followups" in ids
