"""Fixture pengujian keamanan API (RBAC, kiosk, dll).

Memakai database PostgreSQL SUNGGUHAN yang dibuat ulang setiap sesi tes:
    SMR_TEST_DB   nama database tes (default: smr_test_security) - AKAN DI-DROP!
    DB_HOST/DB_PORT/DB_USER/DB_PASSWORD  koneksi server PostgreSQL (lihat .env)

Jalankan:  python -m pytest tests -q
"""
import asyncio
import os
import sys
import tempfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

TEST_DB = os.environ.get("SMR_TEST_DB", "smr_test_security")
if TEST_DB in ("smart_meeting_room",):
    raise RuntimeError("SMR_TEST_DB tidak boleh database utama")

_TMP = tempfile.mkdtemp(prefix="smr_tests_")
os.environ.update({
    "DB_NAME": TEST_DB,
    "JWT_SECRET": os.environ.get("TEST_JWT_SECRET", "t" * 48),
    "LICENSE_ENFORCED": "false",
    "LICENSE_DIR": _TMP,
    "LICENSE_FILE": "",
    "UPLOAD_DIR": str(Path(_TMP) / "uploads"),
    "BCRYPT_ROUNDS": "4",
    "ENABLE_API_DOCS": "false",
})

import asyncpg  # noqa: E402

from src.api.config import get_settings  # noqa: E402


def _admin_dsn(db: str) -> str:
    s = get_settings()
    return f"postgresql://{s.DB_USER}:{s.DB_PASSWORD}@{s.DB_HOST}:{s.DB_PORT}/{db}"


async def _recreate_db() -> None:
    conn = await asyncpg.connect(_admin_dsn("postgres"))
    try:
        await conn.execute(f'DROP DATABASE IF EXISTS "{TEST_DB}" WITH (FORCE)')
        await conn.execute(f'CREATE DATABASE "{TEST_DB}"')
    finally:
        await conn.close()
    from src.api.db.migrator import run_pending

    results = await run_pending(_admin_dsn(TEST_DB), log=lambda _m: None)
    failed = [r for r in results if not r.ok]
    assert not failed, failed


asyncio.run(_recreate_db())

from fastapi.testclient import TestClient  # noqa: E402

from src.api.main import app  # noqa: E402
from src.api.utils.rate_limit import rate_limiter  # noqa: E402

ADMIN_PASSWORD = "AdminBaru123!"


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture(autouse=True)
def _reset_rate_limits():
    rate_limiter._hits.clear()
    yield


def login(client, username: str, password: str) -> dict:
    r = client.post("/api/v1/auth/login", json={"username": username, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture(scope="session")
def admin(client) -> dict:
    """Header auth Super Admin (password default diganti dulu)."""
    r = client.post("/api/v1/auth/login", json={"username": "admin", "password": "admin123"})
    if r.status_code == 200:
        h = {"Authorization": f"Bearer {r.json()['access_token']}"}
        r2 = client.post("/api/v1/auth/change-password", headers=h,
                         json={"old_password": "admin123", "new_password": ADMIN_PASSWORD})
        assert r2.status_code == 200, r2.text
    return login(client, "admin", ADMIN_PASSWORD)


def role_id(client, admin_headers, name: str) -> str:
    r = client.get("/api/v1/roles", headers=admin_headers, params={"per_page": 100})
    assert r.status_code == 200, r.text
    for item in r.json()["data"]["items"]:
        if item["name"].lower() == name.lower():
            return item["id"]
    raise AssertionError(f"role {name} tidak ada")


def make_user(client, admin_headers, username: str, role: str, password: str = "Rahasia123!") -> dict:
    r = client.post("/api/v1/users", headers=admin_headers, json={
        "username": username, "name": username.title(), "email": f"{username}@example.com",
        "password": password, "role_id": role_id(client, admin_headers, role),
    })
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    return {"id": data["id"], "headers": login(client, username, password)}


@pytest.fixture(scope="session")
def staff(client, admin) -> dict:
    return make_user(client, admin, "staff1", "User")


@pytest.fixture(scope="session")
def staff2(client, admin) -> dict:
    return make_user(client, admin, "staff2", "User")


@pytest.fixture(scope="session")
def manager(client, admin) -> dict:
    """User dengan role Admin (bukan Super Admin)."""
    return make_user(client, admin, "manager1", "Admin")
