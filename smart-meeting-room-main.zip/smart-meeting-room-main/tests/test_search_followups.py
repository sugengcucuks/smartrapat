"""Pencarian lintas rapat (FTS migration 019) + Dashboard tindak lanjut."""
from datetime import date, timedelta
from uuid import uuid4

import pytest

API = "/api/v1"
TODAY = date.today()


@pytest.fixture(scope="module")
def corpus(client, admin):
    """Dua notulen dengan kata kunci unik: judul+action (zebra), transkrip (devops)."""
    h = admin  # fixture admin = header auth Super Admin.
    r = client.post(f"{API}/notes", headers=h, json={
        "title": "Rapat Koordinasi Zebra", "date": str(TODAY),
        "start_time": "08:00", "end_time": "09:00",
        "action_items": [{
            "task": "Siapkan laporan kwartalan regu zebra",
            "owner": "Budi", "due_date": str(TODAY + timedelta(days=7)), "status": "open",
        }],
    })
    assert r.status_code == 201, r.text
    note1 = r.json()["data"]

    r = client.post(f"{API}/notes", headers=h, json={
        "title": "Rapat Anggrek", "date": str(TODAY),
        "start_time": "10:00", "end_time": "11:00",
    })
    assert r.status_code == 201, r.text
    note2 = r.json()["data"]
    r = client.post(f"{API}/notes/{note2['id']}/segments", headers=h, json={
        "text": "Pembahasan pipeline devops menyusul panen anggrek",
        "speaker_name": "Cici", "start_ms": 5000,
    })
    assert r.status_code == 201, r.text
    return {"note1": note1, "note2": note2}


# --- Pencarian ---------------------------------------------------------------

def test_search_requires_permission(client, staff):
    """Anonim ditolak; role User punya notes.view sehingga boleh mencari."""
    assert client.get(f"{API}/search", params={"q": "zebra"}).status_code in (401, 403)
    r = client.get(f"{API}/search", params={"q": "zebra"}, headers=staff["headers"])
    assert r.status_code == 200, r.text


def test_search_query_too_short(client, admin):
    r = client.get(f"{API}/search", params={"q": "z"}, headers=admin)
    assert r.status_code == 422


def test_search_finds_note_title(client, admin, corpus):
    r = client.get(f"{API}/search", params={"q": "zebra"}, headers=admin)
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    assert data["counts"]["notes"] >= 1
    hits = [n for n in data["results"]["notes"] if n["id"] == corpus["note1"]["id"]]
    assert hits, data["results"]["notes"]
    assert "zebra" in hits[0]["title"].lower()
    assert "<mark>" in hits[0]["snippet"].lower()


def test_search_finds_transcript(client, admin, corpus):
    r = client.get(f"{API}/search", params={"q": "devops"}, headers=admin)
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    assert data["counts"]["transcripts"] >= 1
    hit = data["results"]["transcripts"][0]
    assert hit["note_id"] == corpus["note2"]["id"]
    assert hit["speaker_name"] == "Cici"
    assert "<mark>" in hit["snippet"].lower()


def test_search_finds_action_item(client, admin, corpus):
    r = client.get(f"{API}/search", params={"q": "kwartalan"}, headers=admin)
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    assert data["counts"]["actions"] >= 1
    hit = data["results"]["actions"][0]
    assert hit["note_id"] == corpus["note1"]["id"]
    assert hit["owner"] == "Budi"


def test_search_type_filter(client, admin, corpus):
    r = client.get(f"{API}/search", params={"q": "zebra", "type": "actions"}, headers=admin)
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    assert data["results"]["notes"] == [] and data["results"]["transcripts"] == []
    assert data["counts"]["total"] == data["counts"]["actions"]


# --- Dashboard tindak lanjut --------------------------------------------------

def test_followups_requires_permission(client, staff, corpus):
    """Anonim ditolak; role User (notes.view) boleh lihat tapi bukan mengubah."""
    assert client.get(f"{API}/followups/summary").status_code in (401, 403)
    assert client.get(f"{API}/followups/summary", headers=staff["headers"]).status_code == 200
    assert client.get(f"{API}/followups/items", headers=staff["headers"]).status_code == 200
    # Item corpus dibuat Super Admin: staff bukan pembuat/pemilik -> 403.
    item_id = client.get(f"{API}/followups/items", headers=staff["headers"],
                         params={"owner": "Budi"}).json()["data"]["items"][0]["id"]
    r = client.patch(f"{API}/followups/items/{item_id}", headers=staff["headers"],
                     json={"status": "done"})
    assert r.status_code == 403, r.text


def test_followups_summary_counts_corpus(client, admin, corpus):
    r = client.get(f"{API}/followups/summary", headers=admin)
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    assert data["total"] >= 1
    assert data["open"] >= 1
    assert any(o["owner"] == "Budi" for o in data["by_owner"])


def test_followups_items_filter_and_pagination(client, admin, corpus):
    h = admin
    r = client.get(f"{API}/followups/items", headers=h, params={"owner": "Budi", "status": "open"})
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    assert data["total"] >= 1 and data["items"]
    for item in data["items"]:
        # Filter owner bersifat ilike (mengandung), seed lama punya "Budi Santoso".
        assert "budi" in (item["owner"] or "").lower()
    mine = next(i for i in data["items"] if i["note_id"] == corpus["note1"]["id"])
    assert "kwartalan" in mine["task"].lower()
    assert mine["note_title"] == "Rapat Koordinasi Zebra"
    assert mine["meeting_date"] == str(TODAY)

    # Filter teks + halaman di luar jangkauan tetap valid.
    r = client.get(f"{API}/followups/items", headers=h, params={"q": "kwartalan", "page": 1, "per_page": 5})
    assert r.status_code == 200
    assert r.json()["data"]["total"] >= 1


def test_followups_update_item_status(client, admin, corpus):
    h = admin
    r = client.get(f"{API}/followups/items", headers=h, params={"owner": "Budi", "status": "open"})
    item = r.json()["data"]["items"][0]

    r = client.patch(f"{API}/followups/items/{item['id']}", headers=h,
                     json={"status": "in_progress", "owner": "Budi", "due_date": str(TODAY)})
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    assert data["status"] == "in_progress"

    # Ringkasan ikut berubah.
    r = client.get(f"{API}/followups/summary", headers=h)
    assert r.json()["data"]["in_progress"] >= 1

    # Kembalikan ke open agar idempoten bila suite dijalankan lagi pada DB yang sama.
    client.patch(f"{API}/followups/items/{item['id']}", headers=h, json={"status": "open"})


def test_followups_update_item_not_found(client, admin):
    r = client.patch(f"{API}/followups/items/{uuid4()}", headers=admin, json={"status": "done"})
    assert r.status_code == 404
