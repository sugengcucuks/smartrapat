"""Booking (status dipaksa server, IDOR), kiosk token, PIN lockout, presensi, lisensi, laporan."""
from datetime import date, datetime, timedelta

import pytest

API = "/api/v1"


def _room(client, headers, code="R-A101"):
    r = client.get(f"{API}/rooms", headers=headers, params={"per_page": 100})
    assert r.status_code == 200, r.text
    for room in r.json()["data"]["items"]:
        assert room.get("pairing_key") in (None, ""), "pairing_key bocor di list ruangan"
        if room["code"] == code:
            return room
    raise AssertionError(code)


def _new_room(client, admin, code):
    r = client.post(f"{API}/rooms", headers=admin, json={"name": f"Ruang {code}", "code": code, "capacity": 8})
    assert r.status_code == 200, r.text
    room = r.json()["data"]
    assert room.get("pairing_key") in (None, "")
    return room


def _pair(client, admin, room):
    key = client.get(f"{API}/rooms/{room['id']}/pairing-key", headers=admin).json()["data"]["pairing_key"]
    r = client.post(f"{API}/door-display/pair", json={"room_code": room["code"], "pairing_key": key})
    assert r.status_code == 200, r.text
    token = r.json()["data"]["kiosk_token"]
    return {"X-Kiosk-Token": token}


def _slot(offset_days=1, hour=9):
    d = date.today() + timedelta(days=offset_days)
    return str(d), f"{hour:02d}:00:00", f"{hour + 1:02d}:00:00"


def test_booking_status_forced_and_idor(client, admin, staff, staff2):
    room = _room(client, staff["headers"])
    d, s, e = _slot(2, 9)
    r = client.post(f"{API}/bookings", headers=staff["headers"], json={
        "room_id": room["id"], "title": "Rapat Staf", "date": d, "start_time": s, "end_time": e,
        "attendees": 2, "status": "approved",
        "participants": [{"user_id": staff2["id"], "is_guest": False}],
    })
    assert r.status_code == 200, r.text
    b = r.json()["data"]
    assert b["status"] == "pending"
    assert b["participants"][0]["ticket_code"]  # pemilik melihat tiket

    # User lain tidak bisa ubah / batal / hapus / approve / atur mic.
    h2 = staff2["headers"]
    assert client.put(f"{API}/bookings/{b['id']}", headers=h2, json={"title": "hijack"}).status_code == 403
    assert client.put(f"{API}/bookings/{b['id']}/cancel", headers=h2).status_code == 403
    assert client.delete(f"{API}/bookings/{b['id']}", headers=h2).status_code == 403
    assert client.put(f"{API}/bookings/{b['id']}/approve", headers=h2, json={}).status_code == 403
    assert client.put(f"{API}/bookings/{b['id']}/seat-assignments", headers=h2, json={"items": []}).status_code == 403
    # Pemilik tidak bisa menyetujui sendiri lewat update status.
    assert client.put(f"{API}/bookings/{b['id']}", headers=staff["headers"],
                      json={"status": "approved"}).status_code == 403

    # Peserta hanya melihat tiketnya sendiri; user lain tidak melihat tiket sama sekali.
    other = make_other = client.get(f"{API}/bookings/{b['id']}", headers=h2).json()["data"]
    assert other["participants"][0]["ticket_code"]  # staff2 adalah peserta -> tiketnya sendiri
    third = pytest.importorskip("tests.conftest").make_user(client, admin, "outsider", "User")
    seen = client.get(f"{API}/bookings/{b['id']}", headers=third["headers"]).json()["data"]
    assert all(p["ticket_code"] is None for p in seen["participants"])
    listed = client.get(f"{API}/bookings", headers=third["headers"], params={"per_page": 100}).json()["data"]
    for item in listed["items"]:
        if item["user_id"] != third["id"]:
            assert all(p["ticket_code"] is None for p in item["participants"])
    del make_other

    # Approver menyetujui.
    r = client.put(f"{API}/bookings/{b['id']}/approve", headers=admin, json={"approval_notes": "ok"})
    assert r.status_code == 200 and r.json()["data"]["status"] == "approved"


def test_kiosk_flow_and_pin_lockout(client, admin, staff):
    room = _new_room(client, admin, "T-KIOSK1")
    other_room = _new_room(client, admin, "T-KIOSK2")

    # Tanpa token -> 401; key salah -> 403.
    assert client.get(f"{API}/door-display/status/{room['code']}").status_code == 401
    assert client.post(f"{API}/door-display/pair",
                       json={"room_code": room["code"], "pairing_key": "RM-WRONG1"}).status_code == 403
    # Admin: pairing key hanya dari endpoint khusus; user biasa ditolak.
    assert client.get(f"{API}/rooms/{room['id']}/pairing-key", headers=staff["headers"]).status_code == 403
    kh = _pair(client, admin, room)

    assert client.get(f"{API}/door-display/status/{room['code']}", headers=kh).status_code == 200
    assert client.get(f"{API}/door-display/status/{other_room['code']}", headers=kh).status_code == 403
    assert client.get(f"{API}/door-display/{room['code']}/available-slots", headers=kh).status_code == 200
    # Welcome message: baca oleh kiosk, ubah hanya admin.
    assert client.get(f"{API}/door-display/{room['code']}/welcome-message", headers=kh).status_code == 200
    wm = {"room_id": room["id"], "title": "Halo"}
    assert client.put(f"{API}/door-display/{room['code']}/welcome-message", headers=kh, json=wm).status_code in (401, 403)
    assert client.put(f"{API}/door-display/{room['code']}/welcome-message", headers=admin, json=wm).status_code == 200

    # Walk-in booking -> approved atas nama akun sistem kiosk.
    now = datetime.now()
    if now.hour >= 22:
        pytest.skip("terlalu larut untuk uji walk-in")
    start = (now + timedelta(minutes=1)).strftime("%H:%M")
    r = client.post(f"{API}/door-display/{room['code']}/book", headers=kh,
                    json={"title": "Walk in", "start_time": start, "duration_minutes": 30})
    assert r.status_code == 200, r.text
    booking_id = r.json()["data"]["booking_id"]
    assert r.json()["data"]["status"] == "approved"
    detail = client.get(f"{API}/bookings/{booking_id}", headers=admin).json()["data"]
    assert detail["user_name"] == "Kiosk Display"
    # Bentrok -> 409 tanpa membocorkan judul.
    r = client.post(f"{API}/door-display/{room['code']}/book", headers=kh,
                    json={"title": "Dobel", "start_time": start, "duration_minutes": 30})
    assert r.status_code == 409 and "Walk in" not in r.text

    # Set Master PIN (min 6 digit).
    assert client.put(f"{API}/rooms/{room['id']}/master-pin", headers=admin, json={"pin": "1234"}).status_code == 422
    assert client.put(f"{API}/rooms/{room['id']}/master-pin", headers=admin, json={"pin": "246810"}).status_code == 200

    # Cancel tanpa PIN / PIN salah ditolak; 5x salah -> terkunci (429).
    assert client.post(f"{API}/door-display/{room['code']}/cancel/{booking_id}", headers=kh).status_code == 403
    for _ in range(4):
        r = client.post(f"{API}/door-display/early-release/{booking_id}", headers=kh, json={"pin": "000000"})
        assert r.status_code == 403
    r = client.post(f"{API}/door-display/early-release/{booking_id}", headers=kh, json={"pin": "246810"})
    assert r.status_code == 429, r.text  # terkunci walau PIN benar

    # Regenerate pairing key -> token lama dicabut.
    assert client.post(f"{API}/rooms/{room['id']}/pairing-key/regenerate", headers=admin).status_code == 200
    assert client.get(f"{API}/door-display/status/{room['code']}", headers=kh).status_code == 401


def test_kiosk_cancel_with_pin(client, admin):
    room = _new_room(client, admin, "T-CANCEL")
    kh = _pair(client, admin, room)
    assert client.put(f"{API}/rooms/{room['id']}/master-pin", headers=admin, json={"pin": "135790"}).status_code == 200
    now = datetime.now()
    if now.hour >= 22:
        pytest.skip("terlalu larut untuk uji walk-in")
    start = (now + timedelta(minutes=2)).strftime("%H:%M")
    r = client.post(f"{API}/door-display/{room['code']}/book", headers=kh,
                    json={"title": "Cancel me", "start_time": start, "duration_minutes": 15})
    assert r.status_code == 200, r.text
    bid = r.json()["data"]["booking_id"]
    r = client.post(f"{API}/door-display/{room['code']}/cancel/{bid}", headers=kh, json={"pin": "135790"})
    assert r.status_code == 200, r.text


def test_door_display_websocket_requires_token(client, admin):
    room = _new_room(client, admin, "T-WS")
    with client.websocket_connect(f"{API}/ws/door-display/{room['code']}") as ws:
        msg = ws.receive_json()
        assert msg["type"] == "auth_error"
    kh = _pair(client, admin, room)
    with client.websocket_connect(f"{API}/ws/door-display/{room['code']}?kiosk_token={kh['X-Kiosk-Token']}") as ws:
        assert ws.receive_json()["event"] == "connected"


def test_presensi_scan_requires_kiosk_and_approved(client, admin, staff, staff2):
    assert client.post(f"{API}/presensi/scan", json={"code": "ABCD-1234"}).status_code == 401
    assert client.post(f"{API}/presensi/scan", headers=staff["headers"], json={"code": "ABCD-1234"}).status_code == 403

    room = _new_room(client, admin, "T-PRES")
    now = datetime.now()
    if now.hour >= 22 or now.hour < 1:
        pytest.skip("jam tidak cocok untuk uji presensi hari ini")
    start = (now - timedelta(minutes=10)).strftime("%H:%M:00")
    end = (now + timedelta(minutes=50)).strftime("%H:%M:00")
    r = client.post(f"{API}/bookings", headers=staff["headers"], json={
        "room_id": room["id"], "title": "Presensi", "date": str(date.today()), "start_time": start,
        "end_time": end, "attendees": 2, "participants": [{"user_id": staff2["id"], "is_guest": False}],
    })
    if r.status_code == 409:
        pytest.skip("slot bentrok")
    assert r.status_code == 200, r.text
    b = r.json()["data"]
    ticket = b["participants"][0]["ticket_code"]
    kh = _pair(client, admin, room)

    # Pending -> ditolak (tidak auto-approve).
    r = client.post(f"{API}/presensi/scan", headers=kh, json={"code": ticket, "room_code": room["code"]})
    assert r.status_code == 400 and "belum disetujui" in r.text
    assert client.get(f"{API}/bookings/{b['id']}", headers=admin).json()["data"]["status"] == "pending"

    client.put(f"{API}/bookings/{b['id']}/approve", headers=admin, json={})
    # room_code salah -> ditolak.
    assert client.post(f"{API}/presensi/scan", headers=kh,
                       json={"code": ticket, "room_code": "R-A101"}).status_code == 400
    r = client.post(f"{API}/presensi/scan", headers=kh, json={"code": ticket, "room_code": room["code"]})
    assert r.status_code == 200, r.text
    # Attendance: kiosk ruangan ini / pemilik OK, anonim 401.
    assert client.get(f"{API}/presensi/bookings/{b['id']}/attendance").status_code == 401
    assert client.get(f"{API}/presensi/bookings/{b['id']}/attendance", headers=kh).status_code == 200
    assert client.get(f"{API}/presensi/bookings/{b['id']}/attendance", headers=staff["headers"]).status_code == 200


def test_license_activate_garbage_does_not_clobber(client, admin):
    from src.api.licensing.service import license_file_path

    path = license_file_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("EXISTING-LICENSE\n", encoding="utf-8")
    r = client.post(f"{API}/license/activate", json={"license_key": "garbage-garbage-garbage-garbage"})
    assert r.status_code == 400
    assert path.read_text(encoding="utf-8") == "EXISTING-LICENSE\n"
    path.unlink()


def test_license_rejects_empty_fingerprint():
    from src.api.licensing.core import LicensePayload, validate_payload

    payload = LicensePayload.from_dict({"license_id": "L1", "customer": "C", "fingerprint": ""})
    assert not validate_payload(payload, "abc").valid


def test_reports_real_files(client, admin, staff):
    r = client.get(f"{API}/reports/bookings/download", headers=admin, params={"format": "pdf"})
    assert r.status_code == 200, r.text[:300]
    assert r.headers["content-type"] == "application/pdf" and r.content[:4] == b"%PDF"
    r = client.get(f"{API}/reports/bookings", headers=admin, params={"format": "xlsx", "date_from": "2020-01-01"})
    assert r.status_code == 200 and r.content[:2] == b"PK"
    r = client.get(f"{API}/reports/equipment/download", headers=admin, params={"format": "xlsx"})
    assert r.status_code == 200 and r.content[:2] == b"PK"
    r = client.get(f"{API}/reports/export", headers=admin, params={"format": "json", "report_type": "all"})
    assert r.status_code == 200 and "bookings" in r.json()["data"]
    r = client.get(f"{API}/reports/attendance", headers=admin, params={"date_from": "2020-01-01"})
    assert r.status_code == 200 and "items" in r.json()["data"]
    assert client.get(f"{API}/reports/export", headers=staff["headers"]).status_code == 403


def test_formula_and_markup_escaping():
    from src.api.utils.reports_generator import esc, safe_cell

    assert safe_cell("=HYPERLINK(\"x\")") == "'=HYPERLINK(\"x\")"
    assert safe_cell("@SUM(1)") == "'@SUM(1)"
    assert safe_cell("Rapat") == "Rapat"
    assert esc("<b>x</b> & y") == "&lt;b&gt;x&lt;/b&gt; &amp; y"


def test_maintenance_health_and_backup(client, admin):
    r = client.get(f"{API}/maintenance/health", headers=admin)
    assert r.status_code == 200
    assert 0 <= r.json()["data"]["storage_used_pct"] <= 100
    r = client.post(f"{API}/maintenance/backup", headers=admin)
    if r.status_code == 503:
        pytest.skip("pg_dump tidak tersedia")
    assert r.status_code == 200, r.text
    fname = r.json()["data"]["filename"]
    r = client.get(f"{API}/system/backups/{fname}/download", headers=admin)
    assert r.status_code == 200 and r.content[:5] == b"PGDMP"
    assert client.get(f"{API}/system/backups/..%2F..%2Fetc%2Fpasswd/download", headers=admin).status_code in (400, 404)
    # Restore butuh konfirmasi.
    r = client.post(f"{API}/maintenance/restore", headers=admin, files={"file": ("x.dump", b"PGDMP")})
    assert r.status_code == 400
