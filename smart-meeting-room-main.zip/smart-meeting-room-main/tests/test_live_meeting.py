"""Denah kursi, pemetaan mic, penugasan kursi, state live meeting & presensi auto-kursi."""
from datetime import date, datetime, timedelta

import pytest

from tests.conftest import make_user

API = "/api/v1"


def _new_room(client, admin, code, capacity=20):
    r = client.post(f"{API}/rooms", headers=admin, json={"name": f"Ruang {code}", "code": code, "capacity": capacity})
    assert r.status_code == 200, r.text
    return r.json()["data"]


def _today_window():
    now = datetime.now()
    if now.hour >= 22 or now.hour < 1:
        pytest.skip("jam tidak cocok untuk uji rapat hari ini")
    start = (now - timedelta(minutes=10)).strftime("%H:%M:00")
    end = (now + timedelta(minutes=50)).strftime("%H:%M:00")
    return str(date.today()), start, end


def _booking(client, owner, admin, room, participants, date_=None, start=None, end=None, approve=True):
    if date_ is None:
        date_, start, end = _today_window()
    r = client.post(f"{API}/bookings", headers=owner["headers"], json={
        "room_id": room["id"], "title": "Rapat Live", "date": date_, "start_time": start, "end_time": end,
        "attendees": max(1, len(participants)), "participants": participants,
    })
    assert r.status_code == 200, r.text
    b = r.json()["data"]
    if approve:
        r = client.put(f"{API}/bookings/{b['id']}/approve", headers=admin, json={})
        assert r.status_code == 200, r.text
    return b


def _pair(client, admin, room):
    key = client.get(f"{API}/rooms/{room['id']}/pairing-key", headers=admin).json()["data"]["pairing_key"]
    r = client.post(f"{API}/door-display/pair", json={"room_code": room["code"], "pairing_key": key})
    assert r.status_code == 200, r.text
    return {"X-Kiosk-Token": r.json()["data"]["kiosk_token"]}


# ------------------------------------------------------------
# Denah kursi
# ------------------------------------------------------------

@pytest.mark.parametrize("layout", ["u_shape", "boardroom", "classroom", "circle"])
def test_generate_layouts(client, admin, layout):
    room = _new_room(client, admin, f"T-GEN-{layout[:5].upper()}")
    r = client.post(f"{API}/rooms/{room['id']}/seats/generate", headers=admin,
                    json={"layout": layout, "count": 16, "chair_count": 1, "link_channels": True})
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    seats = data["seats"]
    assert len(seats) == 16
    assert [s["seat_no"] for s in seats] == list(range(1, 17))
    assert seats[0]["seat_type"] == "chair"
    assert all(0 <= s["pos_x"] <= 100 and 0 <= s["pos_y"] <= 100 for s in seats)
    # Tidak ada dua kursi di posisi yang sama.
    assert len({(s["pos_x"], s["pos_y"]) for s in seats}) == 16
    # Kanal default dibuat & dipetakan kursi n -> Mic n.
    assert data["channels_created"] == 16
    assert seats[2]["channel"]["channel_no"] == 3
    assert seats[2]["channel"]["receiver_label"] == "M118-A CH3"
    assert seats[9]["channel"]["receiver_label"] == "M118-B CH2"
    assert data["layout"]["type"] == layout and data["layout"]["tables"]

    # Generate ulang dengan jumlah lain: kanal yang ada dipakai ulang (tidak dibuat lagi).
    r = client.post(f"{API}/rooms/{room['id']}/seats/generate", headers=admin,
                    json={"layout": layout, "count": 10, "chair_count": 2, "link_channels": True})
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    assert data["channels_created"] == 0 and len(data["seats"]) == 10
    assert [s["seat_type"] for s in data["seats"][:3]] == ["chair", "chair", "delegate"]
    assert len(data["audio_channels"]) == 16


def test_seat_crud_and_validation(client, admin, staff):
    room = _new_room(client, admin, "T-SEAT1")
    other = _new_room(client, admin, "T-SEAT2")
    gen = client.post(f"{API}/rooms/{room['id']}/seats/generate", headers=admin,
                      json={"layout": "boardroom", "count": 4, "link_channels": True}).json()["data"]
    other_ch = client.post(f"{API}/rooms/{other['id']}/seats/generate", headers=admin,
                           json={"layout": "circle", "count": 2, "link_channels": True}).json()["data"]["audio_channels"][0]
    seats = gen["seats"]
    ch = {c["channel_no"]: c for c in gen["audio_channels"]}

    # Baca: staf (rooms.view) boleh; tulis: hanya rooms.write.
    assert client.get(f"{API}/rooms/{room['id']}/seats", headers=staff["headers"]).status_code == 200
    assert client.put(f"{API}/rooms/{room['id']}/seats", headers=staff["headers"], json={"items": []}).status_code == 403
    assert client.post(f"{API}/rooms/{room['id']}/seats/generate", headers=staff["headers"],
                       json={"layout": "circle", "count": 4}).status_code == 403

    def item(s, **kw):
        base = {k: s[k] for k in ("id", "seat_no", "label", "seat_type", "pos_x", "pos_y", "rotation", "audio_channel_id")}
        base.update(kw)
        return base

    # Nomor kursi ganda -> 400.
    bad = [item(seats[0]), item(seats[1], seat_no=seats[0]["seat_no"])]
    r = client.put(f"{API}/rooms/{room['id']}/seats", headers=admin, json={"items": bad})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "DUPLICATE_SEAT_NO"
    # Kanal dipakai dua kursi -> 400.
    bad = [item(seats[0]), item(seats[1], audio_channel_id=seats[0]["audio_channel_id"])]
    r = client.put(f"{API}/rooms/{room['id']}/seats", headers=admin, json={"items": bad})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "DUPLICATE_CHANNEL"
    # Kanal ruangan lain -> 400.
    r = client.put(f"{API}/rooms/{room['id']}/seats", headers=admin,
                   json={"items": [item(seats[0], audio_channel_id=other_ch["id"])]})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "CHANNEL_NOT_IN_ROOM"
    # Posisi di luar 0..100 -> 422.
    r = client.put(f"{API}/rooms/{room['id']}/seats", headers=admin, json={"items": [item(seats[0], pos_x=120)]})
    assert r.status_code == 422

    # Tukar nomor & kanal kursi 1 <-> 2, hapus kursi 4, tambah kursi baru; id tetap stabil.
    items = [
        item(seats[0], seat_no=2, label="2", audio_channel_id=ch[2]["id"], pos_x=10.5),
        item(seats[1], seat_no=1, label="1", audio_channel_id=ch[1]["id"], seat_type="chair"),
        item(seats[2]),
        {"seat_no": 9, "label": "Notulis", "seat_type": "secretary", "pos_x": 95, "pos_y": 95, "rotation": 0},
    ]
    r = client.put(f"{API}/rooms/{room['id']}/seats", headers=admin, json={
        "items": items, "layout": {"type": "custom", "tables": [{"shape": "rect", "x": 20, "y": 30, "w": 60, "h": 40}]},
    })
    assert r.status_code == 200, r.text
    out = {s["seat_no"]: s for s in r.json()["data"]["seats"]}
    assert set(out) == {1, 2, 3, 9}
    assert out[2]["id"] == seats[0]["id"] and out[2]["channel"]["channel_no"] == 2 and out[2]["pos_x"] == 10.5
    assert out[1]["id"] == seats[1]["id"] and out[1]["seat_type"] == "chair"
    assert out[9]["audio_channel_id"] is None and out[9]["seat_type"] == "secretary"
    assert r.json()["data"]["layout"]["type"] == "custom"


# ------------------------------------------------------------
# Rapat: mulai / perpanjang / akhiri + penugasan kursi
# ------------------------------------------------------------

def test_meeting_lifecycle_and_seats(client, admin, staff, staff2):
    outsider = make_user(client, admin, "outsider_live", "User")
    room = _new_room(client, admin, "T-LIVE1")
    gen = client.post(f"{API}/rooms/{room['id']}/seats/generate", headers=admin,
                      json={"layout": "u_shape", "count": 6, "chair_count": 1, "link_channels": True}).json()["data"]
    seats = gen["seats"]
    b = _booking(client, staff, admin, room, [
        {"user_id": staff["id"], "is_guest": False},
        {"user_id": staff2["id"], "is_guest": False},
        {"is_guest": True, "guest_name": "Tamu Dinas", "guest_email": "tamu@example.com"},
    ])
    bid = b["id"]

    # Snapshot: pemilik & peserta boleh; nama peserta ternormalisasi.
    r = client.get(f"{API}/bookings/{bid}/live", headers=staff2["headers"])
    assert r.status_code == 200, r.text
    snap = r.json()["data"]
    assert snap["booking"]["meeting_status"] == "scheduled"
    assert snap["permissions"]["can_control"] is False
    names = sorted(p["name"] for p in snap["participants"])
    assert "Tamu Dinas" in names and "Staff1" in names
    assert len(snap["seats"]) == 6 and snap["seats"][0]["channel"]["label"] == "Mic 1"
    assert all("ticket_code" not in p for p in snap["participants"])

    # User lain tanpa hak kontrol -> 403.
    for path, body in [("meeting/start", None), ("meeting/extend", {"minutes": 15}), ("meeting/end", None)]:
        assert client.post(f"{API}/bookings/{bid}/{path}", headers=outsider["headers"], json=body).status_code == 403
    assert client.put(f"{API}/bookings/{bid}/seat-assignments", headers=staff2["headers"],
                      json={"items": []}).status_code == 403
    assert client.post(f"{API}/bookings/{bid}/seat-assignments/auto", headers=outsider["headers"],
                       json={}).status_code == 403

    # Akhiri sebelum mulai -> 409.
    assert client.post(f"{API}/bookings/{bid}/meeting/end", headers=staff["headers"]).status_code == 409
    r = client.post(f"{API}/bookings/{bid}/meeting/start", headers=staff["headers"])
    assert r.status_code == 200, r.text
    snap = r.json()["data"]
    assert snap["booking"]["meeting_status"] == "live" and snap["booking"]["actual_start_at"]
    # Mulai lagi -> idempoten.
    assert client.post(f"{API}/bookings/{bid}/meeting/start", headers=staff["headers"]).status_code == 200

    # Penugasan manual: validasi kursi & peserta.
    parts = {p["name"]: p for p in snap["participants"]}
    guest = parts["Tamu Dinas"]
    other_room_seat = client.post(
        f"{API}/rooms/{_new_room(client, admin, 'T-LIVE1X')['id']}/seats/generate", headers=admin,
        json={"layout": "circle", "count": 2, "link_channels": False}).json()["data"]["seats"][0]
    r = client.put(f"{API}/bookings/{bid}/seat-assignments", headers=staff["headers"],
                   json={"items": [{"seat_id": other_room_seat["id"], "participant_id": guest["id"]}]})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "SEAT_NOT_IN_ROOM"
    r = client.put(f"{API}/bookings/{bid}/seat-assignments", headers=staff["headers"],
                   json={"items": [{"seat_id": seats[1]["id"], "participant_id": seats[1]["id"]}]})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "PARTICIPANT_NOT_IN_BOOKING"
    r = client.put(f"{API}/bookings/{bid}/seat-assignments", headers=staff["headers"], json={"items": [
        {"seat_id": seats[1]["id"], "participant_id": guest["id"]},
        {"seat_id": seats[2]["id"], "participant_id": guest["id"]},
    ]})
    assert r.status_code == 400 and r.json()["detail"]["code"] == "DUPLICATE_PARTICIPANT"

    r = client.put(f"{API}/bookings/{bid}/seat-assignments", headers=staff["headers"], json={"items": [
        {"seat_id": seats[5]["id"], "participant_id": guest["id"], "role_label": "Narasumber"},
        {"seat_id": seats[4]["id"], "display_name": "Operator AV"},
    ]})
    assert r.status_code == 200, r.text
    items = {i["seat_id"]: i for i in r.json()["data"]["items"]}
    assert items[seats[5]["id"]]["name"] == "Tamu Dinas"
    assert items[seats[4]["id"]]["name"] == "Operator AV"
    # Pindahkan tamu ke kursi lain -> kursi lama otomatis kosong.
    r = client.put(f"{API}/bookings/{bid}/seat-assignments", headers=staff["headers"],
                   json={"items": [{"seat_id": seats[3]["id"], "participant_id": guest["id"]}]})
    items = {i["seat_id"]: i for i in r.json()["data"]["items"]}
    assert seats[5]["id"] not in items and items[seats[3]["id"]]["participant_id"] == guest["id"]
    # Kosongkan kursi.
    r = client.put(f"{API}/bookings/{bid}/seat-assignments", headers=staff["headers"],
                   json={"items": [{"seat_id": seats[4]["id"]}]})
    assert seats[4]["id"] not in {i["seat_id"] for i in r.json()["data"]["items"]}

    # Isi otomatis: pemilik (peserta) -> kursi pimpinan.
    r = client.post(f"{API}/bookings/{bid}/seat-assignments/auto", headers=staff["headers"], json={"strategy": "all"})
    assert r.status_code == 200, r.text
    assert r.json()["data"]["assigned"] == 2
    items = {i["seat_id"]: i for i in r.json()["data"]["items"]}
    assert items[seats[0]["id"]]["name"] == "Staff1"  # kursi 1 = chair
    snap = client.get(f"{API}/bookings/{bid}/live", headers=staff["headers"]).json()["data"]
    assert all(p["seat"] for p in snap["participants"])

    # Kursi sedang dipakai rapat live -> tidak boleh dihapus / denah dibuat ulang.
    r = client.put(f"{API}/rooms/{room['id']}/seats", headers=admin, json={"items": []})
    assert r.status_code == 409
    r = client.post(f"{API}/rooms/{room['id']}/seats/generate", headers=admin, json={"layout": "circle", "count": 4})
    assert r.status_code == 409

    # Perpanjang: bentrok dengan booking berikutnya -> 409, tanpa bentrok -> OK.
    snap_end = datetime.strptime(snap["booking"]["end_time"], "%H:%M:%S")
    nxt_start = snap_end + timedelta(minutes=20)
    if nxt_start.date() == snap_end.date() and nxt_start.hour < 23:
        _booking(client, staff2, admin, room, [], date_=str(date.today()),
                 start=nxt_start.strftime("%H:%M:00"), end=(nxt_start + timedelta(minutes=30)).strftime("%H:%M:00"),
                 approve=False)
        r = client.post(f"{API}/bookings/{bid}/meeting/extend", headers=staff["headers"], json={"minutes": 30})
        assert r.status_code == 409 and r.json()["detail"]["code"] == "SCHEDULE_CONFLICT"
    assert client.post(f"{API}/bookings/{bid}/meeting/extend", headers=staff["headers"],
                       json={"minutes": 200}).status_code == 422
    r = client.post(f"{API}/bookings/{bid}/meeting/extend", headers=admin, json={"minutes": 15})
    assert r.status_code == 200, r.text
    snap = r.json()["data"]
    assert snap["booking"]["extended_minutes"] == 15
    assert (datetime.strptime(snap["booking"]["end_time"], "%H:%M:%S") - snap_end) == timedelta(minutes=15)

    # Akhiri: rekaman aktif ikut dihentikan (baris DB), booking selesai.
    import asyncio

    import asyncpg

    from tests.conftest import _admin_dsn, TEST_DB

    async def _add_recording():
        conn = await asyncpg.connect(_admin_dsn(TEST_DB))
        try:
            await conn.execute("INSERT INTO meeting_recordings (booking_id, status) VALUES ($1, 'recording')", bid)
            return await conn.fetchval("SELECT count(*) FROM meeting_recordings WHERE booking_id=$1 AND status='stopped'", bid)
        finally:
            await conn.close()

    asyncio.run(_add_recording())
    assert client.get(f"{API}/bookings/{bid}/live", headers=staff["headers"]).json()["data"]["recording"]["status"] == "recording"
    r = client.post(f"{API}/bookings/{bid}/meeting/end", headers=staff["headers"])
    assert r.status_code == 200, r.text
    snap = r.json()["data"]
    assert snap["booking"]["meeting_status"] == "ended" and snap["booking"]["status"] == "completed"
    assert snap["recording"] is None
    assert client.post(f"{API}/bookings/{bid}/meeting/start", headers=staff["headers"]).status_code == 409
    assert client.post(f"{API}/bookings/{bid}/meeting/extend", headers=staff["headers"],
                       json={"minutes": 15}).status_code == 409


def test_meeting_start_rules(client, admin, staff):
    room = _new_room(client, admin, "T-LIVE2")
    # Belum disetujui -> 400.
    b = _booking(client, staff, admin, room, [], approve=False)
    r = client.post(f"{API}/bookings/{b['id']}/meeting/start", headers=staff["headers"])
    assert r.status_code == 400 and r.json()["detail"]["code"] == "NOT_APPROVED"
    # Bukan hari ini -> 400.
    d = str(date.today() + timedelta(days=3))
    b2 = _booking(client, staff, admin, room, [], date_=d, start="09:00:00", end="10:00:00")
    r = client.post(f"{API}/bookings/{b2['id']}/meeting/start", headers=staff["headers"])
    assert r.status_code == 400 and r.json()["detail"]["code"] == "NOT_TODAY"
    assert client.get(f"{API}/bookings/{b2['id']}/live", headers=staff["headers"]).status_code == 200
    assert client.get(f"{API}/bookings/00000000-0000-0000-0000-000000000000/live", headers=admin).status_code == 404


# ------------------------------------------------------------
# Presensi -> kursi otomatis
# ------------------------------------------------------------

def test_scan_auto_assigns_seat(client, admin, staff, staff2):
    room = _new_room(client, admin, "T-LIVE3")
    gen = client.post(f"{API}/rooms/{room['id']}/seats/generate", headers=admin,
                      json={"layout": "boardroom", "count": 4, "chair_count": 1, "link_channels": False}).json()["data"]
    seats = gen["seats"]
    # Kursi 2 dijadikan notulis -> tidak boleh diisi otomatis.
    items = [{k: s[k] for k in ("id", "seat_no", "label", "seat_type", "pos_x", "pos_y", "rotation")} for s in seats]
    items[1]["seat_type"] = "secretary"
    assert client.put(f"{API}/rooms/{room['id']}/seats", headers=admin, json={"items": items}).status_code == 200

    b = _booking(client, staff, admin, room, [
        {"user_id": staff2["id"], "is_guest": False},
        {"is_guest": True, "guest_name": "Tamu A", "guest_email": "a@example.com"},
    ])
    tickets = {p["user_id"] or p["guest_name"]: p["ticket_code"] for p in b["participants"]}
    kh = _pair(client, admin, room)

    r = client.post(f"{API}/presensi/scan", headers=kh, json={"code": tickets[staff2["id"]], "room_code": room["code"]})
    assert r.status_code == 200, r.text
    seat = r.json()["data"]["seat"]
    assert seat == {"seat_id": seats[2]["id"], "seat_no": 3, "label": "3"}  # delegate pertama (bukan chair/secretary)

    # Scan ulang -> kursi yang sama.
    r = client.post(f"{API}/presensi/scan", headers=kh, json={"code": tickets[staff2["id"]], "room_code": room["code"]})
    assert r.json()["data"]["already_checked_in"] is True and r.json()["data"]["seat"]["seat_no"] == 3

    r = client.post(f"{API}/presensi/scan", headers=kh, json={"code": tickets["Tamu A"], "room_code": room["code"]})
    assert r.json()["data"]["seat"]["seat_no"] == 4

    snap = client.get(f"{API}/bookings/{b['id']}/live", headers=staff["headers"]).json()["data"]
    assert snap["attendance"] == {"attended": 2, "total": 2}
    via = {s["seat_no"]: s["assignment"] and s["assignment"]["assigned_via"] for s in snap["seats"]}
    assert via == {1: None, 2: None, 3: "checkin", 4: "checkin"}


def test_scan_without_seats_has_no_seat(client, admin, staff, staff2):
    room = _new_room(client, admin, "T-LIVE4")
    b = _booking(client, staff, admin, room, [{"user_id": staff2["id"], "is_guest": False}])
    kh = _pair(client, admin, room)
    r = client.post(f"{API}/presensi/scan", headers=kh,
                    json={"code": b["participants"][0]["ticket_code"], "room_code": room["code"]})
    assert r.status_code == 200, r.text
    assert r.json()["data"]["seat"] is None


def test_live_hub_events(client, admin, staff, staff2, monkeypatch):
    """Event WebSocket live dikirim lewat live_hub (modul IoT) bila tersedia."""
    from src.api.routers import live_meeting

    calls = []

    class FakeHub:
        async def broadcast(self, room_id, event, data):
            calls.append((room_id, event, data))

        def invalidate_room(self, room_id):
            calls.append((room_id, "invalidate", None))

    monkeypatch.setattr(live_meeting, "live_hub", FakeHub())
    room = _new_room(client, admin, "T-LIVE5")
    client.post(f"{API}/rooms/{room['id']}/seats/generate", headers=admin,
                json={"layout": "circle", "count": 3, "chair_count": 0, "link_channels": False})
    b = _booking(client, staff, admin, room, [{"user_id": staff2["id"], "is_guest": False}])
    kh = _pair(client, admin, room)
    calls.clear()
    client.post(f"{API}/presensi/scan", headers=kh, json={"code": b["participants"][0]["ticket_code"]})
    ev = [c for c in calls if c[1] == "attendance_changed"]
    assert ev and ev[0][0] == room["id"] and ev[0][2]["seat"]["seat_no"] == 1
    client.post(f"{API}/bookings/{b['id']}/meeting/start", headers=staff["headers"])
    assert any(c[1] == "meeting_status" and c[2]["meeting_status"] == "live" for c in calls)
    client.post(f"{API}/bookings/{b['id']}/seat-assignments/auto", headers=staff["headers"], json={})
    assert any(c[1] == "seats_changed" for c in calls)
